#include "JLIB.H"
#include "DRIVER.H"
#include "SWD.H"


static CONST UINT PgmBlob[] = //404Byte (0x194)
    {
    0xE00ABE00, 0x062D780D, 0x24084068, 0xD3000040, 0x1E644058, 0x1C49D1FA, 0x2A001E52, 0x4770D1F2,
    0x4603b510, 0x69804851, 0x0224240f, 0x4c4f4320, 0x484f61a0, 0x484f60e0, 0x484f60e0, 0x484f6120,
    0x46206120, 0x240169c0, 0x40200524, 0xd1062800, 0x4c4c484b, 0x20066020, 0x484b6060, 0x200060a0,
    0x4601bd10, 0x68404841, 0x43102202, 0x60504a3f, 0x68404610, 0x43102201, 0x60504a3c, 0x47702000,
    0x483a4601, 0x22016840, 0x43100252, 0x60504a37, 0x68404610, 0x43102208, 0x60504a34, 0x60082000,
    0x483ae002, 0x60104a37, 0x69804830, 0x0fc007c0, 0xd1f62800, 0x6840482d, 0x02522201, 0x4a2b4390,
    0x46106050, 0x22086840, 0x4a284390, 0x20006050, 0x46034770, 0x47702001, 0x4603b570, 0x303f4608,
    0x01890981, 0xe03b2500, 0x68404820, 0x02b62601, 0x4e1e4330, 0x46306070, 0x26086840, 0x4e1b4330,
    0x24406070, 0x6810e004, 0x1d1b6018, 0x1f241d12, 0xd1f82c00, 0x481de002, 0x60304e1a, 0x69804813,
    0x0fc007c0, 0xd1f62800, 0x69804810, 0x0236260f, 0x28004030, 0x480dd006, 0x43306980, 0x61b04e0b,
    0xbd702001, 0x68404809, 0x02b62601, 0x4e0743b0, 0x46306070, 0x26086840, 0x4e0443b0, 0x1c6d6070,
    0x42a80988, 0x2000d8c0, 0x0000e7eb, 0x40022000, 0x89abcdef, 0x02030405, 0x8c9daebf, 0x13141516,
    0x00005555, 0x40003000, 0x00000fff, 0x0000aaaa, 0x00000000
    };


static CONST SECTOR_INFO_T SectorsInfo[] =
    {
    {0x08000000, 0x00000080},
    };

static PROGRAM_TARGET_T TargetPgm =
    {
    0x20000021, //Init
    0x20000063, //UnInit
    0,          //EraseChip - NOT SUPPORTED
    0x20000081, //EraseSector
    0x200000d9, //ProgramPage
    0,          //Verify
    0,          //InitMcu
    0,          //GetCRC32

    {
    0x20000001, //BKPT: start of blob + 1
    0x20000190, //RSB: blob start + header + rw data offset
    0x20000800  //RSP: stack pointer
    },

    0x20000000+0x00000A00,  //mem buffer location
    0x20000000,             //location to write prog_blob in target RAM
    sizeof(PgmBlob),        //prog_blob size
    PgmBlob,                //address of prog_blob
    0x00000080              //ram_to_flash_bytes_to_be_written
    };




static CONST TARGET_CFG_T TargetDevice =
    {
    .SectorsInfo                = SectorsInfo,
    .SectorInfoLen              = countof(SectorsInfo),
    .FlashRegions[0].Start      = 0x08000000,
    .FlashRegions[0].End        = 0x08030000,
    .FlashRegions[0].Flags      = kRegionIsDefault,
    .FlashRegions[0].FlashAlgo  = &TargetPgm,
    .RamRegions[0].Start        = 0x20000000,
    .RamRegions[0].End          = 0x20005000,
    .RtBoardId                  = "STM32L082xZ"
    };



VOID WINAPI STM32L082xZ_InitTarget(VOID)
    {
    AddTargetDevice(&TargetDevice);
    }

