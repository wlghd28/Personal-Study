///////////////////////////////////////////////////////////////////////////////
//          USB Storage (USB MSC)�� JFAT ��� ������ ����̹���
//
//                  FMC(Flexible Memory controller)
///////////////////////////////////////////////////////////////////////////////


#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"



///////////////////////////////////////////////////////////////////////////////
//                  STM32F7xx_ll_sdmmc.c
///////////////////////////////////////////////////////////////////////////////


//__HAL_SD_GET_FLAG()   => SDInst->STA &
//__HAL_SD_CLEAR_FLAG() => SDInst->ICR=
//__SDMMC_CLEAR_FLAG()  => SDInst->ICR=
//__HAL_SD_ENABLE_IT()  => SDInst->MASK|=
//__HAL_SD_DISABLE_IT() => SDInst->MASK&=~



LOCAL(VOID) SD_SendCommand(SD_TypeDef *SDInst, UINT Arg, UINT Cmd)
    {
    SDInst->ARG=Arg;
    SDInst->CMD=(SDInst->CMD & ~CMD_CLEAR_MASK) | Cmd;
    }


LOCAL(UINT) SD_GetCommandResponse(SD_TypeDef *SDInst)
    {
    return SDInst->RESPCMD & 0xFF;
    }


LOCAL(BOOL) SD_WaitStatusFlag(SD_TypeDef *SDInst, UINT Flag)
    {
    UINT Cnt=(SystemCoreClock/8/1000)*SDMMC_CMDTIMEOUT;

    while ((SDInst->STA & Flag)==0)
        {
        if (Cnt--==0) return FALSE;
        }
    return TRUE;
    }


LOCAL(UINT) SD_GetCmdResp1(SD_TypeDef *SDInst, UINT SD_Cmd, UINT Timeout)
    {
    UINT R1;

    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CCRCFAIL|SDMMC_FLAG_CMDREND|SDMMC_FLAG_CTIMEOUT)==FALSE) return SDMMC_ERROR_TIMEOUT;

    if (SDInst->STA & SDMMC_FLAG_CTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_CTIMEOUT;
        return SDMMC_ERROR_CMD_RSP_TIMEOUT;
        }
    else if (SDInst->STA & SDMMC_FLAG_CCRCFAIL)
        {
        SDInst->ICR=SDMMC_FLAG_CCRCFAIL;
        return SDMMC_ERROR_CMD_CRC_FAIL;
        }

    if (SD_GetCommandResponse(SDInst)!=SD_Cmd) return SDMMC_ERROR_CMD_CRC_FAIL;

    SDInst->ICR=SDMMC_STATIC_FLAGS;

    R1=SDInst->RESP1;
    if ((R1 & SDMMC_OCR_ERRORBITS)==0)              return SDMMC_ERROR_NONE;
    else if (R1 & SDMMC_OCR_ADDR_OUT_OF_RANGE)      return SDMMC_ERROR_ADDR_OUT_OF_RANGE;
    else if (R1 & SDMMC_OCR_ADDR_MISALIGNED)        return SDMMC_ERROR_ADDR_MISALIGNED;
    else if (R1 & SDMMC_OCR_BLOCK_LEN_ERR)          return SDMMC_ERROR_BLOCK_LEN_ERR;
    else if (R1 & SDMMC_OCR_ERASE_SEQ_ERR)          return SDMMC_ERROR_ERASE_SEQ_ERR;
    else if (R1 & SDMMC_OCR_BAD_ERASE_PARAM)        return SDMMC_ERROR_BAD_ERASE_PARAM;
    else if (R1 & SDMMC_OCR_WRITE_PROT_VIOLATION)   return SDMMC_ERROR_WRITE_PROT_VIOLATION;
    else if (R1 & SDMMC_OCR_LOCK_UNLOCK_FAILED)     return SDMMC_ERROR_LOCK_UNLOCK_FAILED;
    else if (R1 & SDMMC_OCR_COM_CRC_FAILED)         return SDMMC_ERROR_COM_CRC_FAILED;
    else if (R1 & SDMMC_OCR_ILLEGAL_CMD)            return SDMMC_ERROR_ILLEGAL_CMD;
    else if (R1 & SDMMC_OCR_CARD_ECC_FAILED)        return SDMMC_ERROR_CARD_ECC_FAILED;
    else if (R1 & SDMMC_OCR_CC_ERROR)               return SDMMC_ERROR_CC_ERR;
    else if (R1 & SDMMC_OCR_STREAM_READ_UNDERRUN)   return SDMMC_ERROR_STREAM_READ_UNDERRUN;
    else if (R1 & SDMMC_OCR_STREAM_WRITE_OVERRUN)   return SDMMC_ERROR_STREAM_WRITE_OVERRUN;
    else if (R1 & SDMMC_OCR_CID_CSD_OVERWRITE)      return SDMMC_ERROR_CID_CSD_OVERWRITE;
    else if (R1 & SDMMC_OCR_WP_ERASE_SKIP)          return SDMMC_ERROR_WP_ERASE_SKIP;
    else if (R1 & SDMMC_OCR_CARD_ECC_DISABLED)      return SDMMC_ERROR_CARD_ECC_DISABLED;
    else if (R1 & SDMMC_OCR_ERASE_RESET)            return SDMMC_ERROR_ERASE_RESET;
    else if (R1 & SDMMC_OCR_AKE_SEQ_ERROR)          return SDMMC_ERROR_AKE_SEQ_ERR;
    return SDMMC_ERROR_GENERAL_UNKNOWN_ERR;
    }


LOCAL(UINT) SD_GetCmdResp2(SD_TypeDef *SDInst)
    {
    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CCRCFAIL|SDMMC_FLAG_CMDREND|SDMMC_FLAG_CTIMEOUT)==FALSE) return SDMMC_ERROR_TIMEOUT;

    if (SDInst->STA & SDMMC_FLAG_CTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_CTIMEOUT;
        return SDMMC_ERROR_CMD_RSP_TIMEOUT;
        }

    if (SDInst->STA & SDMMC_FLAG_CCRCFAIL)
        {
        SDInst->ICR=SDMMC_FLAG_CCRCFAIL;
        return SDMMC_ERROR_CMD_CRC_FAIL;
        }

    SDInst->ICR=SDMMC_STATIC_FLAGS;
    return SDMMC_ERROR_NONE;
    }




LOCAL(UINT) SD_CmdReadMultiBlock(SD_TypeDef *SDInst, UINT ReadAdd)
    {
    SD_SendCommand(SDInst, ReadAdd, SDMMC_CMD_READ_MULT_BLOCK|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_READ_MULT_BLOCK, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdReadSingleBlock(SD_TypeDef *SDInst, UINT ReadAdd)
    {
    SD_SendCommand(SDInst, ReadAdd, SDMMC_CMD_READ_SINGLE_BLOCK|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_READ_SINGLE_BLOCK, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdWriteSingleBlock(SD_TypeDef *SDInst, UINT WriteAdd)
    {
    SD_SendCommand(SDInst, WriteAdd, SDMMC_CMD_WRITE_SINGLE_BLOCK|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_WRITE_SINGLE_BLOCK, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdWriteMultiBlock(SD_TypeDef *SDInst, UINT WriteAdd)
    {
    SD_SendCommand(SDInst, WriteAdd, SDMMC_CMD_WRITE_MULT_BLOCK|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_WRITE_MULT_BLOCK, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdStopTransfer(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_STOP_TRANSMISSION|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_STOP_TRANSMISSION, 100000000);
    }



LOCAL(UINT) SD_CmdBlockLength(SD_TypeDef *SDInst, UINT BlockSize)
    {
    SD_SendCommand(SDInst, BlockSize, SDMMC_CMD_SET_BLOCKLEN|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SET_BLOCKLEN, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdAppCommand(SD_TypeDef *SDInst, UINT Arg)
    {
    SD_SendCommand(SDInst, Arg, SDMMC_CMD_APP_CMD|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_APP_CMD, SDMMC_CMDTIMEOUT);
    }



LOCAL(UINT) SD_CmdBusWidth(SD_TypeDef *SDInst, UINT BusWidth)
    {
    SD_SendCommand(SDInst, BusWidth, SDMMC_CMD_APP_SD_SET_BUSWIDTH|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_APP_SD_SET_BUSWIDTH, SDMMC_CMDTIMEOUT);
    }


LOCAL(UINT) SD_CmdSendStatus(SD_TypeDef *SDInst, UINT Arg)
    {
    SD_SendCommand(SDInst, Arg, SDMMC_CMD_SEND_STATUS|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SEND_STATUS, SDMMC_CMDTIMEOUT);
    }


LOCAL(UINT) SD_CmdSendCSD(SD_TypeDef *SDInst, UINT Arg)
    {
    SD_SendCommand(SDInst, Arg, SDMMC_CMD_SEND_CSD|SDMMC_RESPONSE_LONG|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp2(SDInst);
    }


LOCAL(UINT) SD_CmdSendCID(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_ALL_SEND_CID|SDMMC_RESPONSE_LONG|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp2(SDInst);
    }


LOCAL(UINT) SD_CmdSelDesel(SD_TypeDef *SDInst, UINT64 Addr)
    {
    SD_SendCommand(SDInst, Addr, SDMMC_CMD_SEL_DESEL_CARD|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SEL_DESEL_CARD, SDMMC_CMDTIMEOUT);
    }


LOCAL(UINT) SD_CmdSendSCR(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_SD_APP_SEND_SCR|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SD_APP_SEND_SCR, SDMMC_CMDTIMEOUT);
    }


#if 0
LOCAL(UINT) SD_CmdSDEraseStartAdd(SD_TypeDef *SDInst, UINT StartAdd)
    {
    SD_SendCommand(SDInst, StartAdd, SDMMC_CMD_SD_ERASE_GRP_START|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SD_ERASE_GRP_START, SDMMC_CMDTIMEOUT);
    }


LOCAL(UINT) SD_CmdSDEraseEndAdd(SD_TypeDef *SDInst, UINT EndAdd)
    {
    SD_SendCommand(SDInst, EndAdd, SDMMC_CMD_SD_ERASE_GRP_END|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SD_ERASE_GRP_END, SDMMC_CMDTIMEOUT);
    }


LOCAL(UINT) SD_CmdErase(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_ERASE|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_ERASE, SDMMC_MAXERASETIMEOUT);
    }


LOCAL(UINT) SD_CmdStatusRegister(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_SD_APP_STATUS|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);
    return SD_GetCmdResp1(SDInst, SDMMC_CMD_SD_APP_STATUS, SDMMC_CMDTIMEOUT);
    }
#endif


LOCAL(UINT) SD_CmdGoIdleState(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, 0, SDMMC_CMD_GO_IDLE_STATE|SDMMC_RESPONSE_NO|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);

    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CMDSENT)==FALSE) return SDMMC_ERROR_TIMEOUT;
    SDInst->ICR=SDMMC_STATIC_FLAGS;
    return SDMMC_ERROR_NONE;
    }


LOCAL(UINT) SD_CmdAppOperCommand(SD_TypeDef *SDInst, UINT SdType)
    {
    SD_SendCommand(SDInst, SDMMC_VOLTAGE_WINDOW_SD|SdType, SDMMC_CMD_SD_APP_OP_COND|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);

    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CCRCFAIL|SDMMC_FLAG_CMDREND|SDMMC_FLAG_CTIMEOUT)==FALSE) return SDMMC_ERROR_TIMEOUT;

    if (SDInst->STA & SDMMC_FLAG_CTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_CTIMEOUT;
        return SDMMC_ERROR_CMD_RSP_TIMEOUT;
        }
    SDInst->ICR=SDMMC_STATIC_FLAGS;
    return SDMMC_ERROR_NONE;
    }



LOCAL(UINT) SD_CmdOperCond(SD_TypeDef *SDInst)
    {
    SD_SendCommand(SDInst, SDMMC_CHECK_PATTERN, SDMMC_CMD_HS_SEND_EXT_CSD|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);

    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CCRCFAIL|SDMMC_FLAG_CMDREND|SDMMC_FLAG_CTIMEOUT)==FALSE) return SDMMC_ERROR_TIMEOUT;

    if (SDInst->STA & SDMMC_FLAG_CTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_CMDREND;
        return SDMMC_ERROR_CMD_RSP_TIMEOUT;
        }

    if (SDInst->STA & SDMMC_FLAG_CMDREND) SDInst->ICR=SDMMC_FLAG_CMDREND;
    return SDMMC_ERROR_NONE;
    }


LOCAL(UINT) SD_CmdSetRelAdd(SD_TypeDef *SDInst, UINT *lpRCA)
    {
    UINT R1;

    SD_SendCommand(SDInst, 0, SDMMC_CMD_SET_REL_ADDR|SDMMC_RESPONSE_SHORT|SDMMC_WAIT_NO|SDMMC_CPSM_ENABLE);

    //SDMMC_GetCmdResp6(SDInst, SDMMC_CMD_SET_REL_ADDR, lpRCA);
    if (SD_WaitStatusFlag(SDInst, SDMMC_FLAG_CCRCFAIL|SDMMC_FLAG_CMDREND|SDMMC_FLAG_CTIMEOUT)==FALSE) return SDMMC_ERROR_TIMEOUT;

    if (SDInst->STA & SDMMC_FLAG_CTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_CTIMEOUT;
        return SDMMC_ERROR_CMD_RSP_TIMEOUT;
        }

    if (SDInst->STA & SDMMC_FLAG_CCRCFAIL)
        {
        SDInst->ICR=SDMMC_FLAG_CCRCFAIL;
        return SDMMC_ERROR_CMD_CRC_FAIL;
        }

    if (SD_GetCommandResponse(SDInst)!=SDMMC_CMD_SET_REL_ADDR) return SDMMC_ERROR_CMD_CRC_FAIL;

    SDInst->ICR=SDMMC_STATIC_FLAGS;

    R1=SDInst->RESP1;
    if ((R1 & (SDMMC_R6_GENERAL_UNKNOWN_ERROR|SDMMC_R6_ILLEGAL_CMD|SDMMC_R6_COM_CRC_FAILED))==0)
        {
        *lpRCA=R1>>16;
        return SDMMC_ERROR_NONE;
        }
    if (R1 & SDMMC_R6_ILLEGAL_CMD) return SDMMC_ERROR_ILLEGAL_CMD;
    if (R1 & SDMMC_R6_COM_CRC_FAILED) return SDMMC_ERROR_COM_CRC_FAILED;
    return SDMMC_ERROR_GENERAL_UNKNOWN_ERR;
    }



//�����Լ��� SDMMC_Init()
LOCAL(VOID) SD_InitClk(SD_TypeDef *SDInst, UINT InitData)
    {
    SDInst->CLKCR=(SDInst->CLKCR & ~CLKCR_CLEAR_MASK) | InitData;
    }



//�����Լ��� SDMMC_ConfigData()
LOCAL(VOID) SD_ConfigData(SD_TypeDef *SDInst, UINT DataTimeOut, UINT DataLength, UINT Ctrl)
    {
    SDInst->DTIMER=DataTimeOut;
    SDInst->DLEN=DataLength;
    SDInst->DCTRL=(SDInst->DCTRL & ~DCTRL_CLEAR_MASK) | Ctrl;
    }




///////////////////////////////////////////////////////////////////////////////
//              STM32F7xx_hal_sd.c
///////////////////////////////////////////////////////////////////////////////




LOCAL(UINT) SD_FindSCR(SD_HandleTypeDef *hSD, UINT *lpSCR)
    {
    UINT Rslt, Index, T[2], StartTick;
    SD_TypeDef *SDInst;

    StartTick=HAL_GetTick();
    T[0]=T[1]=lpSCR[0]=lpSCR[1]=Index=0;

    SDInst=hSD->Instance;
    if ((Rslt=SD_CmdBlockLength(SDInst, 8))!=HAL_OK) goto ProcExit;
    if ((Rslt=SD_CmdAppCommand(SDInst, hSD->SdCard.RelCardAdd<<16))!=HAL_OK) goto ProcExit;

    SD_ConfigData(SDInst, SDMMC_DATATIMEOUT, 8, SDMMC_DATABLOCK_SIZE_8B|SDMMC_TRANSFER_DIR_TO_SDMMC|SDMMC_TRANSFER_MODE_BLOCK|SDMMC_DPSM_ENABLE);

    if ((Rslt=SD_CmdSendSCR(SDInst))!=HAL_OK) goto ProcExit;

    while ((SDInst->STA & (SDMMC_FLAG_RXOVERR|SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_DBCKEND))==0)
        {
        if (SDInst->STA & SDMMC_FLAG_RXDAVL)
            {
            *(T+Index)=SDInst->FIFO;
            Index++;
            }
        if (HAL_GetTick()-StartTick>=SDMMC_DATATIMEOUT) {Rslt=HAL_SD_ERROR_TIMEOUT; goto ProcExit;}
        }

    if (SDInst->STA & SDMMC_FLAG_DTIMEOUT)
        {
        SDInst->ICR=SDMMC_FLAG_DTIMEOUT;
        Rslt=HAL_SD_ERROR_DATA_TIMEOUT;
        goto ProcExit;
        }

    if (SDInst->STA & SDMMC_FLAG_DCRCFAIL)
        {
        SDInst->ICR=SDMMC_FLAG_DCRCFAIL;
        Rslt=HAL_SD_ERROR_DATA_CRC_FAIL;
        goto ProcExit;
        }

    if (SDInst->STA & SDMMC_FLAG_RXOVERR)
        {
        SDInst->ICR=SDMMC_FLAG_RXOVERR;
        Rslt=HAL_SD_ERROR_RX_OVERRUN;
        goto ProcExit;
        }

    SDInst->ICR=SDMMC_STATIC_FLAGS;

    lpSCR[1]=(T[0]<<24) | ((T[0]&0xFF00)<<8) | ((T[0]>>8)&0xFF00) | (T[0]>>24);
    lpSCR[0]=(T[1]<<24) | ((T[1]&0xFF00)<<8) | ((T[1]>>8)&0xFF00) | (T[1]>>24);
    Rslt=HAL_SD_ERROR_NONE;

    ProcExit:
    return Rslt;
    }




LOCAL(UINT) SD_WideBus_Enable(SD_HandleTypeDef *hSD)
    {
    UINT Rslt, Scr[2];
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (SDInst->RESP1 & SDMMC_CARD_LOCKED) {Rslt=HAL_SD_ERROR_LOCK_UNLOCK_FAILED; goto ProcExit;}
    if ((Rslt=SD_FindSCR(hSD, Scr))!=HAL_OK) goto ProcExit;
    if ((Scr[1] & SDMMC_WIDE_BUS_SUPPORT)==0) {Rslt=HAL_SD_ERROR_REQUEST_NOT_APPLICABLE; goto ProcExit;}
    if ((Rslt=SD_CmdAppCommand(SDInst, hSD->SdCard.RelCardAdd<<16))!=HAL_OK) goto ProcExit;
    if ((Rslt=SD_CmdBusWidth(SDInst, 2))!=HAL_OK) goto ProcExit;    //2: Wide bus mode
    Rslt=HAL_SD_ERROR_NONE;

    ProcExit:
    return Rslt;
    }



LOCAL(UINT) SD_WideBus_Disable(SD_HandleTypeDef *hSD)
    {
    UINT Rslt, Scr[2];
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (SDInst->RESP1 & SDMMC_CARD_LOCKED) {Rslt=HAL_SD_ERROR_LOCK_UNLOCK_FAILED; goto ProcExit;}
    if ((Rslt=SD_FindSCR(hSD, Scr))!=HAL_OK) goto ProcExit;
    if ((Scr[1] & SDMMC_SINGLE_BUS_SUPPORT)==0) {Rslt=HAL_SD_ERROR_REQUEST_NOT_APPLICABLE; goto ProcExit;}
    if ((Rslt=SD_CmdAppCommand(SDInst, hSD->SdCard.RelCardAdd<<16))!=HAL_OK) goto ProcExit;
    if ((Rslt=SD_CmdBusWidth(SDInst, 0))!=HAL_OK) goto ProcExit;    //0: Single bus mode
    Rslt=HAL_SD_ERROR_NONE;

    ProcExit:
    return Rslt;
    }




HAL_StatusTypeDef HAL_SD_ConfigWideBusOperation(SD_HandleTypeDef *hSD, UINT WideMode)
    {
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    hSD->State=HAL_SD_STATE_BUSY;

    if (hSD->SdCard.CardType!=CARD_SECURED)
        {
        if (WideMode==SDMMC_BUS_WIDE_8B)        hSD->ErrorCode|=HAL_SD_ERROR_UNSUPPORTED_FEATURE;
        else if (WideMode==SDMMC_BUS_WIDE_4B)   hSD->ErrorCode|=SD_WideBus_Enable(hSD);
        else if (WideMode==SDMMC_BUS_WIDE_1B)   hSD->ErrorCode|=SD_WideBus_Disable(hSD);
        else                                    hSD->ErrorCode|=HAL_SD_ERROR_PARAM;
        }
    else hSD->ErrorCode|=HAL_SD_ERROR_UNSUPPORTED_FEATURE;

    if (hSD->ErrorCode!=HAL_SD_ERROR_NONE)
        {
        SDInst->ICR=SDMMC_STATIC_FLAGS;
        goto ProcExit;
        }

    SD_InitClk(SDInst, hSD->Init.ClockEdge|
                       hSD->Init.ClockBypass|
                       hSD->Init.ClockPowerSave|
                       WideMode|
                       hSD->Init.HardwareFlowControl|
                       hSD->Init.ClockDiv);
    Rslt=HAL_OK;

    ProcExit:
    hSD->State=HAL_SD_STATE_READY;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      HAL_SD_GetCardInfo()
//-----------------------------------------------------------------------------
VOID WINAPI SD_GetCardInfo(SD_HandleTypeDef *hSD, HAL_SD_CardInfoTypeDef*CI)
    {
    CI->CardType=    hSD->SdCard.CardType;
    CI->CardVersion= hSD->SdCard.CardVersion;
    CI->Class=       hSD->SdCard.Class;
    CI->RelCardAdd=  hSD->SdCard.RelCardAdd;
    CI->BlockNbr=    hSD->SdCard.BlockNbr;
    CI->BlockSize=   hSD->SdCard.BlockSize;
    CI->LogBlockNbr= hSD->SdCard.LogBlockNbr;       //�Ѽ��ͼ�
    CI->LogBlockSize=hSD->SdCard.LogBlockSize;      //���� ����Ʈ��
    }



HAL_SD_CardStateTypeDef WINAPI HAL_SD_GetCardState(SD_HandleTypeDef *hSD)
    {
    UINT Stat=0;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (SD_CmdSendStatus(SDInst, hSD->SdCard.RelCardAdd<<16)==HAL_OK) Stat=SDInst->RESP1;
    return (HAL_SD_CardStateTypeDef)((Stat>>9)&0x0F);
    }




LOCAL(VOID) SD_DMATxAbort(DMA_HandleTypeDef*hdma)
    {
    SD_HandleTypeDef *hSD=(SD_HandleTypeDef*)hdma->Parent;
    HAL_SD_CardStateTypeDef CardState;

    hSD->hdmatx=NULL;
    if (hSD->hdmarx==NULL)
        {
        CardState=HAL_SD_GetCardState(hSD);
        hSD->ErrorCode=HAL_SD_ERROR_NONE;
        hSD->State=HAL_SD_STATE_READY;
        if (CardState==HAL_SD_CARD_RECEIVING || CardState==HAL_SD_CARD_SENDING)
            {
            hSD->ErrorCode|=SD_CmdStopTransfer(hSD->Instance);

            if (hSD->ErrorCode!=HAL_SD_ERROR_NONE)
                {
                //HAL_SD_AbortCallback(hSD);
                }
            else{
                //HAL_SD_ErrorCallback(hSD);
                }
            }
        }
    }




LOCAL(VOID) SD_DMARxAbort(DMA_HandleTypeDef*hdma)
    {
    SD_HandleTypeDef *hSD=(SD_HandleTypeDef*)hdma->Parent;
    HAL_SD_CardStateTypeDef CardState;

    hSD->hdmarx=NULL;
    if (hSD->hdmatx==NULL)
        {
        CardState=HAL_SD_GetCardState(hSD);
        hSD->ErrorCode=HAL_SD_ERROR_NONE;
        hSD->State=HAL_SD_STATE_READY;
        if (CardState==HAL_SD_CARD_RECEIVING || CardState==HAL_SD_CARD_SENDING)
            {
            hSD->ErrorCode|=SD_CmdStopTransfer(hSD->Instance);

            if (hSD->ErrorCode!=HAL_SD_ERROR_NONE)
                {
                //HAL_SD_AbortCallback(hSD);
                }
            else{
                //HAL_SD_ErrorCallback(hSD);
                }
            }
        }
    }




VOID HAL_SD_IRQHandler(SD_HandleTypeDef *hSD)
    {
    UINT I, Rslt=HAL_SD_ERROR_NONE;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (SDInst->STA & SDMMC_IT_DATAEND)
        {
        SDInst->ICR=SDMMC_FLAG_DATAEND;
        SDInst->MASK&=~(SDMMC_IT_DATAEND|SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR|SDMMC_IT_RXOVERR);

        if (hSD->Context & SD_CONTEXT_IT)
            {
            if ((hSD->Context&SD_CONTEXT_READ_MULTIPLE_BLOCK)!=0 || (hSD->Context&SD_CONTEXT_WRITE_MULTIPLE_BLOCK)!=0)
                {
                if ((Rslt=SD_CmdStopTransfer(SDInst))!=HAL_SD_ERROR_NONE)
                    {
                    hSD->ErrorCode|=Rslt;
                    //HAL_SD_ErrorCallback(hSD);
                    }
                }

            SDInst->ICR=SDMMC_STATIC_FLAGS;

            hSD->State=HAL_SD_STATE_READY;
            if ((hSD->Context&SD_CONTEXT_READ_SINGLE_BLOCK)!=0 || (hSD->Context&SD_CONTEXT_READ_MULTIPLE_BLOCK)!=0)
                HAL_SD_RxCpltCallback(hSD);
            else
                HAL_SD_TxCpltCallback(hSD);
            }
        else if (hSD->Context & SD_CONTEXT_DMA)
            {
            if (hSD->Context & SD_CONTEXT_WRITE_MULTIPLE_BLOCK)
                {
                if ((Rslt=SD_CmdStopTransfer(SDInst))!=HAL_SD_ERROR_NONE)
                    {
                    hSD->ErrorCode|=Rslt;
                    //HAL_SD_ErrorCallback(hSD);
                    }
                }
            if ((hSD->Context&SD_CONTEXT_READ_SINGLE_BLOCK)==0 && (hSD->Context&SD_CONTEXT_READ_MULTIPLE_BLOCK)==0)
                {
                SDInst->DCTRL&=~SDMMC_DCTRL_DMAEN;
                hSD->State=HAL_SD_STATE_READY;
                HAL_SD_TxCpltCallback(hSD);
                }
            }
        }

    else if (SDInst->STA & SDMMC_IT_TXFIFOHE)
        {
        SDInst->ICR=SDMMC_FLAG_TXFIFOHE;
        for (I=0; I<8; I++) SDInst->FIFO=*hSD->pTxBuffPtr++;    //SD_Write_IT(hSD);
        }

    else if (SDInst->STA & SDMMC_IT_RXFIFOHF)
        {
        SDInst->ICR=SDMMC_FLAG_RXFIFOHF;
        for (I=0; I<8; I++) *hSD->pRxBuffPtr++=SDInst->FIFO;    //SD_Read_IT(hSD);
        }

    else if (SDInst->STA & (SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_RXOVERR|SDMMC_IT_TXUNDERR))
        {
        if (SDInst->STA & SDMMC_IT_DCRCFAIL) hSD->ErrorCode|=HAL_SD_ERROR_DATA_CRC_FAIL;
        if (SDInst->STA & SDMMC_IT_DTIMEOUT) hSD->ErrorCode|=HAL_SD_ERROR_DATA_TIMEOUT;
        if (SDInst->STA & SDMMC_IT_RXOVERR)  hSD->ErrorCode|=HAL_SD_ERROR_RX_OVERRUN;
        if (SDInst->STA & SDMMC_IT_TXUNDERR) hSD->ErrorCode|=HAL_SD_ERROR_TX_UNDERRUN;

        SDInst->ICR=SDMMC_STATIC_FLAGS;
        SDInst->MASK&=~(SDMMC_IT_DATAEND|SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR|SDMMC_IT_RXOVERR);  //__HAL_SD_DISABLE_IT()

        if (hSD->Context & SD_CONTEXT_DMA)
            {
            if (hSD->hdmatx!=NULL)
                {
                hSD->hdmatx->XferAbortCallback=SD_DMATxAbort;
                if (HAL_DMA_Abort_IT(hSD->hdmatx)!=HAL_OK) SD_DMATxAbort(hSD->hdmatx);
                }
            else if (hSD->hdmarx!=NULL)
                {
                hSD->hdmarx->XferAbortCallback=SD_DMARxAbort;
                if (HAL_DMA_Abort_IT(hSD->hdmarx)!=HAL_OK) SD_DMARxAbort(hSD->hdmarx);
                }
            else{
                hSD->ErrorCode=HAL_SD_ERROR_NONE;
                hSD->State=HAL_SD_STATE_READY;
                //HAL_SD_AbortCallback(hSD);
                }
            }
        else if (hSD->Context & SD_CONTEXT_IT)
            {
            hSD->State=HAL_SD_STATE_READY;
            //HAL_SD_ErrorCallback(hSD);
            }
        }
    }




LOCAL(UINT) SD_PowerON(SD_HandleTypeDef *hSD)
    {
    __IO UINT Cnt=0;
    UINT Resp=0, ValidVolt=0;
    UINT Rslt;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if ((Rslt=SD_CmdGoIdleState(SDInst))!=HAL_SD_ERROR_NONE) goto ProcExit;

    if (SD_CmdOperCond(SDInst)!=HAL_SD_ERROR_NONE)
        {
        hSD->SdCard.CardVersion=CARD_V1_X;

        while (ValidVolt==0)
            {
            if (Cnt++==SDMMC_MAX_VOLT_TRIAL) {Rslt=HAL_SD_ERROR_INVALID_VOLTRANGE; goto ProcExit;}
            if (SD_CmdAppCommand(SDInst, 0)!=HAL_SD_ERROR_NONE) {Rslt=HAL_SD_ERROR_UNSUPPORTED_FEATURE; goto ProcExit;}
            if (SD_CmdAppOperCommand(SDInst, SDMMC_STD_CAPACITY)!=HAL_SD_ERROR_NONE) {Rslt=HAL_SD_ERROR_UNSUPPORTED_FEATURE; goto ProcExit;}

            Resp=SDInst->RESP1;
            ValidVolt=Resp>>31;
            }
        hSD->SdCard.CardType=CARD_SDSC;
        }
    else{
        hSD->SdCard.CardVersion=CARD_V2_X;

        while (ValidVolt==0)
            {
            if (Cnt++==SDMMC_MAX_VOLT_TRIAL) {Rslt=HAL_SD_ERROR_INVALID_VOLTRANGE; goto ProcExit;}
            if ((Rslt=SD_CmdAppCommand(SDInst, 0))!=HAL_SD_ERROR_NONE) goto ProcExit;
            if ((Rslt=SD_CmdAppOperCommand(SDInst, SDMMC_HIGH_CAPACITY))!=HAL_SD_ERROR_NONE) goto ProcExit;

            Resp=SDInst->RESP1;
            ValidVolt=Resp>>31;
            }

        if ((Resp & SDMMC_HIGH_CAPACITY)==SDMMC_HIGH_CAPACITY)
            hSD->SdCard.CardType=CARD_SDHC_SDXC;
        else
            hSD->SdCard.CardType=CARD_SDSC;
        }
    Rslt=HAL_SD_ERROR_NONE;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      HAL_SD_GetCardCSD()
//-----------------------------------------------------------------------------
LOCAL(BOOL) SD_GetCardCSD(SD_HandleTypeDef *hSD, HAL_SD_CardCSDTypeDef *Csd)
    {
    BOOL Rslt=FALSE;
    UINT T, CSD0, CSD1, CSD2, CSD3;

    CSD0=hSD->CSD[0];
    CSD1=hSD->CSD[1];
    CSD2=hSD->CSD[2];
    CSD3=hSD->CSD[3];

    T=CSD0>>24;
    Csd->CSDStruct=(BYTE)((T&0xC0)>>6);
    Csd->SysSpecVersion=(BYTE)((T&0x3C)>>2);
    Csd->Reserved1=T&3;

    Csd->TAAC=(CSD0>>16)&0xFF;
    Csd->NSAC=(CSD0>>8)&0xFF;
    Csd->MaxBusClkFrec=CSD0&0xFF;

    Csd->CardComdClasses=(WORD)((CSD1>>24)<<4);

    T=(CSD1>>16)&0xFF;
    Csd->CardComdClasses|=(WORD)(T>>4);
    Csd->RdBlockLen=(BYTE)(T&0x0F);

    T=(CSD1>>8)&0xFF;
    Csd->PartBlockRead=(BYTE)(T>>7);
    Csd->WrBlockMisalign=(BYTE)((T&0x40)>>6);
    Csd->RdBlockMisalign=(BYTE)((T&0x20)>>5);
    Csd->DSRImpl=(BYTE)((T&0x10)>>4);
    Csd->Reserved2=0;

    if (hSD->SdCard.CardType==CARD_SDSC)
        {
        Csd->DeviceSize=(T&3)<<10;

        Csd->DeviceSize|=(CSD1&0xFF)<<2;

        T=CSD2>>24;
        Csd->DeviceSize|=(T&0xC0)>>6;
        Csd->MaxRdCurrentVDDMin=(T&0x38)>>3;
        Csd->MaxRdCurrentVDDMax=T&7;

        T=(CSD2>>16)&0xFF;
        Csd->MaxWrCurrentVDDMin=(T&0xE0)>>5;
        Csd->MaxWrCurrentVDDMax=(T&0x1C)>>2;
        Csd->DeviceSizeMul=(T&3)<<1;

        T=(CSD2>>8)&0xFF;
        Csd->DeviceSizeMul|=T>>7;

        hSD->SdCard.BlockNbr=Csd->DeviceSize+1;
        hSD->SdCard.BlockNbr*=1<<(Csd->DeviceSizeMul+2);
        hSD->SdCard.BlockSize=1<<Csd->RdBlockLen;

        hSD->SdCard.LogBlockNbr=hSD->SdCard.BlockNbr*(hSD->SdCard.BlockSize/512);
        hSD->SdCard.LogBlockSize=512;
        }
    else if (hSD->SdCard.CardType==CARD_SDHC_SDXC)
        {
        Csd->DeviceSize=(CSD1&0x3F)<<16;
        Csd->DeviceSize|=(CSD2>>24)<<8;
        Csd->DeviceSize|=(CSD2>>16)&0xFF;

        T=(CSD2>>8)&0xFF;
        hSD->SdCard.LogBlockNbr=hSD->SdCard.BlockNbr=((UINT64)Csd->DeviceSize+1)*1024;
        hSD->SdCard.LogBlockSize=hSD->SdCard.BlockSize=512;
        }
    else{
        hSD->Instance->ICR=SDMMC_STATIC_FLAGS;  //__HAL_SD_CLEAR_FLAG()
        hSD->ErrorCode|=HAL_SD_ERROR_UNSUPPORTED_FEATURE;
        hSD->State=HAL_SD_STATE_READY;
        goto ProcExit;
        }

    Csd->EraseGrSize=(T&0x40)>>6;
    Csd->EraseGrMul=(T&0x3F)<<1;

    T=CSD2&0xFF;
    Csd->EraseGrMul|=T>>7;
    Csd->WrProtectGrSize=T&0x7F;

    T=CSD3>>24;
    Csd->WrProtectGrEnable=T>>7;
    Csd->ManDeflECC=(T&0x60)>>5;
    Csd->WrSpeedFact=(T&0x1C)>>2;
    Csd->MaxWrBlockLen=(T&3)<<2;

    T=(CSD3>>16)&0xFF;
    Csd->MaxWrBlockLen|=(T&0xC0)>>6;
    Csd->WriteBlockPaPartial=(T&0x20)>>5;
    Csd->ContentProtectAppli=T&1;
    Csd->Reserved3=0;

    T=(CSD3>>8)&0xFF;
    Csd->FileFormatGroup=T>>7;
    Csd->CopyFlag=(T&0x40)>>6;
    Csd->PermWrProtect=(T&0x20)>>5;
    Csd->TempWrProtect=(T&0x10)>>4;
    Csd->FileFormat=(T&0x0C)>>2;
    Csd->ECC=T&3;

    Csd->CSD_CRC=(CSD3&0xFF)>>1;
    Csd->Reserved4=1;
    Rslt++;

    ProcExit:
    return Rslt;
    }



LOCAL(UINT) SD_InitCard(SD_HandleTypeDef *hSD)
    {
    UINT Rslt, SD_Rca=1;
    SD_TypeDef *SDInst;
    HAL_SD_CardCSDTypeDef CSD;

    SDInst=hSD->Instance;
    if ((SDInst->POWER & SDMMC_POWER_PWRCTRL)==0) {Rslt=HAL_SD_ERROR_REQUEST_NOT_APPLICABLE; goto ProcExit;}

    if (hSD->SdCard.CardType!=CARD_SECURED)
        {
        if ((Rslt=SD_CmdSendCID(SDInst))!=HAL_SD_ERROR_NONE) goto ProcExit;
        hSD->CID[0]=SDInst->RESP1;
        hSD->CID[1]=SDInst->RESP2;
        hSD->CID[2]=SDInst->RESP3;
        hSD->CID[3]=SDInst->RESP4;
        }

    if (hSD->SdCard.CardType!=CARD_SECURED)
        {
        if ((Rslt=SD_CmdSetRelAdd(SDInst, &SD_Rca))!=HAL_SD_ERROR_NONE) goto ProcExit;
        }

    if (hSD->SdCard.CardType!=CARD_SECURED)
        {
        hSD->SdCard.RelCardAdd=SD_Rca;

        if ((Rslt=SD_CmdSendCSD(SDInst, hSD->SdCard.RelCardAdd<<16))!=HAL_SD_ERROR_NONE) goto ProcExit;
        hSD->CSD[0]=SDInst->RESP1;
        hSD->CSD[1]=SDInst->RESP2;
        hSD->CSD[2]=SDInst->RESP3;
        hSD->CSD[3]=SDInst->RESP4;
        }

    hSD->SdCard.Class=SDInst->RESP2>>20;
    SD_GetCardCSD(hSD, &CSD);

    if ((Rslt=SD_CmdSelDesel(SDInst, hSD->SdCard.RelCardAdd<<16))==HAL_SD_ERROR_NONE)
        SD_InitClk(SDInst, hSD->Init.ClockEdge|
                           hSD->Init.ClockBypass|
                           hSD->Init.ClockPowerSave|
                           hSD->Init.BusWide|
                           hSD->Init.HardwareFlowControl|
                           hSD->Init.ClockDiv);

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      HAL_SD_Init()
//-----------------------------------------------------------------------------
VOID WINAPI SD_Init(SD_HandleTypeDef *hSD)
    {
    //HAL_SD_InitCard(hSD);
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    SD_InitClk(SDInst, SDMMC_CLOCK_EDGE_RISING|
                       SDMMC_CLOCK_BYPASS_DISABLE|
                       SDMMC_CLOCK_POWER_SAVE_DISABLE|
                       SDMMC_BUS_WIDE_1B|
                       SDMMC_HARDWARE_FLOW_CONTROL_DISABLE|
                       SDMMC_INIT_CLK_DIV);

    SDInst->CLKCR&=~SDMMC_CLKCR_CLKEN;      //__HAL_SD_DISABLE(hSD);
    SDInst->POWER=SDMMC_POWER_PWRCTRL;      //SDMMC_PowerState_ON()
    SDInst->CLKCR|=SDMMC_CLKCR_CLKEN;       //__HAL_SD_ENABLE(hSD);

    HAL_Delay(2);

    SD_PowerON(hSD);
    SD_InitCard(hSD);

    hSD->ErrorCode=HAL_DMA_ERROR_NONE;
    hSD->Context=SD_CONTEXT_NONE;
    hSD->State=HAL_SD_STATE_READY;
    }



HAL_StatusTypeDef HAL_SD_ReadBlocks(SD_HandleTypeDef*hSD, LPBYTE lpData, UINT BlockAdd, UINT NumberOfBlocks, UINT Timeout)
    {
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    UINT I, *lpD, FRslt, StartTick;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    lpD=(UINT*)lpData;
    StartTick=HAL_GetTick();
    if (hSD->State!=HAL_SD_STATE_READY) {hSD->ErrorCode|=HAL_SD_ERROR_BUSY; return HAL_ERROR;}

    hSD->ErrorCode=HAL_DMA_ERROR_NONE;
    if (BlockAdd+NumberOfBlocks > hSD->SdCard.LogBlockNbr) {hSD->ErrorCode|=HAL_SD_ERROR_ADDR_OUT_OF_RANGE; return HAL_ERROR;}

    hSD->State=HAL_SD_STATE_BUSY;

    SDInst->DCTRL=0;
    if (hSD->SdCard.CardType!=CARD_SDHC_SDXC) BlockAdd*=512;
    if ((FRslt=SD_CmdBlockLength(SDInst, BLOCKSIZE))!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}

    SD_ConfigData(SDInst, SDMMC_DATATIMEOUT, NumberOfBlocks*BLOCKSIZE,
        SDMMC_DATABLOCK_SIZE_512B|
        SDMMC_TRANSFER_DIR_TO_SDMMC|
        SDMMC_TRANSFER_MODE_BLOCK|
        SDMMC_DPSM_ENABLE);

    if (NumberOfBlocks>1)
        {
        hSD->Context=SD_CONTEXT_READ_MULTIPLE_BLOCK;
        FRslt=SD_CmdReadMultiBlock(SDInst, BlockAdd);
        }
    else{
        hSD->Context=SD_CONTEXT_READ_SINGLE_BLOCK;
        FRslt=SD_CmdReadSingleBlock(SDInst, BlockAdd);
        }
    if (FRslt!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}

    while ((SDInst->STA & (SDMMC_FLAG_RXOVERR|SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_DATAEND))==0)
        {
        if (SDInst->STA & SDMMC_FLAG_RXFIFOHF)
            {
            for (I=0; I<8; I++) *lpD++=SDInst->FIFO;
            }

        if (Timeout==0 || HAL_GetTick()-StartTick>=Timeout) {hSD->ErrorCode|=HAL_SD_ERROR_TIMEOUT; Rslt=HAL_TIMEOUT; goto ProcExit;}
        }

    if ((SDInst->STA & SDMMC_FLAG_DATAEND)!=0 && NumberOfBlocks>1)
        {
        if (hSD->SdCard.CardType!=CARD_SECURED &&
            (FRslt=SD_CmdStopTransfer(SDInst))!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}
        }

    if (SDInst->STA & SDMMC_FLAG_DTIMEOUT) {hSD->ErrorCode|=HAL_SD_ERROR_DATA_TIMEOUT; goto ProcExit;}
    if (SDInst->STA & SDMMC_FLAG_DCRCFAIL) {hSD->ErrorCode|=HAL_SD_ERROR_DATA_CRC_FAIL; goto ProcExit;}
    if (SDInst->STA & SDMMC_FLAG_RXOVERR)  {hSD->ErrorCode|=HAL_SD_ERROR_RX_OVERRUN; goto ProcExit;}

    while (SDInst->STA & SDMMC_FLAG_RXDAVL)
        {
        *lpD++=SDInst->FIFO;
        if (Timeout==0 || HAL_GetTick()-StartTick>=Timeout) {hSD->ErrorCode|=HAL_SD_ERROR_TIMEOUT; goto ProcExit;}
        }
    Rslt=HAL_OK;

    ProcExit:
    SDInst->ICR=SDMMC_STATIC_FLAGS;
    hSD->State=HAL_SD_STATE_READY;
    return Rslt;
    }




HAL_StatusTypeDef HAL_SD_WriteBlocks(SD_HandleTypeDef*hSD, LPBYTE lpData, UINT BlockAdd, UINT NumberOfBlocks, UINT Timeout)
    {
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    UINT I, *lpS, FRslt, StartTick;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    lpS=(UINT*)lpData;
    StartTick=HAL_GetTick();
    if (hSD->State!=HAL_SD_STATE_READY) {hSD->ErrorCode|=HAL_SD_ERROR_BUSY; return HAL_ERROR;}

    hSD->ErrorCode=HAL_DMA_ERROR_NONE;
    if (BlockAdd+NumberOfBlocks > hSD->SdCard.LogBlockNbr) {hSD->ErrorCode|=HAL_SD_ERROR_ADDR_OUT_OF_RANGE; return HAL_ERROR;}

    hSD->State=HAL_SD_STATE_BUSY;

    SDInst->DCTRL=0;
    if (hSD->SdCard.CardType!=CARD_SDHC_SDXC) BlockAdd*=512;

    if ((FRslt=SD_CmdBlockLength(SDInst, BLOCKSIZE))!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}

    if (NumberOfBlocks>1)
        {
        hSD->Context=SD_CONTEXT_WRITE_MULTIPLE_BLOCK;
        FRslt=SD_CmdWriteMultiBlock(SDInst, BlockAdd);
        }
    else{
        hSD->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;
        FRslt=SD_CmdWriteSingleBlock(SDInst, BlockAdd);
        }
    if (FRslt!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}

    SD_ConfigData(SDInst, SDMMC_DATATIMEOUT, NumberOfBlocks*BLOCKSIZE,
                    SDMMC_DATABLOCK_SIZE_512B|
                    SDMMC_TRANSFER_DIR_TO_CARD|
                    SDMMC_TRANSFER_MODE_BLOCK|
                    SDMMC_DPSM_ENABLE);

    while ((SDInst->STA & (SDMMC_FLAG_TXUNDERR|SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_DATAEND))==0)
        {
        if (SDInst->STA & SDMMC_FLAG_TXFIFOHE)
            {
            for (I=0; I<8; I++) SDInst->FIFO=*lpS++;
            }

        if (Timeout==0 || HAL_GetTick()-StartTick>=Timeout) {hSD->ErrorCode|=HAL_SD_ERROR_TIMEOUT; Rslt=HAL_TIMEOUT; goto ProcExit;}
        }

    if ((SDInst->STA & SDMMC_FLAG_DATAEND)!=0 && NumberOfBlocks>1)
        {
        if (hSD->SdCard.CardType!=CARD_SECURED &&
            (FRslt=SD_CmdStopTransfer(SDInst))!=HAL_SD_ERROR_NONE) {hSD->ErrorCode|=FRslt; goto ProcExit;}
        }

    if (SDInst->STA & SDMMC_FLAG_DTIMEOUT) {hSD->ErrorCode|=HAL_SD_ERROR_DATA_TIMEOUT; goto ProcExit;}
    if (SDInst->STA & SDMMC_FLAG_DCRCFAIL) {hSD->ErrorCode|=HAL_SD_ERROR_DATA_CRC_FAIL; goto ProcExit;}
    if (SDInst->STA & SDMMC_FLAG_TXUNDERR) {hSD->ErrorCode|=HAL_SD_ERROR_TX_UNDERRUN; goto ProcExit;}
    Rslt=HAL_OK;

    ProcExit:
    SDInst->ICR=SDMMC_STATIC_FLAGS;
    hSD->State=HAL_SD_STATE_READY;
    return Rslt;
    }




LOCAL(VOID) SD_DMATransmitCplt(DMA_HandleTypeDef*hdma)
    {
    SD_HandleTypeDef *hSD=(SD_HandleTypeDef*)hdma->Parent;
    hSD->Instance->MASK|=SDMMC_IT_DATAEND;
    }



LOCAL(VOID) SD_DMAError(DMA_HandleTypeDef*hdma)
    {
    SD_HandleTypeDef *hSD=(SD_HandleTypeDef*)hdma->Parent;
    HAL_SD_CardStateTypeDef CardState;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (hdma->ErrorCode!=HAL_DMA_ERROR_FE)
        {
        if (hSD->hdmarx->ErrorCode==HAL_DMA_ERROR_TE || hSD->hdmatx->ErrorCode==HAL_DMA_ERROR_TE)
            {
            SDInst->ICR=SDMMC_STATIC_FLAGS;
            SDInst->MASK&=~(SDMMC_IT_DATAEND|SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR|SDMMC_IT_RXOVERR);

            hSD->ErrorCode|=HAL_SD_ERROR_DMA;
            CardState=HAL_SD_GetCardState(hSD);
            if (CardState==HAL_SD_CARD_RECEIVING || CardState==HAL_SD_CARD_SENDING)
                {
                hSD->ErrorCode|=SD_CmdStopTransfer(SDInst);
                }
            hSD->State=HAL_SD_STATE_READY;
            }
        //HAL_SD_ErrorCallback(hSD);
        }
    }



LOCAL(VOID) SD_DMAReceiveCplt(DMA_HandleTypeDef*hdma)
    {
    UINT Rslt;
    SD_HandleTypeDef *hSD=(SD_HandleTypeDef*)hdma->Parent;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (hSD->Context==(SD_CONTEXT_READ_MULTIPLE_BLOCK|SD_CONTEXT_DMA))
        {
        if ((Rslt=SD_CmdStopTransfer(SDInst))!=HAL_SD_ERROR_NONE)
            {
            hSD->ErrorCode|=Rslt;
            //HAL_SD_ErrorCallback(hSD);
            }
        }

    SDInst->DCTRL&=~SDMMC_DCTRL_DMAEN;
    SDInst->ICR=SDMMC_STATIC_FLAGS;
    hSD->State=HAL_SD_STATE_READY;
    HAL_SD_RxCpltCallback(hSD);
    }




HAL_StatusTypeDef HAL_SD_ReadBlocks_DMA(SD_HandleTypeDef *hSD, LPBYTE lpData, UINT BlockAdd, UINT NumberOfBlocks)
    {
    UINT FRslt;
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (hSD->State!=HAL_SD_STATE_READY) return HAL_BUSY;
    hSD->ErrorCode=HAL_DMA_ERROR_NONE;
    if (BlockAdd+NumberOfBlocks > hSD->SdCard.LogBlockNbr)
        {
        hSD->ErrorCode|=HAL_SD_ERROR_ADDR_OUT_OF_RANGE;
        goto ProcExit;
        }

    hSD->State=HAL_SD_STATE_BUSY;
    SDInst->DCTRL=0;
    SDInst->MASK|=SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_RXOVERR|SDMMC_IT_DATAEND;

    hSD->hdmarx->XferCpltCallback=SD_DMAReceiveCplt;
    hSD->hdmarx->XferErrorCallback=SD_DMAError;
    hSD->hdmarx->XferAbortCallback=NULL;
    HAL_DMA_Start_IT(hSD->hdmarx, (UINT)&SDInst->FIFO, (UINT)lpData, BLOCKSIZE*NumberOfBlocks/4);

    SDInst->DCTRL|=SDMMC_DCTRL_DMAEN;   //__HAL_SD_DMA_ENABLE();

    if (hSD->SdCard.CardType!=CARD_SDHC_SDXC) BlockAdd*=512;
    SD_ConfigData(SDInst, SDMMC_DATATIMEOUT, BLOCKSIZE*NumberOfBlocks,
                    SDMMC_DATABLOCK_SIZE_512B|
                    SDMMC_TRANSFER_DIR_TO_SDMMC|
                    SDMMC_TRANSFER_MODE_BLOCK|
                    SDMMC_DPSM_ENABLE);

    if ((FRslt=SD_CmdBlockLength(SDInst, BLOCKSIZE))!=HAL_SD_ERROR_NONE) goto ErExit;

    if (NumberOfBlocks>1)
        {
        hSD->Context=SD_CONTEXT_READ_MULTIPLE_BLOCK|SD_CONTEXT_DMA;
        FRslt=SD_CmdReadMultiBlock(SDInst, BlockAdd);
        }
    else{
        hSD->Context=SD_CONTEXT_READ_SINGLE_BLOCK|SD_CONTEXT_DMA;
        FRslt=SD_CmdReadSingleBlock(SDInst, BlockAdd);
        }

    if (FRslt!=HAL_SD_ERROR_NONE)
        {
        ErExit:
        SDInst->ICR=SDMMC_STATIC_FLAGS;
        hSD->ErrorCode|=FRslt;
        hSD->State=HAL_SD_STATE_READY;
        goto ProcExit;
        }
    Rslt=HAL_OK;

    ProcExit:
    return Rslt;
    }



HAL_StatusTypeDef HAL_SD_WriteBlocks_DMA(SD_HandleTypeDef *hSD, LPBYTE lpData, UINT BlockAdd, UINT NumberOfBlocks)
    {
    UINT FRslt;
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    SD_TypeDef *SDInst;

    SDInst=hSD->Instance;
    if (hSD->State!=HAL_SD_STATE_READY) return HAL_BUSY;
    hSD->ErrorCode=HAL_DMA_ERROR_NONE;
    if (BlockAdd+NumberOfBlocks > hSD->SdCard.LogBlockNbr)
        {
        hSD->ErrorCode|=HAL_SD_ERROR_ADDR_OUT_OF_RANGE;
        goto ProcExit;
        }

    hSD->State=HAL_SD_STATE_BUSY;
    SDInst->DCTRL=0;
    SDInst->MASK|=SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR;
    hSD->hdmatx->XferCpltCallback=SD_DMATransmitCplt;
    hSD->hdmatx->XferErrorCallback=SD_DMAError;
    hSD->hdmatx->XferAbortCallback=NULL;

    if (hSD->SdCard.CardType!=CARD_SDHC_SDXC) BlockAdd*=512;
    if ((FRslt=SD_CmdBlockLength(SDInst, BLOCKSIZE))!=HAL_SD_ERROR_NONE) goto ErrExit;

    if (NumberOfBlocks>1)
        {
        hSD->Context=SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA;
        FRslt=SD_CmdWriteMultiBlock(SDInst, BlockAdd);
        }
    else{
        hSD->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK|SD_CONTEXT_DMA;
        FRslt=SD_CmdWriteSingleBlock(SDInst, BlockAdd);
        }

    if (FRslt!=HAL_SD_ERROR_NONE)
        {
        ErrExit:
        hSD->ErrorCode|=FRslt;
        SDInst->ICR=SDMMC_STATIC_FLAGS;
        hSD->State=HAL_SD_STATE_READY;
        goto ProcExit;
        }

    SDInst->DCTRL|=SDMMC_DCTRL_DMAEN;   //__HAL_SD_DMA_ENABLE(hSD);
    HAL_DMA_Start_IT(hSD->hdmatx, (UINT)lpData, (UINT)&SDInst->FIFO, BLOCKSIZE*NumberOfBlocks/4);
    SD_ConfigData(SDInst, SDMMC_DATATIMEOUT, BLOCKSIZE*NumberOfBlocks,
                        SDMMC_DATABLOCK_SIZE_512B|
                        SDMMC_TRANSFER_DIR_TO_CARD|
                        SDMMC_TRANSFER_MODE_BLOCK|
                        SDMMC_DPSM_ENABLE);
    Rslt=HAL_OK;

    ProcExit:
    return Rslt;
    }




///////////////////////////////////////////////////////////////////////////////
//                  stm32746g_discovery_sd.c
///////////////////////////////////////////////////////////////////////////////

#define SDCARD_ACCESS_TIMEOUT   3000


static SD_HandleTypeDef  G_SdHandle;
__IO UINT G_WriteStatus, G_ReadStatus;


//VOID HAL_SD_AbortCallback(SD_HandleTypeDef *hsd) {}
VOID HAL_SD_TxCpltCallback(SD_HandleTypeDef *hsd) {G_WriteStatus=1;}            //���ۿϷ� �ݹ�
VOID HAL_SD_RxCpltCallback(SD_HandleTypeDef *hsd) {G_ReadStatus=1;}             //���ſϷ� �ݹ�


LOCAL(BOOL) SD_IsDetected(VOID)
    {
    return PortIn(PI_SDDETECT)==0;
    }


#if USE_SDMMC_DMA
VOID SDMMC_IRQHandler(VOID)             //SDMMC1_IRQHandler
    {
    JOSIntEnter();
    HAL_SD_IRQHandler(&G_SdHandle);
    JOSIntExit();
    }


VOID SDMMC_DMA_Tx_IRQHandler(VOID)      //DMA2_Stream6_IRQHandler
    {
    JOSIntEnter();
    HAL_DMA_IRQHandler(G_SdHandle.hdmatx);
    JOSIntExit();
    }



VOID SDMMC_DMA_Rx_IRQHandler(VOID)      //DMA2_Stream3_IRQHandler
    {
    JOSIntEnter();
    HAL_DMA_IRQHandler(G_SdHandle.hdmarx);
    JOSIntExit();
    }
#endif



LOCAL(VOID) BSP_SD_MspInit(SD_HandleTypeDef*hsd)
    {
    #if USE_SDMMC_DMA
    static DMA_HandleTypeDef DmaRx;
    static DMA_HandleTypeDef DmaTx;
    #endif

    __HAL_RCC_SDMMC1_CLK_ENABLE();
    #if USE_SDMMC_DMA
    SDMMC_DMA_TxRx_CLK_ENABLE();

    HAL_NVIC_SetPriority(SDMMC1_IRQn, 0x05, 0);
    NVIC_EnableIRQ(SDMMC1_IRQn);

    DmaRx.Init.Channel=SDMMC_DMA_Rx_CHANNEL;
    DmaRx.Init.Direction=DMA_PERIPH_TO_MEMORY;
    DmaRx.Init.PeriphInc=DMA_PINC_DISABLE;
    DmaRx.Init.MemInc=DMA_MINC_ENABLE;
    DmaRx.Init.PeriphDataAlignment=DMA_PDATAALIGN_WORD;
    DmaRx.Init.MemDataAlignment=DMA_MDATAALIGN_WORD;
    DmaRx.Init.Mode=DMA_PFCTRL;
    DmaRx.Init.Priority=DMA_PRIORITY_VERY_HIGH;
    DmaRx.Init.FIFOMode=DMA_FIFOMODE_ENABLE;
    DmaRx.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;
    DmaRx.Init.MemBurst=DMA_MBURST_INC4;
    DmaRx.Init.PeriphBurst=DMA_PBURST_INC4;
    DmaRx.Instance=SDMMC_DMA_Rx_STREAM;
    __HAL_LINKDMA(hsd, hdmarx, DmaRx);

    HAL_DMA_DeInit(&DmaRx);
    HAL_DMA_Init(&DmaRx);

    DmaTx.Init.Channel=SDMMC_DMA_Tx_CHANNEL;
    DmaTx.Init.Direction=DMA_MEMORY_TO_PERIPH;
    DmaTx.Init.PeriphInc=DMA_PINC_DISABLE;
    DmaTx.Init.MemInc=DMA_MINC_ENABLE;
    DmaTx.Init.PeriphDataAlignment=DMA_PDATAALIGN_WORD;
    DmaTx.Init.MemDataAlignment=DMA_MDATAALIGN_WORD;
    DmaTx.Init.Mode=DMA_PFCTRL;
    DmaTx.Init.Priority=DMA_PRIORITY_VERY_HIGH;
    DmaTx.Init.FIFOMode=DMA_FIFOMODE_ENABLE;
    DmaTx.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;
    DmaTx.Init.MemBurst=DMA_MBURST_INC4;
    DmaTx.Init.PeriphBurst=DMA_PBURST_INC4;
    DmaTx.Instance=SDMMC_DMA_Tx_STREAM;
    __HAL_LINKDMA(hsd, hdmatx, DmaTx);

    HAL_DMA_DeInit(&DmaTx);
    HAL_DMA_Init(&DmaTx);

    HAL_NVIC_SetPriority(SDMMC_DMA_Rx_IRQn, 0x06, 0);
    NVIC_EnableIRQ(SDMMC_DMA_Rx_IRQn);

    HAL_NVIC_SetPriority(SDMMC_DMA_Tx_IRQn, 0x06, 0);
    NVIC_EnableIRQ(SDMMC_DMA_Tx_IRQn);
    #endif //USE_SDMMC_DMA
    }



BOOL WINAPI SDCARD_Init(VOID)
    {
    BOOL Rslt=FALSE;

    G_SdHandle.Instance=SDMMC1;
    G_SdHandle.Init.ClockEdge=SDMMC_CLOCK_EDGE_RISING;
    G_SdHandle.Init.ClockBypass=SDMMC_CLOCK_BYPASS_DISABLE;
    G_SdHandle.Init.ClockPowerSave=SDMMC_CLOCK_POWER_SAVE_DISABLE;
    G_SdHandle.Init.BusWide=SDMMC_BUS_WIDE_1B;
    G_SdHandle.Init.HardwareFlowControl=SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
    G_SdHandle.Init.ClockDiv=SDMMC_TRANSFER_CLK_DIV;

    if (SD_IsDetected()==FALSE) goto ProcExit;
    BSP_SD_MspInit(&G_SdHandle);
    SD_Init(&G_SdHandle);
    Rslt=HAL_SD_ConfigWideBusOperation(&G_SdHandle, SDMMC_BUS_WIDE_4B)==HAL_OK;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���� �б�
//-----------------------------------------------------------------------------
BOOL WINAPI SDCARD_Read(LPBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    BOOL  Rslt=FALSE;
    #if USE_SDMMC_DMA
    UINT  AlignAddr;
    DWORD StartTick;
    #endif

    if (SD_IsDetected()==FALSE) goto ProcExit;

    #if USE_SDMMC_DMA
    G_ReadStatus=0;
    HAL_SD_ReadBlocks_DMA(&G_SdHandle, Buff, BlockAddr, BlockLen);

    StartTick=GetTickCount();
    while (G_ReadStatus==0)
        {
        if (GetTickCount()-StartTick>=SDCARD_ACCESS_TIMEOUT) goto ProcExit;
        //Sleep(1);     //�̰� ������ MP3����� ���������� �����Ÿ�
        }
    while (HAL_SD_GetCardState(&G_SdHandle)!=HAL_SD_CARD_TRANSFER)
        {
        if (GetTickCount()-StartTick>=SDCARD_ACCESS_TIMEOUT) goto ProcExit;
        //Sleep(1);     //�̰� ������ MP3����� ���������� �����Ÿ�
        }
    AlignAddr=(UINT)Buff & ~0x1F;
    SCB_InvalidateDCache_by_Addr((UINT*)AlignAddr, BlockLen*BLOCKSIZE+((UINT)Buff-AlignAddr));
    #else
    HAL_SD_ReadBlocks(&G_SdHandle, Buff, BlockAddr, BlockLen, SDCARD_ACCESS_TIMEOUT);
    #endif
    Rslt++;

    ProcExit:
    return Rslt;
    }



BOOL WINAPI SDCARD_Write(LPCBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    BOOL  Rslt=FALSE;
    #if USE_SDMMC_DMA
    UINT  AlignAddr;
    DWORD StartTick;
    #endif

    if (SD_IsDetected()==FALSE) goto ProcExit;

    #if USE_SDMMC_DMA
    G_WriteStatus=0;
    AlignAddr=(UINT)Buff&~0x1F;
    SCB_CleanDCache_by_Addr((UINT*)AlignAddr, BlockLen*BLOCKSIZE+((UINT)Buff-AlignAddr));
    HAL_SD_WriteBlocks_DMA(&G_SdHandle, (LPBYTE)Buff, BlockAddr, BlockLen);

    StartTick=GetTickCount();
    while (G_WriteStatus==0)
        {
        if (GetTickCount()-StartTick>=SDCARD_ACCESS_TIMEOUT) goto ProcExit;
        //Sleep(1);
        }
    while (HAL_SD_GetCardState(&G_SdHandle)!=HAL_SD_CARD_TRANSFER)
        {
        if (GetTickCount()-StartTick>=SDCARD_ACCESS_TIMEOUT) goto ProcExit;
        //Sleep(1);
        }
    #else
    HAL_SD_WriteBlocks(&G_SdHandle, (LPBYTE)Buff, BlockAddr, BlockLen, SDCARD_ACCESS_TIMEOUT);
    #endif
    Rslt++;

    ProcExit:
    return Rslt;
    }



BOOL WINAPI SDCARD_GetCapacity(DWORD *lpBlockQty, UINT *lpBlockSize)
    {
    BOOL Rslt=FALSE;
    HAL_SD_CardInfoTypeDef CI;

    if (SD_IsDetected())
        {
        SD_GetCardInfo(&G_SdHandle, &CI);
        *lpBlockQty=CI.LogBlockNbr;     //�Ѽ��ͼ�
        *lpBlockSize=CI.LogBlockSize;   //���� ����Ʈ��
        //Printf("BlockQty=%u.\r\n", *lpBlockQty);  //=15644672
        //Printf("BlockSize=%u\r\n", *lpBlockSize); //=512
        Rslt++;
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �������� �����ΰ�� 0, �����ΰ�� -1�� ����������, BOOL�� ������
//-----------------------------------------------------------------------------
BOOL WINAPI SDCARD_IsReady(VOID)
    {
    int Rslt=FALSE;
    static BYTE NeedInit=1;

    if (SD_IsDetected())
        {
        if (NeedInit) {SDCARD_Init(); NeedInit=0;}
        if (HAL_SD_GetCardState(&G_SdHandle)==HAL_SD_CARD_TRANSFER) Rslt++;
        }
    else NeedInit=1;

    return Rslt;
    }



BOOL WINAPI SDCARD_IsWriteProtected(VOID) {return FALSE;}




