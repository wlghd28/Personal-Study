#include "JLIB.H"
#include "DRIVER.H"
#include "MONITOR.H"
#include "KEY.H"



static BYTE KeyBuff[KEYBUFFSIZE];
static int  KeyCodeQty, KeyGetPos, KeyPutPos;




//-----------------------------------------------------------------------------
//      Ű���ۿ��� ���� Ű�ڵ带 ������ (Ű���۰� ��� ������ ���� ����)
//-----------------------------------------------------------------------------
int WINAPI GetKey(VOID)
    {
    int Key=-1;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if (KeyCodeQty>0)
        {
        Key=KeyBuff[KeyGetPos];
        KeyCodeQty--;
        if (++KeyGetPos>=KEYBUFFSIZE) KeyGetPos=0;
        }
    JOS_EXIT_CRITICAL();
    return Key;
    }



//-----------------------------------------------------------------------------
//      Ű���ۿ��� ���� Ű�� �ִ��� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI CheckKey(VOID)
    {
    return KeyCodeQty;
    }



//-----------------------------------------------------------------------------
//      Ÿ�̸� ���ͷ�Ʈ���� ���
//-----------------------------------------------------------------------------
BOOL WINAPI PutKeyIT(int Key)
    {
    BOOL Rslt=FALSE;

    if (Key!=0 && KeyCodeQty<KEYBUFFSIZE)
        {
        KeyBuff[KeyPutPos]=(BYTE)Key;
        KeyCodeQty++;
        if (++KeyPutPos>=KEYBUFFSIZE) KeyPutPos=0;
        Rslt=TRUE;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ���α׷����� Ű ���� �Ͱ� ���� ó���� ���� ���
//-----------------------------------------------------------------------------
BOOL WINAPI PutKey(int Key)
    {
    BOOL Rslt;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    Rslt=PutKeyIT(Key);
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      1�ʿ� 100�� Ÿ�̸� ���ͷ�Ʈ���� ȣ���Ұ�
//-----------------------------------------------------------------------------
VOID WINAPI ScanKey(int Key, KEYCODETABLE *KeyCodeTable, int KeyQty)
    {
    int    I, KeepTime;
    UINT   Mask, KeyCode, DblTime;
    static UINT OldKey, OldKeyII=~0;
    KEYCODETABLE *KCT;

    if (OldKeyII+1==0) OldKeyII=IgnoreFirstPushedKey(Key);

    //����Ŭ�� ó��
    for (I=0; I<KeyQty; I++)
        {
        KCT=KeyCodeTable+I;
        if ((DblTime=KCT->DblClickTime)!=0)
            {
            if (DblTime<40) DblTime++;
            else{
                PutKeyIT(KCT->KeyDownCode);
                if (KCT->KeyPushTimes==0) PutKeyIT(KCT->KeyUpCode);
                DblTime=0;
                }
            KCT->DblClickTime=DblTime;
            }
        }

    for (I=0,Mask=1; I<KeyQty; I++,Mask<<=1)
        {
        KCT=KeyCodeTable+I;
        if ((Key & Mask)!=(OldKey & Mask))
            {
            KCT->KeepCnt=0;
            OldKey&=~Mask; OldKey|=Key & Mask;          //OldKey=Key;
            }
        else{
            if ((KeepTime=(Key & Mask) ? KCT->OnKeepTime:KCT->OffKeepTime)==0) KeepTime=5;  //�������ϸ� 50ms
            if (KCT->KeepCnt<KeepTime) KCT->KeepCnt++;
            if (KCT->KeepCnt==KeepTime)                 //'H'�̵� 'L'�̵� 50ms �����Ǵ��� Ȯ��
                {
                if (Key & Mask)
                    {
                    if ((OldKeyII & Mask)==0)
                        {
                        PlayKeyClickSound(KeyCode=KCT->KeyDownCode);

                        if (KCT->KeyDblClickCode!=0)
                            {
                            if (KCT->DblClickTime==0)   //ù��° ���� ���
                                {
                                KCT->DblClickTime=1;    //����Ŭ�� Ÿ�̸� ����
                                KeyCode=0;              //ù��° Ű�� ������ÿ��� ������
                                }
                            else{
                                KeyCode=KCT->KeyDblClickCode;
                                KCT->DblClickTime=0;
                                KCT->LongKeyGenFg=1;    //����Ŭ�� �� Up�ڵ带 �߻����� �ʰ�
                                }
                            }
                        PutKeyIT(KeyCode);
                        }
                    else{
                        if (KCT->KeyPushTimes<500)      //��� ������� Overwrap �߻����� �ʰ� �ϱ� ����
                            {
                            if (++KCT->KeyPushTimes==250)   //2.5sec
                                {
                                if (KCT->KeyLongDown1Code!=0)
                                    {
                                    KCT->LongKeyGenFg=1;    //��� ������ �� Up�ڵ带 �߻����� �ʰ�
                                    PutKeyIT(KCT->KeyLongDown1Code);
                                    }
                                }
                            else if (KCT->KeyPushTimes==500)//5sec
                                {
                                if (KCT->KeyLongDown2Code!=0)
                                    {
                                    KCT->LongKeyGenFg=1;    //��� ������ �� Up�ڵ带 �߻����� �ʰ�
                                    PutKeyIT(KCT->KeyLongDown2Code);
                                    }
                                }
                            }
                        }
                    }
                else{
                    if ((OldKeyII & Mask)!=0)
                        {
                        if (KCT->LongKeyGenFg==0 && KCT->DblClickTime==0) PutKeyIT(KCT->KeyUpCode);
                        KCT->LongKeyGenFg=0;
                        KCT->KeyPushTimes=0;
                        }
                    }
                OldKeyII&=~Mask; OldKeyII|=Key & Mask;  //OldKeyII=Key;
                } //if (KCT->KeepCnt==KeepTime)
            } //if ((Key & Mask)==(OldKey & Mask))
        } //for ()
    }




//-----------------------------------------------------------------------------
//      ó���� Ű�� �ְų� Ű�� ���������� TRUE����
//      �� �Լ��� ȣ���� ����� FALSE�� �� Sleep Mode ������
//-----------------------------------------------------------------------------
BOOL WINAPI IsBusyKey(int Key, CONST KEYCODETABLE *KeyCodeTable, int KeyQty)
    {
    int I, Rslt;
    CONST KEYCODETABLE *KCT;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if ((Rslt=CheckKey())==FALSE)
        {                                   //���ͷ�Ʈ�� ���� ������ �� �������� ���ͷ�Ʈ �Ǿ� .DblClickTime Ÿ�̸Ӱ� ������ Ű���ۿ� Ű�� �ְ� .DblClickTime=0�� ���� �� �� �Լ��� FALSE�� �����Ͽ� �������� ���� ������ ����
        if (Key) Rslt++;                    //TestŰ�� ���� ���
        else{
            for (I=0; I<KeyQty; I++)
                {
                KCT=KeyCodeTable+I;
                if (KCT->DblClickTime || KCT->KeyPushTimes) {Rslt++; break;}
                }
            }
        }
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




///////////////////////////////////////////////////////////////////////////////
//              ����� Ÿ�̸�
///////////////////////////////////////////////////////////////////////////////


#define MAXTIMERQTY     10

typedef struct
    {
    int   TimerID;
    DWORD OldTime;
    DWORD Interval;
    } TIMERLIST;

static TIMERLIST TimerList[MAXTIMERQTY];


//-----------------------------------------------------------------------------
//      ����� Ÿ�̸� ó��
//-----------------------------------------------------------------------------
VOID WINAPI K_TimerProc(VOID)
    {
    int   I;
    DWORD Time, Interval;

    Time=GetTickCount();
    for (I=0; I<MAXTIMERQTY; I++)
        {
        if (TimerList[I].TimerID!=0)
            {
            Interval=TimerList[I].Interval;
            if (Time-TimerList[I].OldTime >= Interval)
                {
                TimerList[I].OldTime+=Interval;
                PutKey(TimerList[I].TimerID);
                }
            }
        }
    }



//-----------------------------------------------------------------------------
//      ����� Ÿ�̸Ӹ� ������
//-----------------------------------------------------------------------------
BOOL WINAPI K_SetTimer(int TimerID, DWORD ms)
    {
    int I, Rslt=FALSE, NoUseIdx=255;

    for (I=0; I<MAXTIMERQTY; I++)
        {
        if (TimerList[I].TimerID==0 && NoUseIdx>=MAXTIMERQTY) NoUseIdx=I;
        if (TimerList[I].TimerID==TimerID) {NoUseIdx=I; break;}
        }

    if (NoUseIdx<MAXTIMERQTY)
        {
        TimerList[NoUseIdx].TimerID=TimerID;
        TimerList[NoUseIdx].Interval=ms;
        TimerList[NoUseIdx].OldTime=GetTickCount();
        Rslt=TRUE;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ����� Ÿ�̸Ӹ� ������
//-----------------------------------------------------------------------------
BOOL WINAPI K_KillTimer(int TimerID)
    {
    int I, Rslt=FALSE;

    for (I=0; I<MAXTIMERQTY; I++)
        {
        if (TimerList[I].TimerID==TimerID)
            {
            TimerList[I].TimerID=0;
            Rslt=TRUE;
            break;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      KeyBoard Emulation
//-----------------------------------------------------------------------------
int WINAPI Mon_KeyEmu(int PortNo, LPCSTR MonCmd, LPCSTR lpArg, LPCSTR CmdLine)
    {
    int I, Key, Rslt=MONRSLT_SYNTAXERR;

    if (lpArg[0]=='?')
        {
        Printf("KEY KeyCode ... Key Emulation"CRLF);
        Rslt=MONRSLT_EXIT;
        goto ProcExit;
        }

    if (lpArg[0]=='\'')
        {
        Key=lpArg[1];
        if (Key==0 || lpArg[2]!='\'') goto ProcExit;
        }
    else{
        Key=AtoI(lpArg, &I);
        if (I==0) goto ProcExit;
        }
    PutKey(Key);
    Rslt=MONRSLT_OK;

    ProcExit:
    return Rslt;
    }





