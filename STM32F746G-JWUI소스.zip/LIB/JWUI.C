﻿///////////////////////////////////////////////////////////////////////////////
//                  JWUI (미니 비선점형 윈도우즈 GUI커널)
//
// 프로그래머: 죠우저프
//
// 1997/10 DOS용 미니 JWUI 작성 ... Gray Graphic LCD, '스크린폰'에 적용 (16Bit x86보드)
// 2006/05 삼성중공업 7인치 월패드에 적용 (Analog TFT LCD 사용)
// 2008/02 삼성중공업 10.2인치 월패드에 적용 (TFT LCD 사용, ARM9 32비트로 전환)
// 2020/08 윈도우 매니저 보완 (STM32F746G-DISCO 보드로 작업)
// 2020/10 아랍어 디스플레이 지원
// 2021/08 디자인 이미지 없이 사용하는 대화상자, 위젯 지원
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "JWUI.H"
#if COMMCTRL_EN
#include "COMMCTL.H"
#endif
#if USE_GIF
#include "GIF.H"
#endif
#if USE_PNG
#include "PNGDEC.H"
#endif
#include "KEY.H"
#include "JFAT.H"


#define CACHEMINFREEMEM         2   //메가단위, 남은 메모리가 이보다 작으면 캐쉬안함


#define MEMOWNER_RegisterClass      (MEMOWNER_JWUI+0)
#define MEMOWNER_SetHwndViewList    (MEMOWNER_JWUI+1)
#define MEMOWNER_CreateSolidBrush   (MEMOWNER_JWUI+2)
#define MEMOWNER_CreateHatchBrush   (MEMOWNER_JWUI+3)
#define MEMOWNER_CreatePen          (MEMOWNER_JWUI+4)
#define MEMOWNER_GetWindowDC        (MEMOWNER_JWUI+5)
#define MEMOWNER_GetWindowDCMem     (MEMOWNER_JWUI+6)
#define MEMOWNER_CreateWindowTitle  (MEMOWNER_JWUI+7)
#define MEMOWNER_CreateWindowHwnd   (MEMOWNER_JWUI+8)
#define MEMOWNER_WM_SETTEXT         (MEMOWNER_JWUI+9)
//#define MEMOWNER_DrawBtm          (MEMOWNER_JWUI+10)
#define MEMOWNER_ImageToVram        (MEMOWNER_JWUI+11)
#define MEMOWNER_CacheImage         (MEMOWNER_JWUI+12)
#define MEMOWNER_SetProp            (MEMOWNER_JWUI+13)
#define MEMOWNER_LoadBmpEx          (MEMOWNER_JWUI+14)
#define MEMOWNER_AllocDCMem         (MEMOWNER_JWUI+15)
#define MEMOWNER_TextOut            (MEMOWNER_JWUI+16)
#define MEMOWNER_LoadFont           (MEMOWNER_JWUI+17)
#define MEMOWNER_LoadBmp            (MEMOWNER_JWUI+18)



HINSTANCE HInst;
#define SOLID_FILL      0


HWND hWndScrKbd=NULL;

//static POINT OldMousePos;

static HFONT hFontDef;
static HPEN  WhitePen, BlackPen, NullPen;
static HBRUSH WhiteBrush, BlackBrush, NullBrush, BtnFaceBrush;
static HBITMAP hBtmDefBtnImage;

static HWND WindowList;
static HWND FocusWindow;
static HWND hWndCapture;

static BYTE  CaretFlashFg;
static INT8  CaretViewCnt;      //1이상이면 표시
static HWND  hWndCaretOwner;    //캐럿주인윈도우
static int   CaretPosX, CaretPosY, CaretSizeX, CaretSizeY;
static BYTE  CaretImage[4*32];  //32*32의 커서 Data
static CONST CHAR DlgClassName[]="#32770";
static CONST CHAR ButtonStr[]="Button";

#define MAXPOPUPQTY         16
static HWND PopupWindowList[MAXPOPUPQTY];       //대화상자/메세지박스 같은 팝업 윈도우 목록이 들어감, 모든 팝업윈도우를 닫을 때 사용



typedef struct _HWNDZOTHERLIST
    {
    HWND hWnd;
    struct _HWNDZOTHERLIST *Next;
    } HWNDZOTHERLIST;

static HWNDZOTHERLIST *HwndZOther;   //생성된 모든 윈도우의 Z-Other를 관리함




//-----------------------------------------------------------------------------
//      주어진 윈도우 핸들 정보를 표시함 (디버깅을 위한 함수)
//-----------------------------------------------------------------------------
VOID WINAPI PrintWindow(LPCSTR Title, HWND hWnd)
    {
    CHAR Buff[40];

    lstrcpyn(Buff, Title, sizeof(Buff)-16-1);
    AddCha(Buff, ' ');
    GetClassName(hWnd, GetStrLast(Buff), 16);
    PrintRect(Buff, &hWnd->WA);
    }

VOID WINAPI PrintWindowAndRect(LPCSTR Title, HWND hWnd, CONST RECT *R)
    {
    CHAR Buff[40];

    lstrcpyn(Buff, Title, sizeof(Buff)-16-1);
    AddCha(Buff, ' ');
    GetClassName(hWnd, GetStrLast(Buff), 16);
    PrintRect(Buff, R);
    }


BOOL WINAPI IsWindowClass(HWND hWnd, LPCSTR ClsName)
    {
    return lstrcmpi(hWnd->WC.lpszClassName, ClsName)==0;
    }



//-----------------------------------------------------------------------------
//      주어진 윈도우가 보여지는 윈도우인지 알려줌 (부모 윈도우까지 확인)
//-----------------------------------------------------------------------------
LOCAL(BOOL) IsVisible(HWND hWnd)
    {
    BOOL Rslt=FALSE;

    for (;;)
        {
        if ((hWnd->Style & WS_VISIBLE)==0) break;
        if ((hWnd=hWnd->Parent)==NULL) {Rslt++; break;}
        }
    return Rslt;
    }




///////////////////////////////////////////////////////////////////////////////
//          HDC 처리
///////////////////////////////////////////////////////////////////////////////


COLORREF WINAPI SetTextColor(HDC hDC, COLORREF Col)
    {
    COLORREF Old;

    Old=hDC->TextColor;
    hDC->TextColor=Col;
    return Old;
    }



COLORREF WINAPI SetBkColor(HDC hDC, COLORREF Col)
    {
    COLORREF Old;

    Old=hDC->TextBkColor;
    hDC->TextBkColor=Col;
    return Old;
    }


int WINAPI GetROP2(HDC hDC)
    {
    return hDC->DrawMode;
    }


int WINAPI SetROP2(HDC hDC, int Mode)
    {
    int OldMode;

    OldMode=hDC->DrawMode;
    hDC->DrawMode=Mode;
    return OldMode;
    }



HDC WINAPI GetWindowDC(HWND hWnd)
    {
    HDC  hDC=NULL;

    if (hWnd!=NULL && IsWindow(hWnd)==FALSE) goto ProcExit;
    if ((hDC=AllocMemS(HDCStruc, MEMOWNER_GetWindowDC))==NULL) goto ProcExit;

    ShowCursor(FALSE);

    ZeroMem(hDC, sizeof(HDCStruc));
    hDC->TextColor=COL_BLACK;
    hDC->TextBkColor=COL_WHITE;
    hDC->hWnd=hWnd;

    if (hWnd==NULL) //스크린에 직접그리기
        {
        SetRect(&hDC->WA, 0, 0, LCD_LogResolutionX, LCD_LogResolutionY);
        hDC->lpDCMem=(COLORREF*)AllocVMem(LCD_LogResolutionX*LCD_LogResolutionY*sizeof(COLORREF), MEMOWNER_GetWindowDCMem);
        }
    else{
        hDC->WA=hWnd->WA;
        hDC->lpDCMem=hWnd->lpDCMem;
        }
    //SetRectEmpty(&hDC->PA);   //ZeroMem(hDC...)에서 처리됨
    hDC->WindowWidth=hDC->WA.right-hDC->WA.left;
    SetRect(&hDC->CA, 0,0, hDC->WindowWidth, hDC->WA.bottom-hDC->WA.top);
    hDC->RPA=hDC->CA;

    hDC->DrawMode=R2_COPYPEN;
    hDC->BkMode=OPAQUE;
    hDC->hFont=NULL;
    SelectObject(hDC, hFontDef);
    SelectObject(hDC, BlackPen);
    SelectObject(hDC, WhiteBrush);

    ProcExit:
    return hDC;
    }



//-----------------------------------------------------------------------------
//      클라이언트 영역을 만듦
//-----------------------------------------------------------------------------
LOCAL(VOID) MakeClientArea(HWND hWnd, RECT *R)
    {
    DWORD Style;

    Style=hWnd->Style;
    if ((Style & WS_CAPTION)==WS_CAPTION)
        {
        InflateRect(R, -FRAMEWIDTH, -FRAMEWIDTH);
        R->top+=CYCAPTION;
        }
    else if (Style & WS_BORDER)
        {
        if (Style & WS_CHILD)
             InflateRect(R, -EDGE3DTHICK, -EDGE3DTHICK);
        else InflateRect(R, -THINFRAMEWIDTH, -THINFRAMEWIDTH);
        }
    if (Style & WS_VSCROLL) R->right-=ScrollBarBtnSize;
    if (Style & WS_HSCROLL) R->bottom-=ScrollBarBtnSize;
    }



//hWnd로 부터 얻는 것보다 빠름
LOCAL(VOID) GetClientRectFromDC(HDC hDC, RECT *R)
    {
    SetRect(R, 0,0, hDC->CA.right-hDC->CA.left, hDC->CA.bottom-hDC->CA.top);
    }



//-----------------------------------------------------------------------------
//      hWnd==NULL이면 Screen영역의 DC를 생성함
//-----------------------------------------------------------------------------
HDC WINAPI GetDC(HWND hWnd)
    {
    HDC hDC;

    if ((hDC=GetWindowDC(hWnd))!=NULL)
        {
        if (hWnd!=NULL)
            {
            MakeClientArea(hWnd, &hDC->CA);
            GetClientRectFromDC(hDC, &hDC->RPA);    //그려져야 할 영역을 클라이언트 전체로 전체로 설정
            }
        hDC->IsClientDC=TRUE;
        }
    return hDC;
    }


LOCAL(COLORREF*) GetDCMemPtr(HDC hDC, int X, int Y)
    {
    X+=hDC->CA.left;
    Y+=hDC->CA.top;
    return (hDC->WindowWidth*Y+X) + hDC->lpDCMem;
    }



//-----------------------------------------------------------------------------
//      주어진 영역을 LCD에 표시하도록 마킹해둠, R은 클라이언트 좌표
//-----------------------------------------------------------------------------
LOCAL(VOID) SetDrawArea(HDC hDC, CONST RECT *R)
    {
    MyUnionRect(&hDC->DPA, R);
    }



//-----------------------------------------------------------------------------
//      주어진 영역을 HDC 영역 내부가 되도록 조정함
//      FALSE를 리턴하면 HDC밖의 영역임
//-----------------------------------------------------------------------------
LOCAL(BOOL) AdjustDrawArea(HDC hDC, RECT *DR, CONST RECT *SR)
    {
    BOOL Rslt;
    RECT CR;

    GetClientRectFromDC(hDC, &CR);
    if ((Rslt=IntersectRect(DR, SR, &CR))!=FALSE)
        Rslt=MyIntersectRect(DR, &hDC->RPA);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      두 윈도우의 부모가 같은지 알려줌
//-----------------------------------------------------------------------------
LOCAL(BOOL) SameParent(HWND hWnd1, HWND hWnd2)
    {
    while (hWnd1->Style & WS_CHILD) hWnd1=hWnd1->Parent;
    while (hWnd2->Style & WS_CHILD) hWnd2=hWnd2->Parent;
    return hWnd1==hWnd2;
    }




int WINAPI ReleaseDC(HWND hWnd, HDC hDC)
    {
    int I;
    HWND hWndZ;
    HWNDZOTHERLIST *HZO;
    RECT R;
    RECTLIST RL;

    if (hDC==NULL) return FALSE;            //GetWindowDC()에서 NULL을 리턴할 때는 ShowCursor(FALSE)을 처리하지 않았기에 바로 리턴해야 함
    ZeroMem(&RL, sizeof(RL));
    if (hDC->lpDCMem!=NULL && IsRectEmpty(&hDC->DPA)==FALSE)
        {
        R=hDC->DPA;
        OffsetRect(&R, hDC->WA.left+hDC->CA.left, hDC->WA.top+hDC->CA.top);
        AddRectList(&RL, &R);

        if (hWnd!=NULL)
            {
            //PrintWindowAndRect("ReleaseDC()", hWnd, &R);
            if (hDC->IsClientDC==FALSE)         //윈도우DC일 경우에는 Client영역을 안그렸으므로 이영역을 빼냄
                {
                R=hDC->WA;
                MakeClientArea(hWnd, &R);
                SubRectEx(&RL, &R);
                }

            for (HZO=HwndZOther; HZO!=NULL; HZO=HZO->Next)
                {
                if ((hWndZ=HZO->hWnd)==hWnd) break;
                if (IsVisible(hWndZ)==FALSE) continue;
                if (SameParent(hWnd, hWndZ)==FALSE && (hWndZ->Style & WS_CHILD)!=0) continue;
                SubRectEx(&RL, &hWndZ->WA);     //나를 덮은 윈도우 영역을 죄외시킴
                }
            }

        for (I=0; I<RL.CurrQty; I++)
            {
            LCD_OutputScreen(hDC->lpDCMem, &hDC->WA, RL.RectList+I);
            }
        //if (RL.CurrQty) {Sleep(1000);}   //그리는 과정을 볼 필요가 있을 때
        }
    if (hWnd==NULL || hDC->lpDCMem!=hWnd->lpDCMem) FreeMem(hDC->lpDCMem);       //hWnd==NULL 로 만든 DC일 경우 삭제

    FreeMem(hDC);
    ShowCursor(TRUE);
    FreeMem(RL.RectList);
    return TRUE;
    }


HDC WINAPI BeginPaint(HWND hWnd, PAINTSTRUCT *PS)
    {
    PS->hdc=GetDC(hWnd);
    PS->rcPaint=PS->hdc->RPA=hWnd->PA;
    return PS->hdc;
    }

VOID WINAPI EndPaint(HWND hWnd, CONST PAINTSTRUCT *PS)
    {
    ReleaseDC(hWnd, PS->hdc);
    SetRectEmpty(&hWnd->PA);
    }




//-----------------------------------------------------------------------------
//      기본 아이콘을 그려줌
//-----------------------------------------------------------------------------
VOID WINAPI DrawDefaultIcon(HDC hDC, CONST RECT *R, int IconNo, int Sx, int Sy)
    {
    POINT P;

    if (hBtmDefBtnImage!=NULL)
        {
        P.x=(IconNo&0x0F)*DEFICONSELWIDTH; //&0x0F=%DEFICONCOLUMNQTY
        P.y=(IconNo>>4)*DEFICONSELHEIGHT;  //>>4 = /DEFICONCOLUMNQTY
        DrawBitmap(hDC, (R->left+R->right-Sx)>>1, (R->top+R->bottom-Sy)>>1,
                         Sx, Sy, hBtmDefBtnImage, P.x, P.y, COL_WHITE);
        }
    }




//-----------------------------------------------------------------------------
//      종료버튼을 그림
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawCloseBtn(HDC hDC, RECT *R, BOOL Pushed)
    {
    FillRectCol(hDC, R, Pushed ? COL_CLOSEBTNFACE_A:COL_CLOSEBTNFACE_N);
    DrawDefaultIcon(hDC, R, CLOSEBTNICONNO, CXCLOSEBTNIMAGE, CYCLOSEBTNIMAGE);
    }

LOCAL(VOID) DrawCloseBtnEx(HWND hWnd, RECT *R, BOOL Pushed)
    {
    HDC hDC;

    hDC=GetWindowDC(hWnd);
    DrawCloseBtn(hDC, R, Pushed);
    ReleaseDC(hWnd, hDC);
    }



//-----------------------------------------------------------------------------
//      캡션과 프레임을 그림
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawDlgFrame(HWND hWnd, HDC hDC, BOOL PaintFrameFg)
    {
    RECT AR, R, R1;
    COLORREF CapCol, CapTextCol;
    CHAR Title[80];

    GetWindowText(hWnd, Title, sizeof(Title));

    GetWindowRect(hWnd, &AR);
    OffsetRect(&AR, -AR.left, -AR.top);

    if (PaintFrameFg)
        {
        DrawTwoColRect(hDC, &AR, COL_3DLIGHT, COL_BLACK, DTCR_Box);
        InflateRect(&AR, -1, -1);
        DrawTwoColRect(hDC, &AR, COL_BTNHIGHLIGHT, COL_BTNSHADOW, DTCR_Box);
        InflateRect(&AR, -1, -1);
        DrawTwoColRect(hDC, &AR, COL_3DFACE, COL_3DFACE, DTCR_Box);     //캡션 테두리를 위해 필요
        InflateRect(&AR, -1, -1);
        }
    else InflateRect(&AR, -3, -3);

    R=AR; AR.top=R.bottom=R.top+CYCAPTION;
    R.right-=CXCLOSEBTN;
    CapCol=COL_ACTIVECAPTION; CapTextCol=COL_CAPTIONTEXT;
    if (hWnd->Style & WS_DISABLED) {CapCol=COL_DEACTIVECAPTION; CapTextCol=COL_DECAPTIONTEXT;}
    FillRectCol(hDC, &R, CapCol);

    R1=R; R1.left=R1.right; R1.right=R1.left+CXCLOSEBTN;
    DrawCloseBtn(hDC, &R1, FALSE);

    if (Title[0]!=0)
        {
        SetBkColor(hDC, CapCol);
        SetTextColor(hDC, CapTextCol);
        InflateRect(&R, -3, 0);
        DrawText(hDC, Title, lstrlen(Title), &R, DT_LEFT|DT_VCENTER);
        }
    }



//-----------------------------------------------------------------------------
//      단일선 프레임을 그리고 클라이언트 영역을 칠함
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawThinFrame(HWND hWnd, HDC hDC)
    {
    RECT R;

    GetWindowRect(hWnd, &R);
    OffsetRect(&R, -R.left, -R.top);
    DrawTwoColRect(hDC, &R, COL_THINBORDER, COL_THINBORDER, DTCR_Box);
    }




//-----------------------------------------------------------------------------
//      에디터의 프레임을 그림
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawSunkenFrame(HWND hWnd, HDC hDC)
    {
    RECT R;

    GetWindowRect(hWnd, &R);
    OffsetRect(&R, -R.left, -R.top);
    DrawTwoColRect(hDC, &R, COL_BTNSHADOW, COL_BTNHIGHLIGHT, DTCR_Box);
    InflateRect(&R, -1, -1);
    DrawTwoColRect(hDC, &R, COL_BLACK, COL_3DLIGHT, DTCR_Box);
    }




//-----------------------------------------------------------------------------
//      프레임을 먼저그리고 백그라운드를 나중에 그려야 대화상자 처음 표시가
//      깔끔해짐
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawWindowFrame(HWND hWnd)
    {
    HDC hDC;

    if ((hWnd->Style & WS_BORDER)!=0 && //캡션도 포함됨, 대부분 UI는 이미지로 되어 있어 WS_BORDER 속성을 가지지 않음
        (hDC=GetWindowDC(hWnd))!=NULL)
        {
        if ((hWnd->Style & WS_CAPTION)==WS_CAPTION) DrawDlgFrame(hWnd, hDC, TRUE);
        else{
            if (hWnd->Style & WS_CHILD) DrawSunkenFrame(hWnd, hDC); //Edit, ListBox 같은 것들
            else                        DrawThinFrame(hWnd, hDC);   //Caption이 없는 부모 윈도우
            }
        ReleaseDC(hWnd, hDC);
        }
    }

LOCAL(VOID) DrawWindowFrameAllChild(HWND hWndPrnt)
    {
    HWND hWnd;

    for (hWnd=hWndPrnt->Child; hWnd!=NULL; hWnd=hWnd->Next)
        {
        DrawWindowFrame(hWnd);
        DrawWindowFrameAllChild(hWnd);
        }
    }




//-----------------------------------------------------------------------------
//      클라이언트 영역을 칠함
//-----------------------------------------------------------------------------
LOCAL(VOID) EraseWindowBkgnd(HWND hWnd)
    {
    HDC hDC;

    if ((hDC=GetDC(hWnd))!=NULL)
        {
        hDC->RPA=hWnd->PA;      //2021-08-21
        SendMessage(hWnd, WM_ERASEBKGND, (WPARAM)hDC, 0);
        ReleaseDC(hWnd, hDC);
        }
    }



LOCAL(VOID) EraseWindowBkgndAllChild(HWND hWndPrnt)
    {
    HWND hWnd;

    for (hWnd=hWndPrnt->Child; hWnd!=NULL; hWnd=hWnd->Next)
        {
        EraseWindowBkgnd(hWnd);
        EraseWindowBkgndAllChild(hWnd);
        }
    }




VOID WINAPI UpdateWindow(HWND hWnd)
    {
    if (IsVisible(hWnd)!=FALSE && IsRectEmpty(&hWnd->PA)==FALSE)
        {
        if (hWnd->EraseBkGndFg!=0)
            {
            HideCaret(hWnd);
            DrawWindowFrame(hWnd);
            EraseWindowBkgnd(hWnd);
            ShowCaret(hWnd);
            hWnd->EraseBkGndFg=0;
            }
        SendMessage(hWnd, WM_PAINT, 0, 0);
        }
    }


VOID WINAPI InvalidateRect(HWND hWnd, CONST RECT *AR, BOOL EraseBkFg)
    {
    if (hWnd!=NULL)
        {
        if (AR==NULL) GetClientRect(hWnd, &hWnd->PA);
        else          MyUnionRect(&hWnd->PA, AR);
        if (EraseBkFg) hWnd->EraseBkGndFg=TRUE;
        }
    }



///////////////////////////////////////////////////////////////////////////////
//          Window Class 관리
///////////////////////////////////////////////////////////////////////////////
typedef struct _WndClassListStruc
    {
    WNDCLASS  WC;
    struct _WndClassListStruc *Next;
    } WndClassListStruc;

static WndClassListStruc *WndClassList;


ATOM WINAPI RegisterClass(CONST WNDCLASS *WC)
    {
    WndClassListStruc *WCL;

    if ((WCL=AllocMemS(WndClassListStruc, MEMOWNER_RegisterClass))==NULL) return 0;
    WCL->WC=*WC;
    WCL->Next=WndClassList;
    WndClassList=WCL;
    return 1;
    }

#if (PCMODE>0)
LOCAL(VOID) ReleaseWndClassList()
    {
    HBRUSH hBr;
    WndClassListStruc *WCL;

    while (WndClassList!=NULL)
        {
        WCL=WndClassList;
        WndClassList=WndClassList->Next;
        hBr=WCL->WC.hbrBackground;
        if (hBr!=NULL && hBr!=WhiteBrush && hBr!=BlackBrush && hBr!=NullBrush && hBr!=BtnFaceBrush) //기본 브러시인지 확인
            DeleteObject(hBr);
        FreeMem(WCL);
        }
    }
#endif //(PCMODE>0)




//-----------------------------------------------------------------------------
//      모든 윈도우를 순회할 때 다음 윈도우를 리턴함
//-----------------------------------------------------------------------------
LOCAL(HWND) FindNextWindow(HWND hWnd)
    {
    if (hWnd->Child!=NULL) hWnd=hWnd->Child;
    else{
        for (;;)
            {
            if (hWnd->Next!=NULL) {hWnd=hWnd->Next; break;}
            if (hWnd->Parent==NULL) {hWnd=NULL; break;}
            hWnd=hWnd->Parent;
            }
        }
    return hWnd;
    }



//-----------------------------------------------------------------------------
//      지금까지 생성한 핸들목록 안에 들어 있는지 찾아봄
//-----------------------------------------------------------------------------
BOOL WINAPI IsWindow(HWND hWndChk)
    {
    BOOL Rslt=FALSE;
    HWND hWnd;

    if (hWndChk==NULL) goto ProcExit;
    for (hWnd=WindowList; hWnd!=NULL; hWnd=FindNextWindow(hWnd))
        {
        if (hWnd==hWndChk) {Rslt++; break;}
        }
    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      나를 포함 페어런트의 모든 윈도우 보이기 플래그가 켜저있는지 체크
//-----------------------------------------------------------------------------
BOOL WINAPI IsWindowVisibleII(HWND hWnd) {return IsVisible(hWnd);}



//-----------------------------------------------------------------------------
//      다른 윈도우가 가리지 않아서 모두 보이는 윈도우인지
//-----------------------------------------------------------------------------
BOOL WINAPI IsWindowVisible(HWND hWnd)
    {
    BOOL Rslt=FALSE;
    RECT R;

    if (IsWindow(hWnd)!=FALSE)
        {
        GetClientRect(hWnd, &R); R.right--; R.bottom--;
        ClientToScreen(hWnd, (POINT*)&R.left);
        if (WindowFromPoint(*(POINT*)&R.left)==hWnd) Rslt++;
        ClientToScreen(hWnd, (POINT*)&R.right);
        if (WindowFromPoint(*(POINT*)&R.right)==hWnd) Rslt++;
        Rslt=Rslt==2;
        }
    return Rslt;
    }


BOOL WINAPI IsWindowEnabled(HWND hWnd)
    {
    BOOL Rslt=FALSE;

    if (IsWindow(hWnd)!=FALSE)
        {
        for (;;)
            {
            if (hWnd->Style & WS_DISABLED) break;
            if (hWnd->Parent==NULL || (hWnd->Style & WS_POPUP)!=0) {Rslt++; break;}
            hWnd=hWnd->Parent;
            }
        }
    return Rslt;
    }


LOCAL(VOID) SetShowWindowFlag(HWND hWnd, BOOL IsShow)
    {
    //HWND   hWndChild, hWndBro;

    if (IsShow==FALSE) hWnd->Style&=~WS_VISIBLE;
    else               hWnd->Style|=WS_VISIBLE;
    /*
    if ((hWndChild=hWnd->Child)!=NULL)
        {
        for (hWndBro=hWndChild; hWndBro!=NULL; hWndBro=hWndBro->Next)
            SetShowWindowFlag(hWndBro, IsShow);
        }
    */
    }




//-----------------------------------------------------------------------------
//      DC메모리를 할당함
//-----------------------------------------------------------------------------
LOCAL(VOID) AllocDCMem(HWND hWnd)
    {
    if (hWnd->lpDCMem==NULL) hWnd->lpDCMem=(COLORREF*)AllocVMem((hWnd->WA.right-hWnd->WA.left)*(hWnd->WA.bottom-hWnd->WA.top)*sizeof(COLORREF), MEMOWNER_AllocDCMem);
    }



//-----------------------------------------------------------------------------
//      이 윈도우가 점유했던 영역을 다시 그리도록 함
//-----------------------------------------------------------------------------
LOCAL(VOID) RedrawMyOccupiedArea(HWND hWnd)
    {
    RECT R, WA;
    HWND hWndZ;
    HWNDZOTHERLIST *HZO;

    WA=hWnd->WA;

    //hWnd보다 위에 있는 윈도우가 가린부분을 제외함
    for (HZO=HwndZOther; HZO!=NULL; HZO=HZO->Next)
        {
        if (IsRectEmpty(&WA)) goto ProcExit;
        if ((hWndZ=HZO->hWnd)==hWnd) {HZO=HZO->Next; break;}
        if (IsVisible(hWndZ)==FALSE) continue;
        SubRect(&WA, &hWndZ->WA);
        }

    //hWnd를 가렸던 하위 윈도우를 그리게 함
    for (; HZO!=NULL; HZO=HZO->Next)
        {
        if (IsRectEmpty(&WA)) break;
        hWndZ=HZO->hWnd;
        if (IsVisible(hWndZ) && IntersectRect(&R, &hWndZ->WA, &WA)!=FALSE)
            {
            AllocDCMem(hWndZ);
            ScreenToClient(hWndZ, (POINT*)&R.left);
            ScreenToClient(hWndZ, (POINT*)&R.right);
            InvalidateRect(hWndZ, &R, TRUE);
            SubRect(&WA, &hWndZ->WA);
            }
        }

    ProcExit:;
    }




BOOL WINAPI ShowWindow(HWND hWnd, int CmdShow)
    {
    BOOL OldStat;

    if (IsWindow(hWnd)==FALSE) return FALSE;
    OldStat=IsVisible(hWnd);
    switch (CmdShow)
        {
        case SW_HIDE:
            if (OldStat!=FALSE)
                {
                SendMessage(hWnd, WM_ACTIVATE, WA_INACTIVE, 0);
                SetShowWindowFlag(hWnd, FALSE);
                if (hWnd->lpDCMem) {FreeMem(hWnd->lpDCMem); hWnd->lpDCMem=NULL;}
                RedrawMyOccupiedArea(hWnd);     //이 윈도우가 점유했던 영역을 다시 그림
                }
            break;

        case SW_SHOW:
            if (OldStat==FALSE)
                {
                if (hWnd->lpDCMem==NULL) AllocDCMem(hWnd);
                SetShowWindowFlag(hWnd, TRUE);
                SendMessage(hWnd, WM_ACTIVATE, WA_ACTIVE, 0);
                InvalidateRect(hWnd, NULL, FALSE);
                }
        }
    return OldStat;
    }




//-----------------------------------------------------------------------------
//      Z-Other 목록에서 삭제함
//-----------------------------------------------------------------------------
LOCAL(VOID) DelHwndViewList(HWND hWnd)
    {
    HWNDZOTHERLIST *Prev=NULL, *Curr, *Next;

    for (Curr=HwndZOther; Curr!=NULL; Curr=Curr->Next)
        {
        if (Curr->hWnd==hWnd)
            {
            Next=Curr->Next;
            if (Prev) Prev->Next=Next; else HwndZOther=Next;
            FreeMem(Curr);
            break;
            }
        Prev=Curr;
        }
    }



//-----------------------------------------------------------------------------
//      이미 있는 윈도우이면 Z-Other를 맨 앞으로 두고, 새로운 윈도우이면 맨앞에 추가함
//-----------------------------------------------------------------------------
LOCAL(VOID) SetHwndViewList(HWND hWnd)
    {
    HWNDZOTHERLIST *Prev, *Curr, *Find;

    Prev=Find=NULL;
    for (Curr=HwndZOther; Curr!=NULL; Curr=Curr->Next)
        {
        if (Curr->hWnd==hWnd)
            {
            Find=Curr;
            if (Prev==NULL) goto ProcExit;  //주어진 것이 맨앞이므로
            Prev->Next=Curr->Next;          //주어진 노드를 떼어냄
            break;
            }
        Prev=Curr;
        }

    if (Find==NULL)
        {
        if ((Find=AllocMemS(HWNDZOTHERLIST, MEMOWNER_SetHwndViewList))==NULL) goto ProcExit;
        Find->hWnd=hWnd;
        }
    Find->Next=HwndZOther;
    HwndZOther=Find;

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      대화상자를 윈도우 Handle을 저장함
//-----------------------------------------------------------------------------
LOCAL(BOOL) SetPopWindow(HWND hWnd)
    {
    int I, Rslt=FALSE;

    if (PopupWindowList[MAXPOPUPQTY-1]==NULL)
        {
        for (I=MAXPOPUPQTY-2; I>=0; I--) PopupWindowList[I+1]=PopupWindowList[I];
        PopupWindowList[0]=hWnd;
        Rslt++;
        }
    return Rslt;
    }


//-----------------------------------------------------------------------------
//      대화상자를 윈도우 목록에서 제거함
//-----------------------------------------------------------------------------
LOCAL(BOOL) DelPopWindow(HWND hWnd)
    {
    int I, Rslt=FALSE;

    if (PopupWindowList[0]==hWnd)
        {
        for (I=0; I<=MAXPOPUPQTY-2; I++) PopupWindowList[I]=PopupWindowList[I+1];
        PopupWindowList[MAXPOPUPQTY-1]=NULL;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              팝업윈도우가 있는지 알려줌
//-----------------------------------------------------------------------------
HWND WINAPI GetMostTopWindow()
    {
    return PopupWindowList[0];
    }



BOOL WINAPI DestroyWindow(HWND hWnd)
    {
    BOOL   IsVisiable;
    HWND   hWndChild, hWndPrnt, hWndPrev, hWndNext;

    if (IsWindow(hWnd)==FALSE) return FALSE;
    KillTimer(hWnd, 0);
    IsVisiable=IsVisible(hWnd);
    if ((hWnd->Style & WS_CHILD)==0) SoundEffect("DBC_2");

    while ((hWndChild=hWnd->Child)!=NULL) DestroyWindow(hWndChild);

    if (FocusWindow==hWnd) SendMessage(hWnd, WM_KILLFOCUS, 0, 0);
    SendMessage(hWnd, WM_DESTROY, 0, 0);

    hWndPrnt=hWnd->Parent;
    hWndNext=hWnd->Next;
    hWndPrev=hWnd->Prev;

    if (hWndPrnt!=NULL)
        {
        if (hWndPrnt->Child==hWnd) hWndPrnt->Child=hWndNext;
        }

    if (hWndPrev!=NULL) hWndPrev->Next=hWndNext;
    if (hWndNext!=NULL) hWndNext->Prev=hWndPrev;

    #if HWNDPROPERTY
    RELEASESINGLELINKEDLIST(PROPSTRUCT, hWnd->Prop)
    #endif
    if (IsVisiable) RedrawMyOccupiedArea(hWnd); //이 윈도우가 점유했던 영역을 다시 그림
    FreeMem(hWnd->lpDCMem);
    FreeMem((LPSTR)hWnd->Title);
    FreeMem(hWnd);

    DelHwndViewList(hWnd);
    ClearImportWindow(hWnd);
    DelPopWindow(hWnd);
    if (hWnd==hWndCapture) hWndCapture=NULL;
    if (hWnd==WindowList) WindowList=NULL;
    if (hWnd==hWndCaretOwner) hWndCaretOwner=NULL;
    if (FocusWindow==hWnd)
        {
        FocusWindow=NULL;       //WM_KILLFOCUS가 가지 않도록 (WM_DESTROY전에 위에서 보냄)
        SetFocus(hWndPrnt);
        }
    return TRUE;
    }



LRESULT WINAPI SendMessage(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)
    {
    if (IsWindow(hWnd)==FALSE) return 0;
    return hWnd->WC.lpfnWndProc(hWnd, Msg, wPrm, lPrm);
    }

LRESULT WINAPI CallWindowProc(WNDPROC WndProc, HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)
    {
    return WndProc(hWnd, Msg, wPrm, lPrm);
    }


VOID WINAPI PostQuitMessage(int RetCode)
    {
    PostMessage(NULL, WM_QUIT, RetCode, 0);
    }


BOOL WINAPI TranslateMessage(CONST MSG *Msg)
    {
    int  VkCode, Ascii;
    static CHAR KeyStat=0;

    #define AsciiVirtualKeyQty 30
    static BYTE VirtualKTbl[]=
                {
                '1','2','3','4','5','6','7','8','9','0',
                0xBD,0xBB,0xDB,0xDD,0xBA,0xDE,0xC0,0xDC,0xBC,0xBE,0xBF,
                VK_SPACE,VK_ESCAPE,VK_RETURN,VK_BACK,VK_TAB,VK_ADD,VK_SUBTRACT,VK_MULTIPLY,VK_NUMPAD5
                };
    static BYTE NoShiftAscii[]=
                {
                '1','2','3','4','5','6','7','8','9','0',
                '-','=','[',']',';','\'','`','\\',',','.','/',
                VK_SPACE,VK_ESCAPE,VK_RETURN,VK_BACK,VK_TAB,'+','-','*','5'
                };
    static BYTE ShiftAscii[]=
                {
                '!','@','#','$','%','^','&','*','(',')',
                '_','+','{','}',':','"','~','|','<','>','?',
                VK_SPACE,VK_ESCAPE,VK_RETURN,VK_BACK,VK_TAB,'+','-','*','5'
                };

    VkCode=Msg->wParam;
    if (Msg->message==WM_KEYUP)
        {
        if (VkCode==VK_SHIFT) KeyStat&=~KS_LEFTSHIFT;
        else if (VkCode==VK_CAPITAL) KeyStat&=~KS_CAPSLOCK;
        }
    if (Msg->message!=WM_KEYDOWN) return FALSE;
    if (VkCode==VK_SHIFT) {KeyStat|=KS_LEFTSHIFT; return FALSE;}
    if (VkCode==VK_CAPITAL) {KeyStat|=KS_CAPSLOCK; return FALSE;}

    if (VkCode>='A' && VkCode<='Z')
        {
        Ascii=VkCode;
        if ((KeyStat & KS_CAPSLOCK)==0) Ascii+=0x20;    //소문자로
        if (KeyStat & KS_LEFTSHIFT) Ascii^=0x20;
        }
    else{
        int I;
        if ((I=SearchByte((LPCSTR)VirtualKTbl, AsciiVirtualKeyQty, VkCode))==-1) return FALSE;
        Ascii= KeyStat & KS_LEFTSHIFT ? ShiftAscii[I]:NoShiftAscii[I];
        }
    PostMessage(Msg->hwnd, WM_CHAR, Ascii, Msg->lParam);
    return TRUE;
    }


LONG WINAPI DispatchMessage(CONST MSG *Msg)
    {
    return SendMessage(Msg->hwnd, Msg->message, Msg->wParam, Msg->lParam);
    }




HWND WINAPI CreateWindow(LPCSTR ClassName, LPCSTR Title, DWORD Style, int X, int Y, int Sx, int Sy,
                         HWND hWndParnt, HMENU hMenu, HINSTANCE hInst, LPVOID CreatePrms)
    {
    int    Size;
    HWND   hWnd, hChild;
    POINT  P;
    WndClassListStruc *WCL;
    CREATESTRUCT CS;
    static BYTE CallDepth;

    for (WCL=WndClassList; WCL!=NULL; WCL=WCL->Next)
        if (lstrcmpi(WCL->WC.lpszClassName, ClassName)==0) break;

    if (WCL==NULL) return NULL;
    if (hWndParnt!=NULL && IsWindow(hWndParnt)==FALSE) return NULL;

    Size=WCL->WC.cbWndExtra+ sizeof(HWNDSTRUCT)-sizeof(DWORD);  //-sizeof(DWORD): Extra 1개가 구조체에 기본적으로 있기 때문
    if ((hWnd=(HWND)AllocMem(Size, MEMOWNER_CreateWindowHwnd))==NULL) return NULL;
    ZeroMem(hWnd, Size);
    hWnd->WndExtraSize=WCL->WC.cbWndExtra;

    #if GUIDEBUG
    hWnd->StructSign=MKTAG('H', 'W', 'N', 'D');
    #endif

    if ((Style & WS_CHILD)==0) Style|=WS_VISIBLE;
    hWnd->Style=Style;
    SetRect(&hWnd->WA, X, Y, X+Sx, Y+Sy);
    if (hWndParnt!=NULL && (Style & WS_CHILD)!=0)
        {
        P.x=P.y=0;
        ClientToScreen(hWndParnt, &P);
        OffsetRect(&hWnd->WA, P.x, P.y);
        }

    hWnd->Title=CopyStr(Title, MEMOWNER_CreateWindowTitle);
    hWnd->WC=WCL->WC;
    hWnd->hMenu=hMenu;
    hWnd->Parent=hWndParnt;
    hWnd->Next=hWnd->Child=hWnd->Prev=NULL;

    if (hWndParnt==NULL)
        {
        if (WindowList!=NULL)
            {
            hWnd->Next=WindowList;
            WindowList->Prev=hWnd;
            }
        WindowList=hWnd;
        }
    else{
        hChild=hWndParnt->Child;
        hWndParnt->Child=hWnd;
        if (hChild!=NULL)
            {
            hWnd->Next=hChild;
            hChild->Prev=hWnd;
            }
        }
    GetClientRect(hWnd, &hWnd->PA);

    //if (lstrcmpi(ClassName, DlgClassName)==0) hWnd->PrntAreaPushedFg=PushScreen(hWnd->WA);
    //if ((Style & WS_CHILD)==0) hWnd->PrntAreaPushedFg=PushScreen(hWnd->WA);
    if (Style & WS_VISIBLE) AllocDCMem(hWnd);

    SetHwndViewList(hWnd);

    CallDepth++;

    CS.lpCreateParams=CreatePrms;
    CS.hInstance=hInst;
    CS.hMenu=hMenu;
    CS.hwndParent=hWndParnt;
    CS.cy=Sy;
    CS.cx=Sx;
    CS._y=Y;
    CS._x=X;
    CS.style=Style;
    CS.lpszName=Title;
    CS.lpszClass=ClassName;
    CS.dwExStyle=0;
    if (SendMessage(hWnd, WM_CREATE, 0, (LPARAM)&CS)==-1) {DestroyWindow(hWnd); hWnd=NULL; goto ProcExit;}
        //여기서 Child가 생성되고 그려지는 것이 문제임 (아직 Parent는 화면 초기화도 안한 싯점)

    if (Style & WS_VSCROLL)
        {
        CreateWindow("ScrollBar", "", SBS_VERT|WS_CHILD|WS_VISIBLE,
                      Sx-ScrollBarBtnSize, 0, ScrollBarBtnSize, Sy,
                      hWnd, (HMENU)(ScrollBarChildID+SB_VERT), HInst, NULL);
        }
    if (Style & WS_HSCROLL)
        {
        CreateWindow("ScrollBar", "", SBS_HORZ|WS_CHILD|WS_VISIBLE,
                      0, Sy-ScrollBarBtnSize, Sx, ScrollBarBtnSize,
                      hWnd, (HMENU)(ScrollBarChildID+SB_HORZ), HInst, NULL);
        }

    if (CallDepth==1 && (Style & WS_VISIBLE)!=0)   //CallDepth 부모의 바탕을 먼저 그리고 자식을 그리게 하기 위함, 부모의 바탕을 그리는 속도가 느린 경우 자식을 먼저 튀어나오면 보기 안좋음, 대신 부모의 바탕을 그릴 때 자식 윈도우의 힌색이 보임
        {
        DrawWindowFrame(hWnd);
        DrawWindowFrameAllChild(hWnd);
        EraseWindowBkgnd(hWnd);
        EraseWindowBkgndAllChild(hWnd);
        }

    if ((Style & (DS_MODALFRAME|WS_CHILD))==0) SetFocus(hWnd);
    if ((Style & WS_CHILD)==0) SoundEffect("DBO_2");

    ProcExit:
    CallDepth--;
    return hWnd;
    }



VOID WINAPI FillRectCol(HDC hDC, CONST RECT *AR, COLORREF Col)
    {
    int  Width, Height;
    RECT R;
    COLORREF *lpD;

    if (hDC==NULL || hDC->lpDCMem==NULL) goto ProcExit;
    if (AdjustDrawArea(hDC, &R, AR)==FALSE) goto ProcExit;

    Width=R.right-R.left;
    Height=R.bottom-R.top;

    lpD=GetDCMemPtr(hDC, R.left, R.top);
    while (Height--)
        {
        FillDWord(lpD, Width, Col);
        lpD+=hDC->WindowWidth;
        }

    SetDrawArea(hDC, &R);
    ProcExit:;
    }



VOID WINAPI FillRect(HDC hDC, CONST RECT *AR, HBRUSH hBr)
    {
    if (hBr!=NULL) FillRectCol(hDC, AR, hBr->Col);
    }


COLORREF WINAPI SetPixel(HDC hDC, int X, int Y, COLORREF Col)
    {
    RECT R;
    SetRect(&R, X,Y, X+1, Y+1);
    FillRectCol(hDC, &R, Col);
    return 0;
    }



LOCAL(VOID) DrawHLine(HDC hDC, int X, int Y, int Width, COLORREF Col)
    {
    RECT R;
    SetRect(&R, X,Y, X+Width, Y+1);
    FillRectCol(hDC, &R, Col);
    }



LOCAL(VOID) DrawVLine(HDC hDC, int X, int Y, int Height, COLORREF Col)
    {
    RECT R;
    SetRect(&R, X,Y, X+1, Y+Height);
    FillRectCol(hDC, &R, Col);
    }



//-----------------------------------------------------------------------------
//      Close 버튼 처리
//-----------------------------------------------------------------------------
LOCAL(VOID) CloseBtnProc(HWND hWnd, UINT Msg, LPARAM lPrm)
    {
    int   InRect;
    RECT  R;
    POINT P;

    GetWindowRect(hWnd, &R);
    OffsetRect(&R, -R.left, -R.top);
    InflateRect(&R, -2, -2);
    R.bottom=R.top+CYCAPTION;
    R.left=R.right-CXCLOSEBTN;

    P.x=LoInt16(lPrm);
    P.y=HiInt16(lPrm);
    InRect=PtInRect(&R, P);

    switch (Msg)
        {
        case WM_LBUTTONDOWN:
            if (InRect)
                {
                SetCapture(hWnd);
                DrawCloseBtnEx(hWnd, &R, TRUE);
                hWnd->SysBtnPushed=1;
                }
            break;

        case WM_MOUSEMOVE:
            if (hWnd->SysBtnPushed==0) break;
            DrawCloseBtnEx(hWnd, &R, InRect);
            break;

        case WM_LBUTTONUP:
            if (hWnd->SysBtnPushed==0) break;
            if (InRect) PostMessage(hWnd, WM_SYSCOMMAND, SC_CLOSE, 0);
            DrawCloseBtnEx(hWnd, &R, FALSE);
            ReleaseCapture();
            hWnd->SysBtnPushed=0;
            //break;
        }
    }



LRESULT WINAPI DefWindowProc(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)
    {
    PAINTSTRUCT PS;

    switch (Msg)
        {
        //case WM_SYSKEYDOWN: if (wPrm!=VK_F4) break;
        case WM_CLOSE: DestroyWindow(hWnd); break;

        case WM_ERASEBKGND:
            {
            RECT R;
            GetClientRect(hWnd, &R);
            FillRect((HDC)wPrm, &R, hWnd->WC.hbrBackground);
            return 1;
            }

        case WM_PAINT:
            BeginPaint(hWnd, &PS);
            EndPaint(hWnd, &PS);
            break;

        case WM_CTLCOLORBTN:
        case WM_CTLCOLORSTATIC:
            if (Msg==WM_CTLCOLORBTN)
                {
                SetTextColor((HDC)wPrm, COL_WINDOWTEXT);
                SetBkColor((HDC)wPrm, COL_3DFACE);
                }
            return (LRESULT)GetClassLong(hWnd, GCL_HBRBACKGROUND);

        case WM_GETTEXT:
            *(LPSTR)lPrm=0;
            if (hWnd->Title!=NULL)
                {
                lstrcpyn((LPSTR)lPrm, hWnd->Title, wPrm);
                return lstrlen((LPSTR)lPrm);
                }
            break;

        case WM_GETTEXTLENGTH:
            if (hWnd->Title!=NULL) return lstrlen(hWnd->Title);
            break;

        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_MOUSEMOVE:
            if ((hWnd->Style & WS_CAPTION)==WS_CAPTION) CloseBtnProc(hWnd, Msg, lPrm);
            break;

        case WM_SYSCOMMAND:
            if (wPrm==SC_CLOSE) PostMessage(hWnd, WM_CLOSE, 0, 0);
            break;

        case WM_SETTEXT:
            if (lPrm!=0)
                {
                FreeMem((LPVOID)hWnd->Title);
                if ((hWnd->Title=CopyStr((LPSTR)lPrm, MEMOWNER_WM_SETTEXT))!=NULL)
                    InvalidateRect(hWnd, NULL, FALSE);
                }
        }
    return 0;
    }


HWND WINAPI SetFocus(HWND hWnd)
    {
    HWND hWndOld=NULL;

    if (FocusWindow==hWnd) {hWndOld=hWnd; goto ProcExit;}
    if (IsWindow(hWnd)==FALSE) goto ProcExit;
    if (IsWindow(FocusWindow))
        {
        MSG Msg;

        Msg.hwnd=FocusWindow;
        Msg.message=WM_KILLFOCUS;
        Msg.wParam=(WPARAM)hWnd;
        Msg.lParam=0;
        HangulAutomata(&Msg);
        SendMessage(FocusWindow, WM_KILLFOCUS, (WPARAM)hWnd, 0);
        }

    hWndOld=FocusWindow;
    SendMessage(FocusWindow=hWnd, WM_SETFOCUS, (WPARAM)hWndOld, 0);

    ProcExit:
    return hWndOld;
    }


HWND WINAPI GetFocus()
    {
    if (FocusWindow!=NULL && IsWindow(FocusWindow)==FALSE) FocusWindow=NULL;
    return FocusWindow;
    }


HWND WINAPI GetParent(HWND hWnd)
    {
    if (IsWindow(hWnd)==FALSE) return NULL;
    return hWnd->Parent;
    }



HWND WINAPI GetWindow(HWND hWnd, UINT Rel)
    {
    HWND hWndTmp;

    if (IsWindow(hWnd)==FALSE) return NULL;
    switch (Rel)
        {
        case GW_HWNDFIRST:
            while ((hWndTmp=hWnd->Prev)!=NULL) hWnd=hWndTmp;
            return hWnd;

        case GW_HWNDLAST:
            while ((hWndTmp=hWnd->Next)!=NULL) hWnd=hWndTmp;
            return hWnd;

        case GW_HWNDNEXT:  return hWnd->Next;
        case GW_HWNDPREV:  return hWnd->Prev;
        case GW_CHILD:     return hWnd->Child;
        }
    return NULL;
    }




VOID WINAPI GetClientRect(HWND hWnd, RECT *R)
    {
    *R=hWnd->WA;
    MakeClientArea(hWnd, R);
    OffsetRect(R, -R->left, -R->top);
    }



VOID WINAPI GetWindowRect(HWND hWnd, RECT *R)
    {
    *R=hWnd->WA;
    }


DWORD WINAPI GetClassLong(HWND hWnd, int Offset)
    {
    if (Offset==GCL_HBRBACKGROUND) return (DWORD)hWnd->WC.hbrBackground;
    return 0;
    }


DWORD WINAPI SetClassLong(HWND hWnd, int Offset, DWORD New)     //원래는 모든 Class에 적용되어야 하나 여기서는 주어진 Window에만 영항을 받음
    {
    DWORD Old=0;

    if (Offset==GCL_HBRBACKGROUND)
        {
        Old=(DWORD)hWnd->WC.hbrBackground;
        hWnd->WC.hbrBackground=(HBRUSH)New;
        }
    return Old;
    }


int WINAPI GetClassName(HWND hWnd, LPSTR Buff, int BuffSize)
    {
    lstrcpyn(Buff, hWnd->WC.lpszClassName, BuffSize);
    return lstrlen(Buff);
    }


LONG WINAPI GetWindowLong(HWND hWnd, int Offset)
    {
    LONG Value=0;

    if (hWnd==NULL) goto ProcExit;
    switch (Offset)
        {
        case GWL_STYLE:   return hWnd->Style;
        case GWL_WNDPROC: return (LONG)hWnd->WC.lpfnWndProc;
        case GWL_ID:      return (LONG)hWnd->hMenu;
        case GWL_EXSTYLE: goto ProcExit;
        default:
            if (Offset+4>hWnd->WndExtraSize) break;
            Value=*(LONG*)((LPCBYTE)hWnd->ExtraMem+Offset);
        }
    ProcExit:
    return Value;
    }




LONG WINAPI SetWindowLong(HWND hWnd, int Offset, LONG New)
    {
    LONG Old=0;

    if (hWnd==NULL) goto ProcExit;
    switch (Offset)
        {
        case GWL_WNDPROC:
            Old=(LONG)hWnd->WC.lpfnWndProc;
            hWnd->WC.lpfnWndProc=(WNDPROC)New;
            break;

        case GWL_STYLE:
            Old=hWnd->Style;
            hWnd->Style=New;
            break;

        default:
            if (Offset+4>hWnd->WndExtraSize) break;
            Old=*(LONG*)((LPCBYTE)hWnd->ExtraMem+Offset);
            *(LONG*)((LPBYTE)hWnd->ExtraMem+Offset)=New;
        }
    ProcExit:
    return Old;
    }


VOID WINAPI SetWindowText(HWND hWnd, LPCSTR Text)
    {
    SendMessage(hWnd, WM_SETTEXT, 0, (LPARAM)Text);
    }


int WINAPI GetWindowText(HWND hWnd, LPSTR Buff, int BuffSize)
    {
    return (int)SendMessage(hWnd, WM_GETTEXT, BuffSize, (LPARAM)Buff);
    }


BOOL WINAPI EnableWindow(HWND hWnd, BOOL EnaFg)
    {
    HDC hDC;

    if (EnaFg) hWnd->Style&=~WS_DISABLED;
    else       hWnd->Style|=WS_DISABLED;
    if (EnaFg==FALSE && FocusWindow==hWnd)
        {
        SendMessage(hWnd, WM_KILLFOCUS, 0, 0);
        FocusWindow=NULL;
        }
    if (hWnd->Style & WS_CHILD) {InvalidateRect(hWnd, NULL, FALSE); UpdateWindow(hWnd);}
    else if ((hWnd->Style & WS_CAPTION)==WS_CAPTION)
        {
        hDC=GetWindowDC(hWnd);
        DrawDlgFrame(hWnd, hDC, FALSE);
        ReleaseDC(hWnd, hDC);
        }
    return TRUE;
    }


VOID WINAPI ClientToScreen(HWND hWnd, POINT *P)
    {
    RECT R;

    R=hWnd->WA;
    MakeClientArea(hWnd, &R);
    P->x+=R.left;
    P->y+=R.top;
    }


VOID WINAPI ScreenToClient(HWND hWnd, POINT *P)
    {
    RECT R;

    R=hWnd->WA;
    MakeClientArea(hWnd, &R);
    P->x-=R.left;
    P->y-=R.top;
    }



#define TotalTimerQty 32
typedef struct _TimerStruc
    {
    UINT ID;
    HWND hWndOwner;
    DWORD StartTime;
    DWORD TimeOut;
    } TimerStruc;

static TimerStruc WinTimer[TotalTimerQty];



UINT WINAPI SetTimer(HWND hWnd, UINT ID, UINT TimeOut, TIMERPROC TmrProc)
    {
    int Rslt=FALSE, I, NoUse, Same;

    NoUse=Same=-1;
    for (I=0; I<TotalTimerQty; I++)
        {
        if (Same<0 && WinTimer[I].hWndOwner==hWnd && WinTimer[I].ID==ID) Same=I;
        if (NoUse<0 && WinTimer[I].ID==0) NoUse=I;
        }

    if (NoUse>=0 || Same>=0)
        {
        I=(Same>=0) ? Same:NoUse;
        WinTimer[I].ID=ID;
        WinTimer[I].hWndOwner=hWnd;
        WinTimer[I].StartTime=GetTickCount();
        WinTimer[I].TimeOut=TimeOut;
        Rslt++;
        }
    else Printf("Using All Timer...\r\n");
    return Rslt;
    }


BOOL WINAPI KillTimer(HWND hWnd, UINT ID)
    {
    int Rslt=FALSE, I;

    for (I=0; I<TotalTimerQty; I++)
        {
        if (WinTimer[I].hWndOwner==hWnd && (ID==0 || WinTimer[I].ID==ID))
            {
            WinTimer[I].ID=0;
            Rslt=TRUE;
            //break;  <- ID==0 일경우에는 hWnd의 모든 타이머를 죽여야 하므로
            }
        }
    return Rslt;
    }



LOCAL(VOID) CheckTimer()
    {
    int   I;
    DWORD CurrTime;

    CurrTime=GetTickCount();
    for (I=0; I<TotalTimerQty; I++)
        if (WinTimer[I].ID!=0)
            {
            if (CurrTime-WinTimer[I].StartTime>=WinTimer[I].TimeOut)
                {
                WinTimer[I].StartTime=CurrTime;
                PostMessage(WinTimer[I].hWndOwner, WM_TIMER, WinTimer[I].ID, 0);
                }
            }
    }



HGDIOBJ WINAPI GetStockObject(int Object)
    {
    switch (Object)
        {
        case WHITE_BRUSH: return WhiteBrush;
        case BLACK_BRUSH: return BlackBrush;
        case NULL_BRUSH:  return NullBrush;
        case WHITE_PEN:   return WhitePen;
        case BLACK_PEN:   return BlackPen;
        case NULL_PEN:    return NullPen;
        case DEFAULT_GUI_FONT: return hFontDef;
        }
    return NULL;
    }


HBRUSH WINAPI CreateSolidBrush(COLORREF Col)
    {
    HBRUSH hBr;

    if ((hBr=AllocMemS(HBRUSHStruc, MEMOWNER_CreateSolidBrush))==NULL) return NULL;
    hBr->GdiKind=GDIK_BRUSH;
    hBr->Style=SOLID_FILL;
    hBr->Col=Col;
    return hBr;
    }



HBRUSH WINAPI CreateHatchBrush(int Style, COLORREF Col)
    {
    HBRUSH hBr;

    if ((hBr=AllocMemS(HBRUSHStruc, MEMOWNER_CreateHatchBrush))==NULL) return NULL;
    hBr->GdiKind=GDIK_BRUSH;
    hBr->Style=Style;
    hBr->Col=Col;
    return hBr;
    }



HPEN WINAPI CreatePen(int Style, int Width, COLORREF Col)
    {
    HPEN hPen;

    if ((hPen=AllocMemS(HPENStruc, MEMOWNER_CreatePen))==NULL) return NULL;
    hPen->GdiKind=GDIK_PEN;
    hPen->Style=Style;
    hPen->Width=Width;
    hPen->Col=Col;
    return hPen;
    }


HGDIOBJ WINAPI SelectObject(HDC hDC, HGDIOBJ hObj)
    {
    HGDIOBJ hObjOld=NULL;

    if (CompMemStr(((FONTFILEHEADER*)hObj)->FileID, FONTHEADERSIGN)==0)
        {
        hObjOld=hDC->hFont;
        hDC->hFont=(HFONT)hObj;
        }
    else{
        switch (((HPEN)hObj)->GdiKind)
            {
            case GDIK_PEN:
                hObjOld=hDC->hPen;
                hDC->hPen=(HPEN)hObj;
                break;

            case GDIK_BRUSH:
                hObjOld=hDC->hBrush;
                hDC->hBrush=(HBRUSH)hObj;
                //break;
            }
        }
    return hObjOld;
    }




BOOL WINAPI DeleteObject(HGDIOBJ hGdi)
    {
    return FreeMem((LPVOID)hGdi)==MA_OK;
    }



int WINAPI GetObject(HGDIOBJ hGObj, int BuffSize, LPVOID Buff)
    {
    int ColBits;
    BITMAPINFOHEADER *BIH;

    if (hGObj!=NULL)
        {
        BIH=(BITMAPINFOHEADER*)((LPCBYTE)hGObj+12);     //sizeof(BITMAPFILEHEADER)은 14인데 앞에 2Byte를 뺀 FileData이기 때문
        ZeroMem(Buff, BuffSize);
        ColBits=BIH->biPlanes*BIH->biBitCount;
        ((BITMAP*)Buff)->bmWidth      =BIH->biWidth;
        ((BITMAP*)Buff)->bmHeight     =BIH->biHeight;
        ((BITMAP*)Buff)->bmWidthBytes =GetBmp1LineBytes(BIH->biWidth, ColBits);
        ((BITMAP*)Buff)->bmPlanes     =1;
        ((BITMAP*)Buff)->bmBitsPixel  =ColBits;
        return BuffSize;
        }
    return 0;
    }



//-----------------------------------------------------------------------------
//      주어진 패턴을 단식 메모리에 복사함
//-----------------------------------------------------------------------------
LOCAL(VOID) CopyMonoBits(LPBYTE lpDest, LPCBYTE lpSrcBits, int X, int Width)
    {
    int Byt, DestBit, SrcBit;

    SrcBit=0x80;
    lpDest+=X>>3;
    DestBit=0x80>>(X&7);
    while (Width--)
        {
        Byt=lpDest[0];
        if (lpSrcBits[0] & SrcBit) Byt|=DestBit; else Byt&=~DestBit;
        lpDest[0]=Byt;

        if ((SrcBit>>=1)==0)  {lpSrcBits++; SrcBit=0x80;}
        if ((DestBit>>=1)==0) {lpDest++; DestBit=0x80;}
        }
    }




VOID WINAPI CreateCaret(HWND hWnd, HBITMAP NoUse, int Sx, int Sy)
    {
    DWORD  CursPtn=~0;
    LPBYTE lp;

    hWndCaretOwner=hWnd;
    CaretSizeX=Sx;
    CaretSizeY=Sy;
    CaretViewCnt=0;
    CaretFlashFg=0;

    ZeroMem(lp=CaretImage, sizeof(CaretImage));
    while (Sy--)
        {
        CopyMonoBits(lp, (LPBYTE)&CursPtn, 0, Sx);
        lp+=4;
        }
    }



VOID WINAPI DestroyCaret(VOID)
    {
    hWndCaretOwner=NULL;
    CaretViewCnt=0;
    CaretFlashFg=0;
    }



//-----------------------------------------------------------------------------
//      XPos,YPos에 커서를 표시한다
//-----------------------------------------------------------------------------
LOCAL(VOID) CaretFlash()
    {
    POINT P;

    ShowCursor(FALSE);
    P.x=CaretPosX;
    P.y=CaretPosY;
    ClientToScreen(hWndCaretOwner, &P);
    LCD_XorBits2(P.x, P.y, CaretSizeX, CaretSizeY, 4, CaretImage);
    ShowCursor(TRUE);
    CaretFlashFg^=1;
    }



//-----------------------------------------------------------------------------
//      커서를 보이거나 안보이게 한다
//-----------------------------------------------------------------------------
VOID WINAPI HideCaret(HWND hWnd)
    {
    if (hWndCaretOwner==hWnd)
        {
        if (--CaretViewCnt==0)
            {
            if (CaretFlashFg!=0) CaretFlash();
            }
        }
    }

VOID WINAPI ShowCaret(HWND hWnd)
    {
    if (hWndCaretOwner==hWnd)
        {
        if (++CaretViewCnt==1)
            {
            if (CaretFlashFg==0) CaretFlash();          //캐럿이 표시되어 있으면 끄고
            }
        }
    }


VOID WINAPI SetCaretPos(int X, int Y)
    {
    if (hWndCaretOwner!=NULL)
        {
        if (CaretFlashFg!=0) CaretFlash();              //캐럿이 표시되어 있으면 끄고
        CaretPosX=X;
        CaretPosY=Y;
        if (CaretViewCnt>0) CaretFlash();
        }
    }

VOID WINAPI GetCaretPos(POINT *P)
    {
    P->x=CaretPosX;
    P->y=CaretPosY;
    }




//-----------------------------------------------------------------------------
//              커서를 일정시간마다 깜박인다
//-----------------------------------------------------------------------------
LOCAL(VOID) CaretTimeDisp()
    {
    DWORD CurrTime;
    static DWORD OldTime;

    if (hWndCaretOwner!=NULL && CaretViewCnt>0)
        {
        CurrTime=GetTickCount();
        if (CurrTime-OldTime>=500)
            {
            OldTime=CurrTime;
            CaretFlash();
            }
        }
    }



int WINAPI SetBkMode(HDC hDC, int Mode)
    {
    int OldMode;

    OldMode=hDC->BkMode;
    hDC->BkMode=Mode;
    return OldMode;
    }



#define LeftMouseBtn    0x01
#define RightMouseBtn   0x02
#define MiddleMouseBtn  0x04


#define MsgQueQty 16
static int MsgQGetPos, MsgQPutPos;
static MSG MsgQue[MsgQueQty];

#if (PCMODE>0)
#define DefCriticalVar
static CRITICAL_SECTION CS_MsgQue;
LOCAL(VOID) LockMsgQue(VOID)        {EnterCriticalSection(&CS_MsgQue);}
LOCAL(VOID) UnlockMsgQue(VOID)      {LeaveCriticalSection(&CS_MsgQue);}
LOCAL(VOID) InitMsgQueLock(VOID)    {InitializeCriticalSection(&CS_MsgQue);}
LOCAL(VOID) ReleaseMsgQueLock(VOID) {DeleteCriticalSection(&CS_MsgQue);}
#else
#define DefCriticalVar  JOS_CRITICAL_VAR
#define LockMsgQue      JOS_ENTER_CRITICAL
#define UnlockMsgQue    JOS_EXIT_CRITICAL
#define InitMsgQueLock()
#define ReleaseMsgQueLock()
#endif


LOCAL(BOOL) GetMsgQue(MSG *Msg, UINT fuRemove)
    {
    BOOL Rslt=FALSE;
    DefCriticalVar;

    LockMsgQue();
    if (MsgQGetPos!=MsgQPutPos) //읽을 곳과 넣을 위치가 같으면 빈것임
        {
        CopyMem(Msg, MsgQue+MsgQGetPos, sizeof(MSG));
        if (fuRemove==PM_REMOVE)
            {
            if (++MsgQGetPos>=MsgQueQty) MsgQGetPos=0;
            }
        Rslt++;
        }
    UnlockMsgQue();
    return Rslt;
    }



BOOL WINAPI PostMessage(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)
    {
    int NextPutPos, PrevPutPos, Rslt=FALSE; //, GetPos;
    MSG *M;
    DefCriticalVar;

    LockMsgQue();
    if (Msg==WM_MOUSEMOVE)          //큐의 마지막에 MOUSEMOVE 이면 오버라이팅
        {
        if (MsgQGetPos!=MsgQPutPos)
            {
            if ((PrevPutPos=MsgQPutPos-1)<0) PrevPutPos=MsgQueQty-1;
            M=MsgQue+PrevPutPos;
            if (M->hwnd==hWnd && M->message==WM_MOUSEMOVE) goto PutMsg;
            }
        }
    #if 0   //GUI가 정체되면 CheckTimer()도 처리되지 않음
    else if (Msg==WM_TIMER)         //같은 타이머인데 Q에 있으면 넣지 않음 (정체된 타이머는 의미가 없음)
        {
        GetPos=MsgQGetPos;
        while (GetPos!=MsgQPutPos)  //읽을 곳과 넣을 위치가 같으면 빈것임
            {
            M=MsgQue+GetPos;
            if (M->hwnd==hWnd && M->message==Msg && M->wParam==wPrm) goto PostMsgQt;
            if (++GetPos>=MsgQueQty) GetPos=0;
            }
        }
    #endif

    if ((NextPutPos=MsgQPutPos+1)>=MsgQueQty) NextPutPos=0;
    if (NextPutPos!=MsgQGetPos)     //다음 넣을 곳이 읽을 곳과 같으면 꽉참
        {
        M=MsgQue+MsgQPutPos; MsgQPutPos=NextPutPos;
        M->hwnd=hWnd;
        M->message=Msg;
        PutMsg:
        M->wParam=wPrm;
        M->lParam=lPrm;
        //M->time=GetTickCount();
        Rslt++;
        }
    //PostMsgQt:
    UnlockMsgQue();

    return Rslt;
    }



HWND WINAPI SetCapture(HWND hWnd)
    {
    HWND hWndOldCap;

    hWndOldCap=hWndCapture;
    hWndCapture=hWnd;
    return hWndOldCap;
    }


VOID WINAPI ReleaseCapture()
    {
    hWndCapture=NULL;
    }

HWND WINAPI GetCapture()
    {
    return hWndCapture;
    }



//-----------------------------------------------------------------------------
//              주어진 스크린좌표위에 있는 윈도우를 알려줌
//-----------------------------------------------------------------------------
HWND WINAPI WindowFromPoint(POINT P)
    {
    HWND   hWnd=NULL;
    HWNDZOTHERLIST *HZO;

    for (HZO=HwndZOther; HZO!=NULL; HZO=HZO->Next)
        {
        if (IsVisible(HZO->hWnd)!=FALSE && PtInRect(&HZO->hWnd->WA, P)!=FALSE) {hWnd=HZO->hWnd; break;}
        }
    return hWnd;
    }



#if TOUCHPADONOFF
//-----------------------------------------------------------------------------
//              주어진 스크린좌표위에 있는 윈도우를 알려줌
//-----------------------------------------------------------------------------
LOCAL(HWND) GetMouseOwner(POINT P)
    {
    return hWndCapture!=NULL ? hWndCapture:WindowFromPoint(P);
    }
#endif


/*
//-----------------------------------------------------------------------------
//              MouseEvent를 발생시킴
//         함수명은 WIN32와 같으나 인자는 다름
//-----------------------------------------------------------------------------
VOID WINAPI mouse_event(UINT Msg, int X, int Y)
    {
    HWND   hWnd; //, hWndKbd;
    LPARAM lPrm;

    //if ((hWndKbd=hWndCapture)==NULL) hWndKbd=GetFocus();

    CurrMousePos.x=X;
    CurrMousePos.y=Y;
    if ((hWnd=GetMouseOwner(CurrMousePos))!=NULL)
        {
        LoWord(lPrm)=X-hWnd->WA.left;
        HiWord(lPrm)=Y-hWnd->WA.top;

        //if (hWndScrKbd==NULL && hWndKbd!=NULL && Msg==WM_LBUTTONDOWN)
        //    PostMessage(hWndKbd, WM_KEYUP, VK_LBUTTONDOWN, 0x80000001L);
        PostMessage(hWnd, Msg, 0, lPrm);
        if (Msg==WM_LBUTTONDOWN) {MessageBeep(-1); Delay1ms(25);}
        }
    }
*/


//-----------------------------------------------------------------------------
//              모든 윈도우를 업데이트함
//-----------------------------------------------------------------------------
VOID WINAPI UpdateAllWindow(VOID)
    {
    HWND hWnd;

    for (hWnd=WindowList; hWnd!=NULL; hWnd=FindNextWindow(hWnd)) UpdateWindow(hWnd);
    }



#define LeftMouseBtn    0x01
//-----------------------------------------------------------------------------
//              입력 이벤트를 수집함
//-----------------------------------------------------------------------------
LOCAL(VOID) CheckEvent()
    {
    int    Rslt;
    HWND   hWnd;
    #if TOUCHPADONOFF
    BOOL   PosChanged;
    BYTE   XorStat, MousBtnStat;
    POINT  P;
    LPARAM lPrm;
    static BYTE OldBtnStat;
    static POINT OldMousePos;
    #endif

    CheckTimer();

    //키체크
    if ((Rslt=GetKey())>=0)
        {
        if (KeyProcHook(Rslt)==FALSE &&
            (hWnd=hWndCapture!=NULL ? hWndCapture:GetFocus())!=NULL)
            {
            if (IsWindowEnabled(hWnd)) PostMessage(hWnd, WM_KEYDOWN, Rslt, 1);
            //LongByte2(lPrm)=HiByte(Rslt);
            //PostMessage(hWnd, KeyStat & KS_ALT ? WM_SYSKEYDOWN:WM_KEYDOWN, VtKeyCodeTbl[Rslt>>8], lPrm);
                //lPrm의 하위는 눌린횟수가 나가지만 여기서는 아스키코드가 나감니다
            }
        }

    #if TOUCHPADONOFF
    MousBtnStat=GetTouchStatus(&P);
    XorStat=MousBtnStat ^ OldBtnStat;
    PosChanged=OldMousePos.x!=P.x || OldMousePos.y!=P.y;
    if (PosChanged || XorStat)
        {
        OldMousePos=P; OldBtnStat=MousBtnStat;

        if ((hWnd=GetMouseOwner(P))!=NULL && IsWindowEnabled(hWnd))
            {
            P.x-=hWnd->WA.left;
            P.y-=hWnd->WA.top;
            lPrm=(P.y<<16)+(P.x & 0xFFFF);

            if (XorStat & LeftMouseBtn)
                {
                PostMessage(hWnd, WM_MOUSEACTIVATE, 0, 0);
                PostMessage(hWnd, MousBtnStat & LeftMouseBtn ? WM_LBUTTONDOWN:WM_LBUTTONUP, 0, lPrm);
                if (MousBtnStat & LeftMouseBtn) {MessageBeep(~0); Sleep(25);}
                }
            else if (PosChanged)
                {
                if (MousBtnStat) PostMessage(hWnd, WM_MOUSEMOVE, 0, lPrm);
                }
            }
        }
    #endif //TOUCHPADONOFF

    UpdateAllWindow();
    }



BOOL WINAPI PeekMessage(MSG *Msg, HWND hWnd, UINT MsgFilterMin, UINT MsgFilterMax, UINT RemoveMsg)
    {
    BOOL Rslt;

    CaretTimeDisp();
    if ((Rslt=GetMsgQue(Msg, RemoveMsg))==FALSE)
        {
        CheckEvent();
        Rslt=GetMsgQue(Msg, RemoveMsg);
        }
    return Rslt;
    }



BOOL WINAPI GetMessage(MSG *Msg, HWND hWnd, UINT MsgFilterMin, UINT MsgFilterMax)
    {
    #if DEBUGMESSAGE
    LPCSTR lp;
    //CHAR  Buff[40];
    #endif

    while (PeekMessage(Msg, hWnd, MsgFilterMin, MsgFilterMax, PM_REMOVE)==0)
        {
        JWUI_IdleHook();
        Sleep(1);
        }

    #if DEBUGMESSAGE
    lp=NullStr;
    switch (Msg->message)
        {
        //case WM_MOUSEMOVE:    lp="WM_MOUSEMOVE"; break;
        //case WM_LBUTTONDOWN:  lp="WM_LBUTTONDOWN"; break;
        //case WM_LBUTTONUP:    lp="WM_LBUTTONUP"; break;
        //case WM_TIMER:        lp="WM_TIMER"; break;
        //case WM_PAINT:        lp="WM_PAINT"; break;
        //case WM_ERASEBKGND:   lp="WM_ERASEBKGND"; break;
        case WM_COMMAND:        lp="WM_COMMAND"; break;
        //default:              wsprintf(lp=Buff, "WM_%04X", Msg->message);
        }
    if (lp[0]!=0)
        {
        CHAR Buff[10];
        GetClassName(Msg->hwnd, Buff, sizeof(Buff));
        Printf("%-10s %-14s %08X(%d,%d) %08X(%d,%d)\r\n", Buff, lp,
                      Msg->wParam, LoInt16(Msg->wParam), HiInt16(Msg->wParam),
                (UINT)Msg->lParam, LoInt16(Msg->lParam), HiInt16(Msg->lParam));
        }

    //Print("Popup:");
    //for (int I=0; I<MAXPOPUPQTY; I++) Printf(" %04X", PopupWindowList[I]);
    //Print(CrLfStr);
    #endif //DEBUGMESSAGE

    if (Msg->message==WM_KEYDOWN && Msg->wParam>=' ' && Msg->wParam<=0x7F) SoundEffect("KEY_11");

    return Msg->message==WM_QUIT ? FALSE:TRUE;
    }



int WINAPI GetDeviceCaps(HDC hDC, int Capability)
    {
    int Rslt=0;

    switch (Capability)
        {
        case HORZRES: Rslt=LCD_LogResolutionX; break;
        case VERTRES: Rslt=LCD_LogResolutionY; break;
        case BITSPIXEL: Rslt=1; break;
        case PLANES:  Rslt=4; //break;
        }
    return Rslt;
    }



int WINAPI GetSystemMetrics(int Idx)
    {
    int Rslt=0;

    switch (Idx)
        {
        case SM_CXSCREEN:   Rslt=LCD_LogResolutionX; break;
        case SM_CYSCREEN:   Rslt=LCD_LogResolutionY; break;
        case SM_CYHSCROLL:
        case SM_CXVSCROLL:  Rslt=ScrollBarBtnSize; break;
        case SM_CXEDGE:
        case SM_CYEDGE:     Rslt=EDGE3DTHICK; //break;
        }
    return Rslt;
    }



COLORREF WINAPI GetSysColor(int Idx)
    {
    COLORREF Rslt=0;

    switch (Idx)
        {
        case COLOR_WINDOW:          Rslt=COL_WHITE; break;
        case COLOR_WINDOWTEXT:      Rslt=COL_BLACK; break;
        case COLOR_HIGHLIGHT:       Rslt=COL_BLUE; break;
        case COLOR_HIGHLIGHTTEXT:   Rslt=COL_YELLOW; break;
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      사각형을 그립니다. 왼쪽위와 오른쪽아래를 다른색으로
//-----------------------------------------------------------------------------
VOID WINAPI DrawTwoColRect(HDC hDC, RECT *AR, COLORREF Col1, COLORREF Col2, UINT Mode)
    {
    RECT R;

    R=*AR;
    if (Mode & DTCR_Top)    DrawHLine(hDC, R.left, R.top, R.right-R.left, Col1);
    if (Mode & DTCR_Left)   DrawVLine(hDC, R.left, R.top, R.bottom-R.top, Col1);
    if (Mode & DTCR_Right)  DrawVLine(hDC, R.right-1, R.top, R.bottom-R.top, Col2);
    if (Mode & DTCR_Bottom) DrawHLine(hDC, R.left, R.bottom-1, R.right-R.left, Col2);
    }





BOOL WINAPI Rectangle(HDC hDC, int X1, int Y1, int X2, int Y2)
    {
    RECT   R;
    HPEN   hPen;
    HBRUSH hBr;

    SetRect(&R, X1,Y1, X2,Y2);

    if (hDC->hPen!=NULL)
        {
        if (IsRectEmpty(&R)) goto ProcExit;
        hPen=hDC->hPen;
        if (hPen->Style!=-1) DrawTwoColRect(hDC, &R, hPen->Col, hPen->Col, DTCR_Box);
        }

    if (hDC->hBrush!=NULL)
        {
        hBr=hDC->hBrush;
        if (hBr->Style!=-1)
            {
            InflateRect(&R, -1, -1);
            if (IsRectEmpty(&R)) goto ProcExit;
            FillRectCol(hDC, &R, hBr->Col);
            }
        }
    ProcExit:
    return 0;
    }



//-----------------------------------------------------------------------------
//      메모리를 할당하고 파일을 로딩하여 메모리포인터를 리턴
//-----------------------------------------------------------------------------
LPBYTE WINAPI LoadFile(LPCSTR FileName, int MemOwner, int *lpFileSize)
    {
    #if 1
    int Rslt=FALSE, FileSize;
    HFILE hFile;
    LPBYTE lpMem=NULL;

    if ((hFile=_lopen(FileName, OF_READ))==HFILE_ERROR) goto ProcExit;
    if ((FileSize=GetFileSize(hFile))<=0) goto ProcExit;
    if ((lpMem=(LPBYTE)AllocVMem(FileSize+1, MemOwner))==NULL) goto ProcExit;
    if (_lread(hFile, lpMem, FileSize)!=FileSize) goto ProcExit;
    lpMem[FileSize]=0;
    if (lpFileSize) *lpFileSize=FileSize;
    Rslt++;

    ProcExit:
    _lclose(hFile);
    if (Rslt==FALSE) {FreeMem(lpMem); lpMem=NULL;}
    return lpMem;
    #else       //리소스를 덩어리 파일로 만들어 코드에 붙인 경우 처리
    HFILE  hFile;
    LPBYTE lpMem=NULL;

    if ((hFile=_lopen(FontName, OF_READ))!=HFILE_ERROR)
        {
        lpMem=MapViewOfFile(hFile);
        *lpFileSize=GetFileSize(hFile);
        _lclose(hFile);
        }
    return lpMem;
    #endif
    }



HFONT WINAPI LoadFont(LPCSTR FontName)
    {
    int  FileSize;
    CHAR FilePath[FILENAMEBUFFMAX];

    MakeUIPath(FilePath, FontName);
    return (HFONT)LoadFile(FilePath, MEMOWNER_LoadFont, &FileSize);
    }



//-----------------------------------------------------------------------------
//      한글입력 시 유효한 글자인지 판단해줌
//-----------------------------------------------------------------------------
BOOL WINAPI IsValidHanCha(UINT WCh)
    {
    int ChOrder;
    return LCD_GetCharWidth(hFontDef, WCh, &ChOrder);
    }



//-----------------------------------------------------------------------------
//      주어진 문자열의 높이와 폭을 구해 줍니다
//      StrLen은 문자수가 아니고 UTF8문자열의 Bytes수임
//-----------------------------------------------------------------------------
BOOL WINAPI GetTextExtentPoint32(HDC hDC, LPCSTR Str, int StrLen, SIZE *S)
    {
    int   Rslt;
    HFONT hFont;

    S->cx=S->cy=Rslt=0;
    if ((hFont=hDC->hFont)!=NULL)
        {
        LCD_GetTextExtent(Str, StrLen, S, hFont);
        Rslt++;
        }
    return Rslt;
    }


BOOL WINAPI MyGetTextExtent(HDC hDC, LPCSTR Str, SIZE *S)
    {
    return GetTextExtentPoint32(hDC, Str, lstrlen(Str), S);
    }



//-----------------------------------------------------------------------------
//      한 문자를 표시함
//      (안티알리아싱 글꼴 사용할 때 글자폭보다 1픽셀 메모리를 더 사용함에 주의)
//-----------------------------------------------------------------------------
LOCAL(int) GetFontData(LPBYTE FontBuff, int LineWidth, UINT WCh, HFONT hFont)
    {
    int     X, ChOrder, Width, Height, BytesPerLine, FontType;
    volatile LPBYTE  lpD;           //volatile을 안붙이면 FontBuff가 비디오 메모리인데 F7인데도 불구하고 Align을 맞추어야 해서 컴파일러가 최적화하면 화면이 번쩍거리고 QSPI가 먹통되고 이상한 버그가 생김
    volatile LPCBYTE lpS, lpBits;   //HFONT 도 비디오 메모리임

    FontType=hFont->Kind & FK_KINDMASK;
    if ((Width=LCD_GetCharWidth(hFont, WCh, &ChOrder))==0) goto ProcExit;

    lpBits=hFont->BitsDataLoc + (LPCBYTE)hFont;
    if ((BytesPerLine=hFont->BytesPerLine)==0)  //버전3글꼴
        {
        FONTBITSHEADER *FBH;

        lpBits=((DWORD*)lpBits)[ChOrder] + (LPCBYTE)hFont;
        FBH=(FONTBITSHEADER*)lpBits;
        lpBits+=FBH->HeadSize;
        BytesPerLine=FBH->BytesPerLine;
        FontBuff+=FBH->OffsetY*LineWidth;
        Height=FBH->LineQty;
        }
    else{
        Height=hFont->Height;
        lpBits+=BytesPerLine*Height*ChOrder;
        }

    while (Height--)
        {
        int Byt=0, Pxl;
        lpS=lpBits;
        lpD=FontBuff;
        if (FontType==FK_UNICODE16GRAY)
            {
            for (X=0; X<=Width; X++,Byt<<=4)    //X<=Width <-안티 알리아싱 된 마지막 픽셀까지 넣기 위함
                {
                if ((X&1)==0) Byt=*lpS++;
                Pxl=(Byt>>4) & 0x0F;
                if (Pxl>*lpD) *lpD=Pxl;         //안티알리아싱 된글자들이 1픽셀이 겹치기 때문, 이걸 안해주면 아랍문자가 1픽셀 떨어진 것처럼 보임
                lpD++;
                }
            }
        else{
            for (X=0; X<Width; X++,Byt<<=1)
                {
                if ((X&7)==0) Byt=*lpS++;
                *lpD++=(Byt & 0x80) ? 1:0;
                }
            }
        lpBits+=BytesPerLine;
        FontBuff+=LineWidth;
        }

    ProcExit:
    return Width;
    }



//-----------------------------------------------------------------------------
//      문자열을 DC에 출력함
//-----------------------------------------------------------------------------
BOOL WINAPI TextOut(HDC hDC, int DestX, int DestY, LPCSTR Str, int StrLen)
    {
    int   Len, Rslt=FALSE, X, SrcX, SrcY, Width, Height, FontType, TxR,TxG,TxB, BkR,BkG,BkB,
          WCh, FontBuffWidth, FontBuffHeight;
    #ifdef ARABIC_EN
    int    ChaPos=CP_FRONT, IsFirst=1;
    volatile LPCSTR Start;      //volatile을 안하면 왜 화면이 번쩍거리는지 알 수가 없음
    #endif
    SIZE  S;
    RECT  R, PA;
    HFONT hFont;
    COLORREF TextCol, BkGndCol, *lpD, *lpDCM;
    LPBYTE   Bits, FontMem=NULL;
    volatile LPBYTE lpS;        //비디오 메모리라서 AlignAccess를 해야하기에 혹시나 최적화에서 16비트 억세스를 한다든지 하면 문제가 됨

    if (hDC==NULL || hDC->lpDCMem==NULL || (hFont=hDC->hFont)==NULL || StrLen<=0) goto ProcExit;
    if (GetTextExtentPoint32(hDC, Str, StrLen, &S)==FALSE) goto ProcExit;
    FontBuffWidth=S.cx+1;                       //안티 알리아싱 된 추가 픽셀까지 넣기 위함
    FontBuffHeight=S.cy;
    if ((FontMem=(LPBYTE)AllocVMem(Len=FontBuffWidth*FontBuffHeight, MEMOWNER_TextOut))==NULL) goto ProcExit;
    ZeroMem(FontMem, Len);

    #ifdef ARABIC_EN
    X=FontBuffWidth-1;                          //-1은 안티 알리아싱된 픽셀을 위한 공간임
    #else
    X=0;
    #endif
    while (StrLen>0)
        {
        WCh=GetCharU8(Str, &Len);
        if (Len>StrLen) break;
        Str+=Len;
        StrLen-=Len;

        #ifdef ARABIC_EN
        if (IsSpaceCha(WCh) || IsArabicCha(WCh))
            {
            if (IsArabicVowel(WCh))             //아랍어 모음인가?
                {
                if (IsFirst) continue;          //처음부터 모음이 나오면 무시
                if (WCh!=0x651) continue;       //모음 위치를 조정하기가 어려워 샷다만 표시함
                }
            else{
                IsFirst=0;
                WCh=GetArabicDisplayChar(WCh, &Str, &StrLen, &ChaPos);
                X-=LCD_GetCharWidth(hFont, WCh, &Height);   //Height은 더미
                }
            GetFontData(FontMem+X, FontBuffWidth, WCh, hFont);
            }
        else{
            Str-=Len; Start=Str;
            StrLen+=Len;

            while (StrLen>0)
                {
                WCh=GetCharU8(Str, &Len);
                if (Len>StrLen) break;
                if (IsArabicCha(WCh)) break;
                Str+=Len;
                StrLen-=Len;
                }

            while (IsSpaceCha(Str[-1])) {Str--; StrLen++;}  //아랍문자 앞에 있는 공백은 아랍문자 표시로 처리

            GetTextExtentPoint32(hDC, Start, Str-Start, &S);
            X-=S.cx; SrcX=X;
            while (Start<Str)
                {
                WCh=GetCharU8(Start, &Len);
                Start+=Len;
                SrcX+=GetFontData(FontMem+SrcX, FontBuffWidth, WCh, hFont);
                }
            }
        #else
        X+=GetFontData(FontMem+X, FontBuffWidth, WCh, hFont);
        #endif //ARABIC_FUCTION
        }

    SetRect(&R, DestX, DestY, DestX+FontBuffWidth, DestY+FontBuffHeight);       //표시하라고 지정한 영역
    if (AdjustDrawArea(hDC, &PA, &R)==FALSE) goto ProcExit;
    Width=PA.right-PA.left;
    Height=PA.bottom-PA.top;
    SrcX=PA.left-R.left;
    SrcY=PA.top-R.top;

    FontType=hFont->Kind & FK_KINDMASK;
    TextCol=hDC->TextColor;
    BkGndCol=hDC->TextBkColor;
    TxR=TextCol&0xFF;
    TxG=(TextCol>>8)&0xFF;
    TxB=(TextCol>>16)&0xFF;
    BkR=BkGndCol&0xFF;
    BkG=(BkGndCol>>8)&0xFF;
    BkB=(BkGndCol>>16)&0xFF;

    Bits=SrcY*FontBuffWidth + SrcX + FontMem;
    lpDCM=GetDCMemPtr(hDC, PA.left, PA.top);
    while (Height--)
        {
        int FontPxl, BkAlpha;
        lpS=Bits;
        lpD=lpDCM;
        if (FontType==FK_UNICODE16GRAY)
            {
            for (X=0; X<Width; X++)
                {
                FontPxl=*lpS++;
                if (hDC->BkMode==TRANSPARENT)
                    {
                    BkGndCol=*lpD;
                    BkR=BkGndCol&0xFF;
                    BkG=(BkGndCol>>8)&0xFF;
                    BkB=(BkGndCol>>16)&0xFF;
                    }
                if (FontPxl==0) *lpD=BkGndCol;
                else if (FontPxl==15) *lpD=TextCol;
                else{
                    BkAlpha=15-FontPxl;
                    *lpD=(((BkB*BkAlpha + TxB*FontPxl)/15)<<16) |
                         (((BkG*BkAlpha + TxG*FontPxl)/15)<<8) |
                         ((BkR*BkAlpha + TxR*FontPxl)/15);
                    }
                lpD++;
                }
            }
        else{
            for (X=0; X<Width; X++)
                {
                FontPxl=*lpS++;
                if (FontPxl!=0) *lpD=TextCol;
                else if (hDC->BkMode==OPAQUE) *lpD=BkGndCol;
                lpD++;
                }
            }
        Bits+=FontBuffWidth;
        lpDCM+=hDC->WindowWidth;
        }

    SetDrawArea(hDC, &PA);
    Rslt++;

    ProcExit:
    FreeMem(FontMem);
    return Rslt;
    }

BOOL WINAPI MyTextOut(HDC hDC, int DestX, int DestY, LPCSTR Str)
    {
    return TextOut(hDC, DestX, DestY, Str, lstrlen(Str));
    }



//-----------------------------------------------------------------------------
//      박스안에 문자열을 씁니다
//-----------------------------------------------------------------------------
#define TEXTLINEGAP     2   //줄간격
int WINAPI DrawText(HDC hDC, LPCSTR Text, int StrLen, RECT *AR, UINT Style)
    {
    int  X, Y, WCh, Len, LineHeight, LineWidth, BrkWidth=0, Align, SpaceFg, ChWidth, TotalHeight=0, LineCnt=0;
    LPCSTR StartPos, EndPos, SpacePos, TextEnd;
    SIZE S;
    RECT R;

    if (hDC==NULL || hDC->lpDCMem==NULL || hDC->hFont==NULL || StrLen==0) goto ProcExit;

    if (StrLen<0) StrLen=lstrlen(Text);

    R=*AR;
    Align=Style&3;
    if (GetTextExtentPoint32(hDC, "X", 1, &S)==FALSE) goto ProcExit;
    LineHeight=S.cy+TEXTLINEGAP;
    Y=R.top;

    if ((Style & DT_CALCRECT)==0 && (Style & DT_VCENTER)!=0)
        {
        Len=DrawText(hDC, Text, StrLen, AR, (Style|DT_CALCRECT) & (~DT_VCENTER));
        Y+=((R.bottom-R.top)-Len)>>1;
        if (Y<R.top) Y=R.top;
        }

    TextEnd=Text+StrLen;
    while (Text<TextEnd)
        {
        StartPos=EndPos=Text;
        SpacePos=NULL;          //공백이 나온경우 처음 공백의 시작위치
        SpaceFg=0;              //공백이 나오면 1
        LineWidth=0;

        while (Text<TextEnd)
            {
            WCh=GetCharU8(Text, &Len); Text+=Len;
            if (Text>TextEnd) break;                    //짤린 UTF8문자일 경우
            ChWidth=LCD_GetCharWidth(hDC->hFont, WCh, &Len);

            if (WCh==' ' || WCh==9)
                {
                if (SpaceFg==0) {SpacePos=Text-1; BrkWidth=LineWidth; SpaceFg++;}   //공백 시작위치 위치 기억
                }
            else{
                SpaceFg=0;              //공백이 아님
                if (WCh==13 || WCh==10)
                    {
                    if (Text<TextEnd && Text[0]==(WCh==13 ? 10:13)) Text++;
                    break;
                    }
                }

            if ((Style & DT_WORDBREAK)!=0 && LineWidth+ChWidth > R.right-R.left && SpacePos!=NULL)  //한줄안에 들어가는지 확인
                {
                LineWidth=BrkWidth;
                EndPos=Text=SpacePos;
                while (Text<TextEnd)
                    {
                    if (*(LPCBYTE)Text>' ') break;
                    Text++;
                    }
                break;
                }
            LineWidth+=ChWidth;
            EndPos=Text;
            }

        if ((Style & DT_CALCRECT)==0)
            {
            X=R.left;
            if (Align==DT_CENTER) X=(R.left+R.right-LineWidth)>>1;
            else if (Align==DT_RIGHT) X=R.right-LineWidth;
            TextOut(hDC, X, Y, StartPos, (int)(EndPos-StartPos));
            }
        Y+=LineHeight;
        TotalHeight+=LineHeight;
        LineCnt++;
        if (Style & DT_SINGLELINE) break;
        }

    ProcExit:
    return TotalHeight-TEXTLINEGAP;     //맨 마지막줄은 줄간격이 필요없음
    }

int WINAPI MyDrawText(HDC hDC, LPCSTR DspStr, RECT *R, UINT Format)
    {
    return DrawText(hDC, DspStr, lstrlen(DspStr), R, Format);
    }



//-----------------------------------------------------------------------------
//      대화상자 실행중에도 처리가 되어야 할 Window를 관리합니다
//-----------------------------------------------------------------------------
#define ImporHwndQty    10
static HWND ImporHwndList[ImporHwndQty];

BOOL WINAPI IsImportWindow(HWND hWnd)
    {
    int I;

    for (I=0; I<ImporHwndQty; I++)
        if (ImporHwndList[I]==hWnd) return TRUE;
    return FALSE;
    }

BOOL WINAPI SetImportWindow(HWND hWnd)
    {
    int I;

    for (I=0; I<ImporHwndQty; I++)
        if (ImporHwndList[I]==NULL)
            {
            ImporHwndList[I]=hWnd;
            return TRUE;
            }
    return FALSE;
    }

BOOL WINAPI ClearImportWindow(HWND hWnd)
    {
    int I;

    for (I=0; I<ImporHwndQty; I++)
        if (ImporHwndList[I]==hWnd)
            {
            ImporHwndList[I]=NULL;
            return TRUE;
            }
    return FALSE;
    }




//-----------------------------------------------------------------------------
//          2칼레인텍스를 파레트에서 찾아 풀어놓음
//-----------------------------------------------------------------------------
LOCAL(VOID) ExtractIndex2Color(COLORREF *lpD, LPCBYTE OneLineBuff, CONST COLORREF *lpPalette, UINT Width)
    {
    int BitQty=0, Byt;   //Byt에 들어있는 Bit수
    COLORREF Color, Col1, Col2;

    Col1=lpPalette[0];
    Col2=lpPalette[1];

    while (Width--)
        {
        if (BitQty==0) {Byt=*OneLineBuff++; BitQty=8;}
        Color=(Byt & 0x80)==0 ? Col1:Col2;
        if (Color!=COL_TRANSPARENT) *lpD=Color;
        lpD++; Byt<<=1; BitQty--;
        }
    }



//-----------------------------------------------------------------------------
//          칼레인텍스를 파레트에서 찾아 풀어놓음 [16Color용]
//-----------------------------------------------------------------------------
LOCAL(VOID) ExtractIndex16Color(COLORREF *lpD, LPCBYTE OneLineBuff, CONST COLORREF *lpPalette, int BmpWidth)
    {
    int X=0, Byt=0, Idx;

    for (X=0; X<BmpWidth; X++)
        {
        if ((X & 1)==0)
            {
            Byt=*OneLineBuff++;
            Idx=Byt>>4;
            }
        else Idx=Byt&0x0F;

        *lpD++=lpPalette[Idx];
        }
    }



//-----------------------------------------------------------------------------
//      칼레인텍스를 파레트에서 찾아 풀어놓음 (GIF.C에서도 사용)
//-----------------------------------------------------------------------------
VOID WINAPI ExtractIndex256Color(COLORREF *lpD, LPCBYTE OneLineBuff, CONST COLORREF *lpPalette, int BmpWidth)
    {
    while (BmpWidth--) *lpD++=lpPalette[*OneLineBuff++];
    }



//-----------------------------------------------------------------------------
//      24Bit BitData색을(BGR순) COLORREF로 바꿉니다
//      GIF.C에서도 사용함
//-----------------------------------------------------------------------------
VOID WINAPI Bgr2ColorRef(COLORREF *lpD, LPCBYTE lpBGR, int BmpWidth)
    {
    while (BmpWidth--)
        {
        *lpD++=(lpBGR[0]<<16) | (lpBGR[1]<<8) | lpBGR[2];
        lpBGR+=3;
        }
    }



//-----------------------------------------------------------------------------
//      Bitmap파일을 주어진 메모리에 로딩함
//-----------------------------------------------------------------------------
LOCAL(BOOL) LoadBmpEx(LPCSTR FileName, int *lpWidth, int *lpHeight, COLORREF *VMPtr)
    {
    int   I, Rslt=FALSE, PalSize=0, ColBits, OneLineBytes;   //Time, BitsFilePos,
    HFILE hFile;
    LPBYTE lpMem=NULL;
    COLORREF *lpBits, *Palette=NULL;    //초기값을 설정안해도 되는데 컴파일러가 떽떽거려서
    BITMAPFILEHEADER BFH ALIGN4;
    BITMAPINFOHEADER BIH;

    if ((hFile=_lopen(FileName, OF_READ))==HFILE_ERROR) goto ProcExit;
    if (_lread(hFile, &BFH, sizeof(BITMAPFILEHEADER))!=sizeof(BITMAPFILEHEADER)) goto ProcExit;
    if (BFH.bfType!=0x4D42) goto ProcExit;      //'BM'

    //Printf(COM1, "Ofs=%d\r\n", (BYTE*)&BFH.bfSize-(BYTE*)&BFH);       //컴파일러에 따라 이옵셋이 4가 되는 경우가 있음 pragma 옵션으로 처리해야 함

    ZeroMem(&BIH, sizeof(BITMAPINFOHEADER));
    if (_lread(hFile, &BIH, sizeof(BITMAPINFOHEADER))<16) goto ProcExit;
    if ((int)BIH.biSize<16 || BIH.biCompression!=BI_RGB) goto ProcExit;

    *lpWidth=(int)BIH.biWidth;
    *lpHeight=(int)BIH.biHeight;
    if (VMPtr==NULL) {Rslt++; goto ProcExit;}
    ColBits=BIH.biPlanes*BIH.biBitCount;
    //BitsFilePos=Peek(&BFH.bfOffBits);
    OneLineBytes=GetBmp1LineBytes(BIH.biWidth, ColBits);
    if (ColBits<=8)
        {
        PalSize=1<<ColBits;
        if ((int)BIH.biClrUsed>0) PalSize=GetMin(PalSize, (int)BIH.biClrUsed);
        }

    if ((lpMem=(LPBYTE)AllocMem(PalSize*sizeof(RGBQUAD)+OneLineBytes, MEMOWNER_LoadBmpEx))==NULL) goto ProcExit;

    _llseek(hFile, (int)BIH.biSize+sizeof(BITMAPFILEHEADER), FILE_BEGIN);
    if (ColBits<=8)
        {
        Palette=(COLORREF*)(lpMem+OneLineBytes);
        _lread(hFile, Palette, PalSize*sizeof(RGBQUAD));
        for (I=0; I<PalSize; I++) Palette[I]=ForcePeekARGB(Palette+I);          //RGBQUAD형식을 COLORREF로 변환
        }                                                                       //로딩 후 캐쉬한 후 표시라는 구조이므로, 표시할 때 마다 COLORREF로 바꾸는 것보다는 로딩할 때 바꾸어 두는 것이 효율적임

    //Time=GetTickCount();
    for (lpBits=(BIH.biHeight-1)*BIH.biWidth+VMPtr; --BIH.biHeight>=0; lpBits-=BIH.biWidth)
        {
        _lread(hFile, lpMem, OneLineBytes);
        switch (ColBits)
            {
            case 1: ExtractIndex2Color(lpBits, lpMem, Palette, BIH.biWidth); break;
            case 4: ExtractIndex16Color(lpBits, lpMem, Palette, BIH.biWidth); break;
            case 8: ExtractIndex256Color(lpBits, lpMem, Palette, BIH.biWidth); break;
            case 24: Bgr2ColorRef(lpBits, lpMem, BIH.biWidth);
            }
        }
    //Printf(COM1, "BmpLoadTime=%d\r\n", GetTickCount()-Time);
    Rslt++;

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    FreeMem(lpMem);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      파일의 확장자를 가지고 파일 형식을 알려줌
//-----------------------------------------------------------------------------
int WINAPI GetFileType(LPCSTR FileName)
    {
    int Type=IFT_UNKNOWN;
    LPSTR lpExt;

    lpExt=GetFileExtNameLoc((LPSTR)FileName);
    if      (lstrcmpi(lpExt, "gif")==0) Type=IFT_GIF;
    else if (lstrcmpi(lpExt, "bmp")==0) Type=IFT_BMP;
    else if (lstrcmpi(lpExt, "png")==0) Type=IFT_PNG;
    return Type;
    }



//-----------------------------------------------------------------------------
//      Gif, Bmp, Png 그림을 비디오메모리에 로딩함
//-----------------------------------------------------------------------------
LOCAL(BOOL) LoadImageToVram(LPCSTR ImgFileName, int *lpWidth, int *lpHeight, LPVOID VMPtr, COLORREF TxParColor)
    {
    int Rslt=FALSE, FileType;
    CHAR FilePath[FILENAMEBUFFMAX];

    MakeUIPath(FilePath, ImgFileName);
    FileType=GetFileType(ImgFileName);
    if      (FileType==IFT_BMP) Rslt=LoadBmpEx(FilePath, lpWidth, lpHeight, (COLORREF*)VMPtr);
    #if USE_GIF
    else if (FileType==IFT_GIF) Rslt=LoadGif(FilePath, lpWidth, lpHeight, (LPBYTE)VMPtr, TxParColor);
    #endif
    #if USE_PNG
    else if (FileType==IFT_PNG) Rslt=LoadPng(FilePath, lpWidth, lpHeight, (COLORREF*)VMPtr);
    #endif
    else Printf("Unsupport format '%s'"CRLF, ImgFileName);

    return Rslt;
    }



//-----------------------------------------------------------------------------
//      이미지 크기를 알려줌
//-----------------------------------------------------------------------------
BOOL WINAPI GetImageSize(LPCSTR ImgFName, SIZE *S)
    {
    return LoadImageToVram(ImgFName, &S->cx, &S->cy, NULL, 0);
    }




//-----------------------------------------------------------------------------
//      PNG를 VMem에 로딩해서 리턴함
//-----------------------------------------------------------------------------
HBITMAP WINAPI LoadImage(LPCSTR ImgFileName)
    {
    int Width, Height;
    HBITMAP hBtm=NULL;

    if (LoadImageToVram(ImgFileName, &Width, &Height, NULL, 0)==FALSE) goto ProcExit;
    if ((hBtm=(HBITMAP)AllocVMem(Width * sizeof(COLORREF) * Height + sizeof(RECT), MEMOWNER_ImageToVram))!=NULL)
        {
        SetRect((RECT*)hBtm, 0, 0, Width, Height);
        LoadImageToVram(ImgFileName, &Width, &Height, (LPBYTE)hBtm+sizeof(RECT), 0);
        }
    ProcExit:
    return hBtm;
    }




//-----------------------------------------------------------------------------
//      메세지 박스 아이콘 번호를 얻음
//-----------------------------------------------------------------------------
LOCAL(int) GetMessageBoxIconNo(DWORD DlgStyle)
    {
    int I=-1;

    switch (DlgStyle & MB_ICONMASK)
        {
        case MB_ICONHAND: I=0; break;
        case MB_ICONQUESTION: I=1; break;
        case MB_ICONEXCLAMATION: I=2; break;
        case MB_ICONINFORMATION: I=3; //break;
        }
    return I;
    }



typedef struct _MsgBoxArgStruc
    {
    LPCSTR MsgText, Title;
    UINT   Style;
    } MsgBoxArgStruc;

#define MsgBoxIconSpace         85



DLGFNC(MsgBoxDlgProc)
    {
    int I;
    MsgBoxArgStruc *Arg;

    switch (Msg)
        {
        case WM_INITDIALOG:
            SetWindowLong(hWnd, DWL_USER, lPrm);
            SetTimer(hWnd, 1, 30000, NULL);
            return TRUE;

        case WM_TIMER:
            PostMessage(hWnd, WM_COMMAND, IDOK, 0);
            return TRUE;

        case WM_PAINT:
            {
            int  L;
            HDC  hDC;
            RECT R;
            SIZE S;
            PAINTSTRUCT PS;

            Arg=(MsgBoxArgStruc*)GetWindowLong(hWnd, DWL_USER);
            hDC=BeginPaint(hWnd, &PS);

            SetBkMode(hDC, TRANSPARENT);
            if ((hWnd->Style & WS_CAPTION)!=WS_CAPTION)
                {
                SetTextColor(hDC, COL_WHITE);
                L=lstrlen(Arg->Title);
                GetTextExtentPoint32(hDC, Arg->Title, L, &S);
                TextOut(hDC, (MsgBoxTitleWidth-S.cx)/2+MsgBoxTitlePx, (MsgBoxTitleHeight-S.cy)/2+MsgBoxTitlePy, Arg->Title, L);
                }

            if ((I=GetMessageBoxIconNo(Arg->Style))>=0)
                DrawImageEx(hDC, MSGBOXBTNGAP, MSGBOXBTNGAP, MSGBOXICONFNAME, I*MSGBOXICONSIZE, 0, MSGBOXICONSIZE, MSGBOXICONSIZE, RGB(8,8,8));

            GetClientRect(hWnd, &R);
            InflateRect(&R, -MSGBOXBTNGAP, -MSGBOXBTNGAP);
            R.bottom-=MSGBOXBTNSIZEY+MSGBOXBTNGAP;
            if (I>=0) R.left+=MSGBOXICONSIZE+MSGBOXBTNGAP;

            SetTextColor(hDC, COL_BLACK);
            DrawText(hDC, Arg->MsgText, lstrlen(Arg->MsgText), &R, DT_CENTER|DT_VCENTER);
            EndPaint(hWnd, &PS);
            return TRUE;
            }

        case WM_COMMAND:
            Arg=(MsgBoxArgStruc*)GetWindowLong(hWnd, DWL_USER);
            I=Arg->Style & MB_TYPEMASK;
            switch (WMCMDID)
                {
                case IDOK:
                    if (I!=MB_OK && I!=MB_OKCANCEL) break;
                    EndDialog(hWnd, WMCMDID);
                    break;

                case IDCANCEL:
                    if (I==MB_OK) {EndDialog(hWnd, IDOK); break;}
                    if (I!=MB_OKCANCEL && I!=MB_YESNOCANCEL) break;
                case IDYES:
                case IDNO:
                    EndDialog(hWnd, WMCMDID);
                }
            return TRUE;
        }
    return FALSE;
    }



int WINAPI MessageBox(HWND hWnd, LPCSTR MsgText, LPCSTR Title, UINT Style)
    {
    int  MsgStyle;
    MsgBoxArgStruc Arg;
    DIALOGTEMPLATE *DT, DlgTemplate[6]; //6으로 한 이유는 콘트롤 목록 끝 인식으로 빈 레코드가 필요함

    ZeroMem(DlgTemplate, sizeof(DlgTemplate));
    DT=DlgTemplate;
    DT->Title=MSGBOXDLGTITLE;
    DT->ID=(HMENU)NullStr;
    DT->ClassName=DlgClassName;
    DT->Style=WS_POPUP|WS_CAPTION;
    DT->X=DT->Y=-1;
    //DT->Sx=DT->Sy=0;
    DT++;

    MsgStyle=Style & MB_TYPEMASK;
    if (MsgStyle==MB_YESNOCANCEL || MsgStyle==MB_YESNO)
        {
        DT->Title=MSGBOXYESBTNTITLE;
        DT->ID=(HMENU)IDYES;
        DT->ClassName=ButtonStr;
        DT->Style=MSGBOXBTNSTYLE;
        //DT->X=DT->Y=0;
        DT->Sx=MSGBOXBTNSIZEX;
        DT->Sy=MSGBOXBTNSIZEY;
        DT++;

        DT->Title=MSGBOXNOBTNTITLE;
        DT->ID=(HMENU)IDNO;
        DT->ClassName=ButtonStr;
        DT->Style=MSGBOXBTNSTYLE;
        //DT->X=DT->Y=0;
        DT->Sx=MSGBOXBTNSIZEX;
        DT->Sy=MSGBOXBTNSIZEY;
        DT++;
        }
    if (MsgStyle==MB_OK || MsgStyle==MB_OKCANCEL)
        {
        DT->Title=MSGBOXOKBTNTITLE;
        DT->ID=(HMENU)IDOK;
        DT->ClassName=ButtonStr;
        DT->Style=MSGBOXBTNSTYLE;
        //DT->X=DT->Y=0;
        DT->Sx=MSGBOXBTNSIZEX;
        DT->Sy=MSGBOXBTNSIZEY;
        DT++;
        }
    if (MsgStyle==MB_OKCANCEL || MsgStyle==MB_YESNOCANCEL)
        {
        DT->Title=MSGBOXCANCELBTNTITLE;
        DT->ID=(HMENU)IDCANCEL;
        DT->ClassName=ButtonStr;
        DT->Style=MSGBOXBTNSTYLE;
        //DT->X=DT->Y=0;
        DT->Sx=MSGBOXBTNSIZEX;
        DT->Sy=MSGBOXBTNSIZEY;
        }

    Arg.MsgText=MsgText;
    if ((Arg.Title=Title)==NULL) Arg.Title=MSGBOXERRORTITLE;
    Arg.Style=Style;
    return DialogBoxParam(HInst, MAKEINTRESOURCE(DlgTemplate), hWnd, MsgBoxDlgProc, (LPARAM)&Arg);
    }



HWND WINAPI GetNextDlgGroupItem(HWND hWndDlg, HWND hWndCtrl, BOOL PreviousFg)
    {
    HWND   hWnd, hWndTmp;

    hWnd=hWndCtrl;
    do  {
        if (PreviousFg!=FALSE)  //현재 윈도우 맨나중것이 맨위임
            {
            if (hWnd->Next!=NULL) hWnd=hWnd->Next;
            else while ((hWndTmp=hWnd->Prev)!=NULL) hWnd=hWndTmp;
            }
        else{
            if (hWnd->Prev!=NULL) hWnd=hWnd->Prev;
            else while ((hWndTmp=hWnd->Next)!=NULL) hWnd=hWndTmp;
            }

        if (hWnd->Style & WS_GROUP) break;
        } while (hWnd!=hWndCtrl);
    return hWnd;
    }



HWND WINAPI GetNextDlgTabItem(HWND hWndDlg, HWND hWndCtrl, BOOL PreviousFg)
    {
    HWND   hWnd, hWndTmp;

    hWnd=hWndCtrl;
    do  {
        if (PreviousFg!=FALSE)  //현재 인도우 맨나중것이 맨위임
            {
            if (hWnd->Next!=NULL) hWnd=hWnd->Next;
            else while ((hWndTmp=hWnd->Prev)!=NULL) hWnd=hWndTmp;
            }
        else{
            if (hWnd->Prev!=NULL) hWnd=hWnd->Prev;
            else while ((hWndTmp=hWnd->Next)!=NULL) hWnd=hWndTmp;
            }

        if ((hWnd->Style & WS_TABSTOP)!=0 && (hWnd->Style & WS_DISABLED)==0) break;
        } while (hWnd!=hWndCtrl);
    return hWnd;
    }



VOID WINAPI CheckDlgButton(HWND hWnd, int BtnID, UINT Check)
    {
    SendDlgItemMessage(hWnd, BtnID, BM_SETCHECK, Check, 0);
    }



VOID WINAPI CheckRadioButton(HWND hWnd, int First, int Last, int Check)
    {
    int I;

    for (I=First; I<=Last; I++)
        CheckDlgButton(hWnd, I, I==Check ? 1:0);
    }



UINT WINAPI IsDlgButtonChecked(HWND hWnd, int BtnID)
    {
    return (UINT)SendDlgItemMessage(hWnd, BtnID, BM_GETCHECK, 0, 0);
    }



int WINAPI GetDlgCtrlID(HWND hWnd)
    {
    return (int)hWnd->hMenu;
    }


HWND WINAPI GetDlgItem(HWND hWndPrnt, int CtlID)
    {
    HWND hWnd;

    if (hWndPrnt==NULL) return NULL;
    for (hWnd=hWndPrnt->Child; hWnd!=NULL; hWnd=hWnd->Next)
        {
        if ((int)hWnd->hMenu==CtlID) break;
        }
    return hWnd;
    }


LRESULT WINAPI SendDlgItemMessage(HWND hWnd, int CtlID, UINT Msg, WPARAM wPrm, LPARAM lPrm)
    {
    return SendMessage(GetDlgItem(hWnd, CtlID), Msg, wPrm, lPrm);
    }


VOID WINAPI SetDlgItemText(HWND hWnd, int CtlID, LPCSTR szStr)
    {
    SendMessage(GetDlgItem(hWnd, CtlID), WM_SETTEXT, 0, (LPARAM)szStr);
    }


int WINAPI GetDlgItemText(HWND hWnd, int CtlID, LPSTR szBuff, int BuffSize)
    {
    return (int)SendMessage(GetDlgItem(hWnd, CtlID), WM_GETTEXT, BuffSize, (LPARAM)szBuff);
    }



//-----------------------------------------------------------------------------
//      DlgItem의 문자열을 가져옴, 메모리 할당하여 리턴, 사용 후 반환할것
//-----------------------------------------------------------------------------
LPSTR WINAPI GetDlgItemTextMem(HWND hWnd, int EBID, int MemOwner)
    {
    int   Len;
    LPSTR lpMem;

    if (EBID!=0) hWnd=GetDlgItem(hWnd, EBID);
    Len=GetWindowTextLength(hWnd)+1;
    if ((lpMem=(LPSTR)AllocMem(Len, MemOwner))!=NULL) GetWindowText(hWnd, lpMem, Len);
    return lpMem;
    }




VOID WINAPI SetDlgItemInt(HWND hWnd, int CtlID, UINT Val, BOOL SignFg)
    {
    CHAR Buff[10];

    wsprintf(Buff, SignFg==FALSE ? "%u":"%d", Val);
    SetDlgItemText(hWnd, CtlID, Buff);
    }


UINT WINAPI GetDlgItemInt(HWND hWnd, int CtlID, BOOL *lpErr, BOOL SignFg)
    {
    int  NextLoc;
    UINT Rslt;
    CHAR Buff[40];

    GetDlgItemText(hWnd, CtlID, Buff, sizeof(Buff));
    CleanupStr(Buff);
    Rslt=AtoI(Buff, &NextLoc);
    if (lpErr) *lpErr=NextLoc==0 || Buff[NextLoc]!=0;
    return Rslt;
    }



typedef struct _ImageCacheHeader
    {
    struct _ImageCacheHeader *Next;
    HBITMAP hBtm;
    CHAR  ImgFName[FILENAMEBUFFMAX];
    } ImageCacheHeader;

static ImageCacheHeader *ImageCache;


#if (PCMODE>0)
#define DefCriticalVar
static CRITICAL_SECTION CS_CacheImage;
LOCAL(VOID) LockCacheImage(VOID)        {EnterCriticalSection(&CS_CacheImage);}
LOCAL(VOID) UnlockCacheImage(VOID)      {LeaveCriticalSection(&CS_CacheImage);}
LOCAL(VOID) InitCacheImageLock(VOID)    {InitializeCriticalSection(&CS_CacheImage);}
LOCAL(VOID) ReleaseCacheImageLock(VOID) {DeleteCriticalSection(&CS_CacheImage);}
#else
#define DefCriticalVar      JOS_CRITICAL_VAR
#define LockCacheImage      JOS_ENTER_CRITICAL
#define UnlockCacheImage    JOS_EXIT_CRITICAL
#define InitCacheImageLock()
#define ReleaseCacheImageLock()
#endif



#if (PCMODE>0)
//-----------------------------------------------------------------------------
//      Image Cache를 Free합니다
//-----------------------------------------------------------------------------
LOCAL(VOID) ReleaseImgCache()
    {
    ImageCacheHeader *ToDel;

    while (ImageCache!=NULL)
        {
        DeleteObject(ImageCache->hBtm);
        ToDel=ImageCache; ImageCache=ImageCache->Next;
        FreeMem(ToDel);
        }
    }
#endif



//-----------------------------------------------------------------------------
//      캐쉬를 지움
//-----------------------------------------------------------------------------
VOID WINAPI DeleteCache(LPCSTR ImgFileName)
    {
    ImageCacheHeader *ImgChe, *ImgChePar=NULL;
    DefCriticalVar;

    LockCacheImage();
    for (ImgChe=ImageCache; ImgChe!=NULL; ImgChe=ImgChe->Next)
        {
        if (lstrcmpi(ImgChe->ImgFName, ImgFileName)==0)
            {
            DeleteObject(ImgChe->hBtm);
            DELSINGLELINK(ImageCacheHeader, ImageCache, ImgChePar, ImgChe)
            break;
            }
        }
    UnlockCacheImage();
    }




//-----------------------------------------------------------------------------
//      이미지 파일을 비디오 메모리에 압축 풀어서 캐쉬해 놓습니다
//-----------------------------------------------------------------------------
BOOL WINAPI CacheImage(LPCSTR ImgFileName)
    {
    int    Rslt=FALSE, Width;
    UINT   MFree;
    ImageCacheHeader *ImgChe=NULL;
    DefCriticalVar;

    //JOSSemPend(DispRsrcSem, 0);
    MFree=GetVMemFree(NULL, &Width, NULL);
    if (Width!=MA_OK || MFree<CACHEMINFREEMEM*1024*1024) goto ProcExit;

    if ((ImgChe=AllocMemS(ImageCacheHeader, MEMOWNER_CacheImage))==NULL) goto ProcExit;
    ZeroMem(ImgChe, sizeof(ImageCacheHeader));
    lstrcpy(ImgChe->ImgFName, ImgFileName);
    if ((ImgChe->hBtm=LoadImage(ImgFileName))==NULL) goto ProcExit;

    LockCacheImage();
    ImgChe->Next=ImageCache;
    ImageCache=ImgChe;
    UnlockCacheImage();

    Rslt++;

    ProcExit:
    if (Rslt==FALSE && ImgChe!=NULL)
        {
        DeleteObject(ImgChe->hBtm);
        FreeMem(ImgChe);
        }
    //JOSSemPost(DispRsrcSem);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      캐쉬된 이미지를 리턴함
//-----------------------------------------------------------------------------
HBITMAP WINAPI GetCachedImage(LPCSTR ImgFileName)
    {
    ImageCacheHeader *ImgChe;
    DefCriticalVar;

    LockCacheImage();
    for (ImgChe=ImageCache; ImgChe!=NULL; ImgChe=ImgChe->Next)
        if (lstrcmpi(ImgChe->ImgFName, ImgFileName)==0) break;
    UnlockCacheImage();

    return ImgChe!=NULL ? ImgChe->hBtm:NULL;
    }




//-----------------------------------------------------------------------------
//      저장된 이미지를 hDC 메모리에 복사
//      DestX, DestY는 음수 가능
//      표시할 이미지가 해당 윈도우보다 크면 윈도우 크기만큼만 표시
//
//      DontCare==COL_TRANSPARENT(-1) 이면 알파채널 처리
//      DontCare==COL_NOTRANSPARENT(-2) 이면 원래 이미지 그대로 표시
//      그외이면 DontCare과 같은 이미지 픽셀 색상은 표시하지 않음
//-----------------------------------------------------------------------------
VOID WINAPI DrawBitmap(HDC hDC, int DestX, int DestY, int Width, int Height,
                       HBITMAP hBtm, int SrcX, int SrcY, COLORREF DontCare)
    {
    int  X, ImgWidth, ImgHeight, R,G,B, Alpha, BkAlpha;
    RECT R1, IR, PA, *ImgR;
    COLORREF Col, *lpS, *lpD, *lpDCM, *Bits;

    if (hDC==NULL || hDC->lpDCMem==NULL) goto ProcExit;

    ImgR=(RECT*)hBtm;
    ImgWidth=ImgR->right-ImgR->left;
    if (Width==0) Width=ImgWidth;
    ImgHeight=ImgR->bottom-ImgR->top;
    if (Height==0) Height=ImgHeight;

    SetRect(&R1, DestX, DestY, DestX+Width, DestY+Height);                       //표시하라고 지정한 영역
    SetRect(&IR, 0,0, ImgWidth, ImgHeight); OffsetRect(&IR, DestX-SrcX, DestY-SrcY);    //이미지 옵셋과 크기를 반영한 영역
    MyIntersectRect(&R1, &IR);

    if (AdjustDrawArea(hDC, &PA, &R1)==FALSE) goto ProcExit;
    Width=PA.right-PA.left;
    Height=PA.bottom-PA.top;
    SrcX=PA.left-IR.left;
    SrcY=PA.top-IR.top;

    Bits=(COLORREF*)((LPCBYTE)hBtm+sizeof(RECT)) + (SrcY*ImgWidth+SrcX);
    lpDCM=GetDCMemPtr(hDC, PA.left, PA.top);
    while (Height--)
        {
        lpS=Bits;
        lpD=lpDCM;
        for (X=0; X<Width; X++)
            {
            Col=*lpS++;
            if (DontCare==COL_TRANSPARENT)
                {
                if ((Alpha=Col>>24)!=0)
                    {
                    if (Alpha==255) *lpD=Col;
                    else{
                        R=Col&0xFF;
                        G=(Col>>8)&0xFF;
                        B=(Col>>16)&0xFF;
                        BkAlpha=255-Alpha;
                        *((LPBYTE)lpD+0)=(BYTE)((*((LPBYTE)lpD+0)*BkAlpha + R*Alpha)>>8);   //원래는 255로 나누어야 하지만, 속도향상을 위해 256으로 나눔 (1이 작아짐, 255가 254가 됨, 565-LCD에서는 티안남)
                        *((LPBYTE)lpD+1)=(BYTE)((*((LPBYTE)lpD+1)*BkAlpha + G*Alpha)>>8);
                        *((LPBYTE)lpD+2)=(BYTE)((*((LPBYTE)lpD+2)*BkAlpha + B*Alpha)>>8);
                        }
                    }
                }
            else{
                if ((Col&0xFFFFFF)!=DontCare) *lpD=Col;
                }
            lpD++;
            }
        Bits+=ImgWidth;
        lpDCM+=hDC->WindowWidth;
        }
    SetDrawArea(hDC, &PA);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      저장된 이미지를 hDC 메모리에 저장
//-----------------------------------------------------------------------------
VOID WINAPI GetBitmapSize(HBITMAP hBtm, SIZE *S)
    {
    RECT *R;

    R=(RECT*)hBtm;
    S->cx=R->right - R->left;
    S->cy=R->bottom - R->top;
    }



//-----------------------------------------------------------------------------
//      주어진 좌표를 중심으로 이미지를 표시함
//-----------------------------------------------------------------------------
VOID WINAPI DrawImageCenter(HDC hDC, int X, int Y, HBITMAP Img, HBITMAP BkgndImg, BOOL DispOnOff)
    {
    SIZE S;
    RECT R;

    GetBitmapSize(Img, &S);
    R.left=X-(S.cx>>1);
    R.top=Y-(S.cy>>1);
    R.right=R.left+S.cx;
    R.bottom=R.top+S.cy;
    if (BkgndImg)  DrawBitmap(hDC, R.left, R.top, R.right-R.left, R.bottom-R.top, BkgndImg, R.left, R.top, COL_NOTRANSPARENT);
    if (DispOnOff) DrawBitmap(hDC, R.left, R.top, 0, 0,                           Img,      0, 0,          COL_TRANSPARENT);
    }



//-----------------------------------------------------------------------------
//      이미지 파일을 비디오 메모리에 캐쉬하고 화면에 찍습니다
//-----------------------------------------------------------------------------
VOID WINAPI DrawImageEx(HDC hDC, int X, int Y, LPCSTR ImgFileName, int SrcX, int SrcY, int Width, int Height, COLORREF TxparentCol)
    {
    HBITMAP hBtm;

    if (hDC->lpDCMem==NULL) goto ProcExit;
    for (;;)
        {
        if ((hBtm=GetCachedImage(ImgFileName))!=NULL)
            {
            DrawBitmap(hDC, X, Y, Width, Height, hBtm, SrcX, SrcY, TxparentCol);
            break;
            }

        if (CacheImage(ImgFileName)==FALSE)     //캐쉬메모리가 부족하면 찍고 메모리를 비움
            {
            if ((hBtm=LoadImage(ImgFileName))!=NULL)
                {
                DrawBitmap(hDC, X, Y, Width, Height, hBtm, SrcX, SrcY, TxparentCol);
                DeleteObject(hBtm);
                }
            break;
            }
        }
    ProcExit:;
    }

VOID WINAPI DrawImage(HDC hDC, int X, int Y, LPCSTR ImgFileName)
    {
    DrawImageEx(hDC, X, Y, ImgFileName, 0,0,0,0, COL_NOTRANSPARENT);
    }





typedef struct _DIALOGARGUMENT
    {
    INT16   X,Y, Sx,Sy;
    LPCSTR  Title;
    DWORD   Style;
    DLGPROC DlgProc;
    LPARAM  UserPrm;
    CONST DIALOGTEMPLATE *DlgCtl;
    } DIALOGARGUMENT;



WNDFNC(DefDlgProc)  //DlgClassName
    {
    HWND hWndChild;
    DIALOGARGUMENT *Dlg;
    CONST DIALOGTEMPLATE *Ctl;

    Dlg=(DIALOGARGUMENT*)GetWindowLong(hWnd, DWL_DLGTEMP);
    switch (Msg)
        {
        case WM_CREATE:
            Dlg=(DIALOGARGUMENT*)((CREATESTRUCT*)lPrm)->lpCreateParams;
            SetWindowLong(hWnd, DWL_DLGTEMP, (LONG)Dlg);

            for (Ctl=Dlg->DlgCtl; Ctl->ClassName!=NULL; Ctl++);
            for (;;)
                {
                if (--Ctl==Dlg->DlgCtl) break;  //첫번째 항목은 대화상자 정보임
                CreateWindow(Ctl->ClassName, Ctl->Title, Ctl->Style, Ctl->X, Ctl->Y, Ctl->Sx, Ctl->Sy, hWnd, Ctl->ID, HInst, NULL);
                }
            hWndChild=GetWindow(hWnd, GW_CHILD);
            SetFocus(hWndChild==NULL ? hWnd:GetNextDlgTabItem(hWnd, GetNextDlgTabItem(hWnd, hWndChild, TRUE), FALSE));
            SendMessage(hWnd, WM_INITDIALOG, 0, Dlg->UserPrm);
            Ret0:
            return 0;

        case WM_KEYDOWN:
            switch (wPrm)
                {
                case VK_RETURN:
                case VK_ESCAPE:
                    PostMessage(hWnd, WM_COMMAND, wPrm==VK_RETURN ? IDOK:IDCANCEL, 0);
                    break;

                case VK_TAB:
                    {
                    HWND hWndNext, hWndFocus;
                    hWndFocus=GetFocus();
                    if ((hWndNext=GetNextDlgTabItem(hWnd, hWndFocus, FALSE))!=hWndFocus)
                        SetFocus(hWndNext);
                    }
                }
            goto Ret0;

        case WM_CLOSE:
            PostMessage(hWnd, WM_COMMAND, IDCANCEL, 0);
            goto Ret0;

        case WM_DESTROY:
            if (Dlg!=NULL) Dlg->DlgProc(hWnd, Msg, wPrm, lPrm); //2007.11.28추가
            SetWindowLong(hWnd, DWL_DLGTEMP, (LONG)NULL);
            PostQuitMessage(GetWindowLong(hWnd, DWL_MSGRESULT));
            goto Ret0;

        case WM_CTLCOLORBTN:
        case WM_CTLCOLORSTATIC:
            SetTextColor((HDC)wPrm, COL_WINDOWTEXT);
            SetBkColor((HDC)wPrm, COL_3DFACE);
            return GetClassLong(hWnd, GCL_HBRBACKGROUND);

        case WM_ERASEBKGND:     //이게 정상이나 차일드 보다 먼저 바탕을 칠해야 하기에 WM_CREATE에서 처리함
            if (Dlg!=NULL)
                {
                if ((Dlg->Style & WS_CAPTION)!=WS_CAPTION && Dlg->Title[0]!=0)
                    DrawImage((HDC)wPrm, 0, 0, Dlg->Title);
                else{
                    RECT R;
                    GetClientRect(hWnd, &R);
                    FillRect((HDC)wPrm, &R, hWnd->WC.hbrBackground);
                    }
                }
            return 1;
        }


    if (Msg==WM_COMMAND)
        switch (WMCMDID)
            {
            case IDOK:     SoundEffect("YBT_14"); break;
            case IDCANCEL: SoundEffect("CBT_1"); break;
            case IDYES:    SoundEffect("YBT_1"); break;
            case IDNO:     SoundEffect("NBT_1"); break;
            }
    if (Dlg!=NULL && Dlg->DlgProc(hWnd, Msg, wPrm, lPrm)!=FALSE) return 0;
    if (Msg==WM_OUTSIDELBTNDOWN) MessageBeep(~0);
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }



BOOL WINAPI IsDialogMessage(HWND hDlg, MSG *Msg)
    {
    HWND hWnd;

    for (hWnd=Msg->hwnd; hWnd!=NULL; hWnd=hWnd->Parent)
        if (hWnd==hDlg)
            {
            int Rslt;
            if ((Rslt=HangulAutomata(Msg))==0) TranslateMessage(Msg);
            if (Rslt!=2) DispatchMessage(Msg);
            return TRUE;
            }

    if (Msg->message>=WM_LBUTTONDOWN && Msg->message<=WM_MBUTTONDBLCLK && IsImportWindow(Msg->hwnd)==FALSE)
        {
        if (Msg->message==WM_LBUTTONDOWN)
            {
            Msg->hwnd=hDlg;
            Msg->message=WM_OUTSIDELBTNDOWN;
            DispatchMessage(Msg);
            //MessageBeep(0);
            }
        }
    else DispatchMessage(Msg);
    return FALSE;
    }



VOID WINAPI EndDialog(HWND hWnd, int Rslt)
    {
    SetWindowLong(hWnd, DWL_MSGRESULT, Rslt);
    DestroyWindow(hWnd);
    }


int WINAPI DialogBoxParam(HINSTANCE hInst, LPCSTR DlgTemp, HWND hWnd, DLGPROC DlgProc, LPARAM UserPrm)
    {
    HWND  hDlg, hWndFocus;
    MSG   Msg;
    SIZE  S;
    DIALOGARGUMENT Dlg;
    DIALOGTEMPLATE *Ctl;
    CONST DIALOGTEMPLATE *DT;

    Msg.wParam=0;               //Err Return Value
    hWndFocus=GetFocus();
    if (hWnd!=NULL)
        {
        SendMessage(hWnd, WM_ACTIVATE, WA_INACTIVE, 0);
        EnableWindow(hWnd, FALSE);
        }

    ZeroMem(&Dlg, sizeof(Dlg));
    Dlg.DlgCtl=DT=(CONST DIALOGTEMPLATE*)DlgTemp;
    Dlg.DlgProc=DlgProc;
    Dlg.UserPrm=UserPrm;
    Dlg.Title=DT->Title;
    Dlg.Style=DT->Style;
    Dlg.X=DT->X;
    Dlg.Y=DT->Y;
    Dlg.Sx=DT->Sx;
    Dlg.Sy=DT->Sy;

    if ((Dlg.Style & WS_CAPTION)==WS_CAPTION)
        {
        if (DlgProc==MsgBoxDlgProc)
            {
            HDC hDC;
            int BtnQty=0, PosX;
            MsgBoxArgStruc *MBArg;

            MBArg=(MsgBoxArgStruc*)UserPrm;
            Dlg.Title=MBArg->Title;

            hDC=GetDC(hWnd);
            GetTextExtentPoint32(hDC, MBArg->MsgText, lstrlen(MBArg->MsgText), &S);
            ReleaseDC(hWnd, hDC);

            for (Ctl=(DIALOGTEMPLATE*)DT; Ctl->ClassName!=NULL; Ctl++) BtnQty++;
            BtnQty--;   //맨 위 대화상자 정보는 빼고

            Dlg.Sx=GetMax(S.cx+MSGBOXICONSIZE+MSGBOXBTNGAP*3, (MSGBOXBTNSIZEX+MSGBOXBTNGAP)*BtnQty+MSGBOXBTNGAP);
            Dlg.Sy=MSGBOXICONSIZE+CYCAPTION+MSGBOXBTNSIZEY+MSGBOXBTNGAP*3;

            PosX=(Dlg.Sx-((MSGBOXBTNSIZEX+MSGBOXBTNGAP)*BtnQty-MSGBOXBTNGAP))>>1;
            for (;;)
                {
                if (--Ctl==DT) break;   //첫번째 항목은 대화상자 정보임
                Ctl->X=PosX; PosX+=MSGBOXBTNGAP+MSGBOXBTNSIZEX;
                Ctl->Y=Dlg.Sy-CYCAPTION-MSGBOXBTNGAP-MSGBOXBTNSIZEY;
                }
            }
        }
    else if (DT->Title[0]!=0)
        {
        if (GetImageSize(DT->Title, &S)==FALSE) goto ProcExit;
        Dlg.Sx=S.cx;
        Dlg.Sy=S.cy;
        }

    if (Dlg.X<0) Dlg.X=(LCD_LogResolutionX-Dlg.Sx)>>1;
    if (Dlg.Y<0) Dlg.Y=(LCD_LogResolutionY-Dlg.Sy)>>1;
    if ((hDlg=CreateWindow(DT->ClassName, Dlg.Title, Dlg.Style|DS_MODALFRAME,
                           Dlg.X, Dlg.Y, Dlg.Sx, Dlg.Sy, hWnd, (HMENU)NULL, HInst, &Dlg))==NULL) goto ProcExit; //DefDlgProc
    SetPopWindow(hDlg);

    while (GetMessage(&Msg, 0, 0, 0))
        {
        IsDialogMessage(hDlg, &Msg);
        WatchDogOut();
        }

    ProcExit:
    if (hWnd!=NULL)
        {
        EnableWindow(hWnd, TRUE);
        SendMessage(hWnd, WM_ACTIVATE, WA_ACTIVE, 0);
        }
    SetFocus(hWndFocus);
    return Msg.wParam;
    }



//-----------------------------------------------------------------------------
//      비례간격 문자의 경우 주어진 길이 만큼만 제한합니다
//-----------------------------------------------------------------------------
VOID WINAPI CutStringLen(HDC hDC, LPSTR DestStr, LPCSTR SrcStr, int Limit)
    {
    int  L=0;           //초기값을 설정안해도 되는데 컴파일러가 떽떽거려서
    UINT Cha, HiCha=0;
    SIZE S;

    DestStr[0]=0;
    while ((Cha=*SrcStr++)!=0)
        {
        if (HiCha==0) L=lstrlen(DestStr);
        AddCha(DestStr, Cha);
        if (HiCha==0 && Cha>=0x80) {HiCha=Cha; continue;}
        HiCha=0;
        GetTextExtentPoint32(hDC, DestStr, lstrlen(DestStr), &S);
        if (S.cx>Limit)
            {
            DestStr[L]=0;
            break;
            }
        }
    }



int WINAPI GetWindowTextLength(HWND hWnd)
    {
    return SendMessage(hWnd, WM_GETTEXTLENGTH, 0, 0);
    }



#if HWNDPROPERTY
HANDLE WINAPI GetProp(HWND hWnd, LPCSTR Name)
    {
    HANDLE h=NULL;
    PROPSTRUCT *Prop;

    for (Prop=hWnd->Prop; Prop!=NULL; Prop=Prop->Next)
        {
        if (lstrcmp(Prop->Name, Name)==0)
            {
            h=Prop->Data;
            break;
            }
        }
    return h;
    }



BOOL WINAPI SetProp(HWND hWnd, LPCSTR Name, HANDLE Data)
    {
    BOOL Rslt=FALSE;
    PROPSTRUCT *Prop;

    if ((Prop=(PROPSTRUCT*)AllocMem(lstrlen(Name)+sizeof(PROPSTRUCT), MEMOWNER_SetProp))!=NULL)
        {
        Prop->Data=(LPVOID)Data;
        lstrcpy(Prop->Name, Name);
        Prop->Next=hWnd->Prop;
        hWnd->Prop=Prop;
        Rslt++;
        }
    return Rslt;
    }
#endif



BOOL WINAPI MoveWindow(HWND hWnd, int X, int Y, int Width, int Height, BOOL RepaintFg)
    {
    int Rslt=FALSE, ChgMove, ChgSize;
    POINT P;

    if (IsWindow(hWnd)==FALSE) goto ProcExit;

    ChgMove=ChgSize=0;
    if (hWnd->Parent!=NULL && (hWnd->Style & WS_CHILD)!=0)
        {
        P.x=P.y=0;
        ClientToScreen(hWnd->Parent, &P);
        X+=P.x; Y+=P.y;
        }

    if (hWnd->WA.left!=X || hWnd->WA.top!=Y) ChgMove++;
    if (hWnd->WA.right-hWnd->WA.left!=Width || hWnd->WA.bottom-hWnd->WA.top!=Height) ChgSize++;

    if (ChgMove || ChgSize)
        {
        if (hWnd->lpDCMem==NULL) SetRect(&hWnd->WA, X,Y, X+Width, Y+Height);
        else{
            ShowWindow(hWnd, SW_HIDE);
            SetRect(&hWnd->WA, X,Y, X+Width, Y+Height);
            ShowWindow(hWnd, SW_SHOW);
            }
        if (ChgMove) SendMessage(hWnd, WM_MOVE, 0, MAKELONG(X, Y));
        if (ChgSize) SendMessage(hWnd, WM_SIZE, 0, MAKELONG(Width, Height));
        }
    Rslt++;
    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      이 라이브러리를 초기화합니다
//-----------------------------------------------------------------------------
VOID WINAPI JWUI_Init()
    {
    WNDCLASS WC;

    Printf("JWUI Init...");

    InitMsgQueLock();
    InitCacheImageLock();

    ZeroMem(WinTimer, sizeof(WinTimer));
    WindowList=NULL;
    FocusWindow=NULL;
    WndClassList=NULL;
    HwndZOther=NULL;
    hWndCapture=NULL;

    hFontDef=LoadFont("DEFAULT.FNT");
    hBtmDefBtnImage=LoadImage(DEFICONFILENAME);

    WhitePen=CreatePen(PS_SOLID, 1, COL_WHITE);
    BlackPen=CreatePen(PS_SOLID, 1, COL_BLACK);
    NullPen=CreatePen(-1, 1, COL_BLACK);

    WhiteBrush=CreateSolidBrush(COL_WHITE);
    BlackBrush=CreateSolidBrush(COL_BLACK);
    NullBrush=CreateHatchBrush(-1, COL_BLACK);
    BtnFaceBrush=CreateSolidBrush(COL_BTNFACE);

    ZeroMem(&WC, sizeof(WNDCLASS));
    WC.lpfnWndProc  = DefDlgProc;
    WC.hbrBackground= BtnFaceBrush;
    WC.cbWndExtra   = DWL_ExtraSize;    //DlgPoint, DialogRslt, DwlUser
    #ifdef WIN32
    WC.hInstance  = hInst;
    #endif
    WC.lpszClassName= DlgClassName;
    RegisterClass(&WC);

    Printf(CrLfStr);    //JWUI 초기화 완료
    }


#if (PCMODE>0)
//-----------------------------------------------------------------------------
//      이 라이브러리를 해체합니다 (EMBED시스템에서는 해체자를 호출할 일이 없음)
//-----------------------------------------------------------------------------
VOID WINAPI JWUI_Release()
    {
    DeleteObject(hFontDef);
    DeleteObject(hBtmDefBtnImage);

    DeleteObject(WhitePen);
    DeleteObject(BlackPen);
    DeleteObject(NullPen);

    DeleteObject(WhiteBrush);
    DeleteObject(BlackBrush);
    DeleteObject(NullBrush);
    DeleteObject(BtnFaceBrush);

    ReleaseWndClassList();
    DestroyWindow(WindowList);

    ReleaseImgCache();

    ReleaseMsgQueLock();
    ReleaseCacheImageLock();
    }
#endif //(PCMODE>0)



///////////////////////////////////////////////////////////////////////////////
//          WIN32를 단순하게 해주는 함수들
///////////////////////////////////////////////////////////////////////////////



//-----------------------------------------------------------------------------
//      차일드 윈도들을 만듦
//-----------------------------------------------------------------------------
VOID WINAPI CreateChilds(HWND hWndPar, CONST DIALOGTEMPLATE *Ctl, int Qty)
    {
    Ctl+=Qty;
    while (--Qty>=0)
        {
        Ctl--;
        CreateWindow(Ctl->ClassName, Ctl->Title, Ctl->Style, Ctl->X, Ctl->Y, Ctl->Sx, Ctl->Sy, hWndPar, (HMENU)Ctl->ID, HInst, NULL);
        }
    }



//-----------------------------------------------------------------------------
//      대화상자의 Control에 Focus를 줍니다
//-----------------------------------------------------------------------------
HWND WINAPI SetFocusDlgItem(HWND hWnd, int CtlID)
    {
    return SetFocus(GetDlgItem(hWnd, CtlID));
    }



//-----------------------------------------------------------------------------
//      대화상자의 Control을 Enable하거나 Disable합니다
//-----------------------------------------------------------------------------
VOID WINAPI EnableDlgItem(HWND hWnd, int CtlID, BOOL EnableFg)
    {
    EnableWindow(GetDlgItem(hWnd, CtlID), EnableFg);
    }



//-----------------------------------------------------------------------------
//      대화상자의 Control을 보이거나 안보이게 합니다
//-----------------------------------------------------------------------------
VOID WINAPI ShowHideDlgItem(HWND hWnd, int CtlID, BOOL ShowFg)
    {
    ShowWindow(GetDlgItem(hWnd, CtlID), ShowFg ? SW_SHOW:SW_HIDE);
    }



//-----------------------------------------------------------------------------
//      주어진 문자열을 메세지 박스에 표시 (EucKr 버전)
//-----------------------------------------------------------------------------
int WINAPI DispMsg(HWND hWnd, LPCSTR Str, DWORD Style)
    {
    CHAR Buff[80];

    Buff[0]=0;
    if (hWnd!=NULL) GetWindowText(hWnd, Buff, sizeof(Buff));
    if (Buff[0]==0) lstrcpy(Buff, MSGBOXINFORMTITLE);
    if ((Style & (MB_ICONHAND|MB_ICONQUESTION|MB_ICONASTERISK))==0) Style|=MB_ICONEXCLAMATION;
    return MessageBox(hWnd, Str, Buff, Style);
    }



//-----------------------------------------------------------------------------
//              ParantWindow에게 Notification Message를 보냄
//              PostCmdMsgToParent()를 조금 변형
//-----------------------------------------------------------------------------
LRESULT WINAPI PostNotifyMsg(HWND hWnd, int NotifyMsg)
    {
    return PostMessage(GetParent(hWnd), WM_COMMAND, MAKELONG(GetDlgCtrlID(hWnd), NotifyMsg), (LPARAM)hWnd);
    }



//-----------------------------------------------------------------------------
//      에디터 박스의 길이를 제한합니다 (옛이름:EM_LimitText)
//-----------------------------------------------------------------------------
VOID WINAPI EB_LimitText(HWND hWnd, int EBID, int Limit)
    {
    if (EBID!=0) hWnd=GetDlgItem(hWnd, EBID);
    SendMessage(hWnd, EM_LIMITTEXT, Limit, 0);
    }



//-----------------------------------------------------------------------------
//      EditBox에 길이를 제한하고 문자열을 넣는다
//-----------------------------------------------------------------------------
VOID WINAPI SetDlgItemTextLimit(HWND hWnd, int EBID, LPCSTR Buff, int Limit)
    {
    SendDlgItemMessage(hWnd, EBID, EM_LIMITTEXT, Limit-1, 0);
    SetDlgItemText(hWnd, EBID, Buff);
    }



//-----------------------------------------------------------------------------
//      EditBox에 커서를 맨뒤로 이동
//-----------------------------------------------------------------------------
VOID WINAPI EB_GotoEnd(HWND hWnd, int EBID)
    {
    #if 0   //아직 안만듦
    int  Len;

    if (EBID!=0) hWnd=GetDlgItem(hWnd, EBID);
    Len=GetWindowTextLength(hWnd);
    SendMessage(hWnd, EM_SETSEL, Len, Len);
    #endif
    }




//-----------------------------------------------------------------------------
//      RECT 좌표 4개를 Client좌표로 변환
//-----------------------------------------------------------------------------
VOID WINAPI ScreenToClientRect(HWND hWnd, RECT *R)
    {
    ScreenToClient(hWnd, (POINT*)&R->left);
    ScreenToClient(hWnd, (POINT*)&R->right);
    }



//-----------------------------------------------------------------------------
//      대화상자의 콘트롤을 이동/크기조정합니다
//-----------------------------------------------------------------------------
VOID WINAPI MoveDlgItem(HWND hWnd, HWND hWndChild, int X, int Y, int Sx, int Sy, int AbsFg)
    {
    RECT R;

    GetWindowRect(hWndChild, &R);
    ScreenToClientRect(hWnd, &R);       //대화상자 좌표로 전환
    if ((AbsFg & MOVITM_ABSPOSX)==0) X+=R.left;
    if ((AbsFg & MOVITM_ABSPOSY)==0) Y+=R.top;
    if ((AbsFg & MOVITM_ABSSIZEX)==0) Sx+=R.right-R.left;
    if ((AbsFg & MOVITM_ABSSIZEY)==0) Sy+=R.bottom-R.top;
    MoveWindow(hWndChild, X, Y, Sx, Sy, FALSE);
    }




//디버깅
//if (IsWindowClass(hWnd, "MAIN")) PrintRect("UpdateWindow() PA", &hWnd->PA);
//PrintWindowAndRect("RedrawMyOccupiedArea()", hWndZ, &R);
