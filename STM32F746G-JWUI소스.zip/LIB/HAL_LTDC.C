///////////////////////////////////////////////////////////////////////////////
//          LCD-TFT Display Controller (LTDC)       for STM32F7
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"


#define LTDC_LAYER_J(LtdcInst, LayerIdx)    ((LTDC_Layer_TypeDef*)((UINT)LtdcInst + 0x84 + LayerIdx*0x80))  //LTDC_LAYER(hLtdc, LayerIdx)


__weak VOID HAL_LTDC_LineEventCallback(LTDC_HandleTypeDef *hLtdc) {}
__weak VOID HAL_LTDC_ErrorCallback(LTDC_HandleTypeDef *hLtdc) {}
__weak void HAL_LTDC_ReloadEventCallback(LTDC_HandleTypeDef *hLtdc) {}


VOID HAL_LTDC_IRQHandler(LTDC_HandleTypeDef *hLtdc)
    {
    UINT Isr, Ier;

    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    Isr=LtdcInst->ISR;
    Ier=LtdcInst->IER;
    if ((Isr&LTDC_ISR_TERRIF)!=0 && (Ier&LTDC_IER_TERRIE)!=0)
        {
        LtdcInst->IER&=~LTDC_IT_TE; //__HAL_LTDC_DISABLE_IT()
        LtdcInst->ICR=LTDC_FLAG_TE; //__HAL_LTDC_CLEAR_FLAG()
        hLtdc->ErrorCode|=HAL_LTDC_ERROR_TE;
        HAL_LTDC_ErrorCallback(hLtdc);
        }

    if ((Isr&LTDC_ISR_FUIF)!=0 && (Ier&LTDC_IER_FUIE)!=0)
        {
        LtdcInst->IER&=~LTDC_IT_FU;
        LtdcInst->ICR=LTDC_FLAG_FU;
        hLtdc->ErrorCode|=HAL_LTDC_ERROR_FU;
        HAL_LTDC_ErrorCallback(hLtdc);
        }

    if ((Isr&LTDC_ISR_LIF)!=0 && (Ier&LTDC_IER_LIE)!=0)
        {
        LtdcInst->IER&=~LTDC_IT_LI;
        LtdcInst->ICR=LTDC_FLAG_LI;
        HAL_LTDC_LineEventCallback(hLtdc);
        }

    if ((Isr&LTDC_ISR_RRIF)!=0 && (Ier&LTDC_IER_RRIE)!=0)
        {
        LtdcInst->IER&=~LTDC_IT_RR;
        LtdcInst->ICR=LTDC_FLAG_RR;
        HAL_LTDC_ReloadEventCallback(hLtdc);
        }
    }




HAL_StatusTypeDef HAL_LTDC_ProgramLineEvent(LTDC_HandleTypeDef *hLtdc, UINT Line)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LtdcInst->IER&=~LTDC_IT_LI; //__HAL_LTDC_DISABLE_IT
    LTDC->LIPCR=Line;
    LtdcInst->IER|=LTDC_IT_LI;
    return HAL_OK;
    }




LOCAL(VOID) LTDC_SetConfig(LTDC_HandleTypeDef *hLtdc, LTDC_LayerCfgTypeDef *LC, UINT LayerIdx)
    {
    UINT T;
    LTDC_TypeDef *LtdcInst;
    LTDC_Layer_TypeDef  *L;

    LtdcInst=hLtdc->Instance;
    L=LTDC_LAYER_J(LtdcInst, LayerIdx);     //LTDC_LAYER(hLtdc, LayerIdx)

    L->WHPCR&=~(LTDC_LxWHPCR_WHSTPOS|LTDC_LxWHPCR_WHSPPOS);
    T=(LtdcInst->BPCR & LTDC_BPCR_AHBP)>>16;
    L->WHPCR=(LC->WindowX0+T+1) | ((LC->WindowX1+T)<<16);

    L->WVPCR&=~(LTDC_LxWVPCR_WVSTPOS|LTDC_LxWVPCR_WVSPPOS);
    T=LtdcInst->BPCR & LTDC_BPCR_AVBP;
    L->WVPCR=(LC->WindowY0+T+1) | ((LC->WindowY1+T)<<16);

    L->PFCR&=~LTDC_LxPFCR_PF;
    L->PFCR=LC->PixelFormat;

    L->DCCR&=~(LTDC_LxDCCR_DCBLUE|LTDC_LxDCCR_DCGREEN|LTDC_LxDCCR_DCRED|LTDC_LxDCCR_DCALPHA);
    L->DCCR=LC->Backcolor.Blue|(LC->Backcolor.Green<<8)|(LC->Backcolor.Red<<16)|(LC->Alpha0<<24);

    L->CACR&=~LTDC_LxCACR_CONSTA;
    L->CACR=LC->Alpha;

    L->BFCR&=~(LTDC_LxBFCR_BF2|LTDC_LxBFCR_BF1);
    L->BFCR=LC->BlendingFactor1|LC->BlendingFactor2;

    L->CFBAR&=~LTDC_LxCFBAR_CFBADD;
    L->CFBAR=LC->FBStartAdress;

    T=1;
    if (LC->PixelFormat==LTDC_PIXEL_FORMAT_ARGB8888)    T=4;
    else if (LC->PixelFormat==LTDC_PIXEL_FORMAT_RGB888) T=3;
    else if (LC->PixelFormat==LTDC_PIXEL_FORMAT_ARGB4444 ||
             LC->PixelFormat==LTDC_PIXEL_FORMAT_RGB565   ||
             LC->PixelFormat==LTDC_PIXEL_FORMAT_ARGB1555 ||
             LC->PixelFormat==LTDC_PIXEL_FORMAT_AL88)   T=2;

    L->CFBLR&=~(LTDC_LxCFBLR_CFBLL|LTDC_LxCFBLR_CFBP);
    L->CFBLR=(LC->ImageWidth*T<<16) | ((LC->WindowX1-LC->WindowX0)*T+3);
    L->CFBLNR&=~LTDC_LxCFBLNR_CFBLNBR;
    L->CFBLNR=LC->ImageHeight;
    L->CR|=LTDC_LxCR_LEN;
    }




HAL_StatusTypeDef HAL_LTDC_SetWindowPosition(LTDC_HandleTypeDef *hLtdc, UINT X0, UINT Y0, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->WindowX0=X0;
    LC->WindowX1=X0+LC->ImageWidth;
    LC->WindowY0=Y0;
    LC->WindowY1=Y0+LC->ImageHeight;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    hLtdc->Instance->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }




HAL_StatusTypeDef HAL_LTDC_SetWindowPosition_NoReload(LTDC_HandleTypeDef *hLtdc, UINT X0, UINT Y0, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->WindowX0=X0;
    LC->WindowX1=X0+LC->ImageWidth;
    LC->WindowY0=Y0;
    LC->WindowY1=Y0+LC->ImageHeight;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_ConfigLayer(LTDC_HandleTypeDef *hLtdc, LTDC_LayerCfgTypeDef *LC, UINT LayerIdx)
    {
    hLtdc->LayerCfg[LayerIdx]=*LC;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    hLtdc->Instance->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_EnableCLUT(LTDC_HandleTypeDef *hLtdc, UINT LayerIdx)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LTDC_LAYER_J(LtdcInst, LayerIdx)->CR|=LTDC_LxCR_CLUTEN;
    LtdcInst->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_Reload(LTDC_HandleTypeDef *hLtdc, UINT ReloadType)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LtdcInst->IER|=LTDC_IT_RR;      //__HAL_LTDC_ENABLE_IT(hLtdc, LTDC_IT_RR);
    LtdcInst->SRCR=ReloadType;
    return HAL_OK;
    }




//Color Look-Up Table (CLUT)
HAL_StatusTypeDef HAL_LTDC_ConfigCLUT(LTDC_HandleTypeDef *hLtdc, UINT *Cult, UINT ClutSize, UINT LayerIdx)
    {
    UINT I, T, Clu;
    LTDC_Layer_TypeDef *L;

    L=LTDC_LAYER_J(hLtdc->Instance, LayerIdx);

    for (I=0; I<ClutSize; I++)
        {
        Clu=((*Cult++)<<8)>>8;
        if (hLtdc->LayerCfg[LayerIdx].PixelFormat==LTDC_PIXEL_FORMAT_AL44)
            T=(((I<<4)+I)<<24)|Clu;
        else
            T=(I<<24)|Clu;

        L->CLUTWR=T;
        }
    return HAL_OK;
    }





HAL_StatusTypeDef HAL_LTDC_SetAddress(LTDC_HandleTypeDef *hLtdc, UINT Address, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->FBStartAdress=Address;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    hLtdc->Instance->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }


HAL_StatusTypeDef HAL_LTDC_SetAddress_NoReload(LTDC_HandleTypeDef *hLtdc, UINT Address, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->FBStartAdress=Address;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_SetWindowSize(LTDC_HandleTypeDef *hLtdc, UINT XSize, UINT YSize, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->WindowX1=XSize+LC->WindowX0;
    LC->WindowY1=YSize+LC->WindowY0;
    LC->ImageWidth=XSize;
    LC->ImageHeight=YSize;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    hLtdc->Instance->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_SetWindowSize_NoReload(LTDC_HandleTypeDef *hLtdc, UINT XSize, UINT YSize, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->WindowX1=XSize+LC->WindowX0;
    LC->WindowY1=YSize+LC->WindowY0;
    LC->ImageWidth=XSize;
    LC->ImageHeight=YSize;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_SetAlpha(LTDC_HandleTypeDef *hLtdc, UINT Alpha, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->Alpha=Alpha;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    hLtdc->Instance->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_SetAlpha_NoReload(LTDC_HandleTypeDef *hLtdc, UINT Alpha, UINT LayerIdx)
    {
    LTDC_LayerCfgTypeDef *LC;

    LC=&hLtdc->LayerCfg[LayerIdx];
    LC->Alpha=Alpha;
    LTDC_SetConfig(hLtdc, LC, LayerIdx);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_ConfigColorKeying(LTDC_HandleTypeDef *hLtdc, UINT RGB, UINT LayerIdx)
    {
    LTDC_TypeDef *LtdcInst;
    LTDC_Layer_TypeDef  *L;

    LtdcInst=hLtdc->Instance;
    L=LTDC_LAYER_J(LtdcInst, LayerIdx); //LTDC_LAYER(hLtdc, LayerIdx)

    L->CKCR&=~(LTDC_LxCKCR_CKBLUE|LTDC_LxCKCR_CKGREEN|LTDC_LxCKCR_CKRED);
    L->CKCR=RGB;
    LtdcInst->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_EnableColorKeying(LTDC_HandleTypeDef *hLtdc, UINT LayerIdx)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LTDC_LAYER_J(LtdcInst, LayerIdx)->CR|=LTDC_LxCR_COLKEN;
    LtdcInst->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_EnableColorKeying_NoReload(LTDC_HandleTypeDef *hLtdc, UINT LayerIdx)
    {
    LTDC_LAYER(hLtdc, LayerIdx)->CR|=LTDC_LxCR_COLKEN;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_LTDC_DisableColorKeying(LTDC_HandleTypeDef *hLtdc, UINT LayerIdx)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LTDC_LAYER_J(LtdcInst, LayerIdx)->CR&=~LTDC_LxCR_COLKEN;
    LtdcInst->SRCR=LTDC_SRCR_IMR;
    return HAL_OK;
    }


HAL_StatusTypeDef HAL_LTDC_DisableColorKeying_NoReload(LTDC_HandleTypeDef *hLtdc, UINT LayerIdx)
    {
    LTDC_LAYER(hLtdc, LayerIdx)->CR&=~LTDC_LxCR_COLKEN;
    return HAL_OK;
    }




HAL_StatusTypeDef HAL_LTDC_Init(LTDC_HandleTypeDef *hLtdc)
    {
    LTDC_TypeDef *LtdcInst;

    LtdcInst=hLtdc->Instance;
    LtdcInst->GCR&=~(LTDC_GCR_HSPOL|LTDC_GCR_VSPOL|LTDC_GCR_DEPOL|LTDC_GCR_PCPOL);
    LtdcInst->GCR|=hLtdc->Init.HSPolarity|
                   hLtdc->Init.VSPolarity|
                   hLtdc->Init.DEPolarity|
                   hLtdc->Init.PCPolarity;

    LtdcInst->SSCR&=~(LTDC_SSCR_VSH|LTDC_SSCR_HSW);
    LtdcInst->SSCR|=(hLtdc->Init.HorizontalSync<<16) |
                     hLtdc->Init.VerticalSync;

    LtdcInst->BPCR&=~(LTDC_BPCR_AVBP|LTDC_BPCR_AHBP);
    LtdcInst->BPCR|=(hLtdc->Init.AccumulatedHBP<<16) |
                     hLtdc->Init.AccumulatedVBP;

    LtdcInst->AWCR&=~(LTDC_AWCR_AAH|LTDC_AWCR_AAW);
    LtdcInst->AWCR|=(hLtdc->Init.AccumulatedActiveW<<16) |
                     hLtdc->Init.AccumulatedActiveH;

    LtdcInst->TWCR&=~(LTDC_TWCR_TOTALH|LTDC_TWCR_TOTALW);
    LtdcInst->TWCR|=(hLtdc->Init.TotalWidth<<16) |
                     hLtdc->Init.TotalHeigh;

    LtdcInst->BCCR&=~(LTDC_BCCR_BCBLUE|LTDC_BCCR_BCGREEN|LTDC_BCCR_BCRED);
    LtdcInst->BCCR|=(hLtdc->Init.Backcolor.Red<<16) |
                    (hLtdc->Init.Backcolor.Green<<8) |
                     hLtdc->Init.Backcolor.Blue;

    LtdcInst->IER|=LTDC_IT_TE|LTDC_IT_FU;       //__HAL_LTDC_ENABLE_IT(hLtdc);
    LtdcInst->GCR|=LTDC_GCR_LTDCEN;             //__HAL_LTDC_ENABLE(hLtdc);

    hLtdc->ErrorCode=HAL_LTDC_ERROR_NONE;
    return HAL_OK;
    }



