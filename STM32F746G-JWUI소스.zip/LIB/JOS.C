///////////////////////////////////////////////////////////////////////////////
//                          JOS 1.1 CORE
//
//      ROM: 2914 Byte, RAM: 292 Byte (������ �� map ����, ����:2022-07-06)
//      RAMũ�⿡�� Ÿ��ũ ���� �� ������Ʈ�� ������� ����
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "JOS.H"


#define MEMOWNER_CreateThread   (MEMOWNER_JOS+0)
#define MEMOWNER_JOSQCreate     (MEMOWNER_JOS+1)
#define MEMOWNER_CreateSemaphore (MEMOWNER_JOS+2)


static BYTE JOSRunning;
static BYTE JOSIntNesting;
       BYTE JOSCurrPrio;
static BYTE JOSPrioHighRdy;
       BYTE JOSCpuUsage;

static BYTE LockNesting;
static TASK_LIST TaskReadyTable;
static DWORD G_LastResult;

static JOS_TCB *CurrentTCB;     //���� Run���� Ÿ��ũ
static JOS_TCB *UsingTcbList;   //��ϵ� Ÿ��ũ�� TCB ����Ʈ
static JOS_TCB *TcbPrioTbl[PRIO_IDLETASK+1];



//-----------------------------------------------------------------------------
//      �־��� BYTE�� Bit0���� ���� 1�� ã�� ��ġ
//-----------------------------------------------------------------------------
static CONST BYTE JOSUnMapTbl[256]=
    {
    0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0 to 0x0F
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x10 to 0x1F
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x20 to 0x2F
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x30 to 0x3F
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x40 to 0x4F
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x50 to 0x5F
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x60 to 0x6F
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x70 to 0x7F
    7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x80 to 0x8F
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0x90 to 0x9F
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0xA0 to 0xAF
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0xB0 to 0xBF
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0xC0 to 0xCF
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0xD0 to 0xDF
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,     //0xE0 to 0xEF
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0      //0xF0 to 0xFF
    };



//-----------------------------------------------------------------------------
//      ���� ���
//-----------------------------------------------------------------------------
DWORD WINAPI JOSVersion(VOID)
    {
    return JOS_VERSION;
    }




#if PRIO_IDLETASK>63
LOCAL(UINT) GetBitPos16(UINT Bit16)
    {
    UINT Pos;

    if (Bit16 & 0xFF) Pos=JOSUnMapTbl[Bit16&0xFF];
    else              Pos=JOSUnMapTbl[Bit16>>8]+8;
    return Pos;
    }
#endif




//-----------------------------------------------------------------------------
//      �̺�Ʈ�� �´��� �˷���
//-----------------------------------------------------------------------------
#if JOS_EVENT_EN && JOS_EVENT_NAME_EN
LOCAL(BOOL) IsEvent(JOS_EVENT *Ev)
    {
    BOOL Rslt=FALSE;

    switch (Ev->EventType)
        {
        //case JOS_EVENT_TYPE_MUTEX:
        //case JOS_EVENT_TYPE_MBOX:
        case JOS_EVENT_TYPE_SEM:
        case JOS_EVENT_TYPE_Q: Rslt++;
        }
    return Rslt;
    }



JOS_RESULT WINAPI JOSGetEventName(JOS_EVENT *Ev, LPSTR Buff, int BuffSize)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (Buff==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (IsEvent(Ev)==FALSE) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    lstrcpyn(Buff, Ev->EventName, BuffSize);
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }



JOS_RESULT WINAPI JOSSetEventName(JOS_EVENT *Ev, LPCSTR Name)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (Name==NULL) return JOS_ERR_NULL_PARAM;
    #endif

    if (IsEvent(Ev)==FALSE) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    lstrcpyn(Ev->EventName, Name, JOS_EVENT_NAME_EN);
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif //JOS_EVENT_EN && JOS_EVENT_NAME_EN




//-----------------------------------------------------------------------------
//      �־��� Ÿ��ũ�� �غ񸮽�Ʈ�� ���
//-----------------------------------------------------------------------------
LOCAL(VOID) SetTaskReadyBit(CONST JOS_TCB *TCB)
    {
    TaskReadyTable.TableY|=TCB->TcbBitY;
    TaskReadyTable.Table[TCB->TcbY]|=TCB->TcbBitX;
    }



//-----------------------------------------------------------------------------
//      �־��� Ÿ��ũ�� �غ񸮽�Ʈ���� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) ClrTaskReadyBit(CONST JOS_TCB *TCB)
    {
    if ((TaskReadyTable.Table[TCB->TcbY]&=~TCB->TcbBitX)==0)
        TaskReadyTable.TableY&=~TCB->TcbBitY;
    }




#if JOS_EVENT_EN
//-----------------------------------------------------------------------------
//      �־��� Ÿ��ũ�� �̺�Ʈ�� ��⸮��Ʈ�� ���
//-----------------------------------------------------------------------------
LOCAL(VOID) SetEventWaitTaskBit(JOS_EVENT *Ev, CONST JOS_TCB *TCB)
    {
    Ev->EventTaskList.Table[TCB->TcbY]|=TCB->TcbBitX;
    Ev->EventTaskList.TableY|=TCB->TcbBitY;
    }



//-----------------------------------------------------------------------------
//      �־��� Ÿ��ũ�� �̺�Ʈ�� ��⸮��Ʈ���� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) ClrEventWaitTaskBit(JOS_EVENT *Ev, CONST JOS_TCB *TCB)
    {
    if ((Ev->EventTaskList.Table[TCB->TcbY]&=~TCB->TcbBitX)==0)
        Ev->EventTaskList.TableY&=~TCB->TcbBitY;
    }


#if JOS_EVENT_MULTI_EN
LOCAL(VOID) ClrEventWaitTaskBitMulti(JOS_EVENT **PendEvList, JOS_TCB *TCB)
    {
    JOS_EVENT *Ev;

    for (;;)
        {
        if ((Ev=*PendEvList++)==NULL) break;
        ClrEventWaitTaskBit(Ev, TCB);
        }
    }
#endif
#endif //JOS_EVENT_EN




//-----------------------------------------------------------------------------
//      �켱 ������ ���� ���� Ÿ��ũ�� ���� Ÿ��ũ�� �ƴϸ� ������ȯ
//-----------------------------------------------------------------------------
LOCAL(VOID) Scheduling(BOOL InIrq)
    {
    UINT Y;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if (InIrq && JOSIntNesting>0) JOSIntNesting--;

    if (JOSIntNesting==0 && LockNesting==0)
        {
        #if PRIO_IDLETASK<=63
        Y=JOSUnMapTbl[TaskReadyTable.TableY];
        JOSPrioHighRdy=JOSUnMapTbl[TaskReadyTable.Table[Y]]+(Y<<3);
        #else
        Y=GetBitPos16(TaskReadyTable.TableY);
        JOSPrioHighRdy=GetBitPos16(TaskReadyTable.Table[Y])+(Y<<4);
        #endif

        if (JOSPrioHighRdy!=JOSCurrPrio)
            {
            if (InIrq==FALSE) JOSCtxSw(); else JOSIntCtxSw();
            }
        }
    JOS_EXIT_CRITICAL();
    }




//-----------------------------------------------------------------------------
//          PendSV���� ������ �����ϰ� ȣ���� (���ͷ�Ʈ ���� ȣ���)
//-----------------------------------------------------------------------------
JOS_STK* WINAPI JOSTaskSwitching(JOS_STK *PrevSP)
    {
    if (CurrentTCB)     //�� ó���� Ÿ��ũ�� �����ÿ� NULL
        {
        CurrentTCB->StackPtr=PrevSP;
        CurrentTCB->WorkingTime+=FineTickCnt - CurrentTCB->WorkStartTime;
        }

    JOSTaskSwHook();

    CurrentTCB=TcbPrioTbl[JOSCurrPrio=JOSPrioHighRdy];
    CurrentTCB->WorkStartTime=FineTickCnt;
    return CurrentTCB->StackPtr;
    }




//-----------------------------------------------------------------------------
//      �־��� Prio�� �ش��ϴ� TCB�� ����
//-----------------------------------------------------------------------------
LOCAL(JOS_TCB*) GetTCB(UINT Prio, JOS_RESULT *lpRslt)
    {
    JOS_TCB *TCB;

    if (Prio==JOS_PRIO_SELF) Prio=CurrentTCB->TcbPrio;
    if ((TCB=TcbPrioTbl[Prio])==NULL) *lpRslt=JOS_ERR_TASK_NOT_EXIST;
    else if (TCB==JOS_TCB_RESERVED) {*lpRslt=JOS_ERR_TASK_NOT_EXIST; TCB=NULL;}
    return TCB;
    }





///////////////////////////////////////////////////////////////////////////////
//                          Kernal
///////////////////////////////////////////////////////////////////////////////


VOID WINAPI JOSIntEnter(VOID)
    {
    if (JOSRunning) JOSIntNesting++;
    }



VOID WINAPI JOSIntExit(VOID)
    {
    if (JOSRunning) Scheduling(TRUE);
    }




#if JOS_SCHED_LOCK_EN
//-----------------------------------------------------------------------------
//      �����층�� ����
//-----------------------------------------------------------------------------
VOID WINAPI JOSSchedLock(VOID)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        if (JOSIntNesting==0 && LockNesting<255) LockNesting++;
        JOS_EXIT_CRITICAL();
        }
    }




//-----------------------------------------------------------------------------
//      �����층 �簳
//-----------------------------------------------------------------------------
VOID WINAPI JOSSchedUnlock(VOID)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        if (JOSIntNesting==0 && LockNesting>0 && --LockNesting==0)
            {
            JOS_EXIT_CRITICAL();
            Scheduling(FALSE);
            goto ProcExit;
            }
        JOS_EXIT_CRITICAL();
        }
    ProcExit:;
    }
#endif




//-----------------------------------------------------------------------------
//      JOS Ÿ��ƽ ó��
//-----------------------------------------------------------------------------
VOID WINAPI JOSTimeTick(VOID)
    {
    JOS_TCB *TCB;
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        for (TCB=UsingTcbList; TCB->TcbPrio!=PRIO_IDLETASK; TCB=TCB->Next)
            {
            if (TCB->TcbDelay!=0 && --TCB->TcbDelay==0)
                {
                if (TCB->TcbState & JOS_STAT_PEND_ANY)
                    TCB->PendResult=JOS_STAT_PEND_TIMEOUT;

                if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) SetTaskReadyBit(TCB);
                }
            }
        JOS_EXIT_CRITICAL();
        }
    }




//-----------------------------------------------------------------------------
//      ���̵� Ÿ��ũ
//
// ����ڰ� ���� Ÿ��ũ�߿� ����Ÿ��ũ(��ȥ�� ���ó���ϴ�)�� ������ CPU������
// �������� ����. �� Ÿ��ũ�� ����� Ÿ��ũ���� �켱������ �������̱� ����
//-----------------------------------------------------------------------------
static VOID CALLBACK JOS_IdleTask(LPVOID lpArg)
    {
    DWORD Time;
    JOS_TCB *TCB;
    JOS_CRITICAL_VAR;

    Time=FineTickCnt;
    for (;;)
        {
        if (FineTickCnt-Time>=1000)
            {
            JOS_ENTER_CRITICAL();
            for (TCB=UsingTcbList; ;TCB=TCB->Next)
                {
                TCB->CpuUsage=TCB->WorkingTime/10;
                TCB->WorkingTime=0;
                if (TCB->TcbPrio==PRIO_IDLETASK) {JOSCpuUsage=100-TCB->CpuUsage; break;}
                }
            JOS_EXIT_CRITICAL();

            Time=FineTickCnt;
            }
        JOSTaskIdleHook();
        }
    }




#if JOS_TASK_CHANGE_PRIO_EN
JOS_RESULT WINAPI JOSTaskChangePrio(UINT OldPrio, UINT NewPrio)
    {
    UINT NewY, NewBitX, NewBitY;
    JOS_TCB *TCB;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;
    #if JOS_EVENT_EN
    JOS_EVENT *Ev;
    #if JOS_EVENT_MULTI_EN
    JOS_EVENT**lpMultiEv;
    #endif
    #endif

    #if JOS_ARG_CHK_EN
    if (OldPrio>=PRIO_IDLETASK && OldPrio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    if (NewPrio>=PRIO_IDLETASK) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if (TcbPrioTbl[NewPrio]!=NULL) {JOS_EXIT_CRITICAL(); return JOS_ERR_PRIO_EXIST;}
    if ((TCB=GetTCB(OldPrio, &Rslt))==NULL) {JOS_EXIT_CRITICAL(); return Rslt;}

    #if PRIO_IDLETASK<=63
    NewY=NewPrio>>3;
    NewBitX=1<<(NewPrio&7);
    #else
    NewY=NewPrio>>4;
    NewBitX=1<<(NewPrio&0x0F);
    #endif
    NewBitY=1<<NewY;

    TcbPrioTbl[OldPrio]=NULL;
    TcbPrioTbl[NewPrio]=TCB;

    if ((TaskReadyTable.Table[TCB->TcbY] & TCB->TcbBitX)!=0)
        {
        ClrTaskReadyBit(TCB);

        TaskReadyTable.TableY|=NewBitY;
        TaskReadyTable.Table[NewY]|=NewBitX;
        }

    #if JOS_EVENT_EN
    if ((Ev=TCB->WaitEventPtr)!=NULL)
        {
        ClrEventWaitTaskBit(Ev, TCB);

        Ev->EventTaskList.TableY|=NewBitY;
        Ev->EventTaskList.Table[NewY]|=NewBitX;
        }

    #if JOS_EVENT_MULTI_EN
    if ((lpMultiEv=TCB->MultiWaitEventPtr)!=NULL)
        {
        for (;;)
            {
            if ((Ev=*lpMultiEv++)==NULL) break;
            ClrEventWaitTaskBit(Ev, TCB);

            Ev->EventTaskList.TableY|=NewBitY;
            Ev->EventTaskList.Table[NewY]|=NewBitX;
            }
        }
    #endif
    #endif

    TCB->TcbPrio=NewPrio;
    TCB->TcbY=NewY;
    TCB->TcbBitY=NewBitY;
    TCB->TcbBitX=NewBitX;
    JOS_EXIT_CRITICAL();

    if (JOSRunning) Scheduling(FALSE);
    return JOS_ERR_NONE;
    }
#endif



LOCAL(VOID) JOSTaskReturn(VOID)
    {
    TerminateThread(JOS_PRIO_SELF);
    for (;;);
    }




//-----------------------------------------------------------------------------
//      Ÿ��ũ�� ������
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI CreateThread(LPCSTR Name, UINT StackSize, TASKPROC TaskProc, LPVOID TaskArg, UINT Prio)
    {
    BOOL Rslt=FALSE;
    JOS_TCB *TCB;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Prio>PRIO_IDLETASK) return JOS_ERR_PRIO_INVALID;
    #endif
    if (JOSIntNesting>0) return JOS_ERR_TASK_CREATE_ISR;

    JOS_ENTER_CRITICAL();
    if (TcbPrioTbl[Prio]==NULL) {TcbPrioTbl[Prio]=JOS_TCB_RESERVED; Rslt++;}    //�־��� Ÿ��ũ�� ���ص�
    JOS_EXIT_CRITICAL();
    if (Rslt==FALSE) return JOS_ERR_PRIO_EXIST;

    if ((TCB=(JOS_TCB*)AllocMem(StackSize*sizeof(JOS_STK)+sizeof(JOS_TCB), MEMOWNER_CreateThread))==NULL)
        {
        TcbPrioTbl[Prio]=NULL;
        return JOS_ERR_TASK_NO_MORE_TCB;
        }
    ZeroMem(TCB, StackSize*sizeof(JOS_STK)+sizeof(JOS_TCB));
    TCB->StackBegin=(JOS_STK*)((LPBYTE)TCB+sizeof(JOS_TCB));
    TCB->StackPtr=JOSTaskStkInit(TaskProc, TaskArg, TCB->StackBegin+StackSize, JOSTaskReturn);
    TCB->StackSize=StackSize;
    TCB->TcbPrio=Prio;
    //TCB->PendResult=JOS_STAT_PEND_OK;  //=0
    //TCB->TcbState=0;
    //TCB->TcbDelay=0;

    TCB->TcbDelReq=JOS_ERR_NONE;

    #if PRIO_IDLETASK<=63
    TCB->TcbY=Prio>>3;    //0~7
    TCB->TcbBitX=1<<(Prio&7);
    #else
    TCB->TcbY=Prio>>4;    //0~15
    TCB->TcbBitX=1<<(Prio&0x0F);
    #endif
    TCB->TcbBitY=1<<TCB->TcbY;


    #if JOS_TASK_NAME_EN
    TCB->TaskName[0]='?';
    if (Name) lstrcpyn(TCB->TaskName, Name, JOS_TASK_NAME_EN);
    #endif

    JOSTcbInitHook(TCB);
    TcbPrioTbl[Prio]=TCB;
    CreateThreadHook(TCB);

    JOS_ENTER_CRITICAL();
    TCB->Next=UsingTcbList;
    //TCB->Prev=NULL;
    if (UsingTcbList!=NULL) UsingTcbList->Prev=TCB;
    UsingTcbList=TCB;
    SetTaskReadyBit(TCB);
    JOS_EXIT_CRITICAL();

    if (JOSRunning) Scheduling(FALSE);
    return JOS_ERR_NONE;
    }




//-----------------------------------------------------------------------------
//      Ÿ��ũ�� ������
//      �ڽ��� ����� ��� ������ ��쿡�� ���Լ� ȣ���ߴ� ������ �������� ����
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI TerminateThread(UINT Prio)
    {
    JOS_TCB *TCB, *Prev, *Next;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (JOSIntNesting>0) return JOS_ERR_TASK_DEL_ISR;
    if (Prio==PRIO_IDLETASK) return JOS_ERR_TASK_DEL_IDLE;

    #if JOS_ARG_CHK_EN
    if (Prio!=JOS_PRIO_SELF && Prio>=PRIO_IDLETASK) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))==NULL) {JOS_EXIT_CRITICAL(); return Rslt;}

    ClrTaskReadyBit(TCB);               //�غ񸮽�Ʈ���� ����

    #if JOS_EVENT_EN
    if (TCB->WaitEventPtr!=NULL) ClrEventWaitTaskBit(TCB->WaitEventPtr, TCB);

    #if JOS_EVENT_MULTI_EN
    if (TCB->MultiWaitEventPtr!=NULL) ClrEventWaitTaskBitMulti(TCB->MultiWaitEventPtr, TCB);
    #endif
    #endif //JOS_EVENT_EN

    TerminateThreadHook(TCB);

    if (Prio==JOS_PRIO_SELF) Prio=CurrentTCB->TcbPrio;
    TcbPrioTbl[Prio]=NULL;

    Next=TCB->Next;
    if ((Prev=TCB->Prev)==NULL)         //�Ǿտ� �ִ� ���� (�ǳ��߿� ���� Ÿ��ũ��)
        {
        Next->Prev=NULL;
        UsingTcbList=Next;
        }
    else{
        Prev->Next=Next;
        Next->Prev=Prev;
        }
    if (CurrentTCB==TCB) CurrentTCB=NULL;
    JOS_EXIT_CRITICAL();

    FreeMem(TCB);
    if (JOSRunning) Scheduling(FALSE);
    return JOS_ERR_NONE;
    }




//-----------------------------------------------------------------------------
//              �ش� Ÿ��ũ���� �׾�޶�� ��Ź�� ��
//
//              �׾�޶�� ��Ź�� �޴� ��
//                   VOID Task(LPVOID data)
//                       {
//                       .
//                       .
//                       for (;;)
//                           {
//                           JOSTimeDly(1);
//                           if (JOSTaskDelReq(JOS_PRIO_SELF)==JOS_ERR_TASK_DEL_REQ)
//                               {
//                               �ٸ� �ڿ� �ع�
//                               JOSTaskDel(JOS_PRIO_SELF);
//                               }
//                           }
//                       }
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSTaskDelReq(UINT Prio)
    {
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    if (Prio==PRIO_IDLETASK) return JOS_ERR_TASK_DEL_IDLE;

    #if JOS_ARG_CHK_EN
    if (Prio>=PRIO_IDLETASK && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if (Prio==JOS_PRIO_SELF) Rslt=CurrentTCB->TcbDelReq;
    else if ((TCB=GetTCB(Prio, &Rslt))!=NULL) TCB->TcbDelReq=JOS_ERR_TASK_DEL_REQ;
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




#if JOS_TASK_SUSPEND_EN
//-----------------------------------------------------------------------------
//      �Ͻ�������(Suspend) Ÿ��ũ�� �����簳��
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI ResumeThread(UINT Prio)
    {
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Prio>=PRIO_IDLETASK) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))==NULL) goto ProcExit;
    if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) {Rslt=JOS_ERR_TASK_NOT_SUSPENDED; goto ProcExit;}

    TCB->TcbState&=~JOS_STAT_SUSPEND;
    if ((TCB->TcbState & JOS_STAT_PEND_ANY)==0 && TCB->TcbDelay==0)
        {
        SetTaskReadyBit(TCB);
        JOS_EXIT_CRITICAL();

        if (JOSRunning) Scheduling(FALSE);
        return JOS_ERR_NONE;
        }

    ProcExit:
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �־��� Ÿ��ũ�� �Ͻ����� ��
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI SuspendThread(UINT Prio)
    {
    BOOL Self=FALSE;
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Prio==PRIO_IDLETASK) return JOS_ERR_TASK_SUSPEND_IDLE;
    if (Prio>=PRIO_IDLETASK && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if (Prio==JOS_PRIO_SELF) {Prio=CurrentTCB->TcbPrio; Self=TRUE;}
    else if (Prio==CurrentTCB->TcbPrio) Self=TRUE;

    if ((TCB=GetTCB(Prio, &Rslt))!=NULL)
        {
        ClrTaskReadyBit(TCB);
        TCB->TcbState|=JOS_STAT_SUSPEND;
        }
    JOS_EXIT_CRITICAL();

    if (Rslt==JOS_ERR_NONE && Self==TRUE) Scheduling(FALSE);
    return Rslt;
    }
#endif




#if JOS_TASK_QUERY_EN
//-----------------------------------------------------------------------------
//      TCB ���� ����, ���� ��뷮�� ���Ե�
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSTaskQuery(UINT Prio, JOS_TCBINFO *TI)
    {
    UINT Free=0;
    JOS_TCB *TCB;
    JOS_STK *lpStk;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Prio>PRIO_IDLETASK && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))!=NULL)
        {
        #if JOS_TASK_NAME_EN
        lstrcpyn(TI->TaskName, TCB->TaskName, JOS_TASK_NAME_EN);
        #endif
        TI->CpuUsage=TCB->CpuUsage;
        CopyMem(TI->Context, TI->StackPtr=TCB->StackPtr, JOS_TASK_CONTEXTSIZE*sizeof(UINT));

        lpStk=TCB->StackBegin;
        while (*lpStk++==0) Free++;
        TI->StackFree=Free*sizeof(JOS_STK);
        TI->StackSize=TCB->StackSize*sizeof(JOS_STK);
        }
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif




//-----------------------------------------------------------------------------
//      �־��� �̺�Ʈ�� ��� ���̿��� ���� ���� Ÿ��ũ�� �̺�Ʈ�� ������
//      �� Ÿ��ũ�� �غ񸮽�Ʈ�� ���
//-----------------------------------------------------------------------------
#if JOS_EVENT_EN
LOCAL(UINT) WaitEventTaskToReady(JOS_EVENT *Ev, DWORD QData, UINT ClearState, UINT PendStat)
    {
    UINT Y, Prio;
    JOS_TCB *TCB;

    #if PRIO_IDLETASK<=63
    Y=JOSUnMapTbl[Ev->EventTaskList.TableY];
    Prio=JOSUnMapTbl[Ev->EventTaskList.Table[Y]]+(Y<<3);
    #else
    Y=GetBitPos16(Ev->EventTaskList.TableY);
    Prio=GetBitPos16(Ev->EventTaskList.Table[Y])+(Y<<4);
    #endif

    TCB=TcbPrioTbl[Prio];
    TCB->TcbDelay=0;
    #if JOS_Q_EN
    TCB->QData=QData;
    #endif
    TCB->TcbState&=~ClearState;
    TCB->PendResult=PendStat;
    if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) SetTaskReadyBit(TCB);

    ClrEventWaitTaskBit(Ev, TCB);
    TCB->WaitEventPtr=NULL;

    #if JOS_EVENT_MULTI_EN
    if (TCB->MultiWaitEventPtr!=NULL)
        {
        ClrEventWaitTaskBitMulti(TCB->MultiWaitEventPtr, TCB);
        TCB->WaitEventPtr=Ev;
        }
    #endif
    return Prio;
    }




//-----------------------------------------------------------------------------
//      ���� Ÿ��ũ�� �־��� �̺�Ʈ�� ����ϰ� �غ񸮽�Ʈ���� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) CurrTaskToEventWait(JOS_EVENT *Ev, UINT State, DWORD Timeout)
    {
    CurrentTCB->TcbState|=State;
    CurrentTCB->PendResult=JOS_STAT_PEND_OK;
    CurrentTCB->TcbDelay=(Timeout==INFINITE) ? 0:Timeout;
    CurrentTCB->WaitEventPtr=Ev;
    SetEventWaitTaskBit(Ev, CurrentTCB);
    ClrTaskReadyBit(CurrentTCB);
    }




#if JOS_EVENT_MULTI_EN
LOCAL(VOID) CurrTaskToEventWaitMulti(JOS_EVENT** PendEvList, UINT State, DWORD Timeout)
    {
    JOS_EVENT *Ev;

    CurrentTCB->TcbState|=State|JOS_STAT_MULTI;
    CurrentTCB->PendResult=JOS_STAT_PEND_OK;
    CurrentTCB->TcbDelay=(Timeout==INFINITE) ? 0:Timeout;
    CurrentTCB->WaitEventPtr=NULL;
    CurrentTCB->MultiWaitEventPtr=PendEvList;

    for (;;)
        {
        if ((Ev=*PendEvList++)==NULL) break;
        SetEventWaitTaskBit(Ev, CurrentTCB);
        }
    ClrTaskReadyBit(CurrentTCB);
    }
#endif




//-----------------------------------------------------------------------------
//      Ÿ��ũ�� ��⸦ ���� ����ߴ� TCB ��� Ŭ����
//-----------------------------------------------------------------------------
LOCAL(VOID) FinishPend(VOID)
    {
    CurrentTCB->TcbState=0;
    CurrentTCB->PendResult=JOS_STAT_PEND_OK;
    CurrentTCB->WaitEventPtr=NULL;
    #if JOS_EVENT_MULTI_EN
    CurrentTCB->MultiWaitEventPtr=NULL;
    #endif
    #if JOS_Q_EN
    CurrentTCB->QData=0;
    #endif
    }

#endif //JOS_EVENT_EN




///////////////////////////////////////////////////////////////////////////////
//                          Semaphore
///////////////////////////////////////////////////////////////////////////////
#if JOS_SEM_EN

//-----------------------------------------------------------------------------
//      �����̸� JOSSemCreate
//-----------------------------------------------------------------------------
JOS_EVENT* WINAPI CreateSemaphore(int Cnt)
    {
    JOS_EVENT *Ev=NULL;

    if (JOSIntNesting>0) goto ProcExit;
    if ((Ev=AllocMemS(JOS_EVENT, MEMOWNER_CreateSemaphore))==NULL) goto ProcExit;
    ZeroMem(Ev, sizeof(JOS_EVENT));
    Ev->EventType=JOS_EVENT_TYPE_SEM;
    Ev->EventCnt=Cnt;

    ProcExit:
    return Ev;
    }




//-----------------------------------------------------------------------------
//      �����̸� JOSSemDel
//-----------------------------------------------------------------------------
#if JOS_SEM_DEL_EN
JOS_RESULT WINAPI DeleteSemaphore(JOS_EVENT *Ev, UINT Opt)
    {
    BOOL TasksWaiting;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (Ev->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;
    if (JOSIntNesting>0) return JOS_ERR_DEL_ISR;

    JOS_ENTER_CRITICAL();
    TasksWaiting=Ev->EventTaskList.TableY;
    switch (Opt)
        {
        case JOS_DEL_NO_PEND:
            if (TasksWaiting==FALSE) goto DelSem;
            Rslt=JOS_ERR_TASK_WAITING;
            break;

        case JOS_DEL_ALWAYS:
            while (Ev->EventTaskList.TableY!=0) WaitEventTaskToReady(Ev, 0, JOS_STAT_SEM, JOS_STAT_PEND_ABORT);

            DelSem:
            FreeMem(Ev);
            JOS_EXIT_CRITICAL();

            if (TasksWaiting) Scheduling(FALSE);
            Rslt=JOS_ERR_NONE;
            goto ProcExit;

        default:
            Rslt=JOS_ERR_INVALID_OPT;
        }
    JOS_EXIT_CRITICAL();

    ProcExit:
    return Rslt;
    }
#endif



//-----------------------------------------------------------------------------
//      �����̸� JOSSemPost
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI ReleaseSemaphore(JOS_EVENT *Ev)
    {
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    if (Ev->EventTaskList.TableY!=0)
        {
        WaitEventTaskToReady(Ev, 0, JOS_STAT_SEM, JOS_STAT_PEND_OK);
        JOS_EXIT_CRITICAL();
        Scheduling(FALSE);
        return JOS_ERR_NONE;
        }

    Rslt=JOS_ERR_SEM_OVF;
    if (Ev->EventCnt<65535)
        {
        Ev->EventCnt++;
        Rslt=JOS_ERR_NONE;
        }

    JOS_EXIT_CRITICAL();
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �����̸� JOSSemPend
//
//      �־��� ������� ��ȣ�� �ִ��� ���� ������ �����
//      Timeout==INFINITE(0xFFFFFFFF) �̸� ���� ���
//      Timeout==0 �� �ָ� JOSSemAccept()�� ���� ���ͷ�Ʈ���� ȣ���� �����ϰ�
//      ��ȣ�� ������ JOS_ERR_NONE ������ JOS_ERR_TIMEOUT ����
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI WaitSemaphore(JOS_EVENT *Ev, DWORD Timeout)
    {
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    #if JOS_ARG_CHK_EN
    if (Ev==NULL) {Rslt=JOS_ERR_PEVENT_NULL; goto ProcExit;}
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_SEM) {Rslt=JOS_ERR_EVENT_TYPE; goto ProcExit;}
    if (Timeout!=0)
        {
        if (JOSIntNesting>0) {Rslt=JOS_ERR_PEND_ISR; goto ProcExit;}
        if (LockNesting>0)   {Rslt=JOS_ERR_PEND_LOCKED; goto ProcExit;}
        }

    if (Ev->EventCnt>0) {Ev->EventCnt--; Rslt=JOS_ERR_NONE; goto ProcExit;}
    if (Timeout==0) {Rslt=JOS_ERR_TIMEOUT; goto ProcExit;}

    CurrTaskToEventWait(Ev, JOS_STAT_SEM, Timeout);
    JOS_EXIT_CRITICAL();

    Scheduling(FALSE);

    JOS_ENTER_CRITICAL();
    switch (CurrentTCB->PendResult)
        {
        case JOS_STAT_PEND_OK: Rslt=JOS_ERR_NONE; break;
        case JOS_STAT_PEND_ABORT: Rslt=JOS_ERR_PEND_ABORT; break;

        //case JOS_STAT_PEND_TIMEOUT:
        default:
            ClrEventWaitTaskBit(Ev, CurrentTCB);
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }
    FinishPend();

    ProcExit:
    JOS_EXIT_CRITICAL();
    return Rslt;
    }





#if JOS_SEM_PEND_ABORT_EN
JOS_RESULT WINAPI PendAbortSemaphore(JOS_EVENT *Ev, UINT Opt)
    {
    int Tasks=0;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (Ev->EventTaskList.TableY!=0)
        {
        WaitEventTaskToReady(Ev, 0, JOS_STAT_SEM, JOS_STAT_PEND_ABORT);
        Tasks++;
        if (Opt!=JOS_PEND_OPT_BROADCAST) break;
        }
    JOS_EXIT_CRITICAL();
    if (Tasks==0) return JOS_ERR_NONE;

    Scheduling(FALSE);
    return JOS_ERR_PEND_ABORT;
    }
#endif




#if JOS_SEM_QUERY_EN
JOS_RESULT WINAPI QuerySemaphore(JOS_EVENT *Ev, JOS_EVENT *lpEvDest)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpEvDest==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    CopyMem(lpEvDest, Ev, sizeof(JOS_EVENT));
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif


#endif //JOS_SEM_EN







///////////////////////////////////////////////////////////////////////////////
//                          JOS - Q
///////////////////////////////////////////////////////////////////////////////
#if JOS_Q_EN


//-----------------------------------------------------------------------------
//      QType: JOSQTYPE_BYTE, JOSQTYPE_WORD, JOSQTYPE_DWORD
//      ���ο��� �Ҵ�޵��� ������
//-----------------------------------------------------------------------------
JOS_EVENT* WINAPI JOSQCreate(UINT EntryQty, UINT QType)
    {
    int QSize;
    JOS_Q *Q;
    JOS_EVENT *Ev=NULL;

    if (JOSIntNesting>0) goto ProcExit;

    QSize=EntryQty*QType;
    if ((Ev=(JOS_EVENT*)AllocMem(JOS_EVENT_ALIGNED_SIZE+sizeof(JOS_Q)+QSize, MEMOWNER_JOSQCreate))==NULL) goto ProcExit;
    ZeroMem(Ev, sizeof(JOS_EVENT));

    Q=(JOS_Q*)((LPBYTE)Ev+JOS_EVENT_ALIGNED_SIZE);
    Q->Entry.B.QStart=
    Q->Entry.B.QIn=
    Q->Entry.B.QOut=
    Q->Entry.B.QEnd=(LPBYTE)Q+sizeof(JOS_Q);
    Q->Entry.B.QEnd+=QSize;

    Q->QSize=EntryQty;
    Q->QType=QType;
    Q->QEntries=0;

    Ev->EventType=JOS_EVENT_TYPE_Q;
    Ev->EventPtr=Q;
    //Ev->EventCnt=0;

    ProcExit:
    return Ev;
    }




#if JOS_Q_DEL_EN
//-----------------------------------------------------------------------------
//      �־��� Q�� ������
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSQDel(JOS_EVENT *Ev, UINT Opt)
    {
    BOOL TasksWaiting;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;
    if (JOSIntNesting>0) return JOS_ERR_DEL_ISR;

    JOS_ENTER_CRITICAL();
    TasksWaiting=Ev->EventTaskList.TableY;
    switch (Opt)
        {
        case JOS_DEL_NO_PEND:
            if (TasksWaiting==0) goto DelQ;
            Rslt=JOS_ERR_TASK_WAITING;
            break;

        case JOS_DEL_ALWAYS:
            while (Ev->EventTaskList.TableY!=0) WaitEventTaskToReady(Ev, 0, JOS_STAT_Q, JOS_STAT_PEND_ABORT);

            DelQ:
            JOS_EXIT_CRITICAL();
            FreeMem(Ev);
            if (TasksWaiting!=0) Scheduling(FALSE);
            return JOS_ERR_NONE;

        default:
            Rslt=JOS_ERR_INVALID_OPT;
            //break;
        }
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif




#if JOS_Q_FLUSH_EN
//-----------------------------------------------------------------------------
//      Q�� �ִ� Data�� ��� �������
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSQFlush(JOS_EVENT *Ev)
    {
    JOS_Q *Q;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;
    #endif

    JOS_ENTER_CRITICAL();
    Q=(JOS_Q*)Ev->EventPtr;
    Q->Entry.B.QIn=Q->Entry.B.QOut=Q->Entry.B.QStart;
    Q->QEntries=0;
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif




//-----------------------------------------------------------------------------
//      Q���� �����͸� ������
//-----------------------------------------------------------------------------
LOCAL(DWORD) GetQData(JOS_Q *Q)
    {
    DWORD Msg;

    switch (Q->QType)
        {
        case JOSQTYPE_BYTE: Msg=*Q->Entry.B.QOut++; break;
        case JOSQTYPE_WORD: Msg=*Q->Entry.W.QOut++; break;
        default:            Msg=*Q->Entry.D.QOut++; //break;
        }
    if (Q->Entry.B.QOut==Q->Entry.B.QEnd) Q->Entry.B.QOut=Q->Entry.B.QStart;
    Q->QEntries--;
    return Msg;
    }




//-----------------------------------------------------------------------------
//      Q�� �����Ͱ� ������ �����
//      Timeout==INFINITE(0xFFFFFFFF) �̸� ���� ���
//      Timeout==0 �� �ָ� JOSQAccept()�� ���� ���ͷ�Ʈ���� ȣ���� �����ϰ�
//      ��ȣ�� ������ JOS_ERR_NONE ������ JOS_ERR_TIMEOUT ����
//-----------------------------------------------------------------------------
DWORD WINAPI JOSQPend(JOS_EVENT *Ev, DWORD Timeout, JOS_RESULT *lpRslt)
    {
    DWORD Msg=0;
    JOS_Q *Q;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    #if JOS_ARG_CHK_EN
    if (Ev==NULL) {Rslt=JOS_ERR_PEVENT_NULL; goto ProcExit;}
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) {Rslt=JOS_ERR_EVENT_TYPE; goto ProcExit;}
    if (Timeout!=0)
        {
        if (JOSIntNesting>0) {Rslt=JOS_ERR_PEND_ISR; goto ProcExit;}
        if (LockNesting>0)   {Rslt=JOS_ERR_PEND_LOCKED; goto ProcExit;}
        }

    Q=(JOS_Q*)Ev->EventPtr;
    if (Q->QEntries>0) {Msg=GetQData(Q); Rslt=JOS_ERR_NONE; goto ProcExit;}
    if (Timeout==0) {Rslt=JOS_ERR_TIMEOUT; goto ProcExit;}

    CurrTaskToEventWait(Ev, JOS_STAT_Q, Timeout);
    JOS_EXIT_CRITICAL();

    Scheduling(FALSE);

    JOS_ENTER_CRITICAL();
    switch (CurrentTCB->PendResult)
        {
        case JOS_STAT_PEND_OK: Msg=CurrentTCB->QData; Rslt=JOS_ERR_NONE; break;
        case JOS_STAT_PEND_ABORT: Rslt=JOS_ERR_PEND_ABORT; break;

        //case JOS_STAT_PEND_TIMEOUT:
        default:
            ClrEventWaitTaskBit(Ev, CurrentTCB);
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }
    FinishPend();

    ProcExit:
    if (lpRslt!=NULL) *lpRslt=Rslt;
    JOS_EXIT_CRITICAL();
    return Msg;
    }




#if JOS_Q_PEND_ABORT_EN
//-----------------------------------------------------------------------------
//      �־��� Q�� ����ϰ� �ִ� ��� Ÿ��ũ�� ������ ����
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSQPendAbort(JOS_EVENT *Ev, UINT Opt)
    {
    int Tasks=0;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (Ev->EventTaskList.TableY!=0)
        {
        WaitEventTaskToReady(Ev, 0, JOS_STAT_Q, JOS_STAT_PEND_ABORT);
        Tasks++;
        if (Opt!=JOS_PEND_OPT_BROADCAST) break;
        }
    JOS_EXIT_CRITICAL();
    if (Tasks==0) return JOS_ERR_NONE;

    Scheduling(FALSE);
    return JOS_ERR_PEND_ABORT;
    }
#endif




//-----------------------------------------------------------------------------
//      �־��� �̺�Ʈ�� ������� Ÿ��ũ�� ������ �����
//      �̺�Ʈ���� ��⸮��Ʈ���� ����� �غ񸮽�Ʈ�� ������ϰ� �����층��
//
//      ������� Ÿ��ũ�� ������ Q�� �ְ� ������
//-----------------------------------------------------------------------------
#if JOS_Q_POST_EN
JOS_RESULT WINAPI JOSQPost(JOS_EVENT *Ev, DWORD Msg, UINT Opt)
    {
    int Tasks=0;
    JOS_Q *Q;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (Ev->EventTaskList.TableY!=0)
        {
        WaitEventTaskToReady(Ev, Msg, JOS_STAT_Q, JOS_STAT_PEND_OK);
        Tasks++;
        if ((Opt & JOS_POST_OPT_BROADCAST)==0) break;
        }

    if (Tasks>0)
        {
        JOS_EXIT_CRITICAL();
        if ((Opt & JOS_POST_OPT_NO_SCHED)==0) Scheduling(FALSE);
        return JOS_ERR_NONE;
        }

    Q=(JOS_Q*)Ev->EventPtr;
    if (Q->QEntries>=Q->QSize) {Rslt=JOS_ERR_Q_FULL; goto ProcExit;}

    if (Opt & JOS_POST_OPT_FRONT)
        {
        if (Q->Entry.B.QOut==Q->Entry.B.QStart) Q->Entry.B.QOut=Q->Entry.B.QEnd;
        switch (Q->QType)
            {
            case JOSQTYPE_BYTE:  *--Q->Entry.B.QOut=Msg; break;
            case JOSQTYPE_WORD:  *--Q->Entry.W.QOut=Msg; break;
            default:             *--Q->Entry.D.QOut=Msg; //break;
            }
        }
    else{
        switch (Q->QType)
            {
            case JOSQTYPE_BYTE:  *Q->Entry.B.QIn++=Msg; break;
            case JOSQTYPE_WORD:  *Q->Entry.W.QIn++=Msg; break;
            default:             *Q->Entry.D.QIn++=Msg; //break;
            }
        if (Q->Entry.B.QIn==Q->Entry.B.QEnd) Q->Entry.B.QIn=Q->Entry.B.QStart;
        }
    Q->QEntries++;
    Rslt=JOS_ERR_NONE;

    ProcExit:
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif





#if JOS_Q_QUERY_EN
//-----------------------------------------------------------------------------
//      Q�� ������ ����
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI JOSQQuery(JOS_EVENT *Ev, JOS_Q_INFO *QI)
    {
    DWORD Msg=0;
    JOS_Q *Q;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN
    if (Ev==NULL) return JOS_ERR_PEVENT_NULL;
    if (QI==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (Ev->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    Q=(JOS_Q*)Ev->EventPtr;
    if (Q->QEntries>0)
        {
        switch (Q->QType)
            {
            case JOSQTYPE_BYTE:  Msg=*Q->Entry.B.QOut; break;
            case JOSQTYPE_WORD:  Msg=*Q->Entry.W.QOut; break;
            default:             Msg=*Q->Entry.D.QOut; //break;
            }
        }
    QI->QEntry=Msg;
    QI->QEntries=Q->QEntries;
    QI->QSize=Q->QSize;
    JOS_EXIT_CRITICAL();

    return JOS_ERR_NONE;
    }




//-----------------------------------------------------------------------------
//      Q�ȿ� ����Ʈ ũ�⸦ ���� (�������� JOS�� ȣȯ�� ����)
//-----------------------------------------------------------------------------
int WINAPI JOSQEntries(JOS_EVENT *Ev)
    {
    JOS_Q_INFO QI;

    if (JOSQQuery(Ev, &QI)!=JOS_ERR_NONE) QI.QEntries=0;
    return QI.QEntries;
    }
#endif

#endif //JOS_Q_EN




//-----------------------------------------------------------------------------
//      PendEvList ����߿� �ϳ��� ��ȣ�� ������ ������
//      ReadyEvList[] �ȿ��� PendEvList�߿��� ��ȣ�� ������ �̺�Ʈ���� ��
//      �����층�� �Ͼ �ڿ��� ���� ��ȣ�� ���� �̺�Ʈ 1���� ��� ����
//-----------------------------------------------------------------------------
#if JOS_EVENT_EN && JOS_EVENT_MULTI_EN
int WINAPI JOSEventPendMulti(JOS_EVENT *PendEvList[], JOS_EVENT *ReadyEvList[], DWORD *lpQData, DWORD Timeout, JOS_RESULT *lpRslt)
    {
    int I, ReadyEvQty=0, EventsStat=0;
    JOS_RESULT Rslt;
    JOS_EVENT *Ev;
    #if JOS_Q_EN
    JOS_Q *Q;
    #endif
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    #if JOS_ARG_CHK_EN
    if (PendEvList==NULL || PendEvList[0]==NULL || ReadyEvList==NULL || lpQData==0) {Rslt=JOS_ERR_PEVENT_NULL; goto ProcExit;}
    #endif

    ReadyEvList[0]=NULL;
    if (JOSIntNesting>0) {Rslt=JOS_ERR_PEND_ISR; goto ProcExit;}
    if (LockNesting>0) {Rslt=JOS_ERR_PEND_LOCKED; goto ProcExit;}

    for (I=0; ;I++)
        {
        if ((Ev=PendEvList[I])==NULL) break;
        switch (Ev->EventType)
            {
            #if JOS_SEM_EN
            case JOS_EVENT_TYPE_SEM:
                if (Ev->EventCnt>0)
                    {
                    Ev->EventCnt--;
                    *ReadyEvList++=Ev;
                    *lpQData++=0;
                    ReadyEvQty++;
                    }
                else EventsStat|=JOS_STAT_SEM;
                break;
            #endif

            #if JOS_Q_EN
            case JOS_EVENT_TYPE_Q:
                Q=(JOS_Q*)Ev->EventPtr;
                if (Q->QEntries>0)
                    {
                    *lpQData++=GetQData(Q);
                    *ReadyEvList++=Ev;
                    ReadyEvQty++;
                    }
                else EventsStat|=JOS_STAT_Q;
                break;
            #endif

            default: Rslt=JOS_ERR_EVENT_TYPE; goto ProcExit;
            }
        }

    if (ReadyEvQty>0) {*ReadyEvList=NULL; Rslt=JOS_ERR_NONE; goto ProcExit;}

    CurrTaskToEventWaitMulti(PendEvList, EventsStat, Timeout);                  //���� Ÿ��ũ�� �־��� ��� �̺�Ʈ�� �����

    JOS_EXIT_CRITICAL();
    Scheduling(FALSE);
    JOS_ENTER_CRITICAL();

    switch (CurrentTCB->PendResult)
        {
        case JOS_STAT_PEND_OK:
        case JOS_STAT_PEND_ABORT:
            if ((Ev=CurrentTCB->WaitEventPtr)==NULL) goto FromTimeOut;          //NULL���� ���� �� ���� (���Ľ�)
            *ReadyEvList++=Ev;
            *ReadyEvList=NULL;
            ReadyEvQty=1;

            if (CurrentTCB->PendResult==JOS_STAT_PEND_ABORT)
                {
                *lpQData++=0;
                Rslt=JOS_ERR_PEND_ABORT;
                break;
                }

            switch (Ev->EventType)
                {
                #if JOS_SEM_EN
                case JOS_EVENT_TYPE_SEM: *lpQData++=0; break;
                #endif

                #if JOS_Q_EN
                case JOS_EVENT_TYPE_Q: *lpQData++=CurrentTCB->QData; break;
                #endif
                }
            Rslt=JOS_ERR_NONE;
            break;

        //case JOS_STAT_PEND_TIMEOUT:
        default:
            FromTimeOut:
            ClrEventWaitTaskBitMulti(PendEvList, CurrentTCB);
            *lpQData++=0;
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }

    FinishPend();

    ProcExit:
    JOS_EXIT_CRITICAL();
    if (lpRslt!=NULL) *lpRslt=Rslt;
    return ReadyEvQty;
    }
#endif





///////////////////////////////////////////////////////////////////////////////
//                          ��Ÿ
///////////////////////////////////////////////////////////////////////////////



//-----------------------------------------------------------------------------
//      ms ������ �ð� ����
//-----------------------------------------------------------------------------
VOID WINAPI Sleep(UINT ms)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        if (ms!=0 && JOSIntNesting==0 && LockNesting==0)
            {
            DWORD Ticks;

            #if JOS_TICKS_PER_SEC==1000
            Ticks=ms;
            #else
            if ((Ticks=UMulDiv(ms, JOS_TICKS_PER_SEC, 1000))==0) Ticks=1;
            #endif

            JOS_ENTER_CRITICAL();
            ClrTaskReadyBit(CurrentTCB);
            CurrentTCB->TcbDelay=Ticks;
            JOS_EXIT_CRITICAL();
            Scheduling(FALSE);
            }
        }
    else{
        DWORD Tick=FineTickCnt;
        while (FineTickCnt-Tick<ms);
        }
    }




//-----------------------------------------------------------------------------
//      JOS �ʱ�ȭ, ���� �� MemAllocInit() ���� �Ŀ� ȣ���� ��
//-----------------------------------------------------------------------------
VOID WINAPI JOSInit(VOID)
    {
    JOSInitHookBegin();

    JOSIntNesting=0;
    LockNesting=0;
    JOSRunning=FALSE;

    ZeroMem(&TaskReadyTable, sizeof(TaskReadyTable));
    JOSCurrPrio=PRIO_IDLETASK;              //�̷��� �ؾ� ���ʿ� Prio=0�� Ÿ��ũ�� �����층��
    JOSPrioHighRdy=0;
    CurrentTCB=NULL;

    ZeroMem(TcbPrioTbl, sizeof(TcbPrioTbl));
    UsingTcbList=NULL;
    CreateThread("Idle", IDLE_TASK_STK_SIZE, JOS_IdleTask, NULL, PRIO_IDLETASK);
    }




//-----------------------------------------------------------------------------
//      JOS ����, ó������ �ְ� �켱���� Ÿ��ũ ����
//-----------------------------------------------------------------------------
VOID WINAPI JOSStart(VOID)
    {
    JOSRunning=TRUE;
    Scheduling(FALSE);
    for (;;);
    }




//-----------------------------------------------------------------------------
//      TCB�� ��� ���� �����ϰų� ������
//-----------------------------------------------------------------------------
DWORD WINAPI GetLastError(VOID)
    {
    return (CurrentTCB!=NULL) ? CurrentTCB->LastResult:G_LastResult;
    }

VOID WINAPI SetLastError(DWORD ErrCode)
    {
    if (CurrentTCB!=NULL) CurrentTCB->LastResult=ErrCode; else G_LastResult=ErrCode;
    }




