///////////////////////////////////////////////////////////////////////////////
//      FFMPEG ���� ����
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "ZLIB.H"
#include "DRIVER.H" //Printf()
#include "JFAT.H"
#include "JWUI.H"



#define MODULE_TEST     0
#define PNGERR(...)     Printf(__VA_ARGS__)
#define PNGWARN(...)    Printf(__VA_ARGS__)
#define PNGDEBUG(...)   //Printf(__VA_ARGS__)


#define MEMOWNER_PNG_Init               (MEMOWNER_PNGDEC+0)
#define MEMOWNER_AV_DictSet             (MEMOWNER_PNGDEC+1)
#define MEMOWNER_Iso88591toUtf8         (MEMOWNER_PNGDEC+2)
#define MEMOWNER_AV_BPrintGetBuffer     (MEMOWNER_PNGDEC+3)
#define MEMOWNER_GetInternalBuffer      (MEMOWNER_PNGDEC+4)
#define MEMOWNER_AV_FastPaddedMalloc    (MEMOWNER_PNGDEC+5)
#define MEMOWNER_AV_FastPaddedMallocZ   (MEMOWNER_PNGDEC+6)
#define MEMOWNER_LoadPng                (MEMOWNER_PNGDEC+7)
#define MEMOWNER_PNG_GetImageSize       (MEMOWNER_PNGDEC+8)



#define AV_PIX_FMT_NONE         0
#define AV_PIX_FMT_MONOBLACK    1
#define AV_PIX_FMT_PAL8         2
#define AV_PIX_FMT_GRAY8        3       //Bpp=8
#define AV_PIX_FMT_GRAY16BE     4       //Bpp=16
#define AV_PIX_FMT_RGB24        5       //Bpp=24
#define AV_PIX_FMT_RGBA         6       //Bpp=32
#define AV_PIX_FMT_RGB48BE      7
#define AV_PIX_FMT_RGBA64BE     8
#define AV_PIX_FMT_Y400A        9



#define FF_INPUT_BUFFER_PADDING_SIZE    16
#define FFERRTAG(a, b, c, d)            (-MKTAG(a, b, c, d))
#define AVERROR_INVALIDDATA             FFERRTAG('I','N','D','A') //Invalid data found when processing input
#define AVERROR_EXTERNAL                FFERRTAG('E','X','T',' ')
//#define STRIDE_ALIGN                  8       //NO MMX
#define STRIDE_ALIGN                    16      //HAVE_MMX
#define EDGE_WIDTH                      16
#define FFALIGN(x, a)                   (((x)+(a)-1)&~((a)-1))

#define FFSWAP(type,a,b)                {type T=b; b=a; a=T;}

#define PNG_COLOR_MASK_PALETTE    1
#define PNG_COLOR_MASK_COLOR      2
#define PNG_COLOR_MASK_ALPHA      4

#define PNG_COLOR_TYPE_GRAY       0
#define PNG_COLOR_TYPE_PALETTE    (PNG_COLOR_MASK_COLOR | PNG_COLOR_MASK_PALETTE)
#define PNG_COLOR_TYPE_RGB        (PNG_COLOR_MASK_COLOR)
#define PNG_COLOR_TYPE_RGB_ALPHA  (PNG_COLOR_MASK_COLOR | PNG_COLOR_MASK_ALPHA)
#define PNG_COLOR_TYPE_GRAY_ALPHA (PNG_COLOR_MASK_ALPHA)

#define PNG_FILTER_TYPE_LOCO   64
#define PNG_FILTER_VALUE_NONE  0
#define PNG_FILTER_VALUE_SUB   1
#define PNG_FILTER_VALUE_UP    2
#define PNG_FILTER_VALUE_AVG   3
#define PNG_FILTER_VALUE_PAETH 4
#define PNG_FILTER_VALUE_MIXED 5

#define PNG_IHDR        0x0001
#define PNG_IDAT        0x0002
#define PNG_ALLIMAGE    0x0004
#define PNG_PLTE        0x0008

#define PNGSIG_H        0x89504E47
#define PNGSIG_L        0x0D0A1A0A

#define MNGSIG_H        0x8A4D4E47
#define MNGSIG_L        0x0D0A1A0A

#define NB_PASSES       7
#define ENOMEM          12


typedef struct AVRational
    {
    int num;
    int den;
    } AVRational;


typedef struct AVBPrint
    {
    LPSTR Buff;
    UINT DataLen;               //Data����
    UINT BuffSize;              //����ũ��
    char InternalBuffer[1024-0x10];     //0x10�� �� ����� ũ��
    } AVBPrint;



typedef struct ByteStream
    {
    LPCBYTE Buffer, BufferEnd, BufferStart;
    } ByteStream;


typedef struct PNGDecContext
    {
    VOID (WINAPI *AddBytesl2)(BYTE*Dst, BYTE*src1, BYTE*src2, int w);
    VOID (WINAPI *AddPaethPrediction)(BYTE*Dst, BYTE*Src, BYTE*top, int w, int Bpp);

    ByteStream BS;

    int  State;
    int  Width, Height;
    int  BitDepth;
    int  ColorType;
    int  CompressType;
    int  InterlaceType;
    int  FilterType;
    int  Channels;
    int  BitsPerPixel;
    int  Bpp;

    LPBYTE CrowBuf;
    LPBYTE LastRow;
    UINT   LastRowSize;
    LPBYTE TmpRow;
    UINT   TmpRowSize;
    LPBYTE Buffer;
    int  BufferSize;
    int  Pass;
    int  CrowSize;              //compressed row size (include filter type)
    int  RowSize;               //decompressed row size
    int  PassRowSize;           //decompress row size of the current pass
    int  y;
    z_stream ZStream;

    LPBYTE ImgData;
    int  LineSize;
    StringList *MetaData;

    int  PixelFormat;
    int  Samples;

    DWORD Palette[256];
    } PNGDecContext;


//Mask to determine which pixels are valid in a pass
static const BYTE PngPassMask[NB_PASSES]=
    {
    0x01, 0x01, 0x11, 0x11, 0x55, 0x55, 0xFF,
    };



//Mask to determine which y pixels can be written in a pass
static const BYTE PassDspYMask[NB_PASSES]=
    {
    0xFF, 0xFF, 0x0f, 0xFF, 0x33, 0xFF, 0x55,
    };


//Mask to determine which pixels to overwrite while displaying
static const BYTE PngPassDspMask[NB_PASSES]=
    {
    0xFF, 0x0f, 0xFF, 0x33, 0xFF, 0x55, 0xFF
    };


//Mask to determine which y pixels are valid in a pass
static const BYTE FF_PngPassYMmask[NB_PASSES]=
    {
    0x80, 0x80, 0x08, 0x88, 0x22, 0xaa, 0x55,
    };


//Minimum x value
static const BYTE FF_PngPassMinX[NB_PASSES]=
    {
    0, 4, 0, 2, 0, 1, 0
    };


//x shift to get row Width
static const BYTE FF_PngPassShiftX[NB_PASSES]=
    {
    3, 3, 2, 2, 1, 1, 0
    };



static AVRational SampleAspectRatio;



///////////////////////////////////////////////////////////////////////////////
//              BYTE STREAM
///////////////////////////////////////////////////////////////////////////////


LOCAL(VOID) BS_Init(ByteStream*BS, LPCBYTE buf, int buf_size)
    {
    BS->Buffer=buf;
    BS->BufferStart=buf;
    BS->BufferEnd=buf+buf_size;
    }


LOCAL(UINT) BS_GetPos(ByteStream*BS)
    {
    return (UINT)(BS->Buffer - BS->BufferStart);
    }


LOCAL(UINT) BS_GetByte(ByteStream *BS)
    {
    if (BS->BufferEnd - BS->Buffer < 1) return 0;
    return *BS->Buffer++;
    }


LOCAL(UINT) BS_GetBE32(ByteStream*BS)   //bytestream2_get_be32
    {
    UINT U;

    if (BS->BufferEnd - BS->Buffer<4) return 0;
    U=ForcePeekBE(BS->Buffer);          //SDRAM������ STM32F7�ε��� �ƹ��������� 32��Ʈ�� �＼���ϸ� Hard Fault�� �߻���
    BS->Buffer+=4;
    return U;
    }

LOCAL(UINT) BS_GetLE32(ByteStream*BS)   //bytestream2_get_le32
    {
    UINT U;

    if (BS->BufferEnd - BS->Buffer<4) return 0;
    U=ForcePeekLE(BS->Buffer);          //SDRAM������ STM32F7�ε��� �ƹ��������� 32��Ʈ�� �＼���ϸ� Hard Fault�� �߻���
    BS->Buffer+=4;
    return U;
    }


LOCAL(UINT) BS_GetRemainSize(ByteStream*BS)     //bytestream2_get_bytes_left
    {
    return (PTR2UINT)(BS->BufferEnd - BS->Buffer);
    }



LOCAL(VOID) BS_Skip(ByteStream*BS, UINT Size)
    {
    BS->Buffer+=GetMin(BS_GetRemainSize(BS), Size);
    }



///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////


LOCAL(int) FF_PngGetChannels(int ColorType)
    {
    int Channels=1;

    if ((ColorType&(PNG_COLOR_MASK_COLOR|PNG_COLOR_MASK_PALETTE))==PNG_COLOR_MASK_COLOR) Channels=3;
    if (ColorType&PNG_COLOR_MASK_ALPHA) Channels++;
    return Channels;
    }



//-----------------------------------------------------------------------------
//      ff_png_pass_row_size() ... compute the row size of an interleaved pass
//-----------------------------------------------------------------------------
LOCAL(int) FF_PngPassRowSize(int pass, int BitsPerPixel, int Width)
    {
    int Shift, MinX, PassWidth;

    MinX=FF_PngPassMinX[pass];
    if (Width<=MinX) return 0;
    Shift=FF_PngPassShiftX[pass];
    PassWidth=(Width-MinX+(1<<Shift)-1)>>Shift;
    return(PassWidth*BitsPerPixel+7)>>3;
    }



//-----------------------------------------------------------------------------
// NOTE: we try to construct a good looking image at each pass. Width
// is the original image Width. We also do pixel format conversion at this stage
//-----------------------------------------------------------------------------
LOCAL(VOID) PutInterlacedRow(LPBYTE Dst, int Width, int BitsPerPixel, int pass, int ColorType, LPCBYTE Src)
    {
    int X, Mask, DspMask, J, SrcX, B, Bpp;
    BYTE*D;
    LPCBYTE PNG;

    Mask=PngPassMask[pass];
    DspMask=PngPassDspMask[pass];

    switch (BitsPerPixel)
        {
        case 1:
            SrcX=0;
            for (X=0; X<Width; X++)
                {
                J=(X&7);
                if ((DspMask<<J)&0x80)
                    {
                    B=(Src[SrcX>>3]>>(7-(SrcX&7)))&1;
                    Dst[X>>3]&=0xFF7F>>J;
                    Dst[X>>3]|=B<<(7-J);
                    }
                if ((Mask<<J)&0x80)
                    SrcX++;
                }
            break;

        case 2:
            SrcX=0;
            for (X=0; X<Width; X++)
                {
                int J2=2*(X&3);
                J=(X&7);
                if ((DspMask<<J)&0x80)
                    {
                    B=(Src[SrcX>>2]>>(6-2*(SrcX&3)))&3;
                    Dst[X>>2]&=0xFF3F>>J2;
                    Dst[X>>2]|=B<<(6-J2);
                    }
                if ((Mask<<J)&0x80) SrcX++;
                }
            break;

        case 4:
            SrcX=0;
            for (X=0; X<Width; X++)
                {
                int J2=4*(X&1);
                J=(X&7);
                if ((DspMask<<J)&0x80)
                    {
                    B=(Src[SrcX>>1]>>(4-4*(SrcX&1)))&15;
                    Dst[X>>1]&=0xFF0F>>J2;
                    Dst[X>>1]|=B<<(4-J2);
                    }
                if ((Mask<<J)&0x80) SrcX++;
                }
            break;

        default:
            Bpp=BitsPerPixel>>3;
            D=Dst;
            PNG=Src;
            for (X=0; X<Width; X++)
                {
                J=X&7;
                if ((DspMask<<J)&0x80) CopyMem(D, PNG, Bpp);

                D+=Bpp;
                if ((Mask<<J)&0x80) PNG+=Bpp;
                }
            break;
        }
    }



LOCAL(VOID) AddPaethPrediction(BYTE*Dst, BYTE*Src, BYTE*top, int w, int Bpp)
    {
    int I;

    for (I=0; I<w; I++)
        {
        int a, b, c, p, pa, pb, pc;

        a=Dst[I-Bpp];
        b=top[I];
        c=top[I-Bpp];

        p=b-c;
        pc=a-c;

        pa=GetAbs(p);
        pb=GetAbs(pc);
        pc=GetAbs(p+pc);

        if (pa<=pb && pa<=pc) p=a;
        else if (pb<=pc) p=b;
        else p=c;

        Dst[I]=p+Src[I];
        }
    }



//-----------------------------------------------------------------------------
// NOTE: 'Dst' can be equal to 'Last'
//-----------------------------------------------------------------------------
LOCAL(VOID) PNG_FilterRow(PNGDecContext*PNG, BYTE*Dst, int FilterType, BYTE*Src, BYTE*Last, int Size, int Bpp)
    {
    int I, p, r, g, b, a;

    switch (FilterType)
        {
        case PNG_FILTER_VALUE_NONE:
            CopyMem(Dst, Src, Size);
            break;

        case PNG_FILTER_VALUE_SUB:
            for (I=0; I<Bpp; I++) Dst[I]=Src[I];

            if (Bpp==4)
                {
                p=*(int*) Dst;
                for (; I<Size; I+=Bpp)
                    {
                    UINT PNG=*(int*)(Src+I);
                    p=((PNG&0x7f7f7f7f)+(p&0x7f7f7f7f))^((PNG^p)&0x80808080);
                    *(int*)(Dst+I)=p;
                    }
                }
            else{
                if (Bpp==1)
                    {
                    r=Dst[0];
                    for (; I<=Size-1; I+=1) Dst[I+0]=r=r+Src[I+0];
                    }
                else if (Bpp==2)
                    {
                    r=Dst[0];
                    g=Dst[1];
                    for (; I<=Size-2; I+=2)
                        {
                        Dst[I+0]=r=r+Src[I+0];
                        Dst[I+1]=g=g+Src[I+1];
                        }
                    }
                else if (Bpp==3)
                    {
                    r=Dst[0];
                    g=Dst[1];
                    b=Dst[2];
                    for (; I<=Size-3; I+=3)
                        {
                        Dst[I+0]=r=r+Src[I+0];
                        Dst[I+1]=g=g+Src[I+1];
                        Dst[I+2]=b=b+Src[I+2];
                        }
                    }
                else if (Bpp==4)
                    {
                    r=Dst[0];
                    g=Dst[1];
                    b=Dst[2];
                    a=Dst[3];
                    for (; I<=Size-4; I+=4)
                        {
                        Dst[I+0]=r=r+Src[I+0];
                        Dst[I+1]=g=g+Src[I+1];
                        Dst[I+2]=b=b+Src[I+2];
                        Dst[I+3]=a=a+Src[I+3];
                        }
                    }
                for (; I<Size; I++) Dst[I]=Dst[I-Bpp]+Src[I];
                }
            break;

        case PNG_FILTER_VALUE_UP:
            PNG->AddBytesl2(Dst, Src, Last, Size);
            break;

        case PNG_FILTER_VALUE_AVG:
            for (I=0; I<Bpp; I++)
                {
                p=(Last[I]>>1);
                Dst[I]=p+Src[I];
                }
            if (Bpp==1)
                {
                r=Dst[0];
                for (; I<=Size-1; I+=1)
                    Dst[I+0]=r=(((r+Last[I+0])>>1)+Src[I+0]) & 0xFF;
                }
            else if (Bpp==2)
                {
                r=Dst[0];
                g=Dst[1];
                for (; I<=Size-2; I+=2)
                    {
                    Dst[I+0]=r=(((r+Last[I+0])>>1)+Src[I+0]) & 0xFF;
                    Dst[I+1]=g=(((g+Last[I+1])>>1)+Src[I+1]) & 0xFF;
                    }
                }
            else if (Bpp==3)
                {
                r=Dst[0];
                g=Dst[1];
                b=Dst[2];
                for (; I<=Size-3; I+=3)
                    {
                    Dst[I+0]=r=(((r+Last[I+0])>>1)+Src[I+0]) & 0xFF;
                    Dst[I+1]=g=(((g+Last[I+1])>>1)+Src[I+1]) & 0xFF;
                    Dst[I+2]=b=(((b+Last[I+2])>>1)+Src[I+2]) & 0xFF;
                    }
                }
            else if (Bpp==4)
                {
                r=Dst[0];
                g=Dst[1];
                b=Dst[2];
                a=Dst[3];
                for (; I<=Size-4; I+=4)
                    {
                    Dst[I+0]=r=(((r+Last[I+0])>>1)+Src[I+0]) & 0xFF;
                    Dst[I+1]=g=(((g+Last[I+1])>>1)+Src[I+1]) & 0xFF;
                    Dst[I+2]=b=(((b+Last[I+2])>>1)+Src[I+2]) & 0xFF;
                    Dst[I+3]=a=(((a+Last[I+3])>>1)+Src[I+3]) & 0xFF;
                    }
                }

            for (; I<Size; I++) Dst[I]=(((Dst[I-Bpp]+Last[I])>>1)+Src[I]) & 0xFF;
            break;

        case PNG_FILTER_VALUE_PAETH:
            for (I=0; I<Bpp; I++)
                {
                p=Last[I];
                Dst[I]=p+Src[I];
                }
            if (Bpp>2 && Size>4)
                {
                // would write off the end of the array if we let it process the Last pixel with Bpp=3
                int w=Bpp==4?Size:Size-3;
                PNG->AddPaethPrediction(Dst+I, Src+I, Last+I, w-I, Bpp);
                I=w;
                }
            AddPaethPrediction(Dst+I, Src+I, Last+I, Size-I, Bpp);
            break;
        }
    }



LOCAL(VOID) deloco_rgb8(BYTE*Dst, int Size, int Alpha)
    {
    int I;
    for (I=0; I<Size; I+=3+Alpha)
        {
        int g=Dst[I+1];
        Dst[I+0]+=g;
        Dst[I+2]+=g;
        }
    }


LOCAL(VOID) deloco_rgb16(WORD*Dst, int Size, int Alpha)
    {
    int I;
    for (I=0; I<Size; I+=3+Alpha)
        {
        int g=Dst[I+1];
        Dst[I+0]+=g;
        Dst[I+2]+=g;
        }
    }



//-----------------------------------------------------------------------------
//      Process exactly one decompressed row
//-----------------------------------------------------------------------------
LOCAL(VOID) PNG_HandleRow(PNGDecContext*PNG)
    {
    int got_line;
    LPBYTE ptr, LastRow;

    if (PNG->InterlaceType==0)
        {
        ptr=PNG->ImgData+PNG->LineSize*PNG->y;
        if (PNG->y==0)
            LastRow=PNG->LastRow;
        else
            LastRow=ptr-PNG->LineSize;

        PNG_FilterRow(PNG, ptr, PNG->CrowBuf[0], PNG->CrowBuf+1, LastRow, PNG->RowSize, PNG->Bpp);
        // loco lags by 1 row so that it doesn't interfere with top prediction
        if (PNG->FilterType==PNG_FILTER_TYPE_LOCO && PNG->y>0)
            {
            if (PNG->BitDepth==16)
                {
                deloco_rgb16((WORD*)(ptr-PNG->LineSize), PNG->RowSize/2, PNG->ColorType==PNG_COLOR_TYPE_RGB_ALPHA);
                }
            else{
                deloco_rgb8(ptr-PNG->LineSize, PNG->RowSize, PNG->ColorType==PNG_COLOR_TYPE_RGB_ALPHA);
                }
            }
        PNG->y++;
        if (PNG->y==PNG->Height)
            {
            PNG->State|=PNG_ALLIMAGE;
            if (PNG->FilterType==PNG_FILTER_TYPE_LOCO)
                {
                if (PNG->BitDepth==16)
                    {
                    deloco_rgb16((WORD*) ptr, PNG->RowSize/2, PNG->ColorType==PNG_COLOR_TYPE_RGB_ALPHA);
                    }
                else{
                    deloco_rgb8(ptr, PNG->RowSize, PNG->ColorType==PNG_COLOR_TYPE_RGB_ALPHA);
                    }
                }
            }
        }
    else{
        got_line=0;
        for (;;)
            {
            ptr=PNG->ImgData+PNG->LineSize*PNG->y;
            if ((FF_PngPassYMmask[PNG->Pass]<<(PNG->y&7))&0x80)
                {
                //if we already read one row, it is time to stop to wait for the next one
                if (got_line) break;
                PNG_FilterRow(PNG, PNG->TmpRow, PNG->CrowBuf[0], PNG->CrowBuf+1, PNG->LastRow, PNG->PassRowSize, PNG->Bpp);
                FFSWAP(BYTE*, PNG->LastRow, PNG->TmpRow)
                FFSWAP(UINT, PNG->LastRowSize, PNG->TmpRowSize)
                got_line=1;
                }
            if ((PassDspYMask[PNG->Pass]<<(PNG->y&7))&0x80)
                {
                PutInterlacedRow(ptr, PNG->Width, PNG->BitsPerPixel, PNG->Pass, PNG->ColorType, PNG->LastRow);
                }
            PNG->y++;
            if (PNG->y==PNG->Height)
                {
                ZeroMem(PNG->LastRow, PNG->RowSize);
                for (;;)
                    {
                    if (PNG->Pass==NB_PASSES-1)
                        {
                        PNG->State|=PNG_ALLIMAGE;
                        goto the_end;
                        }
                    else{
                        PNG->Pass++;
                        PNG->y=0;
                        PNG->PassRowSize=FF_PngPassRowSize(PNG->Pass, PNG->BitsPerPixel, PNG->Width);
                        PNG->CrowSize=PNG->PassRowSize+1;
                        if (PNG->PassRowSize!=0) break;
                        // skip pass if empty row
                        }
                    }
                }
            }
        the_end:;
        }
    }




LOCAL(int) PNG_DecodeIDat(PNGDecContext*PNG, int TagLen)
    {
    int ret;

    PNG->ZStream.avail_in=GetMin(TagLen, BS_GetRemainSize(&PNG->BS));
    PNG->ZStream.next_in=(LPBYTE)PNG->BS.Buffer;
    BS_Skip(&PNG->BS, TagLen);

    //Decode one line if possible
    while (PNG->ZStream.avail_in>0)
        {
        ret=inflate(&PNG->ZStream, Z_PARTIAL_FLUSH);
        if (ret!=Z_OK && ret!=Z_STREAM_END)
            {
            PNGERR("inflate returned error %d"CRLF, ret);
            return AVERROR_EXTERNAL;
            }
        if (PNG->ZStream.avail_out==0)
            {
            if ((PNG->State&PNG_ALLIMAGE)==0) PNG_HandleRow(PNG);

            PNG->ZStream.avail_out=PNG->CrowSize;
            PNG->ZStream.next_out=PNG->CrowBuf;
            }
        if (ret==Z_STREAM_END && PNG->ZStream.avail_in>0)
            {
            PNGWARN("%d undecompressed bytes left in Buffer"CRLF, PNG->ZStream.avail_in);
            return 0;
            }
        }
    return 0;
    }


#define AV_BPrintIsAllocated(AVBP) ((AVBP)->Buff != (AVBP)->InternalBuffer)



LOCAL(VOID) BP_Init(AVBPrint*AVBP)
    {
    AVBP->Buff=AVBP->InternalBuffer;
    AVBP->Buff[0]=0;
    AVBP->DataLen=0;
    AVBP->BuffSize=(PTR2UINT)((LPSTR)AVBP+sizeof(AVBPrint) - AVBP->InternalBuffer);
    }


LOCAL(VOID) BP_Release(AVBPrint*AVBP)
    {
    if (AV_BPrintIsAllocated(AVBP)) FreeMem(AVBP->Buff);
    BP_Init(AVBP);
    }



LOCAL(LPBYTE) BP_GetBuffer(AVBPrint*AVBP, UINT NeedSize, UINT *lpAvailableSize)
    {
    int   NewSize;
    LPSTR NewStr;

    if (AVBP->BuffSize - AVBP->DataLen < NeedSize)
        {
        NewSize=GetMax(AVBP->BuffSize<<1, AVBP->DataLen+1+NeedSize);
        if ((NewStr=(LPSTR)AllocMem(NewSize, MEMOWNER_AV_BPrintGetBuffer))!=NULL)
            {
            CopyMem(NewStr, AVBP->Buff, AVBP->DataLen+1);
            if (AV_BPrintIsAllocated(AVBP)) FreeMem(AVBP->Buff);
            AVBP->Buff=NewStr;
            AVBP->BuffSize=NewSize;
            }
        }
    *lpAvailableSize = AVBP->BuffSize - AVBP->DataLen;
    return (*lpAvailableSize>=NeedSize) ? (LPBYTE)AVBP->Buff + AVBP->DataLen : NULL;
    }




LOCAL(int) decode_zbuf(AVBPrint*BP, LPCBYTE Data, LPCBYTE DataQ)
    {
    z_stream Z;
    BYTE*Buff;
    UINT BuffSize;
    int Rslt;

    if (inflateInit(&Z)!=Z_OK) return AVERROR_EXTERNAL;
    Z.next_in=(LPBYTE)Data;
    Z.avail_in=(PTR2UINT)(DataQ-Data);

    while (Z.avail_in>0)
        {
        if ((Buff=BP_GetBuffer(BP, 1, &BuffSize))==NULL) {Rslt=-ENOMEM; goto ProcExit;}
        Z.next_out=Buff;
        Z.avail_out=BuffSize;
        Rslt=inflate(&Z, Z_PARTIAL_FLUSH);
        if (Rslt!=Z_OK && Rslt!=Z_STREAM_END) {Rslt=AVERROR_EXTERNAL; goto ProcExit;}
        BP->DataLen+=(PTR2UINT)(Z.next_out-Buff);
        if (Rslt==Z_STREAM_END) break;
        }
    BP->Buff[BP->DataLen]=0;
    Rslt=0;

    ProcExit:
    inflateEnd(&Z);
    return Rslt;
    }



LOCAL(LPBYTE) Iso88591toUtf8(LPCBYTE Iso88591, int InSize)
    {
    int I, Extra;
    LPBYTE out, q;

    for (I=Extra=0; I<InSize; I++) Extra+=Iso88591[I]>=0x80;

    if ((q=out=(LPBYTE)AllocMem(InSize+Extra+1, MEMOWNER_Iso88591toUtf8))==NULL) return NULL;

    for (I=0; I<InSize; I++)
        {
        if (Iso88591[I]>=0x80)
            {
            *q++=0xC0|(Iso88591[I]>>6);
            *q++=0x80|(Iso88591[I]&0x3F);
            }
        else{
            *q++=Iso88591[I];
            }
        }
    *q++=0;
    return out;
    }





LOCAL(VOID) AV_DictSet(PNGDecContext*PNG, LPCSTR Key, LPCSTR Value)
    {
    int  KeyLen;
    StringList *SL, *ParSL=NULL, *DelSL;

    KeyLen=lstrlen(Key);
    for (SL=PNG->MetaData; SL!=NULL; SL=SL->Next)
        {
        if (CompMemStr(SL->String, Key)==0 && SL->String[KeyLen]=='=')
            {
            DelSL=SL; SL=SL->Next;
            if (ParSL!=NULL) ParSL->Next=SL; else PNG->MetaData=SL;
            FreeMem(DelSL);
            break;
            }
        ParSL=SL;
        }

    if ((SL=(StringList*)AllocMem(lstrlen(Value)+KeyLen+2+sizeof(StringList), MEMOWNER_AV_DictSet))!=NULL)      //+2�� '=' �� ���ڿ���NullCha
        {
        wsprintf(SL->String, "%s=%s", Key, Value);
        SL->Next=PNG->MetaData;
        PNG->MetaData=SL;
        }
    }


LOCAL(LPCBYTE) MemChr(LPCBYTE lp, BYTE FindCha, int MemSize)
    {
    while (MemSize--)
        {
        if (*lp==FindCha) return lp;
        lp++;
        }
    return NULL;
    }



LOCAL(int) DecodeTextChunk(PNGDecContext*PNG, DWORD TagLen, int compressed)
    {
    int      Rslt=AVERROR_INVALIDDATA, Method;
    LPCBYTE  Data, DataQ, KeyWord, KeyWordQ;
    LPBYTE   KeyWordU8=NULL, Text, TextU8=NULL;
    UINT     TextLen;
    AVBPrint BP;

    BP_Init(&BP);
    KeyWord=PNG->BS.Buffer;
    DataQ=KeyWord+TagLen;
    if ((KeyWordQ=MemChr(KeyWord, 0, TagLen))==NULL) goto ProcExit;
    Data=KeyWordQ+1;

    if (compressed)
        {
        if (TagLen==0) goto ProcExit;
        Method=*Data++;
        if (Method!=0) goto ProcExit;
        if ((Rslt=decode_zbuf(&BP, Data, DataQ))<0) goto ProcExit;
        Text=(LPBYTE)BP.Buff;
        TextLen=BP.DataLen;
        }
    else{
        Text=(LPBYTE)Data;
        TextLen=(PTR2UINT)(DataQ-Data);
        }

    KeyWordU8=Iso88591toUtf8(KeyWord, (PTR2INT)(KeyWordQ-KeyWord));
    TextU8=Iso88591toUtf8(Text, TextLen);

    if (KeyWordU8==NULL || TextU8==NULL) {Rslt=-ENOMEM; goto ProcExit;}
    AV_DictSet(PNG, (LPCSTR)KeyWordU8, (LPCSTR)TextU8);
    Rslt=0;

    ProcExit:
    FreeMem(KeyWordU8);
    FreeMem(TextU8);
    BP_Release(&BP);
    return Rslt;
    }



LOCAL(VOID) FastPaddedMAlloc(VOID*ptr, UINT*Size, int MinSize)
    {
    int NewMinSize;
    LPBYTE* p=(LPBYTE*)ptr;

    NewMinSize=MinSize+FF_INPUT_BUFFER_PADDING_SIZE;

    if (NewMinSize<(int)*Size) ZeroMem(*p+MinSize, FF_INPUT_BUFFER_PADDING_SIZE);
    else{
        NewMinSize=GetMax(NewMinSize*17/16+32, NewMinSize);
        FreeMem(*p);
        if ((*p=(LPBYTE)AllocMem(NewMinSize, MEMOWNER_AV_FastPaddedMalloc))==NULL) NewMinSize=0;
        else ZeroMem(*p, NewMinSize);

        *Size=NewMinSize;
        }
    }



//-----------------------------------------------------------------------------
//      av_fast_padded_mallocz
//-----------------------------------------------------------------------------
LOCAL(VOID) AV_FastPaddedMallocZ(VOID*ptr, UINT*Size, int MinSize)
    {
    int NewMinSize;
    LPBYTE*p=(LPBYTE*)ptr;

    NewMinSize=MinSize+FF_INPUT_BUFFER_PADDING_SIZE;

    if (NewMinSize<(int)*Size) ZeroMem(*p, MinSize+FF_INPUT_BUFFER_PADDING_SIZE);
    else{
        NewMinSize=GetMax(NewMinSize*17/16+32, NewMinSize);
        FreeMem(*p);
        if ((*p=(LPBYTE)AllocMem(NewMinSize, MEMOWNER_AV_FastPaddedMallocZ))==NULL) NewMinSize=0;
        else ZeroMem(*p, NewMinSize);

        *Size=NewMinSize;
        }
    }




//-----------------------------------------------------------------------------
//      av_image_fill_linesizes()
//-----------------------------------------------------------------------------
LOCAL(int) AV_ImageFillLineSizes(int PixelFormat, int Width)
    {
    int Rslt=0;

    switch (PixelFormat)
        {
        case AV_PIX_FMT_MONOBLACK: Rslt=(Width+7)>>3; break;
        case AV_PIX_FMT_PAL8:
        case AV_PIX_FMT_GRAY8: Rslt=Width; break;
        case AV_PIX_FMT_RGB24: Rslt=Width*3; break;
        case AV_PIX_FMT_RGBA:  Rslt=Width<<2; break;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ff_get_buffer(), update_frame_pool()
//-----------------------------------------------------------------------------
LOCAL(int) GetInternalBuffer(PNGDecContext*PNG)
    {
    int wAlign=1;
    int hAlign=1;
    int w, h, Size;

    w=PNG->Width;
    h=PNG->Height;

    switch (PNG->PixelFormat)                   //avcodec_align_dimensions2() ... switch (s->pix_fmt)
        {
        case AV_PIX_FMT_GRAY8:
        //case AV_PIX_FMT_GRAY16BE:
            wAlign=16;                          //FIXME assume 16 pixel per macroblock
            hAlign=16*2;                        // interlaced needs 2 macroblocks Height
        }

    w=FFALIGN(w, wAlign)+EDGE_WIDTH*2;
    h=FFALIGN(h, hAlign)+EDGE_WIDTH*2;

    for (;;)
        {
        PNG->LineSize=AV_ImageFillLineSizes(PNG->PixelFormat, w);
        w+=w & ~(w-1);
        if ((PNG->LineSize % STRIDE_ALIGN)==0) break;
        }

    Size=PNG->LineSize*h+16+STRIDE_ALIGN-1;

    if ((PNG->ImgData=(BYTE*)AllocVMem(Size, MEMOWNER_GetInternalBuffer))==NULL) return -ENOMEM;
    return 0;
    }




//-----------------------------------------------------------------------------
//      �ȼ� ���� �м�
//-----------------------------------------------------------------------------
LOCAL(int) AnlyPixelFormat(const PNGDecContext* PNG)
    {
    int PixelFormat, BitDepth, BitsPerPixel, ColorType;

    BitDepth=PNG->BitDepth;
    BitsPerPixel=PNG->BitsPerPixel;
    ColorType=PNG->ColorType;

    if ((BitDepth==2 || BitDepth==4 || BitDepth==8) && ColorType==PNG_COLOR_TYPE_RGB)
        {
        PixelFormat=AV_PIX_FMT_RGB24;
        }
    else if ((BitDepth==2 || BitDepth==4 || BitDepth==8) && ColorType==PNG_COLOR_TYPE_RGB_ALPHA)
        {
        PixelFormat=AV_PIX_FMT_RGBA;
        }
    else if ((BitDepth==2 || BitDepth==4 || BitDepth==8) && ColorType==PNG_COLOR_TYPE_GRAY)
        {
        PixelFormat=AV_PIX_FMT_GRAY8;
        }
    #if 0       //No Support
    else if (BitDepth==16 && ColorType==PNG_COLOR_TYPE_GRAY)
        {
        PixelFormat=AV_PIX_FMT_GRAY16BE;
        }
    else if (BitDepth==16 && ColorType==PNG_COLOR_TYPE_RGB)
        {
        PixelFormat=AV_PIX_FMT_RGB48BE;
        }
    else if (BitDepth==16 && ColorType==PNG_COLOR_TYPE_RGB_ALPHA)
        {
        PixelFormat=AV_PIX_FMT_RGBA64BE;
        }
    #endif
    else if ((BitsPerPixel==1 || BitsPerPixel==2 || BitsPerPixel==4 || BitsPerPixel==8) && ColorType==PNG_COLOR_TYPE_PALETTE)
        {
        PixelFormat=AV_PIX_FMT_PAL8;
        }
    else if (BitDepth==1)
        {
        PixelFormat=AV_PIX_FMT_MONOBLACK;
        }
    #if 0       //No Support
    else if (BitDepth==8 && ColorType==PNG_COLOR_TYPE_GRAY_ALPHA)
        {
        PixelFormat=AV_PIX_FMT_Y400A;
        }
    #endif
    else{
        PixelFormat=AV_PIX_FMT_NONE;
        }

    return PixelFormat;
    }



//-----------------------------------------------------------------------------
//      decode_frame
//
//�Ǿտ� ������� 8����Ʈ, �� ���Ĵ� ûũ�� �ݺ�
//
//ûũ ����
//----------
//ũ��4����Ʈ(BE) ... �� ũ�� �ʵ�� ������ �±� �ʵ�, �ǵ� CRC�ʵ带 ������ ���� Dataũ��
//�±�4����Ʈ ... �±��̸�
//���������� ... �� ũ�� ��ŭ
//CRC4Byte
//-----------------------------------------------------------------------------
int WINAPI PNG_DecodeFrame(PNGDecContext*PNG, LPCBYTE PngFileData, int PngFileSize)
    {
    int I,J,K, Rslt;
    LPBYTE lp;
    BYTE B;
    DWORD Tag, TagLen, SigH, SigL;

    BS_Init(&PNG->BS, PngFileData, PngFileSize);

    //Check signature
    SigH=BS_GetBE32(&PNG->BS);
    SigL=BS_GetBE32(&PNG->BS);
    if (!(SigH==PNGSIG_H && SigL==PNGSIG_L) &&
        !(SigH==MNGSIG_H && SigL==MNGSIG_L))
        {
        PNGERR("Missing png signature"CRLF);
        return AVERROR_INVALIDDATA;
        }

    PNG->y=PNG->State=0;

    //Init the zlib
    if ((Rslt=inflateInit(&PNG->ZStream))!=Z_OK)
        {
        PNGERR("PNG: inflateInit error %d"CRLF, Rslt);
        return AVERROR_EXTERNAL;
        }

    for (;;)
        {
        if (BS_GetRemainSize(&PNG->BS)<4)
            {
            PNGERR("PNG: No bytes left"CRLF);
            goto fail;
            }

        if ((TagLen=BS_GetBE32(&PNG->BS))>BS_GetRemainSize(&PNG->BS))
            {
            PNGERR("PNG: Chunk too big"CRLF);
            goto fail;
            }

        Tag=BS_GetLE32(&PNG->BS);
        PNGDEBUG("PNG: Tag=%c%c%c%c TagLen=%u"CRLF, Tag&0xFF, (Tag>>8)&0xFF, (Tag>>16)&0xFF, (Tag>>24)&0xFF, TagLen);

        switch (Tag)
            {
            case MKTAG('I', 'H', 'D', 'R'):
                if (TagLen!=13) goto fail;
                PNG->Width=BS_GetBE32(&PNG->BS);
                PNG->Height=BS_GetBE32(&PNG->BS);
                if (PNG->Width<=0 || PNG->Height<=0)
                    {
                    PNG->Width=PNG->Height=0;
                    PNGERR("Invalid image size"CRLF);
                    goto fail;
                    }
                PNG->BitDepth=BS_GetByte(&PNG->BS);
                PNG->ColorType=BS_GetByte(&PNG->BS);
                PNG->CompressType=BS_GetByte(&PNG->BS);
                PNG->FilterType=BS_GetByte(&PNG->BS);
                PNG->InterlaceType=BS_GetByte(&PNG->BS);
                BS_Skip(&PNG->BS, 4);   //crc
                PNG->State|=PNG_IHDR;
                PNGDEBUG("Width=%d Height=%d depth=%d ColorType=%d CompressType=%d FilterType=%d InterlaceType=%d"CRLF,
                    PNG->Width, PNG->Height, PNG->BitDepth, PNG->ColorType,
                    PNG->CompressType, PNG->FilterType, PNG->InterlaceType);
                break;

            case MKTAG('p', 'H', 'Y', 's'):
                if (PNG->State&PNG_IDAT)
                    {
                    PNGERR("pHYs after IDAT"CRLF);
                    goto fail;
                    }

                SampleAspectRatio.num=BS_GetBE32(&PNG->BS);
                SampleAspectRatio.den=BS_GetBE32(&PNG->BS);
                if (SampleAspectRatio.num<0 || SampleAspectRatio.den<0)
                    {
                    SampleAspectRatio.num=0;
                    SampleAspectRatio.den=1;
                    }

                BS_Skip(&PNG->BS, 1);                                   // unit specifier
                BS_Skip(&PNG->BS, 4);                                   // crc
                break;

            case MKTAG('I', 'D', 'A', 'T'):
                if ((PNG->State&PNG_IHDR)==0)
                    {
                    PNGERR("IDAT without IHDR"CRLF);
                    goto fail;
                    }
                if ((PNG->State&PNG_IDAT)==0)
                    {
                    //Init image info
                    PNG->Channels=FF_PngGetChannels(PNG->ColorType);
                    PNG->BitsPerPixel=PNG->BitDepth*PNG->Channels;
                    PNG->Bpp=(PNG->BitsPerPixel+7)>>3;
                    PNG->RowSize=(PNG->Width*PNG->BitsPerPixel+7)>>3;

                    if ((PNG->PixelFormat=AnlyPixelFormat(PNG))==AV_PIX_FMT_NONE)
                        {
                        PNGERR("PNG: Unsupported (BitDepth=%d, BitsPerPixel=%d, ColorType=%d)"CRLF, PNG->BitDepth, PNG->BitsPerPixel, PNG->ColorType);
                        goto fail;
                        }

                    if (GetInternalBuffer(PNG)<0) goto fail;    //������ �޸� �غ�

                    //Compute the compressed row size
                    if (PNG->InterlaceType==0)
                        {
                        PNG->CrowSize=PNG->RowSize+1;
                        }
                    else{
                        PNG->Pass=0;
                        PNG->PassRowSize=FF_PngPassRowSize(PNG->Pass, PNG->BitsPerPixel, PNG->Width);
                        PNG->CrowSize=PNG->PassRowSize+1;
                        }
                    PNGDEBUG("RowSize=%d CrowSize=%d"CRLF, PNG->RowSize, PNG->CrowSize);

                    //Empty row is used if differencing to the first row
                    AV_FastPaddedMallocZ(&PNG->LastRow, &PNG->LastRowSize, PNG->RowSize);
                    if (PNG->LastRow==0) goto fail;
                    if (PNG->InterlaceType || PNG->ColorType==PNG_COLOR_TYPE_RGB_ALPHA)
                        {
                        FastPaddedMAlloc(&PNG->TmpRow, &PNG->TmpRowSize, PNG->RowSize);
                        if (PNG->TmpRow==NULL) goto fail;
                        }
                    //Compressed row
                    FastPaddedMAlloc(&PNG->Buffer, (UINT*)&PNG->BufferSize, PNG->RowSize+16);
                    if (PNG->Buffer==NULL) goto fail;

                    //We want CrowBuf+1 to be 16-byte aligned
                    PNG->CrowBuf=PNG->Buffer+15;
                    PNG->ZStream.avail_out=PNG->CrowSize;
                    PNG->ZStream.next_out=PNG->CrowBuf;
                    }
                PNG->State|=PNG_IDAT;
                if (PNG_DecodeIDat(PNG, TagLen)<0) goto fail;
                BS_Skip(&PNG->BS, 4);                                   // crc
                break;

            case MKTAG('P', 'L', 'T', 'E'):
                {
                int I,J, r, g, b;

                if ((TagLen%3)!=0 || TagLen>256*3) goto SkipTag;
                //Read the palette
                J=TagLen/3;
                for (I=0; I<J; I++)
                    {
                    r=BS_GetByte(&PNG->BS);
                    g=BS_GetByte(&PNG->BS);
                    b=BS_GetByte(&PNG->BS);
                    PNG->Palette[I]=(0xFFU<<24)|(b<<16)|(g<<8)|r;
                    }

                for (; I<256; I++) PNG->Palette[I]=0xFFU<<24;

                PNG->State|=PNG_PLTE;
                BS_Skip(&PNG->BS, 4);   //crc
                break;
                }

            case MKTAG('t', 'R', 'N', 'S'):     //������
                {
                int I;

                //Read the transparency. XXX: Only palette mode supported
                if (PNG->ColorType!=PNG_COLOR_TYPE_PALETTE || TagLen>256 || (PNG->State&PNG_PLTE)==0) goto SkipTag;

                for (I=0; I<(int)TagLen; I++) *((LPBYTE)(PNG->Palette+I)+3)=BS_GetByte(&PNG->BS);

                BS_Skip(&PNG->BS, 4);   //crc
                break;
                }

            case MKTAG('t', 'E', 'X', 't'):
                if (DecodeTextChunk(PNG, TagLen, 0)<0) PNGWARN("Broken tEXt chunk"CRLF);
                BS_Skip(&PNG->BS, TagLen+4);
                break;

            case MKTAG('z', 'T', 'X', 't'):
                if (DecodeTextChunk(PNG, TagLen, 1)<0) PNGWARN("Broken zTXt chunk"CRLF);
                BS_Skip(&PNG->BS, TagLen+4);
                break;

            case MKTAG('I', 'E', 'N', 'D'):
                if ((PNG->State&PNG_ALLIMAGE)==0) PNGERR("IEND without all image"CRLF);
                if ((PNG->State&(PNG_ALLIMAGE|PNG_IDAT))==0) goto fail;
                BS_Skip(&PNG->BS, 4);                                   // crc
                goto ExpandByte;

            default:    //skip Tag
                SkipTag:
                BS_Skip(&PNG->BS, TagLen+4);
                //break;
            }
        }

    ExpandByte:
    lp=PNG->ImgData;
    J=PNG->Height;

    switch (PNG->BitsPerPixel)
        {
        case 1:
            if (PNG->ColorType!=PNG_COLOR_TYPE_PALETTE)
                {
                PNG->Palette[0]=0;
                PNG->Palette[1]=0xFFFFFF;
                }

            while (J--)
                {
                for (I=PNG->Width-1; I>=0; I--)                 //���� ���۸� ����ϱ⿡ ������ ���� ó���ؾ� ��
                    {
                    K=I&7;
                    B=lp[I>>3];         //if (K==0) B=lp[I>>3]; �Ųٷ� �ϴ� ��� ���� �߻�
                    lp[I]=(B>>(7-K))&1;
                    }
                lp+=PNG->LineSize;
                }
            break;

        case 2:
            if (PNG->ColorType!=PNG_COLOR_TYPE_PALETTE)
                {
                for (I=0; I<4; I++) PNG->Palette[I]=I*0x555555;
                }

            while (J--)
                {
                for (I=PNG->Width-1; I>=0; I--)
                    {
                    K=I&3;
                    B=lp[I>>2];         //if (K==0) B=lp[I>>2]; �Ųٷ� �ϴ� ��� ���� �߻�
                    lp[I]=(B>>((3-K)<<1))&3;
                    }
                lp+=PNG->LineSize;
                }
            break;

        case 4:
            if (PNG->ColorType!=PNG_COLOR_TYPE_PALETTE)
                {
                for (I=0; I<16; I++) PNG->Palette[I]=I*0x111111;
                }

            while (J--)
                {
                for (I=PNG->Width-1; I>=0; I--)
                    {
                    K=I&1;
                    B=lp[I>>1];         //if (K==0) B=lp[I>>1]; �Ųٷ� �ϴ� ��� ���� �߻�
                    lp[I]=(B>>((1-K)<<2))&0x0F;
                    }
                lp+=PNG->LineSize;
                }
            break;

        case 8:
            if (PNG->ColorType!=PNG_COLOR_TYPE_PALETTE)
                {
                for (I=0; I<256; I++) PNG->Palette[I]=I*0x010101;
                }
            break;

        case 24:
            while (J--)
                {
                K=PNG->Width*3;
                for (I=0; I<K; I+=3)
                    {
                    B=lp[I];
                    lp[I]=lp[I+2];
                    lp[I+2]=B;
                    }
                lp+=PNG->LineSize;
                }
            break;

        case 32:
            while (J--)
                {
                K=PNG->Width<<2;
                for (I=0; I<K; I+=4)
                    {
                    B=lp[I];
                    lp[I]=lp[I+2];
                    lp[I+2]=B;
                    }
                lp+=PNG->LineSize;
                }
        }

    Rslt=BS_GetPos(&PNG->BS);

    ProcExit:
    inflateEnd(&PNG->ZStream);
    PNG->CrowBuf=NULL;
    return Rslt;

    fail:
    Rslt=AVERROR_INVALIDDATA;
    goto ProcExit;
    }


LOCAL(VOID) AddBytesl2C(BYTE*Dest, BYTE*Src1, BYTE*Src2, int W)
    {
    long I,A,B;

    for (I=0; I<=W-(int)sizeof(long); I+=sizeof(long))
        {
        A=*(long*)(Src1+I);
        B=*(long*)(Src2+I);
        *(long*)(Dest+I)=((A&0x7F7F7F7F)+(B&0x7F7F7F7F))^((A^B)&0x80808080);
        }

    for (; I<W; I++) Dest[I]=Src1[I]+Src2[I];
    }




//-----------------------------------------------------------------------------
//      ff_pngdsp_init
//-----------------------------------------------------------------------------
PNGDecContext* WINAPI PNG_Init()
    {
    PNGDecContext *PNG;

    if ((PNG=AllocMemS(PNGDecContext, MEMOWNER_PNG_Init))==NULL) goto ProcExit;
    ZeroMem(PNG, sizeof(PNGDecContext));
    PNG->AddBytesl2=AddBytesl2C;
    PNG->AddPaethPrediction=AddPaethPrediction;

    #if 0
    if (ARCH_X86)
        {
        int flags=av_get_cpu_flags();

        #if ARCH_X86_32
        if (HAVE_MMX_EXTERNAL && (flags & AV_CPU_FLAG_MMX))         PNG->AddBytesl2=ff_add_bytes_l2_mmx;
        #endif
        if (HAVE_MMXEXT_EXTERNAL && (flags & AV_CPU_FLAG_MMXEXT))   PNG->AddPaethPrediction=ff_add_png_paeth_prediction_mmxext;
        if (HAVE_SSE2_EXTERNAL && (flags & AV_CPU_FLAG_SSE2))       PNG->AddBytesl2=ff_add_bytes_l2_sse2;
        if (HAVE_SSSE3_EXTERNAL && (flags & AV_CPU_FLAG_SSSE3))     PNG->AddPaethPrediction=ff_add_png_paeth_prediction_ssse3;
        }
    #endif

    ProcExit:
    return PNG;
    }



//-----------------------------------------------------------------------------
//      png_dec_end
//-----------------------------------------------------------------------------
VOID WINAPI PNG_Release(PNGDecContext*PNG)
    {
    if (PNG!=NULL)
        {
        DelAllStringList(&PNG->MetaData);

        FreeMem(PNG->ImgData);
        FreeMem(PNG->Buffer);
        FreeMem(PNG->LastRow);
        FreeMem(PNG->TmpRow);
        FreeMem(PNG);
        }
    }




//-----------------------------------------------------------------------------
//      PNG ������ �̹��� ũ�⸦ ������
//-----------------------------------------------------------------------------
BOOL WINAPI GetPngImageSize(LPCSTR FileName, int *lpWidth, int *lpHeight)
    {
    int Rslt=FALSE, ReadSize;
    HFILE hFile;
    DWORD Tag, TagLen, SigH, SigL;
    ByteStream BS;
    LPBYTE Buff=NULL;

    if ((hFile=_lopen(FileName, OF_READ))==HFILE_ERROR) goto ProcExit;
    if ((Buff=(LPBYTE)AllocMem(512, MEMOWNER_PNG_GetImageSize))==NULL) goto ProcExit;
    if ((ReadSize=_lread(hFile, Buff, 512))<=0) goto ProcExit;
    BS_Init(&BS, Buff, ReadSize);

    SigH=BS_GetBE32(&BS);
    SigL=BS_GetBE32(&BS);
    if (!(SigH==PNGSIG_H && SigL==PNGSIG_L) &&
        !(SigH==MNGSIG_H && SigL==MNGSIG_L)) goto ProcExit;

    for (;;)
        {
        if (BS_GetRemainSize(&BS)<4) goto ProcExit;
        if ((TagLen=BS_GetBE32(&BS))>BS_GetRemainSize(&BS)) goto ProcExit;

        Tag=BS_GetLE32(&BS);
        switch (Tag)
            {
            case MKTAG('I', 'H', 'D', 'R'):
                if (TagLen!=13) goto ProcExit;
                *lpWidth=BS_GetBE32(&BS);
                *lpHeight=BS_GetBE32(&BS);
                Rslt++;
                goto ProcExit;

            default:    //skip Tag
                BS_Skip(&BS, TagLen+4);
                //break;
            }
        }

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    FreeMem(Buff);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      PNG ������ VRAM �޸𸮷� ������
//-----------------------------------------------------------------------------
BOOL WINAPI LoadPng(LPCSTR InPngFName, int *lpWidth, int *lpHeight, DWORD *ImgVMPtr)
    {
    int  X,Y, Size, Rslt=FALSE;
    LPBYTE PngFileData;
    PNGDecContext *PNG=NULL;
    DWORD *lpD;
    LPBYTE lpS;

    if (ImgVMPtr==NULL) return GetPngImageSize(InPngFName, lpWidth, lpHeight);

    if ((PngFileData=LoadFile(InPngFName, MEMOWNER_LoadPng, &Size))==NULL)
        {
        Printf("'%s' Not Found"CRLF, InPngFName);
        goto ProcExit;
        }

    if ((PNG=PNG_Init())==NULL) goto ProcExit;
    if (PNG_DecodeFrame(PNG, PngFileData, Size)<0)
        {
        Printf("PNG_DecodeFrame() Error"CRLF);
        goto ProcExit;
        }

    *lpWidth=PNG->Width;
    *lpHeight=PNG->Height;

    lpS=PNG->ImgData;
    lpD=ImgVMPtr;           //COLORREF ������, LowByte�� Red
    if (PNG->BitsPerPixel<=8)
        {
        for (Y=0; Y<PNG->Height; Y++)
            {
            for (X=0; X<PNG->Width; X++) *lpD++=PNG->Palette[lpS[X]];
            lpS+=PNG->LineSize;
            }
        }
    else if (PNG->BitsPerPixel==24)
        {
        Size=PNG->Width*3;
        for (Y=0; Y<PNG->Height; Y++)
            {
            for (X=0; X<Size; X+=3) *lpD++=ForcePeekRGB(lpS+X); //RGB(lpS[X+2], lpS[X+1], lpS[X]) �� ����ϸ� �����Ϸ��� F7�� ���� �����ؼ� ByteAlign�� ������, ������ F7������ ���� �޸𸮴� Byte Aline�� ���Ѿ� ��
            lpS+=PNG->LineSize;
            }
        }
    else{   //PNG->BitsPerPixel==32
        Size=PNG->Width<<2;
        for (Y=0; Y<PNG->Height; Y++)
            {
            for (X=0; X<Size; X+=4) *lpD++=ForcePeekARGB(lpS+X);
            lpS+=PNG->LineSize;
            }
        }
    Rslt++;

    ProcExit:
    PNG_Release(PNG);
    FreeMem(PngFileData);
    return Rslt;
    }





