///////////////////////////////////////////////////////////////////////////////
//                      DMA / DMA2D
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"



///////////////////////////////////////////////////////////////////////////////
//                              DMA
///////////////////////////////////////////////////////////////////////////////

#define HAL_TIMEOUT_DMA_ABORT   5


typedef struct
    {
    __IO UINT ISR;
    __IO UINT Reserved0;
    __IO UINT IFCR;
    } DMA_Base_Registers;



HAL_StatusTypeDef HAL_DMA_Abort(DMA_HandleTypeDef*hDma)
    {
    DMA_Base_Registers *DMABR;
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;
    DMABR=(DMA_Base_Registers*)hDma->StreamBaseAddress;
    UINT StartTick=HAL_GetTick();

    if (hDma->State!=HAL_DMA_STATE_BUSY)
        {
        hDma->ErrorCode=HAL_DMA_ERROR_NO_XFER;
        __HAL_UNLOCK(hDma);
        return HAL_ERROR;
        }
    else{
        MdaInst->CR&=~(DMA_IT_TC|DMA_IT_TE|DMA_IT_DME);
        MdaInst->FCR&=~DMA_IT_FE;

        if (hDma->XferHalfCpltCallback!=NULL ||
            hDma->XferM1HalfCpltCallback!=NULL)
            MdaInst->CR&=~DMA_IT_HT;

        __HAL_DMA_DISABLE(hDma);

        while (MdaInst->CR & DMA_SxCR_EN)
            {
            if (HAL_GetTick()-StartTick>HAL_TIMEOUT_DMA_ABORT)
                {
                hDma->ErrorCode=HAL_DMA_ERROR_TIMEOUT;
                __HAL_UNLOCK(hDma);
                hDma->State=HAL_DMA_STATE_TIMEOUT;
                return HAL_TIMEOUT;
                }
            }

        DMABR->IFCR=0x3F<<hDma->StreamIndex;

        __HAL_UNLOCK(hDma);
        hDma->State=HAL_DMA_STATE_READY;
        }
    return HAL_OK;
    }




HAL_StatusTypeDef HAL_DMA_Abort_IT(DMA_HandleTypeDef*hDma)
    {
    if (hDma->State!=HAL_DMA_STATE_BUSY)
        {
        hDma->ErrorCode=HAL_DMA_ERROR_NO_XFER;
        return HAL_ERROR;
        }
    hDma->State=HAL_DMA_STATE_ABORT;
    __HAL_DMA_DISABLE(hDma);
    return HAL_OK;
    }




LOCAL(DMA_Base_Registers*) DMA_CalcBaseAndBitshift(DMA_HandleTypeDef*hDma)
    {
    UINT StreamNo;
    DMA_Stream_TypeDef *MdaInst;
    static CONST BYTE FlagBitShiftOfs[8]={0, 6, 16, 22, 0, 6, 16, 22};

    MdaInst=hDma->Instance;
    StreamNo=(((UINT)MdaInst&0xFF)-16)/24;
    hDma->StreamIndex=FlagBitShiftOfs[StreamNo];
    if (StreamNo>3)
        hDma->StreamBaseAddress=((UINT)MdaInst & ~0x3FF)+4;
    else
        hDma->StreamBaseAddress=(UINT)MdaInst & ~0x3FF;

    return (DMA_Base_Registers*)hDma->StreamBaseAddress;
    }



HAL_StatusTypeDef HAL_DMA_DeInit(DMA_HandleTypeDef*hDma)
    {
    DMA_Base_Registers *DMABR;
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;
    if (hDma->State==HAL_DMA_STATE_BUSY) return HAL_BUSY;

    __HAL_DMA_DISABLE(hDma);

    MdaInst->CR=0;
    MdaInst->NDTR=0;
    MdaInst->PAR=0;
    MdaInst->M0AR=0;
    MdaInst->M1AR=0;
    MdaInst->FCR=0x21;

    DMABR=DMA_CalcBaseAndBitshift(hDma);
    DMABR->IFCR=0x3F<<hDma->StreamIndex;

    hDma->XferCpltCallback=NULL;
    hDma->XferHalfCpltCallback=NULL;
    hDma->XferM1CpltCallback=NULL;
    hDma->XferM1HalfCpltCallback=NULL;
    hDma->XferErrorCallback=NULL;
    hDma->XferAbortCallback=NULL;

    hDma->ErrorCode=HAL_DMA_ERROR_NONE;
    hDma->State=HAL_DMA_STATE_RESET;
    __HAL_UNLOCK(hDma);
    return HAL_OK;
    }




LOCAL(VOID) DMA_SetConfig(DMA_HandleTypeDef*hDma, UINT SrcAddr, UINT DestAddr, UINT DataLen)
    {
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;
    MdaInst->CR&=~DMA_SxCR_DBM;
    MdaInst->NDTR=DataLen;

    if (hDma->Init.Direction==DMA_MEMORY_TO_PERIPH)
        {
        MdaInst->PAR=DestAddr;
        MdaInst->M0AR=SrcAddr;
        }
    else{
        MdaInst->PAR=SrcAddr;
        MdaInst->M0AR=DestAddr;
        }
    }




HAL_StatusTypeDef HAL_DMA_Start_IT(DMA_HandleTypeDef*hDma, UINT SrcAddr, UINT DestAddr, UINT DataLen)
    {
    HAL_StatusTypeDef Status=HAL_OK;
    DMA_Base_Registers *DMABR;
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;
    DMABR=(DMA_Base_Registers*)hDma->StreamBaseAddress;

    __HAL_LOCK(hDma);

    if (hDma->State==HAL_DMA_STATE_READY)
        {
        hDma->State=HAL_DMA_STATE_BUSY;
        hDma->ErrorCode=HAL_DMA_ERROR_NONE;
        DMA_SetConfig(hDma, SrcAddr, DestAddr, DataLen);

        DMABR->IFCR=0x3F<<hDma->StreamIndex;

        MdaInst->CR|=DMA_IT_TC|DMA_IT_TE|DMA_IT_DME;
        MdaInst->FCR|=DMA_IT_FE;

        if (hDma->XferHalfCpltCallback!=NULL) MdaInst->CR|=DMA_IT_HT;
        __HAL_DMA_ENABLE(hDma);
        }
    else{
        __HAL_UNLOCK(hDma);
        Status=HAL_BUSY;
        }

    return Status;
    }



LOCAL(HAL_StatusTypeDef) DMA_CheckFifoParam(DMA_HandleTypeDef*hDma)
    {
    HAL_StatusTypeDef Status=HAL_OK;
    UINT T=hDma->Init.FIFOThreshold;

    if (hDma->Init.MemDataAlignment==DMA_MDATAALIGN_BYTE)
        {
        switch (T)
            {
            case DMA_FIFO_THRESHOLD_1QUARTERFULL:
            case DMA_FIFO_THRESHOLD_3QUARTERSFULL:
                if (hDma->Init.MemBurst & DMA_SxCR_MBURST_1) Status=HAL_ERROR;
                break;

            case DMA_FIFO_THRESHOLD_HALFFULL:
                if (hDma->Init.MemBurst==DMA_MBURST_INC16) Status=HAL_ERROR;
                break;

            case DMA_FIFO_THRESHOLD_FULL:
                break;
            }
        }

    else if (hDma->Init.MemDataAlignment==DMA_MDATAALIGN_HALFWORD)
        {
        switch (T)
            {
            case DMA_FIFO_THRESHOLD_1QUARTERFULL:
            case DMA_FIFO_THRESHOLD_3QUARTERSFULL:
                Status=HAL_ERROR;
                break;

            case DMA_FIFO_THRESHOLD_HALFFULL:
                if (hDma->Init.MemBurst & DMA_SxCR_MBURST_1) Status=HAL_ERROR;
                break;

            case DMA_FIFO_THRESHOLD_FULL:
                if (hDma->Init.MemBurst==DMA_MBURST_INC16) Status=HAL_ERROR;
                break;
            }
        }
    else{
        switch (T)
            {
            case DMA_FIFO_THRESHOLD_1QUARTERFULL:
            case DMA_FIFO_THRESHOLD_HALFFULL:
            case DMA_FIFO_THRESHOLD_3QUARTERSFULL:
                Status=HAL_ERROR;
                break;

            case DMA_FIFO_THRESHOLD_FULL:
                if (hDma->Init.MemBurst & DMA_SxCR_MBURST_1) Status=HAL_ERROR;
                break;
            }
        }
    return Status;
    }



VOID HAL_DMA_IRQHandler(DMA_HandleTypeDef*hDma)
    {
    UINT Isr;
    __IO UINT Cnt=0;
    UINT Timeout=SystemCoreClock/9600;
    DMA_Base_Registers *DMABR;
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;
    DMABR=(DMA_Base_Registers*)hDma->StreamBaseAddress;
    Isr=DMABR->ISR;

    if (Isr & (DMA_FLAG_TEIF0_4<<hDma->StreamIndex))
        {
        MdaInst->CR&=~DMA_IT_TE;
        DMABR->IFCR=DMA_FLAG_TEIF0_4<<hDma->StreamIndex;
        hDma->ErrorCode|=HAL_DMA_ERROR_TE;
        }
    if (Isr & (DMA_FLAG_FEIF0_4<<hDma->StreamIndex))
        {
        DMABR->IFCR=DMA_FLAG_FEIF0_4<<hDma->StreamIndex;
        hDma->ErrorCode|=HAL_DMA_ERROR_FE;
        }
    if (Isr & (DMA_FLAG_DMEIF0_4<<hDma->StreamIndex))
        {
        DMABR->IFCR=DMA_FLAG_DMEIF0_4<<hDma->StreamIndex;
        hDma->ErrorCode|=HAL_DMA_ERROR_DME;
        }
    if (Isr & (DMA_FLAG_HTIF0_4<<hDma->StreamIndex))
        {
        DMABR->IFCR=DMA_FLAG_HTIF0_4<<hDma->StreamIndex;

        if (MdaInst->CR & DMA_SxCR_DBM)
            {
            if ((MdaInst->CR & DMA_SxCR_CT)==0)
                {
                if (hDma->XferHalfCpltCallback!=NULL) hDma->XferHalfCpltCallback(hDma);
                }
            else{
                if (hDma->XferM1HalfCpltCallback!=NULL) hDma->XferM1HalfCpltCallback(hDma);
                }
            }
        else{
            if ((MdaInst->CR & DMA_SxCR_CIRC)==0) MdaInst->CR&=~DMA_IT_HT;
            if (hDma->XferHalfCpltCallback!=NULL) hDma->XferHalfCpltCallback(hDma);
            }
        }

    if (Isr & (DMA_FLAG_TCIF0_4<<hDma->StreamIndex))
        {
        DMABR->IFCR=DMA_FLAG_TCIF0_4<<hDma->StreamIndex;

        if (HAL_DMA_STATE_ABORT==hDma->State)
            {
            MdaInst->CR&=~(DMA_IT_TC|DMA_IT_TE|DMA_IT_DME);
            MdaInst->FCR&=~DMA_IT_FE;

            if (hDma->XferHalfCpltCallback || hDma->XferM1HalfCpltCallback)
                {
                MdaInst->CR&=~DMA_IT_HT;
                }

            DMABR->IFCR=0x3F<<hDma->StreamIndex;
            __HAL_UNLOCK(hDma);
            hDma->State=HAL_DMA_STATE_READY;
            if (hDma->XferAbortCallback!=NULL) hDma->XferAbortCallback(hDma);
            return;
            }

        if (MdaInst->CR & DMA_SxCR_DBM)
            {
            if ((MdaInst->CR & DMA_SxCR_CT)==0)
                {
                if (hDma->XferM1CpltCallback!=NULL) hDma->XferM1CpltCallback(hDma);
                }
            else{
                if (hDma->XferCpltCallback!=NULL) hDma->XferCpltCallback(hDma);
                }
            }
        else{
            if ((MdaInst->CR & DMA_SxCR_CIRC)==0)
                {
                MdaInst->CR&=~DMA_IT_TC;
                __HAL_UNLOCK(hDma);
                hDma->State=HAL_DMA_STATE_READY;
                }

            if (hDma->XferCpltCallback!=NULL) hDma->XferCpltCallback(hDma);
            }
        }

    if (hDma->ErrorCode!=HAL_DMA_ERROR_NONE)
        {
        if (hDma->ErrorCode & HAL_DMA_ERROR_TE)
            {
            hDma->State=HAL_DMA_STATE_ABORT;
            __HAL_DMA_DISABLE(hDma);

            do  {
                if (++Cnt>Timeout) break;
                } while (MdaInst->CR & DMA_SxCR_EN);

            __HAL_UNLOCK(hDma);
            hDma->State=HAL_DMA_STATE_READY;
            }

        if (hDma->XferErrorCallback!=NULL) hDma->XferErrorCallback(hDma);
        }
    }




HAL_StatusTypeDef HAL_DMA_Init(DMA_HandleTypeDef*hDma)
    {
    UINT T, StartTick=HAL_GetTick();
    DMA_Base_Registers *DMABR;
    DMA_Stream_TypeDef *MdaInst;

    MdaInst=hDma->Instance;

    __HAL_UNLOCK(hDma);
    hDma->State=HAL_DMA_STATE_BUSY;
    __HAL_DMA_DISABLE(hDma);

    while (MdaInst->CR & DMA_SxCR_EN)
        {
        if (HAL_GetTick()-StartTick>HAL_TIMEOUT_DMA_ABORT)
            {
            hDma->ErrorCode=HAL_DMA_ERROR_TIMEOUT;
            hDma->State=HAL_DMA_STATE_TIMEOUT;
            return HAL_TIMEOUT;
            }
        }

    T=MdaInst->CR;

    T&=~(DMA_SxCR_CHSEL|DMA_SxCR_MBURST|DMA_SxCR_PBURST|
        DMA_SxCR_PL|DMA_SxCR_MSIZE|DMA_SxCR_PSIZE|
        DMA_SxCR_MINC|DMA_SxCR_PINC|DMA_SxCR_CIRC|
        DMA_SxCR_DIR|DMA_SxCR_CT|DMA_SxCR_DBM);

    T|=hDma->Init.Channel|hDma->Init.Direction|
        hDma->Init.PeriphInc|hDma->Init.MemInc|
        hDma->Init.PeriphDataAlignment|hDma->Init.MemDataAlignment|
        hDma->Init.Mode|hDma->Init.Priority;

    if (hDma->Init.FIFOMode==DMA_FIFOMODE_ENABLE)
        T|=hDma->Init.MemBurst|hDma->Init.PeriphBurst;

    MdaInst->CR=T;
    T=MdaInst->FCR;
    T&=~(DMA_SxFCR_DMDIS|DMA_SxFCR_FTH);
    T|=hDma->Init.FIFOMode;

    if (hDma->Init.FIFOMode==DMA_FIFOMODE_ENABLE)
        {
        T|=hDma->Init.FIFOThreshold;

        if (hDma->Init.MemBurst!=DMA_MBURST_SINGLE)
            {
            if (DMA_CheckFifoParam(hDma)!=HAL_OK)
                {
                hDma->ErrorCode=HAL_DMA_ERROR_PARAM;
                hDma->State=HAL_DMA_STATE_READY;
                return HAL_ERROR;
                }
            }
        }

    MdaInst->FCR=T;
    DMABR=DMA_CalcBaseAndBitshift(hDma);
    DMABR->IFCR=0x3F<<hDma->StreamIndex;
    hDma->ErrorCode=HAL_DMA_ERROR_NONE;
    hDma->State=HAL_DMA_STATE_READY;

    return HAL_OK;
    }



UINT HAL_DMA_GetError(DMA_HandleTypeDef *hDma) {return hDma->ErrorCode;}






///////////////////////////////////////////////////////////////////////////////
//                              DMA 2D
///////////////////////////////////////////////////////////////////////////////
#ifdef HAL_DMA2D_MODULE_ENABLED

__weak VOID HAL_DMA2D_CLUTLoadingCpltCallback(DMA2D_HandleTypeDef *hDma2d) {}
__weak VOID HAL_DMA2D_LineEventCallback(DMA2D_HandleTypeDef *hDma2d) {}



//-----------------------------------------------------------------------------
//      ������ �����⸦ ��ٸ�
//-----------------------------------------------------------------------------
HAL_StatusTypeDef HAL_DMA2D_PollForTransfer(DMA2D_HandleTypeDef *hDma2d, UINT Timeout)
    {
    __IO UINT Isr=0;
    UINT StartTick, LayerStart;
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    if (Dma2dInst->CR & DMA2D_CR_START)
        {
        StartTick=HAL_GetTick();

        while ((Dma2dInst->ISR & DMA2D_FLAG_TC)==0)
            {
            Isr=Dma2dInst->ISR;
            if (Isr & (DMA2D_FLAG_CE|DMA2D_FLAG_TE))
                {
                if (Isr & DMA2D_FLAG_CE) hDma2d->ErrorCode|=HAL_DMA2D_ERROR_CE;
                if (Isr & DMA2D_FLAG_TE) hDma2d->ErrorCode|=HAL_DMA2D_ERROR_TE;
                Dma2dInst->IFCR=DMA2D_FLAG_CE|DMA2D_FLAG_TE;                //__HAL_DMA2D_CLEAR_FLAG()
                goto ProcExit;
                }
            if (HAL_GetTick()-StartTick>Timeout)
                {
                hDma2d->ErrorCode|=HAL_DMA2D_ERROR_TIMEOUT;
                Rslt=HAL_TIMEOUT;
                goto ProcExit;
                }
            }
        }
    LayerStart=Dma2dInst->FGPFCCR & DMA2D_FGPFCCR_START;
    LayerStart|=Dma2dInst->BGPFCCR & DMA2D_BGPFCCR_START;
    if (LayerStart!=0)
        {
        StartTick=HAL_GetTick();

        while ((Dma2dInst->ISR & DMA2D_FLAG_CTC)==0)
            {
            Isr=Dma2dInst->ISR;
            if (Isr & (DMA2D_FLAG_CAE|DMA2D_FLAG_CE|DMA2D_FLAG_TE))
                {
                if (Isr & DMA2D_FLAG_CAE) hDma2d->ErrorCode|=HAL_DMA2D_ERROR_CAE;
                if (Isr & DMA2D_FLAG_CE)  hDma2d->ErrorCode|=HAL_DMA2D_ERROR_CE;
                if (Isr & DMA2D_FLAG_TE)  hDma2d->ErrorCode|=HAL_DMA2D_ERROR_TE;
                Dma2dInst->IFCR=DMA2D_FLAG_CAE|DMA2D_FLAG_CE|DMA2D_FLAG_TE;     //__HAL_DMA2D_CLEAR_FLAG()
                goto ProcExit;
                }
            if (HAL_GetTick()-StartTick>Timeout)
                {
                hDma2d->ErrorCode|=HAL_DMA2D_ERROR_TIMEOUT;
                Rslt=HAL_TIMEOUT;
                goto ProcExit;
                }
            }
        }

    Dma2dInst->IFCR=DMA2D_FLAG_TC|DMA2D_FLAG_CTC;                               //__HAL_DMA2D_CLEAR_FLAG()
    Rslt=HAL_OK;

    ProcExit:
    return Rslt;
    }




HAL_StatusTypeDef HAL_DMA2D_ConfigLayer(DMA2D_HandleTypeDef *hDma2d, UINT LayerIdx)
    {
    UINT Mask, Value;
    DMA2D_LayerCfgTypeDef *LC;
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    LC=&hDma2d->LayerCfg[LayerIdx];

    #if defined(DMA2D_ALPHA_INV_RB_SWAP_SUPPORT)
    Value=LC->InputColorMode|
        (LC->AlphaMode<<DMA2D_BGPFCCR_AM_Pos)|
        (LC->AlphaInverted<<DMA2D_BGPFCCR_AI_Pos)|
        (LC->RedBlueSwap<<DMA2D_BGPFCCR_RBS_Pos);
    Mask=DMA2D_BGPFCCR_CM|DMA2D_BGPFCCR_AM|DMA2D_BGPFCCR_ALPHA|DMA2D_BGPFCCR_AI|DMA2D_BGPFCCR_RBS;
    #else
    Value=LC->InputColorMode|(LC->AlphaMode<<DMA2D_BGPFCCR_AM_Pos);
    Mask=DMA2D_BGPFCCR_CM|DMA2D_BGPFCCR_AM|DMA2D_BGPFCCR_ALPHA;
    #endif

    if (LC->InputColorMode==DMA2D_INPUT_A4 || LC->InputColorMode==DMA2D_INPUT_A8)
        Value|=LC->InputAlpha & DMA2D_BGPFCCR_ALPHA;
    else
        Value|=LC->InputAlpha<<DMA2D_BGPFCCR_ALPHA_Pos;

    if (LayerIdx==DMA2D_BACKGROUND_LAYER)
        {
        MODIFY_REG(Dma2dInst->BGPFCCR, Mask, Value);
        Dma2dInst->BGOR=LC->InputOffset;

        if (LC->InputColorMode==DMA2D_INPUT_A4 || LC->InputColorMode==DMA2D_INPUT_A8)
            Dma2dInst->BGCOLR=LC->InputAlpha & (DMA2D_BGCOLR_BLUE|DMA2D_BGCOLR_GREEN|DMA2D_BGCOLR_RED);
        }
    else{
        MODIFY_REG(Dma2dInst->FGPFCCR, Mask, Value);
        Dma2dInst->FGOR=LC->InputOffset;

        if (LC->InputColorMode==DMA2D_INPUT_A4 || LC->InputColorMode==DMA2D_INPUT_A8)
            Dma2dInst->FGCOLR=LC->InputAlpha & (DMA2D_FGCOLR_BLUE|DMA2D_FGCOLR_GREEN|DMA2D_FGCOLR_RED);
        }
    return HAL_OK;
    }



LOCAL(VOID) DMA2D_SetConfig(DMA2D_HandleTypeDef *hDma2d, UINT Data, UINT DstAddress, UINT Width, UINT Height)
    {
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    MODIFY_REG(Dma2dInst->NLR, DMA2D_NLR_NL|DMA2D_NLR_PL, Height|(Width<<DMA2D_NLR_PL_Pos));
    Dma2dInst->OMAR=DstAddress;

    if (hDma2d->Init.Mode==DMA2D_R2M)
        {
        if (hDma2d->Init.ColorMode!=DMA2D_OUTPUT_ARGB8888)
            {
            if (hDma2d->Init.ColorMode==DMA2D_OUTPUT_RGB888)
                {
                Data<<=8;
                Data>>=8;
                }
            else if (hDma2d->Init.ColorMode==DMA2D_OUTPUT_RGB565)
                {
                Data=                 (((Data>>19)&0x1F)<<11) | (((Data>>10)&0x3F)<<5) | ((Data>>3)&0x1F);
                }
            else if (hDma2d->Init.ColorMode==DMA2D_OUTPUT_ARGB1555)
                {
                Data=((Data>>31)<<15)|(((Data>>19)&0x1F)<<10) | (((Data>>11)&0x1F)<<5) | ((Data>>3)&0x1F);
                }
            else{   //==DMA2D_OUTPUT_ARGB4444
                Data=((Data>>28)<<12)|(((Data>>20)&0x0F)<<8)  | (((Data>>12)&0x0F)<<4) | ((Data>>4)&0x0F);
                }
            }
        Dma2dInst->OCOLR=Data;
        }
    else Dma2dInst->FGMAR=Data;
    }




HAL_StatusTypeDef HAL_DMA2D_BlendingStart_IT(DMA2D_HandleTypeDef *hDma2d, UINT SrcAddress1, UINT SrcAddress2, UINT DstAddress, UINT Width, UINT Height)
    {
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    Dma2dInst->BGMAR=SrcAddress2;
    DMA2D_SetConfig(hDma2d, SrcAddress1, DstAddress, Width, Height);
    Dma2dInst->CR |= DMA2D_IT_TC|DMA2D_IT_TE|DMA2D_IT_CE;       //__HAL_DMA2D_ENABLE_IT()
    Dma2dInst->CR |= DMA2D_CR_START;                            //__HAL_DMA2D_ENABLE()
    return HAL_OK;
    }




VOID HAL_DMA2D_IRQHandler(DMA2D_HandleTypeDef *hDma2d)
    {
    UINT Isr;
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    Isr=Dma2dInst->ISR;

    if (Isr & DMA2D_FLAG_TE)
        {
        Dma2dInst->CR &= ~DMA2D_IT_TE;      //__HAL_DMA2D_DISABLE_IT()
        hDma2d->ErrorCode|=HAL_DMA2D_ERROR_TE;
        Dma2dInst->IFCR=DMA2D_FLAG_TE;      //__HAL_DMA2D_CLEAR_FLAG()
        if (hDma2d->XferErrorCallback) hDma2d->XferErrorCallback(hDma2d);
        }
    if (Isr & DMA2D_FLAG_CE)
        {
        Dma2dInst->CR &= ~DMA2D_IT_CE;
        Dma2dInst->IFCR=DMA2D_FLAG_CE;
        hDma2d->ErrorCode|=HAL_DMA2D_ERROR_CE;
        if (hDma2d->XferErrorCallback) hDma2d->XferErrorCallback(hDma2d);
        }
    if (Isr & DMA2D_FLAG_CAE)
        {
        Dma2dInst->CR &= ~DMA2D_IT_CAE;
        Dma2dInst->IFCR=DMA2D_FLAG_CAE;
        hDma2d->ErrorCode|=HAL_DMA2D_ERROR_CAE;
        if (hDma2d->XferErrorCallback) hDma2d->XferErrorCallback(hDma2d);
        }
    if (Isr & DMA2D_FLAG_TW)
        {
        Dma2dInst->CR &= ~DMA2D_IT_TW;
        Dma2dInst->IFCR=DMA2D_FLAG_TW;
        HAL_DMA2D_LineEventCallback(hDma2d);
        }
    if (Isr & DMA2D_FLAG_TC)
        {
        Dma2dInst->CR &= ~DMA2D_IT_TC;
        Dma2dInst->IFCR=DMA2D_FLAG_TC;
        hDma2d->ErrorCode|=HAL_DMA2D_ERROR_NONE;
        if (hDma2d->XferCpltCallback) hDma2d->XferCpltCallback(hDma2d);
        }
    if (Isr & DMA2D_FLAG_CTC)
        {
        Dma2dInst->CR &= ~DMA2D_IT_CTC;
        Dma2dInst->IFCR=DMA2D_FLAG_CTC;
        hDma2d->ErrorCode|=HAL_DMA2D_ERROR_NONE;
        HAL_DMA2D_CLUTLoadingCpltCallback(hDma2d);
        }
    }



HAL_StatusTypeDef HAL_DMA2D_Start(DMA2D_HandleTypeDef *hDma2d, UINT Data, UINT DstAddress, UINT Width, UINT Height)
    {
    DMA2D_SetConfig(hDma2d, Data, DstAddress, Width, Height);
    hDma2d->Instance->CR|=DMA2D_CR_START;   //__HAL_DMA2D_ENABLE(hDma2d);
    return HAL_OK;
    }




HAL_StatusTypeDef HAL_DMA2D_Init(DMA2D_HandleTypeDef *hDma2d)
    {
    DMA2D_TypeDef *Dma2dInst;

    Dma2dInst=hDma2d->Instance;
    __HAL_RCC_DMA2D_CLK_ENABLE();

    MODIFY_REG(Dma2dInst->CR, DMA2D_CR_MODE, hDma2d->Init.Mode);
    MODIFY_REG(Dma2dInst->OPFCCR, DMA2D_OPFCCR_CM, hDma2d->Init.ColorMode);
    MODIFY_REG(Dma2dInst->OOR, DMA2D_OOR_LO, hDma2d->Init.OutputOffset);
    #if defined (DMA2D_ALPHA_INV_RB_SWAP_SUPPORT)
    MODIFY_REG(Dma2dInst->OPFCCR, DMA2D_OPFCCR_AI|DMA2D_OPFCCR_RBS, (hDma2d->Init.AlphaInverted<<DMA2D_OPFCCR_AI_Pos)|(hDma2d->Init.RedBlueSwap<<DMA2D_OPFCCR_RBS_Pos));
    #endif

    hDma2d->ErrorCode=HAL_DMA2D_ERROR_NONE;
    return HAL_OK;
    }

#endif //HAL_DMA2D_MODULE_ENABLED


