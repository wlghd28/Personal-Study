///////////////////////////////////////////////////////////////////////////////
//              N25Q128A 16MByte Flash
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "MONITOR.H"

#define JFAT_SECTOR_SIZE                    512


#define N25Q128A_FLASH_SIZE                 0x1000000   //��üũ��
#define N25Q128A_SECTOR_SIZE                0x10000     //������
#define N25Q128A_SUBSECTOR_SIZE             0x1000      //����� ����
#define N25Q128A_PAGE_SIZE                  0x100       //����ϴ� ����

#define N25Q128A_DUMMY_CYCLES_READ          8
#define N25Q128A_DUMMY_CYCLES_READ_QUAD     10

#define N25Q128A_BULK_ERASE_MAX_TIME        250000
#define N25Q128A_SECTOR_ERASE_MAX_TIME      3000
#define N25Q128A_SUBSECTOR_ERASE_MAX_TIME   800

#define RESET_ENABLE_CMD                    0x66
#define RESET_MEMORY_CMD                    0x99

#define READ_ID_CMD                         0x9E
#define READ_ID_CMD2                        0x9F
#define MULTIPLE_IO_READ_ID_CMD             0xAF
#define READ_SERIAL_FLASH_DISCO_PARAM_CMD   0x5A

#define READ_CMD                            0x03
#define FAST_READ_CMD                       0x0B
#define DUAL_OUT_FAST_READ_CMD              0x3B
#define DUAL_INOUT_FAST_READ_CMD            0xBB
#define QUAD_OUT_FAST_READ_CMD              0x6B
#define QUAD_INOUT_FAST_READ_CMD            0xEB

#define WRITE_ENABLE_CMD                    0x06
#define WRITE_DISABLE_CMD                   0x04

#define READ_STATUS_REG_CMD                 0x05
#define WRITE_STATUS_REG_CMD                0x01

#define READ_LOCK_REG_CMD                   0xE8
#define WRITE_LOCK_REG_CMD                  0xE5

#define READ_FLAG_STATUS_REG_CMD            0x70
#define CLEAR_FLAG_STATUS_REG_CMD           0x50

#define READ_NONVOL_CFG_REG_CMD             0xB5
#define WRITE_NONVOL_CFG_REG_CMD            0xB1

#define READ_VOL_CFG_REG_CMD                0x85
#define WRITE_VOL_CFG_REG_CMD               0x81

#define READ_ENHANCED_VOL_CFG_REG_CMD       0x65
#define WRITE_ENHANCED_VOL_CFG_REG_CMD      0x61

#define PAGE_PROG_CMD                       0x02
#define DUAL_IN_FAST_PROG_CMD               0xA2
#define EXT_DUAL_IN_FAST_PROG_CMD           0xD2
#define QUAD_IN_FAST_PROG_CMD               0x32
#define EXT_QUAD_IN_FAST_PROG_CMD           0x12

#define SUBSECTOR_ERASE_CMD                 0x20
#define SECTOR_ERASE_CMD                    0xD8
#define BULK_ERASE_CMD                      0xC7

#define PROG_ERASE_RESUME_CMD               0x7A
#define PROG_ERASE_SUSPEND_CMD              0x75


#define N25Q128A_SR_WIP                     0x01
#define N25Q128A_SR_WREN                    0x02
#define N25Q128A_SR_BLOCKPR                 0x5C
#define N25Q128A_SR_PRBOTTOM                0x20
#define N25Q128A_SR_SRWREN                  0x80

#define N25Q128A_VCR_WRAP                   0x03
#define N25Q128A_VCR_XIP                    0x08
#define N25Q128A_VCR_NB_DUMMY               0xF0

#define N25Q128A_FSR_PRERR                  0x02
#define N25Q128A_FSR_PGSUS                  0x04
#define N25Q128A_FSR_VPPERR                 0x08
#define N25Q128A_FSR_PGERR                  0x10
#define N25Q128A_FSR_ERERR                  0x20
#define N25Q128A_FSR_ERSUS                  0x40
#define N25Q128A_FSR_READY                  0x80



#define QSPI_OK             0x00
#define QSPI_ERROR          0x01
#define QSPI_BUSY           0x02
#define QSPI_NOT_SUPPORTED  0x04
#define QSPI_SUSPENDED      0x08



static QSPI_HandleTypeDef QSPIHandle;



///////////////////////////////////////////////////////////////////////////////
//                      stm32f7xx_hal_qspi.c
///////////////////////////////////////////////////////////////////////////////


#define QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE 0
#define QSPI_FUNCTIONAL_MODE_INDIRECT_READ  QUADSPI_CCR_FMODE_0
#define QSPI_FUNCTIONAL_MODE_AUTO_POLLING   QUADSPI_CCR_FMODE_1
#define QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED  QUADSPI_CCR_FMODE


LOCAL(HAL_StatusTypeDef) QSPI_WaitFlagState(QUADSPI_TypeDef *Qspi, UINT Flag, FlagStatus State, UINT StartTick, UINT Timeout)
    {
    while (((Qspi->SR & Flag)!=0)!=State)
        {
        if (Timeout!=HAL_MAX_DELAY)
            {
            if (Timeout==0 || HAL_GetTick()-StartTick>Timeout) return HAL_ERROR;
            }
        }
    return HAL_OK;
    }



LOCAL(VOID) QSPI_Config(QUADSPI_TypeDef *Qspi, QSPI_CommandTypeDef*Cmd, UINT FuncMode)
    {
    if (Cmd->DataMode!=QSPI_DATA_NONE && FuncMode!=QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED)
        {
        Qspi->DLR=Cmd->NbData-1;
        }

    if (Cmd->InstructionMode!=QSPI_INSTRUCTION_NONE)
        {
        if (Cmd->AlternateByteMode!=QSPI_ALTERNATE_BYTES_NONE)
            {
            Qspi->ABR=Cmd->AlternateBytes;

            if (Cmd->AddressMode!=QSPI_ADDRESS_NONE)
                {
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateBytesSize|
                    Cmd->AlternateByteMode|Cmd->AddressSize|Cmd->AddressMode|
                    Cmd->InstructionMode|Cmd->Instruction|FuncMode;

                if (FuncMode!=QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED)
                    {
                    Qspi->AR=Cmd->Address;
                    }
                }
            else{
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateBytesSize|
                    Cmd->AlternateByteMode|Cmd->AddressMode|Cmd->InstructionMode|
                    Cmd->Instruction|FuncMode;
                }
            }
        else{
            if (Cmd->AddressMode!=QSPI_ADDRESS_NONE)
                {
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateByteMode|
                    Cmd->AddressSize|Cmd->AddressMode|Cmd->InstructionMode|
                    Cmd->Instruction|FuncMode;

                if (FuncMode!=QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED)
                    {
                    Qspi->AR=Cmd->Address;
                    }
                }
            else{
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateByteMode|
                    Cmd->AddressMode|Cmd->InstructionMode|Cmd->Instruction|
                    FuncMode;
                }
            }
        }
    else{
        if (Cmd->AlternateByteMode!=QSPI_ALTERNATE_BYTES_NONE)
            {
            Qspi->ABR=Cmd->AlternateBytes;

            if (Cmd->AddressMode!=QSPI_ADDRESS_NONE)
                {
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateBytesSize|
                    Cmd->AlternateByteMode|Cmd->AddressSize|Cmd->AddressMode|
                    Cmd->InstructionMode|FuncMode;

                if (FuncMode!=QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED)
                    {
                    Qspi->AR=Cmd->Address;
                    }
                }
            else{
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateBytesSize|
                    Cmd->AlternateByteMode|Cmd->AddressMode|Cmd->InstructionMode|
                    FuncMode;
                }
            }
        else{
            if (Cmd->AddressMode!=QSPI_ADDRESS_NONE)
                {
                Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                    Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateByteMode|
                    Cmd->AddressSize|Cmd->AddressMode|Cmd->InstructionMode|
                    FuncMode;

                if (FuncMode!=QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED)
                    {
                    Qspi->AR=Cmd->Address;
                    }
                }
            else{
                if (Cmd->DataMode!=QSPI_DATA_NONE)
                    {
                    Qspi->CCR=Cmd->DdrMode|Cmd->DdrHoldHalfCycle|Cmd->SIOOMode|
                        Cmd->DataMode|(Cmd->DummyCycles<<18)|Cmd->AlternateByteMode|
                        Cmd->AddressMode|Cmd->InstructionMode|FuncMode;
                    }
                }
            }
        }
    }




LOCAL(HAL_StatusTypeDef) QSPI_Command(QUADSPI_TypeDef *Qspi, QSPI_CommandTypeDef*Cmd, UINT Timeout)
    {
    HAL_StatusTypeDef Status=HAL_ERROR;
    UINT StartTick=HAL_GetTick();

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_BUSY, RESET, StartTick, Timeout))==HAL_OK)
        {
        QSPI_Config(Qspi, Cmd, QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE);
        if (Cmd->DataMode==QSPI_DATA_NONE)
            {
            if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_TC, SET, StartTick, Timeout))==HAL_OK)
                {
                Qspi->FCR=QSPI_FLAG_TC;             //__HAL_QSPI_CLEAR_FLAG()
                }
            }
        }
    return Status;
    }




LOCAL(HAL_StatusTypeDef) QSPI_AutoPolling(QUADSPI_TypeDef *Qspi, QSPI_CommandTypeDef*Cmd, QSPI_AutoPollingTypeDef*Cfg, UINT Timeout)
    {
    HAL_StatusTypeDef Status=HAL_ERROR;
    UINT StartTick=HAL_GetTick();

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_BUSY, RESET, StartTick, Timeout))==HAL_OK)
        {
        Qspi->PSMAR=Cfg->Match;
        Qspi->PSMKR=Cfg->Mask;
        Qspi->PIR=Cfg->Interval;
        MODIFY_REG(Qspi->CR, QUADSPI_CR_PMM|QUADSPI_CR_APMS, Cfg->MatchMode|QSPI_AUTOMATIC_STOP_ENABLE);

        Cmd->NbData=Cfg->StatusBytesSize;
        QSPI_Config(Qspi, Cmd, QSPI_FUNCTIONAL_MODE_AUTO_POLLING);

        if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_SM, SET, StartTick, Timeout))==HAL_OK)
            {
            Qspi->FCR=QSPI_FLAG_SM;
            }
        }
    return Status;
    }



//-----------------------------------------------------------------------------
//  TimeOutActivation ... QSPI_TIMEOUT_COUNTER_ENABLE or QSPI_TIMEOUT_COUNTER_DISABLE
//  TimeOutPeriod (0~0xFFFF) ... Ĩ ������ �����ϱ� ���� FIFO�� ���� ���� ����� Ŭ�� ���� �����մϴ�.
//-----------------------------------------------------------------------------
LOCAL(HAL_StatusTypeDef) QSPI_MemoryMapped(QUADSPI_TypeDef *Qspi, QSPI_CommandTypeDef*Cmd, UINT TimeOutActivation, UINT TimeOutPeriod)
    {
    HAL_StatusTypeDef Status=HAL_ERROR;
    UINT StartTick=HAL_GetTick();

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_BUSY, RESET, StartTick, HAL_QPSI_TIMEOUT_DEFAULT_VALUE))==HAL_OK)
        {
        MODIFY_REG(Qspi->CR, QUADSPI_CR_TCEN, TimeOutActivation);

        if (TimeOutActivation==QSPI_TIMEOUT_COUNTER_ENABLE)
            {
            Qspi->LPTR=TimeOutPeriod;
            Qspi->FCR=QSPI_FLAG_TO;
            Qspi->CR|=QSPI_IT_TO;       //__HAL_QSPI_ENABLE_IT()
            }

        QSPI_Config(Qspi, Cmd, QSPI_FUNCTIONAL_MODE_MEMORY_MAPPED);
        }

    return Status;
    }




LOCAL(HAL_StatusTypeDef) QSPI_Abort(QUADSPI_TypeDef *Qspi)
    {
    HAL_StatusTypeDef Status=HAL_OK;
    UINT StartTick;

    StartTick=HAL_GetTick();

    Qspi->CR|=QUADSPI_CR_ABORT;

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_TC, SET, StartTick, HAL_QPSI_TIMEOUT_DEFAULT_VALUE))==HAL_OK)
        {
        Qspi->FCR=QSPI_FLAG_TC;
        Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_BUSY, RESET, StartTick, HAL_QPSI_TIMEOUT_DEFAULT_VALUE);
        }

    return Status;
    }



LOCAL(HAL_StatusTypeDef) QSPI_Receive(QUADSPI_TypeDef *Qspi, LPBYTE lpData, UINT Timeout)
    {
    HAL_StatusTypeDef Status=HAL_OK;
    UINT StartTick, AddrReg, RxCnt;
    __IO UINT *DataReg;

    StartTick=HAL_GetTick();
    AddrReg=Qspi->AR;
    DataReg=&Qspi->DR;

    RxCnt=Qspi->DLR+1;

    MODIFY_REG(Qspi->CCR, QUADSPI_CCR_FMODE, QSPI_FUNCTIONAL_MODE_INDIRECT_READ);

    Qspi->AR=AddrReg;

    while (RxCnt>0)
        {
        if ((Status=QSPI_WaitFlagState(Qspi, (QSPI_FLAG_FT|QSPI_FLAG_TC), SET, StartTick, Timeout))!=HAL_OK) goto ProcExit;

        *lpData++=*(__IO BYTE*)DataReg;
        RxCnt--;
        }

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_TC, SET, StartTick, Timeout))==HAL_OK)
        {
        Qspi->FCR=QSPI_FLAG_TC;
        }

    ProcExit:
    return Status;
    }





LOCAL(HAL_StatusTypeDef) QSPI_Transmit(QUADSPI_TypeDef *Qspi, LPCBYTE lpData, UINT Timeout)
    {
    HAL_StatusTypeDef Status=HAL_OK;
    UINT StartTick, TxCnt;
    __IO UINT *DataReg;

    StartTick=HAL_GetTick();
    DataReg=&Qspi->DR;

    TxCnt=Qspi->DLR+1;
    MODIFY_REG(Qspi->CCR, QUADSPI_CCR_FMODE, QSPI_FUNCTIONAL_MODE_INDIRECT_WRITE);

    while (TxCnt>0)
        {
        if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_FT, SET, StartTick, Timeout))!=HAL_OK) goto ProcExit;

        *(__IO BYTE*)DataReg=*lpData++;
        TxCnt--;
        }

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_TC, SET, StartTick, Timeout))==HAL_OK)
        {
        Qspi->FCR=QSPI_FLAG_TC;
        }

    ProcExit:
    return Status;
    }




HAL_StatusTypeDef HAL_QSPI_Init(QSPI_HandleTypeDef *hQspi)
    {
    HAL_StatusTypeDef Status=HAL_ERROR;
    UINT StartTick;
    QUADSPI_TypeDef *Qspi;

    Qspi=hQspi->Instance;
    StartTick=HAL_GetTick();

    MODIFY_REG(Qspi->CR, QUADSPI_CR_FTHRES, (hQspi->Init.FifoThreshold-1)<<8);

    if ((Status=QSPI_WaitFlagState(Qspi, QSPI_FLAG_BUSY, RESET, StartTick, HAL_QPSI_TIMEOUT_DEFAULT_VALUE))==HAL_OK)
        {
        MODIFY_REG(Qspi->CR, QUADSPI_CR_PRESCALER|QUADSPI_CR_SSHIFT|QUADSPI_CR_FSEL|QUADSPI_CR_DFM, (hQspi->Init.ClockPrescaler<<24)|hQspi->Init.SampleShifting|hQspi->Init.FlashID|hQspi->Init.DualFlash);

        MODIFY_REG(Qspi->DCR, QUADSPI_DCR_FSIZE|QUADSPI_DCR_CSHT|QUADSPI_DCR_CKMODE,
            (hQspi->Init.FlashSize<<16)|hQspi->Init.ChipSelectHighTime|hQspi->Init.ClockMode);

        Qspi->CR|=QUADSPI_CR_EN;     //__HAL_QSPI_ENABLE(hQspi);
        }

    return Status;
    }



#if USE_QSPI_IRQ
__weak VOID HAL_QSPI_ErrorCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_AbortCpltCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_CmdCpltCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_RxCpltCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_TxCpltCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_FifoThresholdCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_StatusMatchCallback(QSPI_HandleTypeDef *hQspi) {}
__weak VOID HAL_QSPI_TimeOutCallback(QSPI_HandleTypeDef *hQspi) {}




LOCAL(VOID) QSPI_DMAAbortCplt(DMA_HandleTypeDef *hDma)
    {
    QSPI_HandleTypeDef *hQspi=(QSPI_HandleTypeDef*)hDma->Parent;

    hQspi->RxXferCount=0;
    hQspi->TxXferCount=0;

    if (hQspi->State==HAL_QSPI_STATE_ABORT)
        {
        __HAL_QSPI_CLEAR_FLAG(hQspi, QSPI_FLAG_TC);
        __HAL_QSPI_ENABLE_IT(hQspi, QSPI_IT_TC);
        SET_BIT(hQspi->Instance->CR, QUADSPI_CR_ABORT);
        }
    else{
        hQspi->State=HAL_QSPI_STATE_READY;
        HAL_QSPI_ErrorCallback(hQspi);
        }
    }



HAL_StatusTypeDef HAL_QSPI_Abort_IT(QSPI_HandleTypeDef *hQspi)
    {
    HAL_StatusTypeDef status=HAL_OK;

    if (hQspi->State & 2)
        {
        __HAL_UNLOCK(hQspi);

        hQspi->State=HAL_QSPI_STATE_ABORT;
        hQspi->Instance->CR&=~(QSPI_IT_TO|QSPI_IT_SM|QSPI_IT_FT|QSPI_IT_TC|QSPI_IT_TE);

        if (hQspi->Instance->CR & QUADSPI_CR_DMAEN)
            {
            hQspi->Instance->CR&=~QUADSPI_CR_DMAEN;
            hQspi->hdma->XferAbortCallback=QSPI_DMAAbortCplt;
            if (HAL_DMA_Abort_IT(hQspi->hdma)!=HAL_OK)
                {
                hQspi->State=HAL_QSPI_STATE_READY;
                HAL_QSPI_AbortCpltCallback(hQspi);
                }
            }
        else{
            __HAL_QSPI_CLEAR_FLAG(hQspi, QSPI_FLAG_TC);
            __HAL_QSPI_ENABLE_IT(hQspi, QSPI_IT_TC);
            hQspi->Instance->CR|=QUADSPI_CR_ABORT;
            }
        }
    return status;
    }





VOID HAL_QSPI_IRQHandler(QSPI_HandleTypeDef *hQspi)
    {
    __IO UINT*Dr;
    UINT Sr;
    QUADSPI_TypeDef *Qspi;

    Qspi=hQspi->Instance;
    Sr=Qspi->SR;

    if (Sr & QSPI_FLAG_FT)
        {
        Dr=&Qspi->DR;

        if (hQspi->State==HAL_QSPI_STATE_BUSY_INDIRECT_TX)
            {
            while (Qspi->SR & QSPI_FLAG_FT) //__HAL_QSPI_GET_FLAG()
                {
                if (hQspi->TxXferCount>0)
                    {
                    *(__IO BYTE*)Dr=*hQspi->pTxBuffPtr++;
                    hQspi->TxXferCount--;
                    }
                else{
                    Qspi->CR&=~QSPI_IT_FT;
                    break;
                    }
                }
            }
        else if (hQspi->State==HAL_QSPI_STATE_BUSY_INDIRECT_RX)
            {
            while (Qspi->SR & QSPI_FLAG_FT)
                {
                if (hQspi->RxXferCount>0)
                    {
                    *hQspi->pRxBuffPtr++=*(__IO BYTE*)Dr;
                    hQspi->RxXferCount--;
                    }
                else{
                    Qspi->CR&=~QSPI_IT_FT;
                    break;
                    }
                }
            }

        HAL_QSPI_FifoThresholdCallback(hQspi);
        }

    else if (Sr & QSPI_FLAG_TC)
        {
        Qspi->FCR=QSPI_FLAG_TC;
        Qspi->CR&=~(QSPI_IT_TC|QSPI_IT_TE|QSPI_IT_FT);

        if (hQspi->State==HAL_QSPI_STATE_BUSY_INDIRECT_TX)
            {
            if (Qspi->CR & QUADSPI_CR_DMAEN)
                {
                Qspi->CR&=~QUADSPI_CR_DMAEN;
                hQspi->hdma->Instance->CR&=~DMA_SxCR_EN;    //__HAL_DMA_DISABLE(hQspi->hdma);
                }

            #if  defined(QSPI1_V1_0)
            HAL_QSPI_Abort_IT(hQspi);
            #endif

            hQspi->State=HAL_QSPI_STATE_READY;
            HAL_QSPI_TxCpltCallback(hQspi);
            }
        else if (hQspi->State==HAL_QSPI_STATE_BUSY_INDIRECT_RX)
            {
            if (Qspi->CR & QUADSPI_CR_DMAEN)
                {
                Qspi->CR&=~QUADSPI_CR_DMAEN;
                hQspi->hdma->Instance->CR&=~DMA_SxCR_EN;    //__HAL_DMA_DISABLE(hQspi->hdma);
                }
            else{
                Dr=&Qspi->DR;
                while (Qspi->SR & QUADSPI_SR_FLEVEL)
                    {
                    if (hQspi->RxXferCount>0)
                        {
                        *hQspi->pRxBuffPtr=*(__IO BYTE*)Dr;
                        hQspi->pRxBuffPtr++;
                        hQspi->RxXferCount--;
                        }
                    else break;
                    }
                }

            #if  defined(QSPI1_V1_0)
            HAL_QSPI_Abort_IT(hQspi);
            #endif

            hQspi->State=HAL_QSPI_STATE_READY;
            HAL_QSPI_RxCpltCallback(hQspi);
            }
        else if (hQspi->State==HAL_QSPI_STATE_BUSY)
            {
            hQspi->State=HAL_QSPI_STATE_READY;
            HAL_QSPI_CmdCpltCallback(hQspi);
            }
        else if (hQspi->State==HAL_QSPI_STATE_ABORT)
            {
            Qspi->CCR&=~QUADSPI_CCR_FMODE;
            hQspi->State=HAL_QSPI_STATE_READY;

            if (hQspi->ErrorCode==HAL_QSPI_ERROR_NONE)
                HAL_QSPI_AbortCpltCallback(hQspi);
            else
                HAL_QSPI_ErrorCallback(hQspi);
            }
        }
    else if (Sr & QSPI_FLAG_SM)
        {
        Qspi->FCR=QSPI_FLAG_SM;
        if (Qspi->CR & QUADSPI_CR_APMS)
            {
            Qspi->CR&=~(QSPI_IT_SM|QSPI_IT_TE);
            hQspi->State=HAL_QSPI_STATE_READY;
            }
        HAL_QSPI_StatusMatchCallback(hQspi);
        }
    else if (Sr & QSPI_FLAG_TE)
        {
        Qspi->FCR=QSPI_FLAG_TE;
        Qspi->CR&=~(QSPI_IT_SM|QSPI_IT_TC|QSPI_IT_TE|QSPI_IT_FT);
        hQspi->ErrorCode|=HAL_QSPI_ERROR_TRANSFER;
        if (Qspi->CR & QUADSPI_CR_DMAEN)
            {
            Qspi->CR&=~QUADSPI_CR_DMAEN;

            hQspi->hdma->XferAbortCallback=QSPI_DMAAbortCplt;
            if (HAL_DMA_Abort_IT(hQspi->hdma)!=HAL_OK)
                {
                hQspi->ErrorCode|=HAL_QSPI_ERROR_DMA;
                hQspi->State=HAL_QSPI_STATE_READY;
                HAL_QSPI_ErrorCallback(hQspi);
                }
            }
        else{
            hQspi->State=HAL_QSPI_STATE_READY;
            HAL_QSPI_ErrorCallback(hQspi);
            }
        }
    else if (Sr & QSPI_FLAG_TO)
        {
        Qspi->FCR=QSPI_FLAG_TO;
        HAL_QSPI_TimeOutCallback(hQspi);
        }
    }



VOID QUADSPI_IRQHandler(VOID)
    {
    HAL_QSPI_IRQHandler(&QSPIHandle);
    }
#endif //USE_QSPI_IRQ


///////////////////////////////////////////////////////////////////////////////
//                      stm32746g_discovery_qspi.c
///////////////////////////////////////////////////////////////////////////////


BOOL WINAPI QSPI_EnableMemoryMappedMode(VOID)
    {
    QSPI_CommandTypeDef QC;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=QUAD_INOUT_FAST_READ_CMD;
    QC.AddressMode=QSPI_ADDRESS_4_LINES;
    QC.AddressSize=QSPI_ADDRESS_24_BITS;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_4_LINES;
    QC.DummyCycles=N25Q128A_DUMMY_CYCLES_READ_QUAD;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    return QSPI_MemoryMapped(QSPIHandle.Instance, &QC, QSPI_TIMEOUT_COUNTER_DISABLE, 0)==HAL_OK;
    }




LOCAL(int) QSPI_AutoPollingMemReady(QUADSPI_TypeDef *Qspi, UINT Timeout)
    {
    QSPI_CommandTypeDef QC;
    QSPI_AutoPollingTypeDef AP;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=READ_STATUS_REG_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_1_LINE;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;

    AP.Match=0;
    AP.Mask=N25Q128A_SR_WIP;
    AP.MatchMode=QSPI_MATCH_MODE_AND;
    AP.StatusBytesSize=1;
    AP.Interval=0x10;
    AP.AutomaticStop=QSPI_AUTOMATIC_STOP_ENABLE;
    if (QSPI_AutoPolling(Qspi, &QC, &AP, Timeout)!=HAL_OK) return QSPI_ERROR;
    return QSPI_OK;
    }




LOCAL(BOOL) QSPI_WriteEnable(QUADSPI_TypeDef *Qspi)
    {
    QSPI_CommandTypeDef QC;
    QSPI_AutoPollingTypeDef Cfg;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=WRITE_ENABLE_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_NONE;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return FALSE;

    Cfg.Match=N25Q128A_SR_WREN;
    Cfg.Mask=N25Q128A_SR_WREN;
    Cfg.MatchMode=QSPI_MATCH_MODE_AND;
    Cfg.StatusBytesSize=1;
    Cfg.Interval=0x10;
    Cfg.AutomaticStop=QSPI_AUTOMATIC_STOP_ENABLE;

    QC.Instruction=READ_STATUS_REG_CMD;
    QC.DataMode=QSPI_DATA_1_LINE;
    return QSPI_AutoPolling(Qspi, &QC, &Cfg, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)==HAL_OK;
    }




//���̸� BSP_QSPI_Read
LOCAL(BOOL) QSPI_Read(QUADSPI_TypeDef *Qspi, LPBYTE Buff, UINT Addr, UINT ToReadBytes)
    {
    BOOL Rslt=FALSE;
    QSPI_CommandTypeDef QC;

    //Printf("N25Q128A Read %04X %04X"CRLF, Addr, ToReadBytes);
    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=QUAD_INOUT_FAST_READ_CMD;
    QC.AddressMode=QSPI_ADDRESS_4_LINES;
    QC.AddressSize=QSPI_ADDRESS_24_BITS;
    QC.Address=Addr;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_4_LINES;
    QC.DummyCycles=N25Q128A_DUMMY_CYCLES_READ_QUAD;
    QC.NbData=ToReadBytes;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) goto ProcExit;
    MODIFY_REG(Qspi->DCR, QUADSPI_DCR_CSHT, QSPI_CS_HIGH_TIME_3_CYCLE);
    if (QSPI_Receive(Qspi, Buff, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) goto ProcExit;
    MODIFY_REG(Qspi->DCR, QUADSPI_DCR_CSHT, QSPI_CS_HIGH_TIME_6_CYCLE);
    Rslt++;

    ProcExit:
    return Rslt;
    }



//���̸�: BSP_QSPI_Write
LOCAL(BOOL) QSPI_Write(QUADSPI_TypeDef *Qspi, LPCBYTE lpData, UINT Addr, UINT ToWriteSize)
    {
    int Rslt=FALSE, Size, WrtBlkSize;
    QSPI_CommandTypeDef QC;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=EXT_QUAD_IN_FAST_PROG_CMD;
    QC.AddressMode=QSPI_ADDRESS_4_LINES;
    QC.AddressSize=QSPI_ADDRESS_24_BITS;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_4_LINES;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;

    WrtBlkSize=N25Q128A_PAGE_SIZE - Addr % N25Q128A_PAGE_SIZE;
    while (ToWriteSize>0)
        {
        Size=GetMin(ToWriteSize, WrtBlkSize);

        if (QSPI_WriteEnable(Qspi)==FALSE) goto ProcExit;
        QC.Address=Addr;
        QC.NbData=Size;
        //Printf("N25Q128A Write %04X %04X"CRLF, Addr, Size);
        if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) goto ProcExit;
        if (QSPI_Transmit(Qspi, lpData, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) goto ProcExit;
        if (QSPI_AutoPollingMemReady(Qspi, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=QSPI_OK) goto ProcExit;

        lpData+=Size;
        Addr+=Size;
        ToWriteSize-=Size;
        WrtBlkSize=N25Q128A_PAGE_SIZE;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//          ���̸� BSP_QSPI_Erase_Block
//
//      BlockAddr �� �а� ���� �ִ� ����Ʈ �ּ�������, Bit11~Bit0�� ���õ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) QSPI_EraseBlock(QUADSPI_TypeDef *Qspi, UINT BlockAddr)
    {
    BOOL Rslt=FALSE;
    QSPI_CommandTypeDef QC;

    if (QSPI_WriteEnable(Qspi)==FALSE) goto ProcExit;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=SUBSECTOR_ERASE_CMD;
    QC.AddressMode=QSPI_ADDRESS_1_LINE;
    QC.AddressSize=QSPI_ADDRESS_24_BITS;
    QC.Address=BlockAddr;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_NONE;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) goto ProcExit;
    if (QSPI_AutoPollingMemReady(Qspi, N25Q128A_SUBSECTOR_ERASE_MAX_TIME)!=QSPI_OK) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }



int BSP_QSPI_Erase_Chip(VOID)
    {
    QSPI_CommandTypeDef QC;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=BULK_ERASE_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_NONE;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;

    if (QSPI_WriteEnable(QSPIHandle.Instance)==FALSE) return QSPI_ERROR;
    if (QSPI_Command(QSPIHandle.Instance, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_AutoPollingMemReady(QSPIHandle.Instance, N25Q128A_BULK_ERASE_MAX_TIME)!=QSPI_OK) return QSPI_ERROR;

    return QSPI_OK;
    }



int BSP_QSPI_GetStatus(VOID)
    {
    QSPI_CommandTypeDef QC;
    BYTE Reg;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=READ_FLAG_STATUS_REG_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_1_LINE;
    QC.DummyCycles=0;
    QC.NbData=1;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(QSPIHandle.Instance, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_Receive(QSPIHandle.Instance, &Reg, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (Reg & (N25Q128A_FSR_PRERR|N25Q128A_FSR_VPPERR|N25Q128A_FSR_PGERR|N25Q128A_FSR_ERERR)) return QSPI_ERROR;
    if (Reg & (N25Q128A_FSR_PGSUS|N25Q128A_FSR_ERSUS)) return QSPI_SUSPENDED;
    if (Reg & N25Q128A_FSR_READY) return QSPI_OK;
    return QSPI_BUSY;
    }




LOCAL(int) QSPI_DummyCyclesCfg(QUADSPI_TypeDef *Qspi)
    {
    QSPI_CommandTypeDef QC;
    BYTE Reg;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=READ_VOL_CFG_REG_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_1_LINE;
    QC.DummyCycles=0;
    QC.NbData=1;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_Receive(Qspi, &Reg, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_WriteEnable(Qspi)==FALSE) return QSPI_ERROR;

    QC.Instruction=WRITE_VOL_CFG_REG_CMD;
    MODIFY_REG(Reg, N25Q128A_VCR_NB_DUMMY, N25Q128A_DUMMY_CYCLES_READ_QUAD<<POSITION_VAL(N25Q128A_VCR_NB_DUMMY));
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_Transmit(Qspi, &Reg, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    return QSPI_OK;
    }




LOCAL(int) QSPI_ResetMemory(QUADSPI_TypeDef *Qspi)
    {
    QSPI_CommandTypeDef QC;

    QC.InstructionMode=QSPI_INSTRUCTION_1_LINE;
    QC.Instruction=RESET_ENABLE_CMD;
    QC.AddressMode=QSPI_ADDRESS_NONE;
    QC.AlternateByteMode=QSPI_ALTERNATE_BYTES_NONE;
    QC.DataMode=QSPI_DATA_NONE;
    QC.DummyCycles=0;
    QC.DdrMode=QSPI_DDR_MODE_DISABLE;
    QC.DdrHoldHalfCycle=QSPI_DDR_HHC_ANALOG_DELAY;
    QC.SIOOMode=QSPI_SIOO_INST_EVERY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    QC.Instruction=RESET_MEMORY_CMD;
    if (QSPI_Command(Qspi, &QC, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=HAL_OK) return QSPI_ERROR;
    if (QSPI_AutoPollingMemReady(Qspi, HAL_QPSI_TIMEOUT_DEFAULT_VALUE)!=QSPI_OK) return QSPI_ERROR;

    return QSPI_OK;
    }




//-----------------------------------------------------------------------------
//      ���̸�: BSP_QSPI_Init
//-----------------------------------------------------------------------------
int WINAPI QSPI_Init(VOID)
    {
    int Rslt;

    QSPIHandle.Instance=QUADSPI;

    //HAL_QSPI_DeInit(&QSPIHandle);
    __HAL_QSPI_DISABLE(&QSPIHandle);

    __HAL_RCC_QSPI_CLK_ENABLE();
    __HAL_RCC_QSPI_FORCE_RESET();
    __HAL_RCC_QSPI_RELEASE_RESET();

    QSPIHandle.Init.ClockPrescaler=1;
    QSPIHandle.Init.FifoThreshold=4;
    QSPIHandle.Init.SampleShifting=QSPI_SAMPLE_SHIFTING_HALFCYCLE;
    QSPIHandle.Init.FlashSize=POSITION_VAL(N25Q128A_FLASH_SIZE)-1;
    QSPIHandle.Init.ChipSelectHighTime=QSPI_CS_HIGH_TIME_6_CYCLE;
    QSPIHandle.Init.ClockMode=QSPI_CLOCK_MODE_0;
    QSPIHandle.Init.FlashID=QSPI_FLASH_ID_1;
    QSPIHandle.Init.DualFlash=QSPI_DUALFLASH_DISABLE;
    if (HAL_QSPI_Init(&QSPIHandle)!=HAL_OK) {Rslt=QSPI_ERROR; goto ProcExit;}
    if (QSPI_ResetMemory(QSPIHandle.Instance)!=QSPI_OK) {Rslt=QSPI_NOT_SUPPORTED; goto ProcExit;}
    if (QSPI_DummyCyclesCfg(QSPIHandle.Instance)!=QSPI_OK) {Rslt=QSPI_NOT_SUPPORTED; goto ProcExit;}

    //HAL_NVIC_SetPriority(QUADSPI_IRQn, 0x0F, 0);
    //NVIC_EnableIRQ(QUADSPI_IRQn);

    Rslt=QSPI_OK;

    ProcExit:
    //Printf("N25Q128A_Init()=%d"CRLF, Rslt);
    return Rslt;
    }



BOOL WINAPI N25Q128A_Init(VOID)
    {
    static BYTE Initialized;

    if (Initialized==0)
        {
        QSPI_Init();
        Initialized=1;
        }
    return TRUE;
    }



static UINT CachedAddress=~0;           //-1�̸� ĳ������ ���� ����
static DWORD CacheDirtyTime;            //���� �÷�������� cache ������ Ʋ�� ��� �ð��� ��
static BYTE CacheBuffer[N25Q128A_SUBSECTOR_SIZE];
static BYTE StorageLockFg;



//-----------------------------------------------------------------------------
//      ���丮�� �＼�� ��ȸ�� ���� (FALSE�� �����ϴ� ��� �־��� �ð����� ������)
//-----------------------------------------------------------------------------
LOCAL(BOOL) N25Q128A_WaitLock(int Timeout)
    {
    int   Rslt=FALSE;
    DWORD Tick;
    JOS_CRITICAL_VAR;

    Tick=GetTickCount();
    for (;;)
        {
        JOS_ENTER_CRITICAL();
        if (StorageLockFg==0) {StorageLockFg=1; Rslt++;}
        JOS_EXIT_CRITICAL();
        if (Rslt) break;
        if (GetTickCount()-Tick>=Timeout) break;
        }
    return Rslt;
    }


LOCAL(VOID) N25Q128A_Unlock() {StorageLockFg=0;}



//-----------------------------------------------------------------------------
//      �̹� ĳ���ȿ� ������ ĳ���� ����
//-----------------------------------------------------------------------------
BOOL WINAPI N25Q128A_Read(LPBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    BOOL Rslt=FALSE;
    UINT Addr, ToReadBytes, CacheEnd, ReadBytes;

    //Printf("N25Q128A_Read %d %d ... ", BlockAddr, BlockLen);
    if (N25Q128A_WaitLock(10000)==FALSE) return FALSE; //{Printf("Busy"CRLF); return FALSE;}

    Addr=BlockAddr*JFAT_SECTOR_SIZE;
    ToReadBytes=BlockLen*JFAT_SECTOR_SIZE;
    CacheEnd=CachedAddress+N25Q128A_SUBSECTOR_SIZE;

    if (CachedAddress!=~0 && Addr>=CachedAddress && Addr<CacheEnd)
        {
        ReadBytes=GetMin(ToReadBytes, CacheEnd-Addr);
        CopyMem(Buff, Addr-CachedAddress+CacheBuffer, ReadBytes);
        Addr+=ReadBytes;
        Buff+=ReadBytes;
        if ((ToReadBytes-=ReadBytes)==0) {Rslt++; goto ProcExit;}
        }
    Rslt=QSPI_Read(QSPIHandle.Instance, Buff, Addr, ToReadBytes);

    ProcExit:
    N25Q128A_Unlock();
    //Printf(Rslt ? "Ok"CRLF:"Fail"CRLF);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//     ĳ���� ��� (��� �����̸� FALSE����)
//-----------------------------------------------------------------------------
LOCAL(BOOL) FlushCacheBuffer(QUADSPI_TypeDef *Qspi)
    {
    int I;

    if (CacheDirtyTime!=0)
        {
        //Printf("WriteChahe %d"CRLF, CachedAddress>>9);
        for (I=0; I<5; I++)
            {
            if (QSPI_EraseBlock(Qspi, CachedAddress)!=FALSE) break;
            QSPI_Abort(Qspi);
            }
        if (I>=5)
            {
            Printf("[%u Sector cannot Erase]", CachedAddress>>9);
            goto ProcExit;
            }

        if (I!=0) Printf("[Erased %u, %d]", CachedAddress>>9, I);

        if (QSPI_Write(Qspi, CacheBuffer, CachedAddress, N25Q128A_SUBSECTOR_SIZE)==FALSE)
            {
            Printf("[%u Write Error]"CRLF, CachedAddress>>9);
            goto ProcExit;
            }

        CacheDirtyTime=0;
        }
    ProcExit:
    return CacheDirtyTime==0;
    }



//-----------------------------------------------------------------------------
//      ���� ���
//-----------------------------------------------------------------------------
BOOL WINAPI N25Q128A_Write(LPCBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    BOOL Rslt=FALSE;
    UINT Addr, ToWriteBytes, CacheEnd, WriteBytes;

    //Printf("N25Q128A_Write %d %d ... ", BlockAddr, BlockLen);
    if (N25Q128A_WaitLock(10000)==FALSE) return FALSE; //{Printf("Busy"CRLF); return FALSE;}

    Addr=BlockAddr*JFAT_SECTOR_SIZE;
    ToWriteBytes=BlockLen*JFAT_SECTOR_SIZE;

    while (ToWriteBytes>0)
        {
        CacheEnd=CachedAddress+N25Q128A_SUBSECTOR_SIZE;
        if (CachedAddress!=~0 && Addr>=CachedAddress && Addr<CacheEnd)
            {
            WriteBytes=GetMin(ToWriteBytes, CacheEnd-Addr);
            CopyMem(Addr-CachedAddress+CacheBuffer, Buff, WriteBytes);
            CacheDirtyTime=GetTickCount();
            Addr+=WriteBytes;
            Buff+=WriteBytes;
            if ((ToWriteBytes-=WriteBytes)==0) break;
            }

        if (FlushCacheBuffer(QSPIHandle.Instance)==FALSE) goto ProcExit;

        CachedAddress=Addr & ~(N25Q128A_SUBSECTOR_SIZE-1);
        //Printf("ReadChahe %d"CRLF, CachedAddress>>9);
        if (QSPI_Read(QSPIHandle.Instance, CacheBuffer, CachedAddress, N25Q128A_SUBSECTOR_SIZE)==FALSE) {CachedAddress=~0; goto ProcExit;}
        }
    Rslt++;

    ProcExit:
    N25Q128A_Unlock();
    //Printf(Rslt ? "Ok"CRLF:"Fail"CRLF);
    return Rslt;
    }




int WINAPI N25Q128A_GetCapacity(DWORD *lpBlockQty, UINT *lpBlockSize)
    {
    *lpBlockQty=N25Q128A_FLASH_SIZE/JFAT_SECTOR_SIZE;   //�Ѽ��ͼ�
    *lpBlockSize=JFAT_SECTOR_SIZE;                      //���� ����Ʈ�� (��������)
    return TRUE;
    }




//-----------------------------------------------------------------------------
//      Cache �ڵ� ������
//-----------------------------------------------------------------------------
VOID WINAPI N25Q128A_AutoFlush(BOOL NowFlush)
    {
    BOOL Rslt;
    JOS_CRITICAL_VAR;

    if (NowFlush!=FALSE && CacheDirtyTime!=0) goto FlushStart;

    JOS_ENTER_CRITICAL();
    Rslt=CacheDirtyTime!=0 && GetTickCount()-CacheDirtyTime>=4000;  //���ͷ�Ʈ�� ���� ������ CacheDirtyTime!=0�̿��µ� �ð� ��� �߿� ���ͷ�Ʈ���� ĳ���� �÷��õǰ� CacheDirtyTime==0�̵Ǿ� ����ð��� 4���̻����� �Ǵ� ������ ����
    JOS_EXIT_CRITICAL();
    if (Rslt)
        {
        FlushStart:

        Rslt=FALSE;
        if (N25Q128A_WaitLock(10))
            {
            Rslt=FlushCacheBuffer(QSPIHandle.Instance);
            N25Q128A_Unlock();
            }

        if (Rslt) Printf("N25Q128A Flush Cached"CRLF);
        else{
            JOS_ENTER_CRITICAL();
            if (CacheDirtyTime!=0) CacheDirtyTime=GetTickCount();   //�̷�ƾ�� �ʹ� ���� ȣ��ǹǷ�
            JOS_EXIT_CRITICAL();
            }
        }
    }



//-----------------------------------------------------------------------------
//      N25Q128A Function Test
//-----------------------------------------------------------------------------
int WINAPI N25Q128A_Test(LPCSTR Arg)
    {
    int I,J, Rslt=MONRSLT_SYNTAXERR, Addr;
    static BYTE Buff[JFAT_SECTOR_SIZE];

    if (CompMemStrI(Arg, "WS")==0)
        {
        Arg=SkipSpace(Arg+2);
        Addr=AtoH(Arg, &I); Arg=SkipSpace(Arg+I);
        if (I==0) goto ProcExit;
        for (I=0; I<JFAT_SECTOR_SIZE; I++) Buff[I]=I;
        if (Arg[0]!=0)
            {
            J=AtoH(Arg, NULL);
            for (I=0; I<JFAT_SECTOR_SIZE/2; I++) Buff[I+0x80]=J;
            }
        if (N25Q128A_Write(Buff, Addr, 1)!=0)
            {
            Printf("N25Q128A_Write() Error"CRLF);
            Rslt=MONRSLT_EXIT;
            goto ProcExit;
            }
        Rslt=MONRSLT_OK;
        }
    else if (CompMemStrI(Arg, "RS")==0)
        {
        Arg=SkipSpace(Arg+2);
        Addr=AtoH(Arg, &I); Arg=SkipSpace(Arg+I);
        if (I==0) goto ProcExit;
        J=0x5A;
        if (Arg[0]!=0) J=AtoH(Arg, NULL);
        for (I=0; I<JFAT_SECTOR_SIZE; I++) Buff[I]=J;
        if (N25Q128A_Read(Buff, Addr, 1)!=0)
            {
            Printf("N25Q128A_Read() Error"CRLF);
            Rslt=MONRSLT_EXIT;
            goto ProcExit;
            }
        DumpMem(Buff, JFAT_SECTOR_SIZE);
        Rslt=MONRSLT_OK;
        }
    else if (CompMemStrI(Arg, "W")==0)
        {
        Arg=SkipSpace(Arg+1);
        Addr=AtoH(Arg, &I); Arg=SkipSpace(Arg+I);
        if (I==0) goto ProcExit;
        for (I=0; I<JFAT_SECTOR_SIZE; I++) Buff[I]=I;
        if (Arg[0]!=0)
            {
            J=AtoH(Arg, NULL);
            for (I=0; I<JFAT_SECTOR_SIZE/2; I++) Buff[I+0x80]=J;
            }
        if (QSPI_Write(QSPIHandle.Instance, Buff, Addr, JFAT_SECTOR_SIZE)==FALSE)
            {
            Printf("N25Q128A Write Error"CRLF);
            Rslt=MONRSLT_EXIT;
            goto ProcExit;
            }
        Rslt=MONRSLT_OK;
        }
    else if (CompMemStrI(Arg, "R")==0)
        {
        Arg=SkipSpace(Arg+1);
        Addr=AtoH(Arg, &I); Arg=SkipSpace(Arg+I);
        if (I==0) goto ProcExit;
        J=0x5A;
        if (Arg[0]!=0) J=AtoH(Arg, NULL);
        for (I=0; I<JFAT_SECTOR_SIZE; I++) Buff[I]=J;
        if (QSPI_Read(QSPIHandle.Instance, Buff, Addr, JFAT_SECTOR_SIZE)==FALSE)
            {
            Printf("N25Q128A Read Error"CRLF);
            Rslt=MONRSLT_EXIT;
            goto ProcExit;
            }
        DumpMem(Buff, JFAT_SECTOR_SIZE);
        Rslt=MONRSLT_OK;
        }
    else if (CompMemStrI(Arg, "E")==0)
        {
        Arg=SkipSpace(Arg+1);
        Addr=AtoH(Arg, &I);
        if (I==0) goto ProcExit;
        if (QSPI_EraseBlock(QSPIHandle.Instance, Addr)==FALSE)
            {
            Printf("N25Q128A Erase Error"CRLF);
            Rslt=MONRSLT_EXIT;
            goto ProcExit;
            }
        Rslt=MONRSLT_OK;
        }
    else if (CompMemStrI(Arg, "FLUSH")==0)
        {
        Rslt=MONRSLT_EXIT;
        if (CacheDirtyTime==0)
            {
            Printf("N25Q128A No cache data"CRLF);
            goto ProcExit;
            }
        if (FlushCacheBuffer(QSPIHandle.Instance)==FALSE)
            {
            Printf("N25Q128A Cache Flush Error"CRLF);
            goto ProcExit;
            }
        Rslt=MONRSLT_OK;
        }

    ProcExit:
    return Rslt;
    }



BOOL WINAPI N25Q128A_IsReady(VOID) {return TRUE;}
BOOL WINAPI N25Q128A_IsWriteProtected(VOID) {return FALSE;}





