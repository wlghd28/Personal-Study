﻿//-----------------------------------------------------------------------------
//                      STM32F746 LCD 드라이버
//-----------------------------------------------------------------------------

#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "LCD.H"
#include "JFAT.H"
#include "MAIN.H"
#include "SDRAM.H"
#include "PictureFrame.h"


#define VIEWPIECEEDGE   0


#define BI_RGB          0
#define ShowCursor(fShow)

#define MEMOWNER_LoadImage          (MEMOWNER_LCD+0)
#define MEMOWNER_SaveScreen         (MEMOWNER_LCD+1)
#define MEMOWNER_BootMessageFont    (MEMOWNER_LCD+2)

static BYTE CurrentLayer;
static LTDC_HandleTypeDef  hLtdcHandler;
static DMA2D_HandleTypeDef hDma2dHandler;

VOID WINAPI CopyVMem(volatile WORD* lpD, volatile CONST WORD *lpS, DWORD ToFill);   //어셈에서 16비트 정렬억세스로 처리함




//-----------------------------------------------------------------------------
//      현재 주력으로 표시중인 레이어를 리턴
//-----------------------------------------------------------------------------
#define LAYER_ACTIVE    0
#define LAYER_INACTIVE  1
LOCAL(DEVCOLORREF*) GetLayer(UINT Layer)
    {
    if (Layer==LAYER_ACTIVE)
        return (DEVCOLORREF*)(CurrentLayer==0 ? LCD_FB0_START_ADDRESS:LCD_FB1_START_ADDRESS);
    else
        return (DEVCOLORREF*)(CurrentLayer!=0 ? LCD_FB0_START_ADDRESS:LCD_FB1_START_ADDRESS);
    }



DEVCOLORREF* WINAPI GetVRamPos(int X, int Y)
    {
    return GetLayer(LAYER_ACTIVE) + (Y*LCD_ResolutionX + X);
    }

#if LCD_LogResolutionX==LCD_ResolutionX
#define GETVRAMPOSLOG(X,Y)  GetVRamPos(X, Y)
#define GONEXT_X(X) X++
#define GONEXT_Y(Y) Y+=LCD_ResolutionX
#else //LCD_LogResolutionX==LCD_ResolutionX
#define GETVRAMPOSLOG(X,Y)  GetVRamPos(Y, LCD_ResolutionY-1-(X))
#define GONEXT_X(X) X-=LCD_ResolutionX
#define GONEXT_Y(Y) Y++
#endif //LCD_LogResolutionX==LCD_ResolutionX




LOCAL(VOID) LL_FillBuffer(UINT LayerIndex, UINT Dest, UINT Width, UINT Height, COLORREF Color)
    {
    hDma2dHandler.Init.Mode=DMA2D_R2M;
    hDma2dHandler.Init.ColorMode=DMA2D_OUTPUT_RGB565;  //DMA2D_OUTPUT_ARGB8888
    hDma2dHandler.Init.OutputOffset=LCD_ResolutionX-Width;
    hDma2dHandler.Instance=DMA2D;
    HAL_DMA2D_Init(&hDma2dHandler);
    HAL_DMA2D_ConfigLayer(&hDma2dHandler, LayerIndex);
    HAL_DMA2D_Start(&hDma2dHandler, SwapRedBlue(Color), Dest, Width, Height);
    HAL_DMA2D_PollForTransfer(&hDma2dHandler, 10);
    }




VOID WINAPI LCD_Clear(int Layer, COLORREF Color)
    {
    LL_FillBuffer(Layer, Layer==0 ? LCD_FB0_START_ADDRESS:LCD_FB1_START_ADDRESS, LCD_ResolutionX, LCD_ResolutionY, Color);
    }




VOID WINAPI LCD_FillRect(CONST RECT *R, COLORREF Color)
    {
    int Width;

    Width=R->right - R->left;
    LL_FillBuffer(CurrentLayer, (UINT)GetVRamPos(R->left, R->top), Width, R->bottom-R->top, Color);
    }




VOID WINAPI LCD_InitLayer(UINT Layer, UINT FB_Addr, UINT Alpha)
    {
    LTDC_LayerCfgTypeDef LC;

    ZeroMem(&LC, sizeof(LC));
    LC.WindowX0=0;
    LC.WindowX1=LCD_ResolutionX;
    LC.WindowY0=0;
    LC.WindowY1=LCD_ResolutionY;
    LC.PixelFormat=LTDC_PIXEL_FORMAT_RGB565;    //LTDC_PIXEL_FORMAT_ARGB8888
    LC.FBStartAdress=FB_Addr;
    LC.Alpha=Alpha;
    LC.Alpha0=0;
    LC.Backcolor.Blue=255;
    LC.Backcolor.Green=0;
    LC.Backcolor.Red=0;
    LC.BlendingFactor1=LTDC_BLENDING_FACTOR1_PAxCA;
    LC.BlendingFactor2=LTDC_BLENDING_FACTOR2_PAxCA;
    LC.ImageWidth=LCD_ResolutionX;
    LC.ImageHeight=LCD_ResolutionY;
    HAL_LTDC_ConfigLayer(&hLtdcHandler, &LC, Layer);
    }




///////////////////////////////////////////////////////////////////////////////
//                  포토 프레임
///////////////////////////////////////////////////////////////////////////////


//-----------------------------------------------------------------------------
//      비활성화면에서 활성화면으로 복사함
//-----------------------------------------------------------------------------
VOID WINAPI LCD_CopyFBMem(int X, int Y, int Width, int Height)
    {
    UINT Ofs;
    DEVCOLORREF *FB_Act, *FB_Inact;

    Ofs=Y*LCD_ResolutionX+X;
    FB_Act=GetLayer(LAYER_ACTIVE)+Ofs;
    FB_Inact=GetLayer(LAYER_INACTIVE)+Ofs;
    while (Height--)
        {
        CopyVMem(FB_Act, FB_Inact, Width*sizeof(DEVCOLORREF));
        FB_Act+=LCD_ResolutionX;
        FB_Inact+=LCD_ResolutionX;
        }
    }



//-----------------------------------------------------------------------------
//      FadeOut/FadeIn으로 다른 화면으로 전환함
//-----------------------------------------------------------------------------
LOCAL(VOID) FadeInOut()
    {
    int I;

    for (I=0; I<16; I++)
        {
        if (CurrentLayer==0)
            {
            HAL_LTDC_SetAlpha(&hLtdcHandler, (15-I)<<4, 0);
            HAL_LTDC_SetAlpha(&hLtdcHandler, I<<4, 1);
            }
        else{
            HAL_LTDC_SetAlpha(&hLtdcHandler, (15-I)<<4, 1);
            HAL_LTDC_SetAlpha(&hLtdcHandler, I<<4, 0);
            }
        Sleep(50);
        }
    CurrentLayer^=1;
    }




//-----------------------------------------------------------------------------
//      랜덤으로 레이어를 변경
//-----------------------------------------------------------------------------
#define SPM_ONCE        0
#define SPM_ROR1        1
#define SPM_ROR2        2
#define SPM_RANDOM      3
#define SPM_QTY         4
VOID WINAPI SwitchRandomLayer(VOID)
    {
    switch (MyRand(3234)% SPM_QTY)
        {
        case SPM_ONCE: FadeInOut(); break;
        case SPM_ROR1: RotateRightPut(0, 0); break;
        case SPM_ROR2: RotateRightPut(0, 1); break;
        case SPM_RANDOM: RandomPut(0);  break;
        }
    }




//-----------------------------------------------------------------------------
//      COLORREF->RGB565
//-----------------------------------------------------------------------------
UINT WINAPI ColorToRgb565(COLORREF Col)
    {
    UINT R,G,B;

    R=(Col>>(8-5))&0x1F;
    G=(Col>>(16-6))&0x3F;
    B=(Col>>(24-5))&0x1F;
    return (R<<(6+5))+(G<<5)+B;
    }



//-----------------------------------------------------------------------------
//          8Bit Indexed Color을 RGB565로 변환
//-----------------------------------------------------------------------------
LOCAL(VOID) Conv256Col2RGB565(DEVCOLORREF *lpD, volatile LPCBYTE lpBits, UINT BmpWidth, CONST DWORD *Pal)
    {
    int B,G,R;
    DWORD RgbQ;

    while (BmpWidth--)
        {
        RgbQ=Pal[*lpBits++];
        B=(RgbQ>>3)&0x1F;
        G=(RgbQ>>(2+8))&0x3F;
        R=(RgbQ>>(3+16))&0x1F;
        *lpD++=(R<<(6+5))+(G<<5)+B;
        }
    }



//-----------------------------------------------------------------------------
//          24Bit BitData색을(BGR순) RGBQUAD로 바꿉니다
//-----------------------------------------------------------------------------
LOCAL(VOID) ConvBGR2RGB565(DEVCOLORREF *lpD, volatile LPCBYTE lpBGR, UINT BmpWidth)
    {
    int B,G,R;

    while (BmpWidth--)
        {
        B=(*lpBGR++)>>3;
        G=(*lpBGR++)>>2;
        R=(*lpBGR++)>>3;
        *lpD++=(R<<(6+5))+(G<<5)+B;
        }
    }




//-----------------------------------------------------------------------------
//      TrueColor BMP파일을 RGB565로 프레임 메모리에 표시
//-----------------------------------------------------------------------------
VOID WINAPI LCD_DrawBtm(DEVCOLORREF *Scr, LPCBYTE lpBmp)
    {
    int Y, ColBits, OneLineBytes;
    CONST DWORD *Pal;
    BITMAPFILEHEADER *BFH;
    BITMAPINFOHEADER *BIH;

    BFH=(BITMAPFILEHEADER*)(lpBmp-2);
    BIH=(BITMAPINFOHEADER*)((LPBYTE)BFH+sizeof(BITMAPFILEHEADER));

    if (BIH->biCompression!=BI_RGB) goto ProcExit;
    ColBits=BIH->biPlanes*BIH->biBitCount;
    if (ColBits!=8 && ColBits!=24) goto ProcExit;
    OneLineBytes=GetBmp1LineBytes(BIH->biWidth, ColBits);
    Pal=(CONST DWORD*)((LPCBYTE)BIH+BIH->biSize);

    lpBmp+=Peek(&BFH->bfOffBits)-2 + (BIH->biHeight-1)*OneLineBytes;
    Y=BIH->biHeight;
    while (Y--)
        {
        if (ColBits==8) Conv256Col2RGB565(Scr, lpBmp, BIH->biWidth, Pal);
        else if (ColBits==24) ConvBGR2RGB565(Scr, lpBmp, BIH->biWidth);
        lpBmp-=OneLineBytes;
        Scr+=LCD_ResolutionX;
        }
    ProcExit:;
    }




//-----------------------------------------------------------------------------
//      COLORREF(RGB0순) 메모리를 RGB565로 바꾸어 저장
//      Dest에 volatile 를 안붙이면 GCC에서 -Os 옵션을 주면 화면이 깨짐
//      2021-09-06 DEVCOLORREF 재정의 때 volatile을 넣어버림
//-----------------------------------------------------------------------------
LOCAL(VOID) ConvRGB0to565(DEVCOLORREF *Dest, CONST COLORREF *Src, UINT PixelCnt)
    {
    DWORD Col;

    while (PixelCnt--)
        {
        Col=*Src++;
        *Dest=((Col<<8) & 0xF800) |   //R
              ((Col>>5) & 0x07E0) |   //G
              ((Col>>19) & 0x001F);   //B
        GONEXT_X(Dest);
        }
    }



#if VIEWPIECEEDGE
//-----------------------------------------------------------------------------
//      조각으로 표시할 때 엣지를 표시함
//-----------------------------------------------------------------------------
VOID ViewPieceEdge(COLORREF *StartPos, int Width, int Height, int WAWidth)
    {
    int I;
    COLORREF *lpD=StartPos;

    lpD=StartPos;
    for (I=0; I<Width; I++) *lpD++=0;

    lpD=StartPos+WAWidth;
    for (I=0; I<Height-2; I++)
        {
        lpD[0]=lpD[Width-1]=0;
        lpD+=WAWidth;
        }

    if (Height>1)
        for (I=0; I<Width; I++) *lpD++=0;
    }
#endif



//-----------------------------------------------------------------------------
//      그려야할 모든 영역을 JobScreenMem을 DevScreenMem으로 변환하여 LCD 메모리에에 전송
//      PA도 Screen좌표임
//-----------------------------------------------------------------------------
VOID WINAPI LCD_OutputScreen(CONST COLORREF *hDCMem, CONST LPRECT WA, CONST LPRECT PA)
    {
    int  Width, Height, WAWidth;
    RECT PR;
    CONST COLORREF *lpS;
    DEVCOLORREF *lpD;

    SetRect(&PR, 0,0, LCD_LogResolutionX, LCD_LogResolutionY);
    if (MyIntersectRect(&PR, PA)==FALSE) goto ProcExit;

    WAWidth=WA->right-WA->left;
    lpS=((PR.top-WA->top)*WAWidth+(PR.left-WA->left))+hDCMem;

    lpD=GETVRAMPOSLOG(PR.left, PR.top);
    Width=PR.right-PR.left;
    Height=PR.bottom-PR.top;
    #if VIEWPIECEEDGE
    ViewPieceEdge((COLORREF*)lpS, Width, Height, WAWidth);
    #endif
    while (Height--)
        {
        ConvRGB0to565(lpD, lpS, Width);
        lpS+=WAWidth;
        GONEXT_Y(lpD);
        }
    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      VDP Ram에 주어진 패턴으로 VRAM 색을 반전 시킴 (캐럿표시에 사용)
//-----------------------------------------------------------------------------
VOID WINAPI LCD_XorBits2(int DestX, int DestY, int Width, int Height, int WidthBytes, LPCBYTE lpBits)
    {
    int X, Byt;
    LPCBYTE lpS;
    DEVCOLORREF *lpD, *lpLCD;

    if (Width>0 && Height>0)
        {
        lpLCD=GETVRAMPOSLOG(DestX, DestY);
        while (Height--)
            {
            lpS=lpBits;
            lpD=lpLCD;
            for (X=Byt=0; X<Width; X++,Byt<<=1)
                {
                if ((X&7)==0) Byt=*lpS++;
                if (Byt & 0x80) lpD[0]^=0xFFFF;
                GONEXT_X(lpD);
                }

            lpBits+=WidthBytes;
            GONEXT_Y(lpLCD);
            }
        }
    }




//-----------------------------------------------------------------------------
//      저장된 VM의 이미지를 화면에 표시합니다
//-----------------------------------------------------------------------------
BOOL WINAPI LCD_LoadScreen(LPVOID SavedVMPtr, int X, int Y, COLORREF TrnsParCol, BOOL VMFreeFg)
    {
    int   Width, Height, Rslt=FALSE, OneLine;
    RECT  R;
    LPCBYTE lpS;
    DEVCOLORREF *lpD;

    if (SavedVMPtr==NULL) return FALSE;
    ShowCursor(FALSE);

    #if LCD_LogResolutionX==LCD_ResolutionX
    R=*(RECT*)SavedVMPtr;
    #else
    SetRect(&R, ((RECT*)SavedVMPtr)->top, LCD_ResolutionY-((RECT*)SavedVMPtr)->right, ((RECT*)SavedVMPtr)->bottom, LCD_ResolutionY-((RECT*)SavedVMPtr)->left);
    #endif
    Width=R.right - R.left;
    Height=R.bottom - R.top;
    OffsetRect(&R, X, Y);

    OneLine=Width*sizeof(DEVCOLORREF);
    lpS=(LPBYTE)SavedVMPtr+sizeof(RECT);
    lpD=GetVRamPos(R.left, R.top);
    while (Height--)
        {
        //if (TrnsParCol==COL_NOTRANSPARENT) ConvBGR0to565(lpD, lpS, Width);
        //else                               TransParCopyVMem(lpD, lpS, Width, TrnsParCol);
        CopyVMem(lpD, (CONST DEVCOLORREF*)lpS, OneLine);
        lpS+=OneLine;
        lpD+=LCD_ResolutionX;
        }

    Rslt++;

    if (VMFreeFg!=FALSE && SavedVMPtr!=NULL) FreeMem(SavedVMPtr);
    ShowCursor(TRUE);
    return Rslt;
    }


BOOL WINAPI LCD_RestoreScreen(LPVOID SavedVMPtr)
    {
    return LCD_LoadScreen(SavedVMPtr, 0, 0, COL_NOTRANSPARENT, TRUE);
    }



//-----------------------------------------------------------------------------
//      주어진 영역의 화면을 VRAM에 Push합니다 (한글 오토마타에서 입력중 한글 표시에 사용)
//
//      (1) 화면 위치정보 저장 (RECT)
//      (2) 이미지 영역저장
//      (3) (1)번 저장 당시의 포인터 저장
//       VSP<-(3)저장이후 번지
//-----------------------------------------------------------------------------
LPVOID WINAPI LCD_SaveScreen(CONST LPRECT AR)
    {
    int   Width, Height;
    RECT  R;
    DWORD OneLine;
    LPVOID AllocVMPtr=NULL;
    LPBYTE lpD;
    CONST DEVCOLORREF *lpS;

    ShowCursor(FALSE);

    #if LCD_LogResolutionX==LCD_ResolutionX
    R=*AR;
    #else
    SetRect(&R, AR->top, LCD_ResolutionY-AR->right, AR->bottom, LCD_ResolutionY-AR->left);
    #endif

    Width=R.right - R.left;
    Height=R.bottom - R.top;

    if (Width<=0 || Height<=0) goto ProcExit;
    if ((AllocVMPtr=AllocVMem(Width*Height*sizeof(DEVCOLORREF) + sizeof(RECT), MEMOWNER_SaveScreen))==NULL) goto ProcExit;
    *(RECT*)AllocVMPtr=*AR;

    OneLine=Width*sizeof(DEVCOLORREF);
    lpS=GetVRamPos(R.left, R.top);
    lpD=(LPBYTE)AllocVMPtr+sizeof(RECT);
    for (; R.top<R.bottom; R.top++)
        {
        CopyVMem((DEVCOLORREF*)lpD, lpS, OneLine);
        lpS+=LCD_ResolutionX;
        lpD+=OneLine;
        }

    ProcExit:
    ShowCursor(TRUE);
    return AllocVMPtr;
    }



//-----------------------------------------------------------------------------
//      글자의 폭을 구함
//-----------------------------------------------------------------------------
int WINAPI LCD_GetCharWidth(HFONT hFont, UINT WCh, int *lpChOrder)
    {
    int    ChOrder, Width=0;
    LPCBYTE lp, lpWidths;

    lpWidths=(LPCBYTE)hFont+sizeof(FONTFILEHEADER);
    if (WCh<=0x7F || (hFont->Kind & FK_INCCODELIST)==0)
        ChOrder=WCh - hFont->FirstCode;
    else{
        lp=lpWidths;
        if (hFont->Kind & FK_INCWIDTHS) lp+=(hFont->CharQty+3) & ~3;
        ChOrder=BinSearchWord((LPCWSTR)lp, hFont->CharQty, WCh);                //없으면 -1나옴
        }

    if (ChOrder>=0 && ChOrder<hFont->CharQty)
        {
        Width=hFont->Width;
        if (hFont->Kind & FK_INCWIDTHS)
            {
            Width=lpWidths[ChOrder];
            if ((hFont->Kind & FK_KINDMASK)==FK_UNICODE16GRAY) Width--;
            }
        }

    *lpChOrder=ChOrder;
    return Width;
    }




#ifdef ARABIC_EN
#define ARABIC_LAM  0x0644


//-----------------------------------------------------------------------------
//      아랍어 모음인지 알려줌
//-----------------------------------------------------------------------------
BOOL WINAPI IsArabicVowel(int Cha)
    {
    return Cha>=0x64B && Cha<=0x65F;
    }



//-----------------------------------------------------------------------------
//      아랍 문자인지 알려줌
//-----------------------------------------------------------------------------
BOOL WINAPI IsArabicCha(int Cha)
    {
    return (Cha>=0x600 && Cha<=0x65F) || (Cha>=0x66A && Cha<=0x6FF);
    }



BOOL WINAPI IsSpaceCha(int Cha)
    {
    return Cha==9 || Cha==' ';
    }



//-----------------------------------------------------------------------------
//      현재 위치에 표시하기 합당한 문자 코드를 리턴
//-----------------------------------------------------------------------------
int WINAPI GetArabicDisplayChar(int InCha, LPCSTR *lpNextStr, int *lpStrLen, int *lpChaPos)
    {
    int Cha, ChaPos=CP_REAR, PreChaPos, Len, StrLen;
    LPCSTR  NextStr;
    LPCWSTR lpW;
    static CONST WCHAR ArabicPositionTbl[]= //위치에 따라 모양이 바뀌는 글자
        {//단독,어말형,어두형,어중형,
        0x0627,0xFE8E,0x0627,0xFE8E,    //ا 알리프(ㅇ)
        0x0622,0xFE82,0x0622,0xFE82,    //آ 알리프(ㅇ)+물결
        0x0623,0xFE84,0x0623,0xFE84,    //أ 알리프(ㅇ)+위함자
        0x0625,0xFE88,0x0625,0xFE88,    //إ 알리프(ㅇ)+아래함자
        0x0671,0xFB51,0x0671,0xFB51,    //ٱ 알리프 + 와우첨자
        0x0628,0xFE90,0xFE91,0xFE92,    //ب 바(b)
        0x062A,0xFE96,0xFE97,0xFE98,    //ت 타(t)
        0x062B,0xFE9A,0xFE9B,0xFE9C,    //ث 싸(θ)
        0x062C,0xFE9E,0xFE9F,0xFEA0,    //ج 짐(dʒ)
        0x062D,0xFEA2,0xFEA3,0xFEA4,    //ح 하(무성음'ㅎ')
        0x062E,0xFEA6,0xFEA7,0xFEA8,    //خ 카(목긁는소리)
        0x062F,0xFEAA,0x062F,0xFEAA,    //د 달(d)
        0x0630,0xFEAC,0x0630,0xFEAC,    //ذ 델(ð)
        0x0631,0xFEAE,0x0631,0xFEAE,    //ر 라(r)
        0x0632,0xFEB0,0x0632,0xFEB0,    //ز 자이(z)
        0x0633,0xFEB2,0xFEB3,0xFEB4,    //س 씬(ㅆ)
        0x0634,0xFEB6,0xFEB7,0xFEB8,    //ش 쉰(ʃ)
        //0x069B,   ?,     ?,     ?,    //ڛ 점을아래에찍은쉰(ʃ) ... 오토만 제국의 터키어에서 사용
        0x0635,0xFEBA,0xFEBB,0xFEBC,    //ص 쏴드(ㅆ)
        0x0636,0xFEBE,0xFEBF,0xFEC0,    //ض 돠드(ㄷ)
        0x0637,0xFEC2,0xFEC3,0xFEC4,    //ط 똬(ㄸ)
        0x0638,0xFEC6,0xFEC7,0xFEC8,    //ظ 좌
        0x0639,0xFECA,0xFECB,0xFECC,    //ع 아인(ai) ... 목쪼으는 소리
        0x063A,0xFECE,0xFECF,0xFED0,    //غ 가인(gai)
        0x0641,0xFED2,0xFED3,0xFED4,    //ف 퐈(f)
        //0x06A1,   ?,     ?,     ?,    //ڡ 점을아래에찍은 퐈(f) ... 마그레브 지역
        0x0642,0xFED6,0xFED7,0xFED8,    //ق 까프(ㄲ)
        //0x066F,   ?,     ?,     ?,    //ٯ 점없는 까프(ㄲ) ... 마그레브 지역
        0x0643,0xFEDA,0xFEDB,0xFEDC,    //ك 카프(ㅋ)
        0x06A9,0xFB8F,0xFEDB,0xFEDC,    //ک 변형 카프(ㅋ) ... 마그레브 지역 (페르시아, 걸프지역에서 사용)
        0x0644,0xFEDE,0xFEDF,0xFEE0,    //ل 람(l)
        0x0645,0xFEE2,0xFEE3,0xFEE4,    //م 밈(m)
        0x0646,0xFEE6,0xFEE7,0xFEE8,    //ن 눈(n)
        0x0647,0xFEEA,0xFEEB,0xFEEC,    //ه 하(ㅎ)
        0x0648,0xFEEE,0x0648,0xFEEE,    //و 와우(w)
        0x0624,0xFE86,0x0624,0xFE86,    //ؤ 와우(w)+함자
        0x064A,0xFEF2,0xFEF3,0xFEF4,    //ي 야(y)
        0x06CC,0xFEF0,0xFEF3,0xFEF4,    //ی 점없는 야(y) ... 마그레브 지역, 이집트 수단
        0x0629,0xFE94,0x0629,0x0629,    //ة 타마르부타 (여성단어맨뒤에만 사용)
        0x0649,0xFEF0,0xFBE8,0xFBE9,    //ى 알리프막수라
        0x0626,0xFE8A,0xFB8B,0xFB8C,    //ئ 알리프막수라+함자
        0xFEFB,0xFEFC,0xFEFB,0xFEFC,    //ﻻ 람+알리프
        0xFEF5,0xFEF6,0xFEF5,0xFEF6,    //ﻵ 람+알리프+물결
        0xFEF7,0xFEF8,0xFEF7,0xFEF8,    //ﻷ 람+알리프+위함자
        0xFEF9,0xFEFA,0xFEF9,0xFEFA,    //ﻹ 람+알리프+아래함자
        0 //단독,어말형,어두형,어중형
        };

    if (IsArabicCha(InCha)==FALSE) goto Ret;
    PreChaPos=*lpChaPos;
    NextStr=*lpNextStr;
    StrLen=*lpStrLen;

    if (InCha==ARABIC_LAM)              //'람'인 경우 뒤에 알리프가 오면 합쳐진 글자로 표기
        {
        Cha=0;
        while (StrLen>0)
            {
            if ((Cha=GetCharU8(NextStr, &Len))==0) break;
            if (Len>StrLen) break;
            NextStr+=Len;
            StrLen-=Len;
            if (IsArabicVowel(Cha)==FALSE) break;
            }
        switch (Cha)
            {
            case 0x0627: InCha=0xFEFB; goto SetPos;     //람+알리프
            case 0x0622: InCha=0xFEF5; goto SetPos;     //람+알리프+물결
            case 0x0623: InCha=0xFEF7; goto SetPos;     //람+알리프+위함자
            case 0x0625: InCha=0xFEF9; //goto SetPos;   //람+알리프+아래함자
                SetPos:
                *lpNextStr=NextStr;
                *lpStrLen=StrLen;
                break;

            default:
                NextStr=*lpNextStr;
                StrLen=*lpStrLen;
                //break;
            }
        }

    Cha=0;
    while (StrLen>0)
        {
        if ((Cha=GetCharU8(NextStr, &Len))==0) break;
        if (Len>StrLen) break;
        NextStr+=Len;
        StrLen-=Len;
        if (IsArabicVowel(Cha)==FALSE)
            {
            if (IsArabicCha(Cha)) ChaPos=CP_MIDDLE;
            break;
            }
        }

    if (PreChaPos==CP_FRONT)
        {
        if (ChaPos==CP_MIDDLE) ChaPos=CP_FRONT;
        else if (ChaPos==CP_REAR) ChaPos=CP_SINGLE;
        }

    for (lpW=ArabicPositionTbl; ;lpW+=4)
        {
        if ((Cha=*lpW)==0) {ChaPos=CP_FRONT; break;}    //모양이 변하지 않는 글자를 쓴 후에 다음 글자는 어두형으로 표시
        if (Cha==InCha)
            {
            InCha=lpW[ChaPos];
            if (ChaPos==CP_REAR || ChaPos==CP_SINGLE || lpW[CP_MIDDLE]==lpW[CP_REAR]) ChaPos=CP_FRONT;
            else ChaPos=CP_MIDDLE;
            break;
            }
        }

    *lpChaPos=ChaPos;

    Ret:
    return InCha;
    }
#endif //ARABIC_EN



//-----------------------------------------------------------------------------
//      UTF8문자열의 폭과 높이를 구함
//-----------------------------------------------------------------------------
VOID WINAPI LCD_GetTextExtent(LPCSTR Str, int StrLen, SIZE *S, HFONT hFont)
    {
    int WCh, Len, Width=0;
    #ifdef ARABIC_EN
    int ChaPos=CP_FRONT;
    #endif

    while (StrLen>0)
        {
        if ((WCh=GetCharU8(Str, &Len))==0) break;
        if (Len>StrLen) break;
        Str+=Len;
        StrLen-=Len;

        #ifdef ARABIC_EN
        if (IsArabicVowel(WCh)) continue;       //모음은 위치 계산이 힘들어서 표시못함
        WCh=GetArabicDisplayChar(WCh, &Str, &StrLen, &ChaPos);
        #endif
        Width+=LCD_GetCharWidth(hFont, WCh, &Len);
        }
    S->cx=Width;
    S->cy=hFont->Height;
    }



//-----------------------------------------------------------------------------
//      한 문자를 표시함 (LCD 프레임 버퍼에 직접 표시함)
//-----------------------------------------------------------------------------
LOCAL(int) DrawChar(int DestX, int DestY, UINT WCh, COLORREF TextColor, COLORREF BkColor, HFONT hFont)
    {
    int  X, Alpha, Byt, ChOrder, Width, Height, BytesPerLine, FontType, TxColR,TxColG,TxColB, OrgWidth;
    DEVCOLORREF *lpLcd, *lpD;
    LPCBYTE lpS, lpBits;

    if ((OrgWidth=Width=LCD_GetCharWidth(hFont, WCh, &ChOrder))==0) goto ProcExit;

    FontType=hFont->Kind & FK_KINDMASK;
    if ((BytesPerLine=hFont->BytesPerLine)==0)  //버전3글꼴
        {
        FONTBITSHEADER *FBH;

        lpBits=*((DWORD*)(hFont->BitsDataLoc+(LPCBYTE)hFont)+ChOrder) + (LPCBYTE)hFont;
        FBH=(FONTBITSHEADER*)lpBits;
        lpBits+=FBH->HeadSize;
        BytesPerLine=FBH->BytesPerLine;
        DestY+=FBH->OffsetY;
        Height=FBH->LineQty;
        }
    else{
        Height=hFont->Height;
        lpBits=BytesPerLine*Height*ChOrder + hFont->BitsDataLoc + (LPCBYTE)hFont;
        }

    if (FontType==FK_UNICODE16GRAY)
        {
        TxColR=(TextColor>>3) & 0x1F;
        TxColG=(TextColor>>(8+2))& 0x3F;
        TxColB=TextColor>>(16+3);
        Width++;                    //안티 알리아싱 된 마지막 픽셀까지 표시하기 위함
        }

    Width=GetMin(Width, LCD_ResolutionX-DestX);
    Height=GetMin(Height, LCD_ResolutionY-DestY);
    if (Width<=0 || Height<=0) goto ProcExit;

    TextColor=ColorToRgb565(TextColor);
    if (BkColor+1!=0) BkColor=ColorToRgb565(BkColor);

    lpLcd=GetLayer(LAYER_ACTIVE)+(DestY*LCD_ResolutionX+DestX);

    while (Height--)
        {
        lpS=lpBits;
        lpD=lpLcd;
        if (FontType==FK_UNICODE16GRAY)
            {
            for (X=Byt=0; X<Width; X++)
                {
                if ((X&1)==0) {Byt=*lpS++; Alpha=Byt>>4;} else Alpha=Byt&0x0F;
                //Printf("%d",Alpha>9 ? 9:Alpha);
                if (Alpha)
                    {
                    int BkAlpha, BkColR, BkColG, BkColB;

                    BkAlpha=*lpD;
                    BkColR=BkAlpha>>11;
                    BkColG=(BkAlpha>>5) & 0x3F;
                    BkColB=BkAlpha & 0x1F;

                    BkAlpha=15-Alpha;
                    BkColR=(BkColR*BkAlpha + TxColR*Alpha)/15;
                    BkColG=(BkColG*BkAlpha + TxColG*Alpha)/15;
                    BkColB=(BkColB*BkAlpha + TxColB*Alpha)/15;
                    *lpD=(BkColR<<11)+(BkColG<<5)+BkColB;
                    }
                else if (BkColor+1!=0) *lpD=BkColor;
                lpD++;
                }
            }
        else{
            for (X=Byt=0; X<Width; X++)
                {
                if ((X&7)==0) Byt=*lpS++;
                if (Byt & 0x80) *lpD=TextColor;
                else if (BkColor+1!=0) *lpD=BkColor;
                lpD++; Byt<<=1;
                }
            }
        lpBits+=BytesPerLine;
        lpLcd+=LCD_ResolutionX;
        //Printf(CRLF);
        }
    ProcExit:
    return OrgWidth;
    }



//-----------------------------------------------------------------------------
//      UTF8문자열을 표시
//-----------------------------------------------------------------------------
VOID WINAPI LCD_TextOut(int X, int Y, LPCSTR Str, int StrLen, COLORREF TextColor, COLORREF BkColor, HFONT hFont)
    {
    int WCh, Len;
    #ifdef ARABIC_EN
    int    TX, ChaPos=CP_FRONT, IsFirst=1;
    SIZE   S;
    LPCSTR Start;

    LCD_GetTextExtent(Str, StrLen, &S, hFont);
    X+=S.cx+1;          //안티 알리아싱 된 추가 픽셀까지 넣기 위함
    #endif

    while (StrLen>0)
        {
        WCh=GetCharU8(Str, &Len);
        if (Len>StrLen) break;
        Str+=Len;
        StrLen-=Len;

        #ifdef ARABIC_EN
        if (IsSpaceCha(WCh) || IsArabicCha(WCh))
            {
            if (IsArabicVowel(WCh))
                {
                if (IsFirst) continue;              //처음부터 모음이 나오면 무시
                if (WCh!=0x651) continue;           //모음 위치를 조정하기가 어려워 샷다만 표시함
                }
            else{
                IsFirst=0;
                WCh=GetArabicDisplayChar(WCh, &Str, &StrLen, &ChaPos);
                X-=LCD_GetCharWidth(hFont, WCh, &TX);   //TX은 더미
                }
            DrawChar(X, Y, WCh, TextColor, BkColor, hFont);
            }
        else{
            Str-=Len; Start=Str;
            StrLen+=Len;

            while (StrLen>0)
                {
                WCh=GetCharU8(Str, &Len);
                if (Len>StrLen) break;
                if (IsArabicCha(WCh)) break;
                Str+=Len;
                StrLen-=Len;
                }

            while (IsSpaceCha(Str[-1])) {Str--; StrLen++;}  //아랍문자 앞에 있는 공백은 아랍문자 표시로 처리

            LCD_GetTextExtent(Start, Str-Start, &S, hFont);
            X-=S.cx; TX=X;
            while (Start<Str)
                {
                WCh=GetCharU8(Start, &Len);
                Start+=Len;
                TX+=DrawChar(TX, Y, WCh, TextColor, BkColor, hFont);
                }
            }
        #else
        X+=DrawChar(X, Y, WCh, TextColor, BkColor, hFont);
        #endif //ARABIC_FUCTION
        }
    }



//-----------------------------------------------------------------------------
//      화면 캡춰 (16Bit BMP형식으로 저장)
//-----------------------------------------------------------------------------
BOOL WINAPI LCD_CaptureScreen(LPCSTR BmpFileName)
    {
    int    WrtBytes, ImgSize, Rslt=FALSE;
    HFILE  hFile=HFILE_ERROR;
    BITMAPFILEHEADER *BFH;
    BITMAPINFOHEADER BIH;
    CHAR   Buff[16];

    if ((hFile=_lcreat(BmpFileName, 0))==HFILE_ERROR) {Printf("'%s' create error" CRLF, BmpFileName); goto ProcExit;}

    BFH=(BITMAPFILEHEADER*)&BIH;
    ZeroMem(BFH, sizeof(BITMAPFILEHEADER));
    BFH->bfType=0x4D42;     //'BM'
    Poke(&BFH->bfSize,    sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+4*3+LCD_ResolutionX*LCD_ResolutionY*2);
    Poke(&BFH->bfOffBits, sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+4*3);
    _lwrite(hFile, BFH, sizeof(BITMAPFILEHEADER));

    ZeroMem(&BIH, sizeof(BITMAPINFOHEADER));
    BIH.biSize=sizeof(BITMAPINFOHEADER);
    BIH.biWidth=LCD_ResolutionX;
    BIH.biHeight=-LCD_ResolutionY;
    BIH.biPlanes=1;
    BIH.biBitCount=16;
    BIH.biCompression=BI_BITFIELDS;
    _lwrite(hFile, &BIH, sizeof(BITMAPINFOHEADER));

    *(DWORD*)(Buff+0)=0xF800;
    *(DWORD*)(Buff+4)=0x07E0;
    *(DWORD*)(Buff+8)=0x001F;
    _lwrite(hFile, Buff, 4*3);

    ImgSize=LCD_ResolutionX*LCD_ResolutionY*2;
    if ((WrtBytes=_lwrite(hFile, (LPCVOID)GetVRamPos(0,0), ImgSize))==HFILE_ERROR)
        {
        Printf("'%s' write error"CRLF, BmpFileName);
        goto ProcExit;
        }
    if (WrtBytes!=ImgSize)
        {
        Printf("Disk Full"CRLF);
        goto ProcExit;
        }
    Rslt++;

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    return Rslt;
    }



#if 0
LOCAL(VOID) DispWaitMessage(LPCSTR MsgStr)
    {
    int   FileSize;
    SIZE  S;
    HFONT hFont;

    if ((hFont=(HFONT)LoadFile(BOOTMESSAGEFONT, MEMOWNER_BootMessageFont, &FileSize))!=NULL)
        {
        LCD_GetTextExtent(MsgStr, lstrlen(MsgStr), &S, hFont);
        LCD_TextOut((LCD_ResolutionX-S.cx)>>1, (LCD_ResolutionY-S.cy)>>1, MsgStr, lstrlen(MsgStr), COL_WHITE, COL_TRANSPARENT, hFont);
        FreeMem((LPVOID)hFont);
        }
    }
#endif



//-----------------------------------------------------------------------------
//      VRAM에 이미지를 읽어 넣음
//-----------------------------------------------------------------------------
BOOL WINAPI DispImage(LPCSTR BmpFile)
    {
    int   FileSize, Rslt=FALSE;
    HFILE hFile;
    LPBYTE lpVMem;
    BYTE Buff[4];

    if ((hFile=_lopen(BmpFile, OF_READ))!=HFILE_ERROR)
        {
        if ((FileSize=GetFileSize(hFile))>0)
            {
            if ((lpVMem=(LPBYTE)AllocVMem(FileSize, MEMOWNER_LoadImage))!=NULL)
                {
                _lread(hFile, Buff, 2);
                if (*(WORD*)Buff==0x4D42)
                    {
                    _lread(hFile, lpVMem, FileSize-2);
                    LCD_DrawBtm(GetVRamPos((LCD_ResolutionX-260)/2, (LCD_ResolutionY-34)/2), lpVMem);
                    }
                FreeMem(lpVMem);
                }
            }
        _lclose(hFile);
        Rslt++;
        }
    return Rslt;
    }




VOID WINAPI LCD_Init(VOID)
    {
    RCC_PeriphCLKInitTypeDef PCI;

    __HAL_RCC_LTDC_CLK_ENABLE();

    //도트클럭 주파수 계산 = (800+20+46+210)*(480+10+23+22)*60(Frame/Sec) = 34,539,600 Hz
    //BSP_LCD_ClockConfig(&hLtdcHandler, NULL);
    //HSE_VALUE(25000000)/PLL_M(25)*138(PLLSAIN)/PLLSAIR(2)/RCC_PLLSAIDIVR_2 = 34.5M
    ZeroMem(&PCI, sizeof(PCI));
    PCI.PeriphClockSelection=RCC_PERIPHCLK_LTDC;
    PCI.PLLSAI.PLLSAIN=LTDCCLK_PLLSAIN;     //50~432
    PCI.PLLSAI.PLLSAIR=LTDCCLK_PLLSAIR;     //2~7
    PCI.PLLSAIDivR=LTDCCLK_PLLSAIDivR;      //2,4,8,16
    HAL_RCCEx_PeriphCLKConfig(&PCI);

    hLtdcHandler.LayerCfg->ImageWidth=LCD_ResolutionX;
    hLtdcHandler.LayerCfg->ImageHeight=LCD_ResolutionY;
    hLtdcHandler.Init.HorizontalSync=LCD_HSYNC-1;           //0~0xFFF
    hLtdcHandler.Init.VerticalSync  =LCD_VSYNC-1;           //0~0x7FF
    hLtdcHandler.Init.AccumulatedHBP=LCD_HSYNC+LCD_HBP-1;   //~0xFFF
    hLtdcHandler.Init.AccumulatedVBP=LCD_VSYNC+LCD_VBP-1;   //~0x7FF
    hLtdcHandler.Init.AccumulatedActiveH=LCD_ResolutionY+LCD_VSYNC+LCD_VBP-1;   //Total Height ~0x7FF
    hLtdcHandler.Init.AccumulatedActiveW=LCD_ResolutionX+LCD_HSYNC+LCD_HBP-1;   //Total Width ~0xFFF
    hLtdcHandler.Init.TotalHeigh=LCD_ResolutionY+LCD_VSYNC+LCD_VBP+LCD_VFP-1;   //~0x7FF
    hLtdcHandler.Init.TotalWidth=LCD_ResolutionX+LCD_HSYNC+LCD_HBP+LCD_HFP-1;   //~0xFFF
    hLtdcHandler.Init.Backcolor.Blue=0;
    hLtdcHandler.Init.Backcolor.Green=0;
    hLtdcHandler.Init.Backcolor.Red=0;
    hLtdcHandler.Init.HSPolarity=LTDC_HSPOLARITY_AL;    //AL:엑티브로우, AH:엑티브하이
    hLtdcHandler.Init.VSPolarity=LTDC_VSPOLARITY_AL;
    hLtdcHandler.Init.DEPolarity=LTDC_DEPOLARITY_AL;
    hLtdcHandler.Init.PCPolarity=LTDC_PCPOLARITY_IPC;   //픽셀클럭, IIPC:픽셀클럭 반전
    hLtdcHandler.Instance=LTDC;
    HAL_LTDC_Init(&hLtdcHandler);

    SDRAM_Init();
    if (VMemAllocInit(LCD_VRAM_START, LCD_VRAM_ALLOC_SIZE)==FALSE)
        Printf("VMemAllocInit() Error"CRLF);

    LCD_InitLayer(0, LCD_FB0_START_ADDRESS, 255); LCD_Clear(0, COL_BLUE);

    //DispWaitMessage("Wait a moment...");
    //DispWaitMessage(BOOTMESSAGE);
    DispImage("BootLogo.bmp");

    PortOut(PO_LCD_DISP,    HIGH);
    PortOut(PO_LCD_BL_CTRL, HIGH);

    LCD_InitLayer(1, LCD_FB1_START_ADDRESS, 0); LCD_Clear(1, COL_GREEN);
    }




