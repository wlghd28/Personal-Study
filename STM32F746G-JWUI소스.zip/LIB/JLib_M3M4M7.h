#ifndef __JLIB_H__
#define __JLIB_H__

#include "string.h"
#include "stdarg.h"
#if defined(__GNUC__)
#include "stdint.h"
#endif

extern char JLibVersion[];
extern const char NullStr[];
extern const char Psnt1s[];
extern const char Psnt1d[];
extern const char Psnt1u[];
extern const char Psnt2d[];
extern const char ConfigStr[];
extern const char CrLfStr[];
extern const char IniFileName[];
#define CRLF    "\r\n"

#if defined(__GNUC__)
#define CopyMem         MyCopyMem       //VRAM(C0000000)������ ���ĵ� �＼���� �ؾ߸� �ϱ� ����
#else
#define CopyMem         memcpy
#endif

#define CompMem         memcmp
#define CompareMem      memcmp          //������ 0
#define MoveMem         memmove
#define lstrlen         strlen
#define lstrcpy         strcpy
#define lstrcat         strcat
#define lstrcmp         strcmp
#define lstrcmpi        strcasecmp
//#define Jsscanf         sscanf
#define wsprintf        Jsprintf
#define FillMem(Dest, FillBytes, FillByte)   memset(Dest, FillByte, FillBytes)
#define ZeroMem(Dest, FillBytes)             memset(Dest, 0, FillBytes)


#define CHAR            char
#define VOID            void
#define CONST           const
typedef long            LONG;
typedef long            LONG_PTR;
typedef unsigned long   DWORD;
typedef unsigned short  WORD;
typedef unsigned char   BYTE;
typedef signed char     INT8;
#if defined(__GNUC__)
#define UINT            uint32_t
#elif defined(__CC_ARM) //KEIL
typedef unsigned int    UINT;
typedef unsigned int    UINT32;
#endif
typedef char *          LPSTR;
typedef const char *    LPCSTR;
typedef VOID *          LPVOID;
typedef VOID *          HANDLE;
typedef const VOID *    LPCVOID;
typedef BYTE *          LPBYTE;
typedef const BYTE *    LPCBYTE;
typedef const short *   LPCINT16;
typedef int             BOOL;
typedef int             INT32;
typedef WORD *          LPWORD;
typedef const WORD *    LPCWORD;
typedef long long       INT64;
typedef unsigned long long UINT64;
typedef WORD            WCHAR;
typedef WORD *          LPWSTR;
typedef CONST WORD *    LPCWSTR;
typedef unsigned long   COLORREF;
typedef UINT            ATOM;
typedef HANDLE          HGLOBAL;

#define PTR2INT         int
#define PTR2UINT        UINT

#define WINAPI
#define WINAPIV
#define CALLBACK

#define IN
#define OUT
#define INOUT
#define MAX_PATH        160     //4�� ���������� �� ��

#define LOCAL(type) static type WINAPI
#define DIV_ROUNDUP(A,B)    ((A+((B)>>1))/(B))
#define countof(StrucName)  (sizeof(StrucName)/sizeof(StrucName[0]))
#define GetMemberOffset(Struc, Member) (int)(&((Struc*)0)->Member)
#define ALIGN4          __attribute__((aligned))
#define ALIGN_END       __attribute__((aligned(4)))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT     __attribute__((packed))
#define PACK_STRUCT_END


#define DLGFNC(DlgFnc)   static BOOL WINAPI DlgFnc(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)
#define DLGFNCnl(DlgFnc) static BOOL WINAPI DlgFnc(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM)
#define WNDFNC(WndFnc)   static LRESULT WINAPI WndFnc(HWND hWnd, UINT Msg, WPARAM wPrm, LPARAM lPrm)

//WM_COMMAND
#define WMCMDID         LoWord(wPrm)
#define WMCMDNOTIFY     HiWord(wPrm)
#define WMCMDHWND       (HWND)lPrm

//WM_VSCROLL, WM_HSCROLL
#define WMSCROLLCODE    LoInt(wPrm)
#define WMSCROLLPOS     HiInt(wPrm)
#define WMSCROLLHWND    (HWND)lPrm

//WM_MENUSELECT
#define WMMENUSELITEM   LoWord(wPrm)
#define WMMENUSELFLAG   HiWord(wPrm)
#define WMMENUSELHMNU   (HMENU)lPrm

//WM_ACTIVATE
#define WMACTIVATEFG    LoWord(wPrm)
#define WMACTIVATEMINFG HiWord(wPrm)
#define WMACTIVATEHWND  (HWND)lPrm


#define FALSE           0
#define TRUE            1
#define HFILE_ERROR     (-1)
#define INVALID_HANDLE_VALUE    (HANDLE)-1
#define FILENAMEBUFFMAX         80              //�ִ����ϸ�����+1
//#define NULL          0       //(VOID*)0
typedef signed short            INT16;
typedef unsigned short          UINT16;
typedef volatile unsigned long  VDWORD;
typedef volatile unsigned short VWORD;
typedef volatile unsigned char  VBYTE;
typedef volatile unsigned int   VUINT;
#if defined(__GNUC__)
typedef void *                  LPPKVOID;
typedef const void *            LPCPKVOID;
#elif defined(__CC_ARM) //KEIL
typedef __packed void *         LPPKVOID;
typedef __packed const void *   LPCPKVOID;
#endif

#define HFILE           int

typedef DWORD           JTIME;  //����Ͻú��ʸ� ��� �ʴ��������� (2000.1.1����)
typedef INT64           JTIME64;//����Ͻú��ʸ� ��� ms���������� (0000.1.1����)
typedef DWORD           UTIME;  //����Ͻú��ʸ� ��� �ʴ��������� (1970.1.1����)
typedef INT32           TDATE;  //������� ���ϼ���


typedef struct _POINT
    {
    int x, y;
    } POINT;

typedef struct _POINTS
    {
    INT16 x, y;
    } POINTS;

typedef struct _SIZE
    {
    int cx;
    int cy;
    } SIZE;

typedef struct _RECT
    {
    int left, top, right, bottom;
    } RECT, *LPRECT;

typedef struct _SYSTEMTIME
    {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
    } SYSTEMTIME;


//ASCII�ڵ�
#define BEEP            0x07
#define BKSPC           0x08
#define TAB             0x09
#define LF              0x0A
//#define CR            0x0D    //GUI���� ClientRect�� ���� CR�� ����� ���� ����, ��) RECT CR;
#define ESC             0x1B
#define SPACE           ' '

#define CTRL_A          0x01
#define CTRL_B          0x02
#define CTRL_C          0x03
#define CTRL_D          0x04
#define CTRL_E          0x05
#define CTRL_F          0x06
#define CTRL_G          BEEP
#define CTRL_H          BKSPC
#define CTRL_I          TAB
#define CTRL_J          LF
#define CTRL_K          0x0B
#define CTRL_L          0x0C
#define CTRL_M          CR
#define CTRL_N          0x0E
#define CTRL_O          0x0F

#define CTRL_P          0x10
#define CTRL_Q          0x11
#define CTRL_R          0x12
#define CTRL_S          0x13
#define CTRL_T          0x14
#define CTRL_U          0x15
#define CTRL_V          0x16
#define CTRL_W          0x17
#define CTRL_X          0x18
#define CTRL_Y          0x19
#define CTRL_Z          0x1A


#define AllocMemS(struc, Owner) (struc*)AllocMem(sizeof(struc), Owner)

#define ALLOCMEM1(lp1,lp1Size, Owner, ErrJump)                     \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size, Owner))==NULL) goto ErrJump

#define ALLOCMEM2(lp1,lp1Size, lp2,lp2Size, Owner, ErrJump)                \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size, Owner))==NULL) goto ErrJump; \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size

#define ALLOCMEM3(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, Owner, ErrJump)           \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size, Owner))==NULL) goto ErrJump; \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size

#define ALLOCMEM4(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, Owner, ErrJump)      \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size, Owner))==NULL) goto ErrJump; \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size

#define ALLOCMEM5(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size, Owner))==NULL) goto ErrJump; \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size

#define ALLOCMEM6(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, lp6,lp6Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size+lp6Size, Owner))==NULL) goto ErrJump;      \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size;   \
    *(LPSTR*)&lp6=(LPSTR)lp5+lp5Size

#define ALLOCMEM7(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, lp6,lp6Size, lp7,lp7Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size+lp6Size+lp7Size, Owner))==NULL) goto ErrJump;      \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size;   \
    *(LPSTR*)&lp6=(LPSTR)lp5+lp5Size;   \
    *(LPSTR*)&lp7=(LPSTR)lp6+lp6Size

#define ALLOCMEM8(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, lp6,lp6Size, lp7,lp7Size, lp8,lp8Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size+lp6Size+lp7Size+lp8Size, Owner))==NULL) goto ErrJump;      \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size;   \
    *(LPSTR*)&lp6=(LPSTR)lp5+lp5Size;   \
    *(LPSTR*)&lp7=(LPSTR)lp6+lp6Size;   \
    *(LPSTR*)&lp8=(LPSTR)lp7+lp7Size

#define ALLOCMEM9(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, lp6,lp6Size, lp7,lp7Size, lp8,lp8Size, lp9,lp9Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size+lp6Size+lp7Size+lp8Size+lp9Size, Owner))==NULL) goto ErrJump;      \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size;   \
    *(LPSTR*)&lp6=(LPSTR)lp5+lp5Size;   \
    *(LPSTR*)&lp7=(LPSTR)lp6+lp6Size;   \
    *(LPSTR*)&lp8=(LPSTR)lp7+lp7Size;   \
    *(LPSTR*)&lp9=(LPSTR)lp8+lp8Size

#define ALLOCMEM10(lp1,lp1Size, lp2,lp2Size, lp3,lp3Size, lp4,lp4Size, lp5,lp5Size, lp6,lp6Size, lp7,lp7Size, lp8,lp8Size, lp9,lp9Size, lp10,lp10Size, Owner, ErrJump) \
    if ((*(LPSTR*)&lp1=(LPSTR)AllocMem(lp1Size+lp2Size+lp3Size+lp4Size+lp5Size+lp6Size+lp7Size+lp8Size+lp9Size+lp10Size, Owner))==NULL) goto ErrJump;      \
    *(LPSTR*)&lp2=(LPSTR)lp1+lp1Size;   \
    *(LPSTR*)&lp3=(LPSTR)lp2+lp2Size;   \
    *(LPSTR*)&lp4=(LPSTR)lp3+lp3Size;   \
    *(LPSTR*)&lp5=(LPSTR)lp4+lp4Size;   \
    *(LPSTR*)&lp6=(LPSTR)lp5+lp5Size;   \
    *(LPSTR*)&lp7=(LPSTR)lp6+lp6Size;   \
    *(LPSTR*)&lp8=(LPSTR)lp7+lp7Size;   \
    *(LPSTR*)&lp9=(LPSTR)lp8+lp8Size;   \
    *(LPSTR*)&lp10=(LPSTR)lp9+lp9Size


#define SETBITBYTEARRAY(ByteArray, BitNo)   ByteArray[BitNo>>3]|=1<<(BitNo&7)
#define CLRBITBYTEARRAY(ByteArray, BitNo)   ByteArray[BitNo>>3]&=~(1<<(BitNo&7))
#define CHKBITBYTEARRAY(ByteArray, BitNo)   (ByteArray[BitNo>>3]&(1<<(BitNo&7)))

#define PTOWORD(A)      *(WORD*)(A)
#define PTOINT(A)       *(int*)(A)
#define PTOLONG(A)      *(long*)(A)
#define PTODWORD(A)     *(DWORD*)(A)
#define PTOUINT64(A)    *(UINT64*)(A)

#define TOINT(A)        *(int*)&(A)
#define TOWORD(A)       *(WORD*)&(A)
#define TODWORD(A)      *(DWORD*)&(A)
#define TOUINT64(A)     *(UINT64*)&(A)


#define LongByte0(L)    (L&0xFF)
#define LongByte1(L)    ((L>>8)&0xFF)
#define LongByte2(L)    ((L>>16)&0xFF)
#define LongByte3(L)    (L>>24)

#define LoByte(W)       (W&0xFF)
#define HiByte(W)       (W>>8)

#define LoWord(DW)      (DW&0xFFFF)
#define HiWord(DW)      (DW>>16)

#define LoInt16(L)      ((INT16)L)
#define HiInt16(L)      ((int)L>>16)

#define MAKELONG(L,H)   (((H)<<16)|(L))
#define RGB(r,g,b)      ((r) | ((g)<<8) | ((b)<<16))
#define MKTAG(a,b,c,d)  ((a) | ((b)<<8) | ((c)<<16) | ((d)<<24))

#define LoByteW(W)      *(BYTE*)&W
#define HiByteW(W)      *((BYTE*)&W+1)
#define LoWordW(DW)     *(WORD*)&DW
#define HiWordW(DW)     *((WORD*)&DW+1)
#define LoDWordW(V64)   *(DWORD*)&V64
#define HiDWordW(V64)   *((DWORD*)&V64+1)

#define LongByte0W(DW)  *(BYTE*)&DW
#define LongByte1W(DW)  *((BYTE*)&DW+1)
#define LongByte2W(DW)  *((BYTE*)&DW+2)
#define LongByte3W(DW)  *((BYTE*)&DW+3)


#define MAKEIP(IP1, IP2, IP3, IP4) (((DWORD)(IP1)<<24) | ((DWORD)(IP2)<<16) | ((DWORD)(IP3)<<8) | (IP4))
#define BROADCASTIP     MAKEIP(255,255,255,255)



#define MA_OK                   0
#define MA_BROKENMCB            7
#define MA_INSUFFICIENT         8
#define MA_INVALIDPTR           9


#ifdef __cplusplus
LPVOID WINAPI AllocMem(DWORD ReqSize, UINT OwnerID=0);
UINT WINAPI GetMemFree(UINT *lpLargestBlkSize=NULL, int *lpRslt=NULL, int *BlkQty=NULL);
#else
LPVOID WINAPI AllocMem(DWORD ReqSize, UINT OwnerID);
LPVOID WINAPI AllocVMem(DWORD ReqSize, UINT OwnerID);
UINT WINAPI GetMemFree(UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty);
UINT WINAPI GetVMemFree(UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty);
#endif
LPVOID WINAPI ReAllocMem(LPVOID *lpMem, UINT NowSize, UINT NewSize, UINT OwnerID);
BOOL WINAPI MemAllocInit(UINT MemStart, UINT BlkSize);
BOOL WINAPI VMemAllocInit(UINT MemStart, UINT BlkSize);
int  WINAPI FreeMem(LPVOID lpMem);
LPVOID WINAPI ShrinkMem(LPVOID lpMem, int ReqSize);
VOID WINAPI DispMemBlock(BOOL DispBlkFg);
VOID WINAPI DispVMemBlock(BOOL DispBlkFg);

LPSTR WINAPI CopyStr(LPCSTR OrgStr, int Owner);


#ifdef __cplusplus
extern "C"
{
#endif
UINT WINAPI UMulDiv(UINT Multiplicand, UINT Multiplier, UINT Divisor);
UINT WINAPI UDivMod(UINT Dividend, UINT Divisor, UINT *lpRemain);       //Asm�� �ִ� �Լ�
VOID WINAPI FillDWord(LPVOID lpD, UINT Qty, DWORD ToFill);
BOOL WINAPI IsNumeric(int Cha);
BOOL WINAPI IsAscii(int Cha);

#define GETMIN(A, B) ((A)<(B) ? A:B)
#define GETMAX(A, B) ((A)>(B) ? A:B)
int  WINAPI GetMin(int A, int B);
int  WINAPI GetMax(int A, int B);
int  WINAPI GetAbs(int A);
int  WINAPI GetDiff(int A, int B);
UINT WINAPI UGetDiff(UINT A, UINT B);
UINT WINAPI UGetMin(UINT A, UINT B);
UINT WINAPI UGetMax(UINT A, UINT B);
VOID WINAPI ChoiceMin(int *lpA, int B);
VOID WINAPI ChoiceMax(int *lpA, int B);
int  WINAPI Limit(int Value, int Min, int Max);
int  WINAPI UpCaseCha(int Cha);
VOID WINAPI CharUpper(LPSTR Str);
int  WINAPI CharLowerBuff(LPSTR Str, int Len);
LPCSTR WINAPI SkipSpace(LPCSTR Str);
VOID WINAPI DumpMem(LPCVOID lpMem, UINT ViewSize);
BYTE WINAPI GetXorChkSum(VOID *lpMem, UINT Size);
//int  WINAPI lstrlen(LPCSTR Str);
LPSTR WINAPI GetStrLast(LPSTR Str);
LPCSTR WINAPI GetToken(LPCSTR TokenList, int TokenNo);
LPCSTR WINAPI GetNextStr(LPCSTR Str);
VOID WINAPI AddCha(LPSTR Dest, int Cha);
LPSTR WINAPI lstrcpy(LPSTR Dest, LPCSTR Src);
LPSTR WINAPI lstrcpyn(LPSTR Dest, LPCSTR Src, UINT BuffSize);
int  WINAPI lstrcmpi(LPCSTR S1, LPCSTR S2);
//int  WINAPI CompMem(LPCVOID Mem1, LPCVOID Mem2, UINT CompBytes);
int  WINAPI CompMemI(LPCVOID Mem1, LPCVOID Mem2, UINT CompBytes);
int  WINAPI AtoIN(LPCSTR NumStr, int StrLen);
int  WINAPI AtoN(LPCSTR Str, int *NonStrLoc);
DWORD WINAPI AtoH(LPCSTR String, int *NonStrLoc);
DWORD WINAPI AtoHN(LPCSTR Str, int Len);
int  WINAPI CompMemStr(LPCSTR Src, LPCSTR Find);
int  WINAPI CompMemStrI(LPCSTR Src, LPCSTR Find);
BOOL WINAPI IsZeroMem(LPCVOID Mem, int ByteSize);
#define CleanupStr  StrTrim
VOID WINAPI StrTrim(LPSTR String);
int  WINAPI SearchCha(LPCSTR SourceStr, int SrchCha);
int  WINAPI SearchMemByte(LPCVOID Mem, int MemSize, int FindByte);
LPCSTR WINAPI NextWord(LPCSTR lp, int WordCnt);
LPCSTR WINAPI NextCommaWord(LPCSTR lp, int WordNo);
VOID WINAPI DelAllCha(LPSTR String, int DelCha);
VOID WINAPI DelCha(LPSTR String, int DelLoc);
int  WINAPI GetLastChar(LPCSTR Str);
VOID WINAPI StripQuoteSign(LPSTR Buff);

#define CopyMemory  CopyMem
#define ZeroMemory  ZeroMem
#define FillMemory  FillMem
LPVOID WINAPI MyCopyMem(LPVOID Dest, LPCVOID Src, UINT CopyBytes);
//LPVOID WINAPI CopyMemory(LPVOID Dest, LPCVOID Src, UINT CopyBytes);
//LPVOID WINAPI ZeroMemory(LPVOID Dest, UINT FillBytes);
//LPVOID WINAPI FillMemory(LPVOID Dest, UINT FillBytes, BYTE FillByte);

int  WINAPI VsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormStr, va_list VL);
int  Jsprintf(LPSTR DestBuff, LPCSTR FormStr, ...);
int  JsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormatStr, ...);
BOOL Jsscanf(LPCSTR SourceStr, LPCSTR FormatStr, ...);
VOID SysCtlDelay(DWORD Cnt);
int  WINAPI GetJ8ChkSum(LPCBYTE lpMem, UINT Size);

#ifdef __cplusplus
}
#endif



#ifdef __cplusplus              //c������ ���Ұ�
int   WINAPI AtoI(LPCSTR NumStr, int *NextLoc=NULL);
INT64 WINAPI AtoI64(LPCSTR Str, int *NonStrLoc=NULL);
#else
int   WINAPI AtoI(LPCSTR NumStr, int *NextLoc);
INT64 WINAPI AtoI64(LPCSTR Str, int *NonStrLoc);
#endif  //__cplusplus


//STM32Cube_FW_F0_V1.4.0\Drivers\CMSIS\Include\core_cmFunc.h <- __disable_irq()
#ifdef USE_JOS
#include "JOS_CFG.H"
#else
#define JOS_CRITICAL_VAR
#if defined(__CC_ARM) //KEIL
    #define JOS_ENTER_CRITICAL      __disable_irq
    #define JOS_EXIT_CRITICAL       __enable_irq
#elif defined(__GNUC__)
    #define JOS_ENTER_CRITICAL()    __asm volatile ("cpsid i" : : : "memory")
    #define JOS_EXIT_CRITICAL()     __asm volatile ("cpsie i" : : : "memory")
#endif
#endif //USE_JOS

UINT  WINAPI SetIntMask(UINT IntMask);          //���� ���ͷ�Ʈ ����ũ ���� ����

int   WINAPI SearchStr(LPCSTR SourceStr, LPCSTR SrchStr);
LPSTR WINAPI SeparatStr(LPSTR String, int SepCha);
LPSTR WINAPI SeparatStrStr(LPSTR Str, LPCSTR SepStr);
LPCSTR WINAPI CatchToken(LPCSTR Str, int SepCha, LPSTR Buff, int BuffLen);
VOID  WINAPI SubStr(LPSTR Buff, int BuffSize, LPCSTR Src, int ReqLen);
BOOL  WINAPI GetUrlVarText(LPCSTR WebArgList, LPCSTR VarName, LPSTR DataBuff, int BuffSize);
int   WINAPI GetUrlVarInt(LPCSTR WebArgList, LPCSTR VarName);

DWORD WINAPI Hex2Int(LPCSTR StrBuff, int ChaQty);
int  WINAPI DecodeBase64(LPCSTR InBuff, LPSTR OutBuff, int Inlen);
VOID WINAPI EncodeBase64(LPCSTR InBuff, int InDataLen, LPSTR OutBuff, int LineLen, BOOL CnvToWebChaFg);
VOID WINAPI Scrambling(LPVOID lpMem, UINT MemSize, LPCSTR EncrypKey);

int   WINAPI Check2byteCha(LPCSTR Str, int ChkLoc);
int   WINAPI GetChQtyU8(LPCSTR Utf8);
BOOL  WINAPI DelChaU8(LPSTR Utf8, int DelPos);
LPCSTR WINAPI GetChPtrU8(LPCSTR Utf8, int ChaPos);
LPCSTR WINAPI CharNextU8(LPCSTR Utf8);
int   WINAPI GetCharU8(LPCSTR Str, int *lpLen);
LPSTR WINAPI CharNext(LPCSTR Str);
int   WINAPI SetUtf8FromU16(LPSTR Buff, UINT U16);

int   WINAPI GetMonthLastDay(int Year, int Month);
TDATE WINAPI GetTotalDays(int Year, int Month, int Day);
int   WINAPI GetWeek(int Year, int Month, int Day);
VOID  WINAPI CnvFromTotalDay(TDATE TotalDays, int *Year, int *Month, int *Day);
VOID  WINAPI SystemTimeToLocalTime(SYSTEMTIME *ST);
LPSTR WINAPI MakeYMDHMS(LPSTR Buff, CONST SYSTEMTIME *ST);
BOOL  WINAPI GetAppCompileDate(SYSTEMTIME *ST);
BOOL  WINAPI GetAppCompileDateStr(LPSTR Buff);
JTIME WINAPI GetAppCompileDateTime(VOID);
LPSTR WINAPI MakeHttpTimeStr(LPSTR TimeStr, CONST SYSTEMTIME *ST);
BOOL  WINAPI AnalysisHttpTimeStr(LPCSTR TimeStr, SYSTEMTIME *ST);
int   WINAPI ChangeCha(LPSTR String, int from, int to);
LPSTR WINAPI Make10msTimeStr(LPSTR Buff, DWORD _10msTime, BOOL DetailFg);
LPCSTR WINAPI NextLine(LPCSTR SrcStr, int *LineLen);
LPCSTR WINAPI QueryStrOneLine(LPCSTR Str, int *lpLen);
BOOL  WINAPI IsExistLineII(LPCSTR Str, LPCSTR FindLine, LPSTR Buff, int BuffSize);


LPCSTR WINAPI CatchStrOneLine(LPCSTR SrcStr, LPSTR DestBuff, int BuffLen);
int  WINAPI GetIniStrInMem(LPCSTR SecName, LPCSTR VarName, LPSTR Buff, int BuffSize, LPCSTR IniMem);
int  WINAPI GetIniIntInMem(LPCSTR SecName, LPCSTR VarName, int DefValue, LPCSTR IniMem);
VOID WINAPI PutString(LPSTR *lplpStr, LPCSTR PutStr);
VOID WINAPI lstrcatn(LPSTR DestBuff, LPCSTR SrcBuff, int BuffSize);


int  WINAPI GetIniStr(LPCSTR szSection, LPCSTR szEntry, LPSTR szBuff, int BuffSize);
int  WINAPI GetIniStrEx(LPCSTR szSection, LPCSTR szEntry, LPSTR szBuff, int BuffSize, LPCSTR DefStr);
VOID WINAPI WriteIniStrN(LPCSTR Section, int EntryNo, LPCSTR Buff);
int  WINAPI GetIniInt(LPCSTR szSection, LPCSTR szEntry, int DefValue);
int  WINAPI GetIniStrN(LPCSTR Section, int EntryNo, LPSTR Buff, int BuffSize);
VOID WINAPI WriteIniStr(LPCSTR szSection, LPCSTR szEntry, LPCSTR szBuff);
VOID WINAPI WriteIniInt(LPCSTR szSection, LPCSTR szEntry, int Value);


INT32 WINAPI PackSecondExceptDate(CONST SYSTEMTIME *ST);
VOID  WINAPI UnpackSecondExceptDate(SYSTEMTIME *ST, INT32 Secs);
VOID  WINAPI UnpackMilliSecondExceptDate(SYSTEMTIME *ST, INT32 ms);
DWORD WINAPI SystemTimeToUnixTime(CONST SYSTEMTIME *ST);
JTIME WINAPI PackTotalSecond(CONST SYSTEMTIME *ST);
JTIME64 WINAPI JTimeToJTime64(JTIME JTime);
JTIME64 WINAPI PackTotalSecond64(CONST SYSTEMTIME *ST);
VOID  WINAPI UnpackTotalSecond(SYSTEMTIME *ST, JTIME JTime);
VOID  WINAPI UnpackTotalSecond64(SYSTEMTIME *ST, JTIME64 JTime);

VOID  WINAPI PokeW(LPPKVOID Ptr, UINT W);
VOID  WINAPI Poke(LPPKVOID Ptr, DWORD Dw);
VOID  WINAPI PokeBIW(LPPKVOID Ptr, UINT W);
VOID  WINAPI PokeBI(LPPKVOID Ptr, DWORD Dw);
DWORD WINAPI Peek(LPCPKVOID Ptr);
UINT  WINAPI PeekW(LPCPKVOID Ptr);
DWORD WINAPI PeekBI(LPCPKVOID Ptr);
UINT  WINAPI PeekBIW(LPCPKVOID Ptr);
DWORD WINAPI PeekCDAB(LPCPKVOID Ptr);

DWORD WINAPI ForcePeekLE(LPCPKVOID Ptr);
DWORD WINAPI ForcePeekBE(LPCPKVOID Ptr);
DWORD WINAPI ForcePeekRGB(LPCPKVOID Ptr);
DWORD WINAPI ForcePeekARGB(LPCPKVOID Ptr);


#define SWAPENDIANW(W)      (((W&0xFF)<<8) | (W>>8))
#define SWAPENDIANDW(Dw)    ((Dw<<24) | ((Dw>>8)&0xFF00) | ((Dw&0xFF00)<<8) | (Dw>>24))


VOID   WINAPI MakeHexStr(LPSTR Buff, LPCBYTE lpMem, int MemSize);
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen);
LPCSTR WINAPI ScanInt(LPCSTR Str, int *lpValue);
int    WINAPI GetBitCnt(UINT Value);
DWORD  WINAPI CalculateCRC(LPCBYTE Buff, DWORD BuffSize, DWORD PreCRC);
UINT   WINAPI CalculateCrc16(LPCVOID Buff, UINT BuffSize, UINT Crc);

VOID WINAPI EncryptDecrypt(LPBYTE Buff, int BuffSize, DWORD Crc, int Mode);
//Mode����
#define ED_ENCRYPT  0
#define ED_DECRYPT  1

int    WINAPI FloatToInt(UINT Float, UINT Digit, UINT Max);
VOID   WINAPI InsCha(LPSTR SrcStr, int InsLoc, int Cha);
VOID   WINAPI InsStr(LPSTR SrcStr, int InsLoc, LPCSTR ToInsStr);
VOID   WINAPI AdjustDialStr(LPSTR DialStr, int BuffLen);
int    WINAPI BinSearchWord(CONST WORD *ArrayBase, UINT Elements, UINT SearchWord);
VOID   WINAPI StripQuoteSign(LPSTR Buff);
LPCSTR WINAPI GetMsgStr(LPCSTR MsgName);
int    WINAPI SearchBackCha(LPCSTR Str, int Cha);
LPSTR  WINAPI GetFileNameLocU8(LPSTR FPath);
LPSTR  WINAPI GetFileExtNameLoc(LPSTR FPath);


typedef struct _ElasticBuffer   *HELB;
HELB   WINAPI ELB_New(int BlockSize);                   //�ʱ�ȭ, BlockSize�� �Ҵ� ����
VOID   WINAPI ELB_Clear(HELB EB);                       //�Ҵ���� ���۴� �״�� �ΰ� �����͸� ����
VOID   WINAPI ELB_Delete(HELB EB);                      //HELB�� ������
LPSTR  WINAPI ELB_ReleaseHusk(HELB EB);                 //����⸸ Free�ϰ� ���� ������ ����, ��� �� FreeMem()�ؾ���
LPSTR  WINAPI ELB_Prepare(HELB EB, int ReqSize);        //�䱸�� ��ŭ �߰��ϰ� �߰��� ���� ������ ����
LPCSTR WINAPI ELB_GetBuffer(HELB EB);                   //���� ���������� ����
int    WINAPI ELB_GetLength(HELB EB);                   //���� ������ ũ�� ����
int    WINAPI ELB_UpdateSize(HELB EB, int Size);        //���̳ʸ� �ٷ� �� ũ�⸦ �߰���
LPSTR  WINAPI ELB_PutBin(HELB EB, LPCVOID Data, int Len); //���̳ʸ� ������ �߰�
LPSTR  WINAPI ELB_PutByte(HELB EB, int Byt);
LPSTR  WINAPI ELB_PutWord(HELB EB, int W);
LPSTR  WINAPI ELB_PutDword(HELB EB, int Dw);
LPSTR  WINAPI ELB_PutQword(HELB EB, INT64 Qw);
LPSTR  WINAPI ELB_PutString(HELB EB, LPCSTR Str);
VOID   WINAPI ELB_TrimEnd(HELB EB);
LPSTR  WINAPI ELB_PutLenStr(HELB EB, LPCSTR Str);
LPSTR  WINAPIV ELB_Printf(HELB EB, LPCSTR FormStr, ...);        //���Ĺ��ڿ��� ���߾� ���ۿ� ������
int    WINAPI ELB_GetData(HELB EB, LPVOID Buff, int ReqSize);   //�������� �Ϻ� �Ǵ� ���θ� ������, uff�� NULL�� �ָ� �����͸� ������

COLORREF WINAPI GetTempColor(int Temp, int Width);

int WINAPI MulDiv(int Multiplicand, int Multiplier, int Divisor);    //Startup_STM32F746xx.s
UINT64 WINAPI UDiv64_32(UINT64 A, UINT B, UINT *lpRemain);
int WINAPI SearchByte(LPCVOID lpMem, int MemSize, UINT SrchByte);
int WINAPI GetBmp1LineBytes(int Width, int ColBits);
DWORD WINAPI SwapEndianDW(DWORD DwValue);
UINT  WINAPI SwapEndianW(UINT wValue);


VOID WINAPI PrintRect(LPCSTR Title, CONST RECT *R);
VOID WINAPI SetRectEmpty(RECT *R);
BOOL WINAPI IsRectEmpty(CONST RECT *R);
BOOL WINAPI EqualRect(CONST RECT *R1, CONST RECT *R2);
VOID WINAPI SetRect(RECT *R, int Left, int Top, int Right, int Bottom);
VOID WINAPI OffsetRect(RECT *R, int X, int Y);
VOID WINAPI InflateRect(RECT *R, int X, int Y);
BOOL WINAPI IntersectRect(RECT *DR, CONST RECT *R1, CONST RECT *R2);
BOOL WINAPI MyIntersectRect(RECT *R1, CONST RECT *R2);
BOOL WINAPI IsIntersectRect(CONST RECT *R1, CONST RECT *R2);
BOOL WINAPI IsIncludeRect(CONST RECT *R1, CONST RECT *R2);
BOOL WINAPI PtInRect(CONST RECT *R, POINT P);
BOOL WINAPI UnionRect(RECT *DR, CONST RECT *R1, CONST RECT *R2);
VOID WINAPI MyUnionRect(INOUT RECT *R1, CONST RECT *R2);
BOOL WINAPI SubtractRect(RECT *DR, CONST RECT *R1, CONST RECT *R2);
BOOL WINAPI SubRect(RECT *R1, CONST RECT *R2);

typedef struct _RECTLIST
    {
    int AllocQty;
    int CurrQty;
    RECT *RectList;
    } RECTLIST;

BOOL WINAPI AddRectList(RECTLIST *RL, CONST RECT *R);
BOOL WINAPI AddRectListFront(RECTLIST *RL, CONST RECT *R);
VOID WINAPI SubRectEx(RECTLIST *RL, CONST RECT *ToSub);


typedef struct _RGBQUAD
    {
    BYTE    rgbBlue;
    BYTE    rgbGreen;
    BYTE    rgbRed;
    BYTE    rgbReserved;
    } RGBQUAD;


//#pragma pack(push,2)
typedef struct _BITMAPFILEHEADER
    {
    WORD    bfType;
    DWORD   bfSize;
    WORD    bfReserved1;
    WORD    bfReserved2;
    DWORD   bfOffBits;
    }__attribute__((packed)) BITMAPFILEHEADER;   //GCC���
//#pragma pack(pop)


typedef struct _BITMAPINFOHEADER
    {
    DWORD   biSize;
    INT32   biWidth;
    INT32   biHeight;
    WORD    biPlanes;
    WORD    biBitCount;
    DWORD   biCompression;
    DWORD   biSizeImage;
    INT32   biXPelsPerMeter;
    INT32   biYPelsPerMeter;
    DWORD   biClrUsed;
    DWORD   biClrImportant;
    } BITMAPINFOHEADER;

//biCompression field
#define BI_RGB          0
#define BI_BITFIELDS    3


typedef struct _StringList
    {
    struct _StringList *Next;
    struct _StringList *Down;
    CHAR String[1];     //NullChar
    } StringList;

StringList* WINAPI AddStringList(StringList **Root, LPCSTR ToAddStr);
BOOL WINAPI DelStringList(StringList **Root, StringList *DelStr);
VOID WINAPI DelAllStringList(StringList **Root);
StringList* WINAPI GetStringList(StringList *Root, int No);

COLORREF WINAPI SwapRedBlue(COLORREF Col);
VOID WINAPI Utf16ToUtf8(LPCWSTR Utf16, LPSTR Utf8);
VOID WINAPI MakeSizeStrEx(LPSTR Buff, UINT64 TotalBytes);
INT32 WINAPI Frac28_Mul(INT32 A, INT32 B);
VOID WINAPI SetLittleEndian24Bit(LPBYTE Buff, DWORD LEData);
DWORD WINAPI MyRand(DWORD InitData);
int WINAPI Bin2Bcd(int Value);
int WINAPI Bcd2Bin(int Value);
BOOL WINAPI ChkWildcardFileName(LPCSTR FileName, LPCSTR WildCard);
VOID WINAPI PokeNibble(LPBYTE Buff, int Index, int Value);
int  WINAPI PeekNibble(LPCBYTE Buff, int Index);


typedef struct _STRINGPOOL STRINGPOOL, *LPSTRINGPOOL;
typedef WORD STRPOOL;
UINT WINAPI StrPool_Add(LPSTRINGPOOL *lpSP, LPCSTR String);
LPCSTR WINAPI StrPool_Get(LPSTRINGPOOL SP, UINT StrOfs);
#define StrPool_Free    FreeMem



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� �����մϴ�
//
//      Key     : ���Ľ�����, �ϳ� ������ �������� �̵� FKey: Key�� �ճ��
//      Search  : Key �������� �������� ����  FSearch   : Search�� �ճ��
//      Smallest: ���� ���� ���                FSmallest : Smallest�� �ճ��
//-----------------------------------------------------------------------------
#define SINGLELISTSORT(Type, List, CompareFnc)                                  \
    {                                                                           \
    Type *Key, *FKey, *Smallest, *FSmallest, *Search, *FSearch;                 \
                                                                                \
    Key=List;                                                                   \
    while (Key!=NULL)                                                           \
        {                                                                       \
        /*(1)���� ���� ���� ã��*/                                              \
        Smallest=FSearch=Key; Search=Key->Next;                                 \
        while (Search!=NULL)                                                    \
            {                                                                   \
            if (CompareFnc(Search, Smallest)<0) {FSmallest=FSearch; Smallest=Search;} \
            FSearch=Search; Search=Search->Next;                                \
            }                                                                   \
                                                                                \
        /*(2)ã�� ���� ���� ���� �Ǿտ� ���� ã��*/                             \
        if (Key==Smallest) {FKey=Key; Key=Key->Next;}   /*�̹� ���ĵ� ��� �������� �̵�*/ \
        else{                                                                              \
            FSmallest->Next=Smallest->Next;             /*������������ ���*/            \
            Smallest->Next=Key;                         /*������������ Ű�� �տ� ����*/    \
            if (Key==List) List=Smallest; else FKey->Next=Smallest;             \
            FKey=Smallest;                                                      \
            }                                                                   \
        }                                                                       \
    }



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� �����մϴ� (Next����� ���Ƿ� ��)
//
//      Key     : ���Ľ�����, �ϳ� ������ �������� �̵� FKey: Key�� �ճ��
//      Search  : Key �������� �������� ����  FSearch   : Search�� �ճ��
//      Smallest: ���� ���� ���                FSmallest : Smallest�� �ճ��
//-----------------------------------------------------------------------------
#define SINGLELISTSORTII(Type, List, Next, CompareFnc)                          \
    {                                                                           \
    Type *Key, *FKey, *Smallest, *FSmallest, *Search, *FSearch;                 \
                                                                                \
    Key=List;                                                                   \
    while (Key!=NULL)                                                           \
        {                                                                       \
        /*(1)���� ���� ���� ã��*/                                              \
        Smallest=FSearch=Key; Search=Key->Next;                                 \
        while (Search!=NULL)                                                    \
            {                                                                   \
            if (CompareFnc(Search, Smallest)<0) {FSmallest=FSearch; Smallest=Search;} \
            FSearch=Search; Search=Search->Next;                                \
            }                                                                   \
                                                                                \
        /*(2)ã�� ���� ���� ���� �Ǿտ� ���� ã��*/                             \
        if (Key==Smallest) {FKey=Key; Key=Key->Next;}   /*�̹� ���ĵ� ��� �������� �̵�*/ \
        else{                                                                              \
            FSmallest->Next=Smallest->Next;             /*������������ ���*/            \
            Smallest->Next=Key;                         /*������������ Ű�� �տ� ����*/    \
            if (Key==List) List=Smallest; else FKey->Next=Smallest;             \
            FKey=Smallest;                                                      \
            }                                                                   \
        }                                                                       \
    }



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� �Ǿտ� �߰��մϴ�
//-----------------------------------------------------------------------------
#define ADDSINGLELINKEDLISTFIRST(Root, New)             \
    {                                                   \
    New->Next=Root;                                     \
    Root=New;                                           \
    }




//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� �߰��մϴ� (�ǵڿ�)
//-----------------------------------------------------------------------------
#define ADDSINGLELINKEDLIST(Struct, Root, New)          \
    {                                                   \
    Struct *Tmp;                                        \
    if ((Tmp=Root)==NULL) Root=New;                     \
    else{                                               \
        while (Tmp->Next!=NULL) Tmp=Tmp->Next;          \
        Tmp->Next=New;                                  \
        }                                               \
    }



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� �ϳ��� �����մϴ�
//-----------------------------------------------------------------------------
#define DELSINGLELINKEDLIST(Struct, Root, Del)          \
    {                                                   \
    Struct *p, *Par=NULL;                               \
    for (p=Root; p!=NULL; p=p->Next)                    \
        {                                               \
        if (p==Del)                                     \
            {                                           \
            p=p->Next;                                  \
            if (Par==NULL) Root=p; else Par->Next=p;    \
            FreeMem(Del);                               \
            break;                                      \
            }                                           \
        Par=p;                                          \
        }                                               \
    }



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ�� ��� �����մϴ�
//-----------------------------------------------------------------------------
#define RELEASESINGLELINKEDLIST(Struct, Root)           \
    while (Root!=NULL)                                  \
        {                                               \
        Struct *Tmp;                                    \
        Tmp=Root; Root=Root->Next;                      \
        FreeMem(Tmp);                                   \
        }



//-----------------------------------------------------------------------------
//      �̱� ����Ʈ���� �ϳ��� ��ũ�� ����ϴ�
//      Del�� ������ġ�� �����Ѿ� �մϴ�
//-----------------------------------------------------------------------------
#define DELSINGLELINK(Struct, Root, Par, Del)           \
    {                                                   \
    Struct *Tmp;                                        \
    Tmp=Del;                                            \
    Del=Del->Next;                                      \
    if (Par==NULL) Root=Del; else Par->Next=Del;        \
    FreeMem(Tmp);                                       \
    }



//-----------------------------------------------------------------------------
//      �̱۸���Ʈ���� �־�������� Prev��带 �ݴϴ�
//-----------------------------------------------------------------------------
#define GETPREVNODE(Struct, Root, Curr, Prev)           \
    {                                                   \
    Struct *p;                                          \
    Prev=NULL;                                          \
    if (Root!=Curr)                                     \
        for (p=Root; p!=NULL; p=p->Next)                \
            {                                           \
            if (p->Next==Curr) {Prev=p; break;}         \
            }                                           \
    }



#define MEMOWNER_JWUI       50
#define MEMOWNER_LCD        70
#define MEMOWNER_AniGif     80
#define MEMOWNER_PNGDEC     90
#define MEMOWNER_JOS        100
#define MEMOWNER_COMMCTL    110
#define MEMOWNER_Driver     150
#define MEMOWNER_JFAT       200
#define MEMOWNER_INIDATA    250



#endif // __JLIB_H__

