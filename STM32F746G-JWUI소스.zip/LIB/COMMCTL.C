///////////////////////////////////////////////////////////////////////////////
//              JWUI Common ��Ʈ��(����)
//
// ���α׷���: �ҿ�����
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "JOS.H"
#include "DRIVER.H"
#include "JWUI.H"
#if USE_GIF
#include "GIF.H"
#endif
#include "COMMCTL.H"

#define CLASSLOCAL              //near _pascal
#define WNOTHING        ~0
#define LINECHALIMIT    40

#define MEMOWNER_TE_Init            (MEMOWNER_COMMCTL+0)
#define MEMOWNER_EditWndProc        (MEMOWNER_COMMCTL+1)
#define MEMOWNER_TE_PutCha1         (MEMOWNER_COMMCTL+2)
#define MEMOWNER_TE_PutCha2         (MEMOWNER_COMMCTL+3)
#define MEMOWNER_TE_DeleteCha       (MEMOWNER_COMMCTL+4)
#define MEMOWNER_TE_SetText         (MEMOWNER_COMMCTL+5)
#define MEMOWNER_SetImgButtonText   (MEMOWNER_COMMCTL+6)
#define MEMOWNER_Static_WMCREATE    (MEMOWNER_COMMCTL+7)
#define MEMOWNER_Static_WMSETTEXT   (MEMOWNER_COMMCTL+8)
#define MEMOWNER_LB_AddString       (MEMOWNER_COMMCTL+9)
#define MEMOWNER_LB_InsertString    (MEMOWNER_COMMCTL+10)
#define MEMOWNER_LB_WMCREATE        (MEMOWNER_COMMCTL+11)
#define MEMOWNER_AniGifBtnWndProc   (MEMOWNER_COMMCTL+12)
#define MEMOWNER_ScrollBarWM_CREATE (MEMOWNER_COMMCTL+13)
#define MEMOWNER_ButtonWM_CREATE    (MEMOWNER_COMMCTL+14)
#define MEMOWNER_ManualBtnWM_CREATE (MEMOWNER_COMMCTL+15)
#define MEMOWNER_SH_WMCREATE        (MEMOWNER_COMMCTL+16)
#define MEMOWNER_HD_InsertItem1     (MEMOWNER_COMMCTL+17)
#define MEMOWNER_HD_InsertItem2     (MEMOWNER_COMMCTL+18)
#define MEMOWNER_HD_SetItem         (MEMOWNER_COMMCTL+19)
#define MEMOWNER_LVC_WMCREATE       (MEMOWNER_COMMCTL+20)
#define MEMOWNER_LVC_InsertItem     (MEMOWNER_COMMCTL+21)
#define MEMOWNER_LVC_SetItemText    (MEMOWNER_COMMCTL+22)
#define MEMOWNER_LV_SetColumn       (MEMOWNER_COMMCTL+23)



static CONST CHAR ButtonStr[]="Button";
       CONST CHAR WC_HEADER[]="SysHeader32";
       CONST CHAR WC_LISTVIEW[]="SysListView32";


static CONST BYTE CheckRadioBtnFont[]=
    {
    32,0,       //HeadSize
    0x4A,0x73,0x6F,0x66,0x74,0x42,0x69,0x74,0x46,0x6E,0x74,0x56,0x30,0x33,0,    //"JsoftBitFntV03"
    0x43,       //Kind  FK_INCWIDTHS|FK_UNICODE16GRAY
    13,0,       //Width
    13,0,       //Height
    7,0,        //BytesPerLine
    0x41,0,     //FirstCode
    5,0,        //CharQty
    0x28,0,0,0, //BitsDataLoc

    12,12,12,13, 13,0,0,0,

    0x00,0x03,0x57,0x75,0x30,0x00,0x00,
    0x00,0x56,0x9E,0xE9,0x65,0x00,0x00,
    0x05,0x7F,0xFF,0xFF,0xF7,0x50,0x00,
    0x36,0xFF,0xFF,0xFF,0xFF,0x63,0x00,
    0x59,0xFF,0xFF,0xFF,0xFF,0x95,0x00,
    0x6E,0xFF,0xFF,0xFF,0xFF,0xE6,0x00,
    0x6E,0xFF,0xFF,0xFF,0xFF,0xE6,0x00,
    0x59,0xFF,0xFF,0xFF,0xFF,0x95,0x00,
    0x26,0xFF,0xFF,0xFF,0xFF,0x62,0x00,
    0x05,0x7F,0xFF,0xFF,0xF7,0x50,0x00,
    0x00,0x56,0x9E,0xE9,0x65,0x00,0x00,
    0x00,0x02,0x56,0x65,0x20,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,

    0x00,0x03,0x68,0x86,0x30,0x00,0x00,
    0x00,0x75,0x20,0x02,0x57,0x00,0x00,
    0x07,0x40,0x00,0x00,0x04,0x70,0x00,
    0x35,0x00,0x00,0x00,0x00,0x53,0x00,
    0x62,0x00,0x00,0x00,0x00,0x26,0x00,
    0x80,0x00,0x00,0x00,0x00,0x08,0x00,
    0x80,0x00,0x00,0x00,0x00,0x08,0x00,
    0x62,0x00,0x00,0x00,0x00,0x26,0x00,
    0x35,0x00,0x00,0x00,0x00,0x53,0x00,
    0x07,0x40,0x00,0x00,0x04,0x70,0x00,
    0x00,0x75,0x20,0x02,0x57,0x00,0x00,
    0x00,0x03,0x68,0x86,0x30,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,

    0x00,0x03,0x68,0x86,0x30,0x00,0x00,
    0x00,0x75,0x20,0x02,0x57,0x00,0x00,
    0x07,0x40,0x00,0x00,0x04,0x70,0x00,
    0x35,0x00,0x7C,0xC7,0x00,0x53,0x00,
    0x62,0x07,0xDD,0xDD,0x70,0x26,0x00,
    0x80,0x0C,0xDD,0xDD,0xC0,0x08,0x00,
    0x80,0x0C,0xDD,0xDD,0xC0,0x08,0x00,
    0x62,0x07,0xDD,0xDD,0x70,0x26,0x00,
    0x35,0x00,0x7C,0xC7,0x00,0x53,0x00,
    0x07,0x40,0x00,0x00,0x04,0x70,0x00,
    0x00,0x75,0x20,0x02,0x57,0x00,0x00,
    0x00,0x03,0x68,0x86,0x30,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,

    0x77,0x77,0x77,0x77,0x77,0x77,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x70,0x00,0x00,0x00,0x00,0x00,0x70,
    0x77,0x77,0x77,0x77,0x77,0x77,0x70,

    0x99,0x99,0x99,0x99,0x99,0x99,0x90,
    0x90,0x00,0x00,0x00,0x00,0x00,0x90,
    0x90,0x00,0x00,0x00,0x03,0x30,0x90,
    0x90,0x00,0x00,0x00,0x1C,0xE5,0x90,
    0x90,0x00,0x00,0x00,0xAE,0xE5,0x90,
    0x90,0x07,0x10,0x06,0xEE,0x90,0x90,
    0x90,0x9E,0xB1,0x3E,0xEC,0x00,0x90,
    0x90,0x5E,0xEB,0xDE,0xD1,0x00,0x90,
    0x90,0x08,0xEE,0xEE,0x30,0x00,0x90,
    0x90,0x00,0x9E,0xE5,0x00,0x00,0x90,
    0x90,0x00,0x08,0x80,0x00,0x00,0x90,
    0x90,0x00,0x00,0x00,0x00,0x00,0x90,
    0x99,0x99,0x99,0x99,0x99,0x99,0x90,
    };



//-----------------------------------------------------------------------------
//      ������ Text�� ���̸� ����
//-----------------------------------------------------------------------------
LOCAL(int) GetTextHeight(HDC hDC)
    {
    SIZE S;
    MyGetTextExtent(hDC, "A", &S);      //'A'
    return S.cy;
    }

LOCAL(int) GetWindowTextHeight(HWND hWnd)
    {
    int Height;
    HDC hDC;

    hDC=GetDC(hWnd);
    Height=GetTextHeight(hDC);
    ReleaseDC(hWnd, hDC);
    return Height;
    }



//-----------------------------------------------------------------------------
//      �θ�Window���� WM_CTLCOLOR�޼����� ������ �������� ����
//-----------------------------------------------------------------------------
LOCAL(HBRUSH) SendCtlColor(HWND hWnd, HDC hDC, UINT CtlColorMsg)
    {
    return (HBRUSH)SendMessage(GetParent(hWnd), CtlColorMsg, (WPARAM)hDC, (LPARAM)hWnd);
    }


//-----------------------------------------------------------------------------
//      �θ�Window���� WM_COMMAND�޼����� �����ϴ�
//-----------------------------------------------------------------------------
VOID WINAPI PostParentCmdMsg(HWND hWnd, int NotiMsg)
    {
    PostMessage(GetParent(hWnd), WM_COMMAND, (NotiMsg<<16) | (GetWindowLong(hWnd, GWL_ID) & 0xFFFF), (LPARAM)hWnd);
    }



//-----------------------------------------------------------------------------
//      �θ�Window���� WM_COMMAND�޼����� �����ϴ�
//-----------------------------------------------------------------------------
VOID WINAPI SendParentCmdMsg(HWND hWnd, int NotiMsg)
    {
    SendMessage(GetParent(hWnd), WM_COMMAND, (NotiMsg<<16) | (GetWindowLong(hWnd, GWL_ID) & 0xFFFF), (LPARAM)hWnd);
    }



//-----------------------------------------------------------------------------
//      EnterŰ�� EscŰ�� �θ� Window���� �����ϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI PostParentSpecKeyMsg(HWND hWnd, WPARAM wPrm, LPARAM lPrm)
    {
    if (wPrm==VK_ESCAPE || wPrm==VK_TAB || wPrm==VK_RETURN)
        {
        PostMessage(GetParent(hWnd), WM_KEYDOWN, wPrm, lPrm);
        return TRUE;
        }
    return FALSE;
    }



//-----------------------------------------------------------------------------
//      Control�� WS_TABSTOP�Ӽ��� ������ ��Ŀ���� �ް��մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI LBtnCtrlFocus(HWND hWnd)
    {
    if (/*(GWLSTYLE(hWnd) & WS_TABSTOP) && */GetFocus()!=hWnd) SetFocus(hWnd);
    }



///////////////////////////////////////////////////////////////////////////////
//                      Edit Window                                          //
///////////////////////////////////////////////////////////////////////////////


typedef struct _OneLineStruc
    {
    struct _OneLineStruc *Next, *Prev;
    int  LineNo;
    CHAR String[1];     //������ �������� ��, �ѹ��ڰ� 3Byte�� ���� ����
    } OneLineStruc;



//-----------------------------------------------------------------------------
//      Text Edit Class
//-----------------------------------------------------------------------------
typedef struct _TextEditClass
    {
    OneLineStruc *Curr;
    HWND   hWnd;
    HFONT  hFont;
    int    CurrXLoc, BkupXLoc;  //����Ŀ����ġ(���ڴ�����)
    POINT  VP;                  //�ȼ�������
    POINT  SelStart, SelEnd;    //x�� ���� ����, y�� Line������
    LPVOID NCmplScr;
    POINT  NCmplPos;
    int    LineChaLimit;
    int    AvgLineHeight;
    } TextEditClass;


#ifndef _WIN32
LOCAL(VOID) TE_DispNoCmplCha(TextEditClass *TE, UINT NoCmplCha)
    {
    HDC  hDC;
    HWND hWnd;
    SIZE S;

    hWnd=TE->hWnd;
    HideCaret(hWnd);

    if (NoCmplCha==0)
        {
        if (TE->NCmplScr!=NULL)
            {
            LCD_RestoreScreen(TE->NCmplScr);
            TE->NCmplScr=NULL;
            CreateCaret(hWnd, NULL, 2, TE->AvgLineHeight);
            }
        }
    else{
        hDC=GetDC(hWnd);
        if (TE->NCmplScr==NULL)
            {
            RECT R;

            GetWindowRect(hWnd, &R);
            GetCaretPos(&TE->NCmplPos);
            MyGetTextExtent(hDC, "\xEC\xA0\x95", &S);   //'��'
            S.cx++;     //��Ƽ �˸��ƽ� �� �߰� �ȼ����� �ֱ� ����
            R.left+=TE->NCmplPos.x; R.top+=TE->NCmplPos.y;
            R.right=R.left+S.cx;  R.bottom=R.top+S.cy;
            TE->NCmplScr=LCD_SaveScreen(&R);
            CreateCaret(hWnd, NULL, S.cx, S.cy);
            }
        if (TE->NCmplScr!=NULL)
            {
            WCHAR U16[2];
            CHAR  Buff[4];

            U16[0]=NoCmplCha; U16[1]=0;
            Utf16ToUtf8(U16, Buff);
            SetTextColor(hDC, COL_WHITE);
            SetBkColor(hDC, COL_BLACK);
            MyTextOut(hDC, TE->NCmplPos.x, TE->NCmplPos.y, Buff);
            }
        ReleaseDC(hWnd, hDC);
        }
    ShowCaret(hWnd);
    }
#endif


LOCAL(VOID) TE_CalcTextHeight(TextEditClass *TE)
    {
    HDC hDC;

    hDC=GetDC(TE->hWnd);
    if (TE->hFont) SelectObject(hDC, TE->hFont);
    TE->AvgLineHeight=GetTextHeight(hDC);
    ReleaseDC(TE->hWnd, hDC);
    }



LOCAL(VOID) TE_Init(TextEditClass *TE, HWND hWnd)
    {
    ZeroMem(TE, sizeof(TextEditClass));
    TE->hWnd=hWnd;
    TE->LineChaLimit=LINECHALIMIT;
    if ((TE->Curr=AllocMemS(OneLineStruc, MEMOWNER_TE_Init))!=NULL)
        ZeroMem(TE->Curr, sizeof(OneLineStruc));

    TE_CalcTextHeight(TE);
    }


LOCAL(OneLineStruc*) TE_GetFirst(TextEditClass *TE)
    {
    OneLineStruc *OL;

    for (OL=TE->Curr; OL->Prev!=NULL; ) OL=OL->Prev;
    return OL;
    }


LOCAL(VOID) TE_Release(TextEditClass *TE)
    {
    OneLineStruc *OL, *Del;

    for (OL=TE_GetFirst(TE); OL!=NULL; )
        {
        Del=OL;
        OL=OL->Next;
        FreeMem(Del);
        }
    }



LOCAL(VOID) TE_CalcPos(TextEditClass *TE)
    {
    int  LineCnt=0;
    OneLineStruc *OL;

    for (OL=TE_GetFirst(TE); OL!=NULL; OL=OL->Next) OL->LineNo=LineCnt++;
    }



LOCAL(BOOL) TE_IsViewLine(TextEditClass *TE, OneLineStruc *OL)
    {
    int Y;
    RECT AR;

    GetClientRect(TE->hWnd, &AR);
    Y=OL->LineNo*TE->AvgLineHeight - TE->VP.y;
    return Y>=AR.top && Y+TE->AvgLineHeight<=AR.bottom;
    }



LOCAL(int) TE_GetLineY(TextEditClass *TE)
    {
    return TE->Curr->LineNo*TE->AvgLineHeight;
    }



LOCAL(VOID) TE_GetCaretPos(TextEditClass *TE, POINT *P)
    {
    HDC   hDC;
    SIZE  S;
    OneLineStruc *Curr;

    S.cx=0;
    Curr=TE->Curr;
    if (Curr->String[0]!=0 &&
        (hDC=GetDC(TE->hWnd))!=NULL)
        {
        GetTextExtentPoint32(hDC, Curr->String, GetChPtrU8(Curr->String, TE->CurrXLoc)-Curr->String, &S);
        ReleaseDC(TE->hWnd, hDC);
        }
    P->x=S.cx;
    P->y=TE_GetLineY(TE);
    }



LOCAL(BOOL) TE_AdjustVP(TextEditClass *TE)
    {
    int   HX, HY;
    RECT  CurrR, AR;

    GetClientRect(TE->hWnd, &AR); HX=AR.right/2; HY=AR.bottom/2;
    OffsetRect(&AR, TE->VP.x, TE->VP.y);
    TE_GetCaretPos(TE, (POINT*)&CurrR.left);
    CurrR.right=CurrR.left+TE->AvgLineHeight;
    CurrR.bottom=CurrR.top+TE->AvgLineHeight;
    if (IsIncludeRect(&AR, &CurrR)==FALSE)
        {
        if (CurrR.left<AR.left)
            {
            if (AR.left<HX) OffsetRect(&AR, -AR.left, 0);
            else{
                OffsetRect(&AR, -HX, 0);
                if (CurrR.left<AR.left) OffsetRect(&AR, CurrR.left-AR.left, 0);
                }
            }
        else if (CurrR.right>AR.right)
            {
            //OffsetRect(&AR, HX, 0);
            //if (CurrR.right>AR.right) OffsetRect(&AR, CurrR.right-HX-AR.left, 0);
            AR.left=CurrR.right-AR.right+AR.left;
            }

        if (CurrR.top<AR.top)
            {
            if (AR.top<HY) OffsetRect(&AR, 0, -AR.top);
            else{
                OffsetRect(&AR, 0, -HY);
                if (CurrR.top<AR.top) OffsetRect(&AR, 0, CurrR.top-AR.top);
                }
            }
        else if (CurrR.bottom>AR.bottom)
            {
            OffsetRect(&AR, 0, HY);
            if (CurrR.bottom>AR.bottom) OffsetRect(&AR, 0, CurrR.bottom-HY-AR.top);
            }
        TE->VP=*(POINT*)&AR.left;
        return TRUE;
        }
    return FALSE;
    }



LOCAL(VOID) TE_Draw(TextEditClass *TE, HDC hDC, BOOL AllFg)
    {
    OneLineStruc *OL;

    if (AllFg!=0)
        {
        for (OL=TE_GetFirst(TE); OL!=NULL; OL=OL->Next)
            MyTextOut(hDC, -TE->VP.x, OL->LineNo*TE->AvgLineHeight - TE->VP.y, OL->String);
        }
    else MyTextOut(hDC, -TE->VP.x, TE_GetLineY(TE) - TE->VP.y, TE->Curr->String);
    }



LOCAL(VOID) TE_ReDraw(TextEditClass *TE, int OldY)
    {
    HWND hWnd;
    RECT R;

    hWnd=TE->hWnd;
    if (TE_AdjustVP(TE))
        InvalidateRect(hWnd, NULL, TRUE);
    else{
        GetClientRect(hWnd, &R);
        if (OldY==-32767)
            {
            HDC hDC;
            HideCaret(hWnd);
            if ((hDC=GetDC(hWnd))!=NULL)
                {
                R.top=TE_GetLineY(TE) - TE->VP.y; R.bottom=R.top+TE->AvgLineHeight;
                FillRect(hDC, &R, (HBRUSH)GetClassLong(hWnd, GCL_HBRBACKGROUND));
                TE_Draw(TE, hDC, 0);
                ReleaseDC(hWnd, hDC);
                }
            ShowCaret(hWnd);
            }
        else{
            R.top=OldY-TE->VP.y;
            InvalidateRect(hWnd, &R, TRUE);
            }
        }
    }



LOCAL(VOID) TE_DeleteCha(TextEditClass *TE, WPARAM wPrm)
    {
    int  ChaQty, Size, OldY;
    OneLineStruc *T, *OL, *Curr;

    if ((Curr=TE->Curr)==NULL) goto ProcExit;

    ChaQty=GetChQtyU8(Curr->String);
    if (TE->CurrXLoc<0) TE->CurrXLoc=0;
    else if (TE->CurrXLoc>ChaQty) TE->CurrXLoc=ChaQty;

    if (wPrm==VK_BACK)
        {
        if (TE->CurrXLoc>0) TE->CurrXLoc--;
        else{
            if ((Curr=Curr->Prev)==NULL) goto ProcExit;
            TE->Curr=Curr;
            TE->CurrXLoc=ChaQty=GetChQtyU8(Curr->String);
            }
        }

    if (TE->CurrXLoc<ChaQty)
        {
        DelChaU8(Curr->String, TE->CurrXLoc);
        TE_ReDraw(TE, -32767);
        }
    else{       //�ǵڿ��� ����� ������ Data�� ���ٷ� �Ѿ���� �������� ������
        OldY=Curr->LineNo*TE->AvgLineHeight;
        if ((OL=Curr->Next)==NULL) goto ProcExit;

        Size=lstrlen(Curr->String)+sizeof(OneLineStruc);    //sizeof(OneLineStruc)�� Null�� ������ 1Byte�� ����
        if (ReAllocMem((LPVOID*)&TE->Curr, Size, lstrlen(OL->String)+Size, MEMOWNER_TE_DeleteCha)==NULL) goto ProcExit; //Curr�� �ٲ�
        Curr=TE->Curr;
        lstrcat(Curr->String, OL->String);
        Curr->Next=OL->Next;
        if ((T=Curr->Next)!=NULL) T->Prev=Curr;
        if ((T=Curr->Prev)!=NULL) T->Next=Curr;     //Curr�� ���Ҵ��Ͽ� �����Ͱ� �ٲ�����Ƿ�
        FreeMem(OL);

        TE_CalcPos(TE);
        TE_ReDraw(TE, OldY);
        }

    ProcExit:;
    }



LOCAL(VOID) TE_PutCha(TextEditClass *TE, WPARAM wPrm)
    {
    int   Size, ChaQty, OldY;
    CHAR  ChaBuff[4];
    LPSTR lp;
    OneLineStruc *T, *OL, *Curr;

    if ((Curr=TE->Curr)==NULL) goto ProcExit;
    SetUtf8FromU16(ChaBuff, wPrm);

    ChaQty=GetChQtyU8(Curr->String);
    if (TE->CurrXLoc<0) TE->CurrXLoc=0;
    else if (TE->CurrXLoc>ChaQty) TE->CurrXLoc=ChaQty;
    switch (wPrm)
        {
        case VK_BACK:
            TE_DeleteCha(TE, VK_BACK);
            break;

        case VK_RETURN:
            OldY=Curr->LineNo*TE->AvgLineHeight;
            lp=(LPSTR)GetChPtrU8(Curr->String, TE->CurrXLoc);
            Size=lstrlen(lp)+sizeof(OneLineStruc);
            if ((OL=(OneLineStruc*)AllocMem(Size, MEMOWNER_TE_PutCha1))==NULL) break;

            ZeroMem(OL, Size);
            lstrcpy(OL->String, lp);
            lp[0]=0;

            OL->Prev=Curr;
            if ((OL->Next=Curr->Next)!=NULL) OL->Next->Prev=OL;
            Curr->Next=OL;
            TE->Curr=OL;

            TE_CalcPos(TE);
            TE->CurrXLoc=TE->BkupXLoc=0;

            TE_ReDraw(TE, OldY);
            break;

        default:
            if (ChaQty>=TE->LineChaLimit) break;

            Size=lstrlen(Curr->String)+sizeof(OneLineStruc);    //sizeof(OneLineStruc)�� Null�� ������ 1Byte�� ����
            if (ReAllocMem((LPVOID*)&TE->Curr, Size, lstrlen(ChaBuff)+Size, MEMOWNER_TE_PutCha2)==NULL) break;

            Curr=TE->Curr;
            if (TE->CurrXLoc>=ChaQty) lstrcat(Curr->String, ChaBuff);
            else InsStr((LPSTR)GetChPtrU8(Curr->String, TE->CurrXLoc), 0, ChaBuff);

            TE->CurrXLoc++; TE->BkupXLoc=TE->CurrXLoc;

            if ((T=Curr->Prev)!=NULL) T->Next=Curr;             //TE->Curr�� �ٲ���� ����
            if ((T=Curr->Next)!=NULL) T->Prev=Curr;

            TE_ReDraw(TE, -32767);
        }
    ProcExit:;
    }



LOCAL(VOID) TE_SetCaretPos(TextEditClass *TE)
    {
    POINT P;

    if (GetFocus()==TE->hWnd)
        {
        TE_GetCaretPos(TE, &P);
        SetCaretPos(P.x-TE->VP.x, P.y-TE->VP.y);
        }
    }




LOCAL(VOID) TE_SetToCaretPosFromMousePos(TextEditClass *TE, LPARAM lPrm)
    {
    int   I, Y, ChaQty;
    HDC   hDC;
    SIZE  S;
    POINT P;
    OneLineStruc *OL;

    P.x=LoInt16(lPrm)+TE->VP.x;
    P.y=HiInt16(lPrm)+TE->VP.y;

    for (OL=TE_GetFirst(TE),Y=0; OL!=NULL; OL=OL->Next)
        {
        Y+=TE->AvgLineHeight;
        if (P.y<Y) break;
        }

    if (OL==NULL) goto ProcExit;

    TE->Curr=OL;
    ChaQty=GetChQtyU8(OL->String);
    hDC=GetDC(TE->hWnd);
    for (I=0; I<ChaQty; I++)
        {
        GetTextExtentPoint32(hDC, OL->String, GetChPtrU8(OL->String, I+1) - OL->String, &S);
        if (P.x<S.cx) break;
        }
    ReleaseDC(TE->hWnd, hDC);

    TE->BkupXLoc=TE->CurrXLoc=I;
    TE_SetCaretPos(TE);

    ProcExit:;
    }




LOCAL(VOID) TE_KeyFunc(TextEditClass *TE, WPARAM wPrm)
    {
    int  ChaQty;
    HWND hWnd;
    RECT R;
    OneLineStruc *T, *OL, *Curr;

    hWnd=TE->hWnd;
    Curr=TE->Curr;
    switch (wPrm)
        {
        case VK_DELETE:
            TE_DeleteCha(TE, VK_DELETE);
            return;

        case VK_HOME:
            if (TE->CurrXLoc==0) break;
            TE->CurrXLoc=0;
            goto XMoveCurs;

        case VK_END:
            ChaQty=GetChQtyU8(Curr->String);
            if (TE->CurrXLoc>=ChaQty) break;
            TE->CurrXLoc=ChaQty;
            goto XMoveCurs;

        case VK_LEFT:
            if (TE->CurrXLoc>0) TE->CurrXLoc--;
            else{
                if ((T=Curr->Prev)==NULL) break;
                TE->Curr=T;
                TE->CurrXLoc=GetChQtyU8(TE->Curr->String);
                }
            goto XMoveCurs;

        case VK_RIGHT:
            if (TE->CurrXLoc<GetChQtyU8(Curr->String)) TE->CurrXLoc++;
            else{
                if ((T=Curr->Next)==NULL) break;
                TE->Curr=T;
                TE->CurrXLoc=0;
                }
            XMoveCurs:
            TE->BkupXLoc=TE->CurrXLoc;
            break;

        case VK_UP:
            //UpProc:
            if ((T=Curr->Prev)==NULL) break;
            TE->Curr=T;
            goto XCursSet;

        case VK_DOWN:
            if ((T=Curr->Next)==NULL) break;
            TE->Curr=T;

            XCursSet:
            TE->CurrXLoc=GetMin(TE->BkupXLoc, GetChQtyU8(TE->Curr->String));
            break;

        case VK_PRIOR:
             for (OL=TE->Curr; OL!=NULL; OL=OL->Prev)    //���̴� ���� Line�� ã���ϴ�
                {
                if (TE_IsViewLine(TE, OL)==FALSE) break;
                TE->Curr=OL;
                }
            GetClientRect(hWnd, &R);
            TE->VP.y=TE_GetLineY(TE) - R.bottom + TE->AvgLineHeight;
            if (TE->VP.y<0) TE->VP.y=0;
            goto PageMoveEnd;

        case VK_NEXT:
            for (OL=TE->Curr; OL!=NULL; OL=OL->Next)    //���̴� �ǾƷ� Line�� ã���ϴ�
                {
                if (TE_IsViewLine(TE, OL)==FALSE) break;
                TE->Curr=OL;
                }
            TE->VP.y=TE_GetLineY(TE);

            PageMoveEnd:
            InvalidateRect(hWnd, NULL, TRUE);
            goto ProcExit;

        default: return;
        }
    if (TE_AdjustVP(TE)) InvalidateRect(hWnd, NULL, TRUE);

    ProcExit:
    TE_SetCaretPos(TE);
    }




LOCAL(VOID) TE_SetText(TextEditClass *TE, LPCSTR Text)
    {
    int    L, Size, Lines=0;
    HWND   hWnd;
    LPCSTR lp;
    OneLineStruc *OL;

    hWnd=TE->hWnd;
    TE_Release(TE);
    TE_Init(TE, hWnd); FreeMem(TE->Curr); TE->Curr=NULL;

    while (*Text!=0)
        {
        Text=(LPSTR)QueryStrOneLine(lp=Text, &L);
        Size=L+sizeof(OneLineStruc);
        if ((OL=(OneLineStruc*)AllocMem(Size, MEMOWNER_TE_SetText))==NULL) break;

        ZeroMem(OL, Size);
        CopyMem(OL->String, lp, L);

        OL->Prev=TE->Curr;
        OL->Next=NULL;
        if (TE->Curr!=NULL) TE->Curr->Next=OL;
        TE->Curr=OL;
        Lines++;
        }
    if (TE->Curr==NULL) TE_Init(TE, hWnd);
    if (Lines!=1) TE->Curr=TE_GetFirst(TE);     //��Ƽ������ ���� �� ������, �̱۶����� ���� �� �ڷ�
    TE_CalcPos(TE);
    if (Lines==1) {TE->CurrXLoc=lstrlen(TE->Curr->String); TE_AdjustVP(TE);}
    TE_SetCaretPos(TE);
    }



LOCAL(int) TE_GetText(TextEditClass *TE, LPSTR Text, int BuffLen)
    {
    int  L;
    CHAR FirstFg=1, *lp;
    OneLineStruc *OL;

    if (BuffLen<1) return 0;
    lp=Text;
    if (BuffLen==1) goto ProcExit;
    BuffLen--;

    for (OL=TE_GetFirst(TE); OL!=NULL; OL=OL->Next)
        {
        if (FirstFg==0)
            {
            if (BuffLen<2) break;
            *lp++=13;
            *lp++=10;
            BuffLen-=2;
            }
        FirstFg=0;
        if ((L=GetMin(lstrlen(OL->String), BuffLen))==0) break;
        CopyMem(lp, OL->String, L); lp+=L; BuffLen-=L;
        }

    ProcExit:
    *lp=0;
    return lstrlen(Text);
    }



LOCAL(int) TE_GetTextLen(TextEditClass *TE)
    {
    int  Len=0;
    CHAR FirstFg=1;
    OneLineStruc *OL;

    for (OL=TE_GetFirst(TE); OL!=NULL; OL=OL->Next)
        {
        if (FirstFg==0) Len+=2;
        FirstFg=0;
        Len+=lstrlen(OL->String);
        }
    return Len;
    }




//-----------------------------------------------------------------------------
//      Edit Window Proc
//-----------------------------------------------------------------------------
WNDFNC(EditWndProc)
    {
    PAINTSTRUCT   PS;
    TextEditClass *TE;

    TE=(TextEditClass*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            if ((TE=AllocMemS(TextEditClass, MEMOWNER_EditWndProc))==NULL) return -1;
            SetWindowLongPtr(hWnd, 0, (LONG_PTR)TE);
            TE_Init(TE, hWnd);
            Ret0:
            return 0;

        case WM_PAINT:
            HideCaret(hWnd);
            BeginPaint(hWnd, &PS);
            TE_Draw(TE, PS.hdc, 1);
            EndPaint(hWnd, &PS);
            ShowCaret(hWnd);    //EndPaint()�� ReleaseDC() ���� LCD�� ǥ���ϱ� ������ �� ��ġ���� ĳ���� �Ѿ� ��
            goto Ret0;

        case WM_SETTEXT:
            TE_SetText(TE, (LPCSTR)lPrm);
            InvalidateRect(hWnd, NULL, TRUE);
            goto Ret0;

        case WM_GETTEXT: return TE_GetText(TE, (LPSTR)lPrm, wPrm);
        case WM_GETTEXTLENGTH: return TE_GetTextLen(TE);

        case WM_GETFONT: return (LRESULT)TE->hFont;
        case WM_SETFONT:
            TE->hFont=(HFONT)wPrm;
            TE_CalcTextHeight(TE);
            if (lPrm) InvalidateRect(hWnd, NULL, TRUE);
            goto Ret0;

        case WM_KEYDOWN:
            if (wPrm==VK_ESCAPE || wPrm==VK_TAB ||
                ((GWLSTYLE(hWnd) & ES_WANTRETURN)==0 && wPrm==VK_RETURN))
                PostMessage(GetParent(hWnd), Msg, wPrm, lPrm);
            else{
                TE_KeyFunc(TE, wPrm);
                if (wPrm==VK_DELETE) goto SendNotifyMsg;
                }
            goto Ret0;

        case WM_CHAR:
            if (wPrm==VK_ESCAPE || wPrm==VK_TAB ||
                ((GWLSTYLE(hWnd) & ES_WANTRETURN)==0 && wPrm==VK_RETURN)) break;
            TE_PutCha(TE, wPrm);
            TE_SetCaretPos(TE);
            SendNotifyMsg:
            PostParentCmdMsg(hWnd, EN_CHANGE);
            goto Ret0;

        case WM_LBUTTONDOWN:
            if (GetFocus()!=hWnd) {SetFocus(hWnd); break;}
            TE_SetToCaretPosFromMousePos(TE, lPrm);
            break;

        case WM_SETFOCUS:
            CreateCaret(TE->hWnd, NULL, 2, TE->AvgLineHeight);
            TE_SetCaretPos(TE);
            ShowCaret(hWnd);
            PostParentCmdMsg(hWnd, EN_SETFOCUS);
            goto Ret0;

        case WM_KILLFOCUS:
            HideCaret(hWnd);
            DestroyCaret();
            PostParentCmdMsg(hWnd, EN_KILLFOCUS);
            goto Ret0;

        case EM_LIMITTEXT:
            TE->LineChaLimit=wPrm;
            goto Ret0;

        case WM_DESTROY:
            if (TE!=NULL)
                {
                TE_Release(TE);
                FreeMem(TE);
                SetWindowLong(hWnd, 0, 0);
                }
            goto Ret0;

        #ifndef _WIN32
        case WM_IME_COMPOSITION:
            TE_DispNoCmplCha(TE, wPrm);
            goto Ret0;
        #endif
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




///////////////////////////////////////////////////////////////////////////////
//                      Button Window                                        //
///////////////////////////////////////////////////////////////////////////////

typedef struct _BUTTONCTX
    {
    HWND hWnd;
    int BtnStat;
    int BtnChecked;
    int BtnImgNo;
    int BtnFlash;   //Manual��ư���� �����
    LPSTR BtnText;
    } BUTTONCTX;

//BtnFlash�� Bit����
#define BTNFLASH_ENABLE         0x0001
#define BTNFLASH_STATUS         0x0002



//-----------------------------------------------------------------------------
//      ��ư�� Text��ġ�� �̹����� �߾ӿ� ǥ����
//      JsprintfN(Buff, sizeof(Buff), "<%d %d %d>", COMBOBTNICONNO, CXCOMBOBTNIMAGE, CYCOMBOBTNIMAGE);
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawImageText(HDC hDC, CONST RECT *R, LPCSTR DefIconInfo)
    {
    int   IconNo, Sx, Sy;

    DefIconInfo=ScanInt(DefIconInfo, &IconNo);
    DefIconInfo=ScanInt(DefIconInfo, &Sx);
                ScanInt(DefIconInfo, &Sy);
    DrawDefaultIcon(hDC, R, IconNo, Sx, Sy);
    }



//-----------------------------------------------------------------------------
//  ���η� 10���� �����Ǿ� �ִ� �̹������� �־��� ��ȣ�� �ش��ϴ� ��ǥ�� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) GetImgOfs(int ImgNo, int SpaceX, int SpaceY, BOOL PushedFg, POINT *P)
    {
    ImgNo<<=1;
    if (PushedFg==0) ImgNo++;
    P->y=ImgNo/10*SpaceY;
    P->x=ImgNo%10*SpaceX;
    }





LOCAL(VOID) DrawBtn(BUTTONCTX *BC, HDC hDC)
    {
    int   ImgNo, BtnStyle, BtnType, BtnState;
    HWND  hWnd;
    DWORD Style;
    SIZE  ImgS;
    RECT  R;
    HBITMAP hBtm;
    LPSTR lp, BtnText, lpNext;
    CHAR Buff[FILENAMEBUFFMAX*4], ImgFName[FILENAMEBUFFMAX];

    hWnd=BC->hWnd;
    GetWindowText(hWnd, Buff, sizeof(Buff));
    GetClientRect(hWnd, &R);
    BtnState=BC->BtnStat;
    Style=GWLSTYLE(hWnd);
    BtnText=BC->BtnText;
    BtnStyle=(int)Style;
    BtnType=BtnStyle & BS_TYPEMASK;
    if (BtnType==BS_PUSHBUTTON || BtnType==BS_DEFPUSHBUTTON)
        {
        if (BtnStyle & BS_BITMAP)
            {
            if (Buff[0]!=0)
                {
                if ((ImgNo=BC->BtnImgNo)==WNOTHING)       //�׸����� 2���� ������ ���
                    {
                    if (Style & WS_DISABLED)
                        {
                        lp=Buff;
                        for (;;)
                            {
                            lpNext=(LPSTR)NextWord(lp, 1);
                            if (lpNext[0]==0) break;    //�� ������ �׸��� Disable�̹����� ���
                            lp=lpNext;
                            }
                        ScanWord(lp, ImgFName, sizeof(ImgFName));
                        }
                    else if (BC->BtnChecked!=0)
                        {
                        ScanWord(lp=(LPSTR)NextWord(Buff, 2), ImgFName, sizeof(ImgFName));
                        if (BtnState!=0)
                            {
                            lp=(LPSTR)NextWord(lp, 1);
                            if (lp[0]!=0) ScanWord(lp, ImgFName, sizeof(ImgFName));
                            else          ScanWord(NextWord(Buff, 1), ImgFName, sizeof(ImgFName));
                            }
                        }
                    else if (BC->BtnFlash & BTNFLASH_STATUS)
                        {
                        ScanWord(NextWord(Buff, 2), ImgFName, sizeof(ImgFName));
                        }
                    else{
                        ScanWord(Buff, ImgFName, sizeof(ImgFName));
                        if (BtnState!=0)
                            {
                            lp=(LPSTR)NextWord(Buff, 1);
                            if (lp[0]!=0) ScanWord(lp, ImgFName, sizeof(ImgFName));
                            }
                        }
                    //DrawWindowBatang(hWnd);
                    DrawImage(hDC, 0, 0, ImgFName);
                    if (BtnText!=NULL)
                        {
                        SetBkMode(hDC, TRANSPARENT);
                        SendCtlColor(hWnd, hDC, WM_CTLCOLORBTN);
                        if (BtnState!=0) OffsetRect(&R, 1, 1);
                        MyDrawText(hDC, BtnText, &R, DT_CENTER|DT_VCENTER);
                        }
                    }
                else{   //�׸����� �Ѱ����� ���� ��ư�� �߶� ����ϴ� ���
                    lp=(LPSTR)ScanWord(Buff, ImgFName, sizeof(ImgFName));
                    lp=(LPSTR)ScanInt(lp, &ImgS.cx);
                    ScanInt(lp, &ImgS.cy);

                    if ((hBtm=LoadImage(ImgFName))!=NULL)
                        {
                        POINT P;
                        GetImgOfs(ImgNo, ImgS.cx, ImgS.cy, BtnState, &P);
                        DrawBitmap(hDC, 0, 0, R.right, R.bottom, hBtm, P.x, P.y, COL_WHITE);
                        DeleteObject(hBtm);
                        }
                    }
                }
            }
        else{           //�Ϲ� Text��ư
            DrawTwoColRect(hDC, &R, BtnState==0 ? COL_BTNHIGHLIGHT:COL_BLACK, COL_BLACK, DTCR_Box);
            InflateRect(&R, -1, -1);
            DrawTwoColRect(hDC, &R, BtnState==0 ? COL_3DLIGHT:COL_BTNSHADOW, COL_BTNSHADOW, DTCR_Box);
            InflateRect(&R, -1, -1);
            FillRectCol(hDC, &R, COL_BTNFACE);

            if (Buff[0]!=0)
                {
                int Len;

                SendCtlColor(hWnd, hDC, WM_CTLCOLORBTN);
                if (BtnState!=0) OffsetRect(&R, 1, 1);
                Len=lstrlen(Buff);
                if (Buff[0]=='<' && Buff[Len-1]=='>')
                    {
                    Buff[Len-1]=0;
                    DrawImageText(hDC, &R, Buff+1);
                    }
                else MyDrawText(hDC, Buff, &R, DT_CENTER|DT_VCENTER);
                }
            }
        }
    else{       //������ư�� üũ�ڽ�
        #if USEDESIGNUI
        ImgNo=0;
        if (BtnType==BS_AUTORADIOBUTTON) ImgNo=5;
        else if (BtnType==BS_AUTOCHECKBOX) ImgNo=7;
        if (ImgNo!=0)
            {
            if (BC->BtnChecked!=0) ImgNo++;

            if ((hBtm=LoadImage("COMMBTN.BMP"))!=NULL)
                {
                POINT P;
                GetImgOfs(ImgNo, CommBtnImgSpace, CommBtnImgSpace, BtnState, &P);
                DrawBitmap(hDC, 0, 0, CommBtnImgSize, CommBtnImgSize, hBtm, P.x, P.y, COL_WHITE);
                DeleteObject(hBtm);
                }
            if (Buff[0]!=0)
                {
                SendCtlColor(hWnd, hDC, WM_CTLCOLORBTN);
                R.left+=CommBtnImgSpace;
                MyDrawText(hDC, Buff, &R, DT_LEFT);
                }
            }
        #else
        FillRectCol(hDC, &R, COL_BTNFACE);

        if (BtnType==BS_AUTORADIOBUTTON)
            {
            int Y;
            HFONT hFontOld;
            COLORREF BkColOld;

            hFontOld=(HFONT)SelectObject(hDC, (HFONT)CheckRadioBtnFont);
            SetBkMode(hDC, TRANSPARENT);
            SetTextColor(hDC, COL_WHITE);
            Y=(R.top+R.bottom-RADIOBTNSELHEIGHT)>>1;
            TextOut(hDC, R.left, Y, "A", 1);
            BkColOld=SetTextColor(hDC, BtnState==0 ? COL_BLACK:RGB(38,160,218));
            TextOut(hDC, R.left, Y, BC->BtnChecked==0 ? "B":"C", 1);
            R.left+=RADIOBTNSELWIDTH;
            SelectObject(hDC, hFontOld);
            SetTextColor(hDC, BkColOld);
            R.left+=RADIOBTNSELWIDTH;
            }
        else if (BtnType==BS_AUTOCHECKBOX)
            {
            HFONT hFontOld;
            COLORREF BkColOld;

            hFontOld=(HFONT)SelectObject(hDC, (HFONT)CheckRadioBtnFont);
            BkColOld=SetTextColor(hDC, BtnState==0 ? COL_BLACK:RGB(38,160,218));
            TextOut(hDC, R.left, (R.top+R.bottom-CHECKBTNSELHEIGHT)>>1, BC->BtnChecked==0 ? "D":"E", 1);
            R.left+=CHECKBTNSELWIDTH;
            SelectObject(hDC, hFontOld);
            SetTextColor(hDC, BkColOld);
            }

        if (Buff[0]!=0)
            {
            SendCtlColor(hWnd, hDC, WM_CTLCOLORBTN);
            R.left+=4;
            MyDrawText(hDC, Buff, &R, DT_LEFT|DT_VCENTER);
            }
        #endif
        }
    }


LOCAL(BOOL) IsWndRadioBtn(HWND hWnd)
    {
    CHAR WClsName[16];

    GetClassName(hWnd, WClsName, sizeof(WClsName));
    return lstrcmp(WClsName, ButtonStr)==0 &&
           (GWLSTYLE(hWnd) & BS_TYPEMASK)==BS_AUTORADIOBUTTON;
    }



//-----------------------------------------------------------------------------
//      �̹��� ��ư�� ǥ���� Text�� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) SetImgButtonText(BUTTONCTX *BC, LPSTR NewText)
    {
    if (BC->BtnText) {FreeMem(BC->BtnText); BC->BtnText=NULL;}
    if (NewText!=NULL && NewText[0]!=0) BC->BtnText=CopyStr(NewText, MEMOWNER_SetImgButtonText);
    }




//-----------------------------------------------------------------------------
//      Button Window Proc
//-----------------------------------------------------------------------------
WNDFNC(ButtonWndProc)
    {
    int  I;
    RECT R;
    BUTTONCTX *BC;
    CHAR Buff[FILENAMEBUFFMAX*2], ImgFName[FILENAMEBUFFMAX];

    BC=(BUTTONCTX*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            if ((BC=AllocMemS(BUTTONCTX, MEMOWNER_ButtonWM_CREATE))!=NULL)      //���ؽ�Ʈ�� ������ �޸� �Ҵ�
                {
                ZeroMem(BC, sizeof(BUTTONCTX));

                BC->hWnd=hWnd;
                if (GetWindowText(hWnd, Buff, sizeof(Buff))>0)
                    {
                    I=WNOTHING;     //Gif�����׸� ���
                    ScanWord(Buff, ImgFName, sizeof(ImgFName));
                    if (GetFileType(ImgFName)==IFT_BMP) I=AtoI(NextWord(Buff, 3), NULL);
                    BC->BtnImgNo=I;
                    }
                }
            SetWindowLongPtr(hWnd, 0, (LONG_PTR)BC);
            Ret0:
            return 0;

        case WM_DESTROY:
            if (BC!=NULL)
                {
                if (BC->BtnText!=NULL) FreeMem(BC->BtnText);
                FreeMem(BC);
                }
            goto Ret0;

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            if (BC) DrawBtn(BC, PS.hdc);
            EndPaint(hWnd, &PS);
            goto Ret0;
            }

        case WM_KEYDOWN:
            PostParentSpecKeyMsg(hWnd, wPrm, lPrm);
            goto Ret0;

        case WM_LBUTTONDOWN:
            if (BC==NULL) goto Ret0;
            LBtnCtrlFocus(hWnd);
            SetCapture(hWnd);
            //  ||
            //  \/
        case WM_MOUSEMOVE:
            if (BC==NULL) goto Ret0;
            if (GetCapture()==hWnd)
                {
                POINT P;
                GetClientRect(hWnd, &R);
                P.x=LoWord(lPrm);
                P.y=HiWord(lPrm);
                BC->BtnStat=PtInRect(&R, P);
                InvalidateRect(hWnd, NULL, FALSE);
                }
            goto Ret0;

        case WM_LBUTTONUP:
            if (BC==NULL) goto Ret0;
            if (GetCapture()!=hWnd) break;
            ReleaseCapture();
            if (BC->BtnStat!=0)
                {
                switch (GWLSTYLE(hWnd) & BS_TYPEMASK)
                    {
                    case BS_AUTORADIOBUTTON:
                        {
                        HWND hWndBrth, hWndTmp;

                        hWndBrth=hWnd;
                        for (;;)
                            {
                            if (GWLSTYLE(hWndBrth) & WS_GROUP) break;
                            if ((hWndTmp=GetWindow(hWndBrth, GW_HWNDPREV))==NULL) break;
                            if (IsWndRadioBtn(hWndTmp)==FALSE) break;
                            hWndBrth=hWndTmp;
                            }
                        for (;;)
                            {
                            SendMessage(hWndBrth, BM_SETCHECK, 0, 0);
                            if ((hWndBrth=GetWindow(hWndBrth, GW_HWNDNEXT))==NULL) break;
                            if (IsWndRadioBtn(hWndBrth)==FALSE) break;
                            if (GWLSTYLE(hWndBrth) & WS_GROUP) break;
                            }
                        BC->BtnChecked=1;
                        }
                        break;

                    case BS_AUTOCHECKBOX:
                        BC->BtnChecked^=1;
                    }
                PostParentCmdMsg(hWnd, 0);
                }

            BC->BtnStat=0;
            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);
            goto Ret0;

        case BM_SETIMAGE:
            if (BC) BC->BtnImgNo=wPrm;
            InvalidateRect(hWnd, NULL, FALSE);
            goto Ret0;

        case BM_GETCHECK: return BC ? BC->BtnChecked:0;

        case BM_SETCHECK:
            if (BC) BC->BtnChecked=wPrm;
            InvalidateRect(hWnd, NULL, FALSE);
            goto Ret0;

        case BM_GETTEXT: return BC ? (LRESULT)BC->BtnText:(LRESULT)NULL;
        case BM_SETTEXT:
            if (BC) SetImgButtonText(BC, (LPSTR)lPrm);
            InvalidateRect(hWnd, NULL, FALSE);
            return 1;

        case WM_ERASEBKGND: return 1;
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }



//-----------------------------------------------------------------------------
//      Manual Button Window Proc
//-----------------------------------------------------------------------------
#define BTNFLASH_TIMER  1
WNDFNC(ManualBtnWndProc)
    {
    int I;
    BUTTONCTX *BC;
    CHAR Buff[FILENAMEBUFFMAX*2], ImgFName[FILENAMEBUFFMAX];

    BC=(BUTTONCTX*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            if ((BC=AllocMemS(BUTTONCTX, MEMOWNER_ManualBtnWM_CREATE))!=NULL)   //���ؽ�Ʈ�� ������ �޸� �Ҵ�
                {
                ZeroMem(BC, sizeof(BUTTONCTX));

                BC->hWnd=hWnd;
                if (GetWindowText(hWnd, Buff, sizeof(Buff))>0)
                    {
                    I=WNOTHING;     //Gif�����׸� ���
                    ScanWord(Buff, ImgFName, sizeof(ImgFName));
                    if (GetFileType(ImgFName)==IFT_BMP) I=AtoI(NextWord(Buff, 3), NULL);
                    BC->BtnImgNo=I;
                    }
                }
            SetWindowLongPtr(hWnd, 0, (LONG_PTR)BC);
            Ret0:
            return 0;

        case WM_DESTROY:
            if (BC!=NULL)
                {
                if (BC->BtnText) FreeMem(BC->BtnText);
                FreeMem(BC);
                }
            goto Ret0;

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            if (BC) DrawBtn(BC, PS.hdc);
            EndPaint(hWnd, &PS);
            goto Ret0;
            }

        case WM_TIMER:
            if (BC==NULL) goto Ret0;
            if (wPrm==BTNFLASH_TIMER)
                {
                int Stat;

                if (IsWindowVisible(hWnd)!=FALSE)
                    {
                    Stat=BC->BtnFlash;
                    if (Stat & BTNFLASH_ENABLE) //KillTimer�Ѱ�쿡�� ������ �޼����� ���� ��찡 ����
                        {
                        BC->BtnFlash=Stat ^ BTNFLASH_STATUS;
                        InvalidateRect(hWnd, NULL, FALSE);
                        UpdateWindow(hWnd);
                        }
                    }
                }
            goto Ret0;

        case WM_KEYDOWN:
            PostParentSpecKeyMsg(hWnd, wPrm, lPrm);
            goto Ret0;

        case WM_LBUTTONDOWN:
            if (BC==NULL) goto Ret0;
            //SetCapture(hWnd);
            //2006.1.25 �޴��� ��ư�� ���콺�� ���� �� �׼��� �ǵ��� ����
            PostParentCmdMsg(hWnd, BC->BtnStat);
            goto Ret0;

        #if 0
        case WM_LBUTTONUP:
            if (BC==NULL) goto Ret0;
            if (GetCapture()!=hWnd) break;
            ReleaseCapture();
            PostParentCmdMsg(hWnd, BC->BtnStat);
            goto Ret0;
        #endif

        case BM_GETSTATE: return BC ? BC->BtnStat:0;

        case BM_SETSTATE:
            if (BC) BC->BtnStat=wPrm;
            RedrawBtn:
            if (IsWindowVisible(hWnd)!=FALSE)
                {
                InvalidateRect(hWnd, NULL, FALSE);
                UpdateWindow(hWnd);
                }
            goto Ret0;

        case BM_GETCHECK: return BC ? BC->BtnChecked:0;

        case BM_SETCHECK:
            if (BC) BC->BtnChecked=wPrm;
            InvalidateRect(hWnd, NULL, FALSE);
            goto Ret0;

        case BM_SETIMAGE:
            if (BC) BC->BtnImgNo=wPrm;
            goto RedrawBtn;

        case BM_SETFLASH:
            if (BC) BC->BtnFlash=wPrm;
            if (wPrm!=0)
                {
                SetTimer(hWnd, BTNFLASH_TIMER, 500, NULL);
                SendMessage(hWnd, WM_TIMER, BTNFLASH_TIMER, 0);
                }
            else{
                KillTimer(hWnd, BTNFLASH_TIMER);
                goto RedrawBtn;
                }
            goto Ret0;

        case BM_GETFLASH: return BC ? BC->BtnFlash & BTNFLASH_ENABLE:0;
        case BM_GETTEXT:  return BC ? (LRESULT)BC->BtnText:(LRESULT)NULL;
        case BM_SETTEXT:
            if (BC) SetImgButtonText(BC, (LPSTR)lPrm);
            InvalidateRect(hWnd, NULL, FALSE);
            return 1;

        case WM_ERASEBKGND: return 1;
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }



///////////////////////////////////////////////////////////////////////////////
//                      Static Window                                        //
///////////////////////////////////////////////////////////////////////////////


//-----------------------------------------------------------------------------
//      Static Window Proc
//-----------------------------------------------------------------------------
WNDFNC(StaticWndProc)
    {
    LPSTR Text, Title;

    Text=(LPSTR)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            Title=(LPSTR)((CREATESTRUCT*)lPrm)->lpszName;
            if (Title!=NULL && Title[0]!=0)
                SetWindowLongPtr(hWnd, 0, (LONG_PTR)CopyStr(Title, MEMOWNER_Static_WMCREATE));
            Ret0:
            return 0;

        case WM_DESTROY:
            if (Text!=NULL)
                {
                FreeMem(Text);
                SetWindowLongPtr(hWnd, 0, 0);
                }
            goto Ret0;

        case WM_PAINT:
            {
            WORD Style;
            RECT R;
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            if (Text!=NULL)
                {
                GetClientRect(hWnd, &R);
                if ((Style=GWLSTYLE(hWnd) & SS_TYPEMASK)==SS_BITMAP) DrawImage(PS.hdc, 0, 0, Text);
                else{
                    FillRect(PS.hdc, &R, SendCtlColor(hWnd, PS.hdc, WM_CTLCOLORSTATIC));
                    if (Text[0]!=0)
                        {
                        if (Style!=SS_LEFTNOWORDWRAP) Style=(Style & 3) | DT_WORDBREAK;
                        SendCtlColor(hWnd, PS.hdc, WM_CTLCOLORSTATIC);
                        MyDrawText(PS.hdc, Text, &R, Style); //|DT_VCENTER
                        }
                    }
                }
            EndPaint(hWnd, &PS);
            goto Ret0;
            }

        case WM_SETTEXT:
            FreeMem(Text); Text=NULL;
            if (lPrm!=0 && *(LPSTR)lPrm!=0) Text=CopyStr((LPSTR)lPrm, MEMOWNER_Static_WMSETTEXT);
            SetWindowLongPtr(hWnd, 0, (LONG)Text);
            InvalidateRect(hWnd, NULL, TRUE);
            UpdateWindow(hWnd);
            goto Ret0;

        case WM_GETTEXT:
            *(LPSTR)lPrm=0;
            if (Text==0) goto Ret0;
            lstrcpyn((LPSTR)lPrm, Text, wPrm);
            return lstrlen(Text);

        case WM_ERASEBKGND:
            #if 0
            if ((GWLSTYLE(hWnd) & SS_TYPEMASK)!=SS_BITMAP)
                {
                FillRect((HDC)wPrm, &((HDC)wPrm)->PA,
                         SendCtlColor(hWnd, (HDC)wPrm, WM_CTLCOLORSTATIC));
                }
            #endif
            return 1;
        }
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }





///////////////////////////////////////////////////////////////////////////////
//                      ScrollBar Window                                     //
///////////////////////////////////////////////////////////////////////////////


typedef struct _SCROLLBARCTX
    {
    HWND hWnd;
    int Min;            //������ ���常 �� �ξ��ٰ� ��û�� �� Pos�� ������
    int DataSize;
    int Pos;            //���ο��� 0����
    int TmpPos;
    int PageSize;
    BYTE FirstPBtn;     //ó�� ���콺 LBUTTON���� ������ư
    BYTE PushedBtn;
    BYTE ImgNo;
    POINTS LBtnDownPos; //���콺Ŭ���� ��ġ
    LPVOID TumbScrMem;
    } SCROLLBARCTX;

//PushedBtn
#define SBBTN_A     0
#define SBBTN_B     1
#define SBBTN_THUMB 2



#if USEDESIGNUI
//-----------------------------------------------------------------------------
//      ���ڷѹ� ���� Pos�� ���� �ȼ��� ��ġ�� ������ݴϴ�
//      ThumpHeight�� ������������ ����
//-----------------------------------------------------------------------------
LOCAL(int) GetScrlBarPixelPos(SCROLLBARCTX *SBC, int BtnWinth, int WndLen, int ThumbSize)
    {
    return MulDiv(SBC->SBPos,
                  WndLen-BtnWinth-BtnWinth-ThumbSize,       //����Tumb�� �̵��� �� �ִ� �Ÿ�
                  SBC->Max)+BtnWinth+ThumbSize/2;
    }
#endif



//-----------------------------------------------------------------------------
//      �־��� �ȼ��� ��ġ�� ���ڷѹ� ���� Pos���� ������ݴϴ�
//-----------------------------------------------------------------------------
LOCAL(int) PixelPosToSBPos(SCROLLBARCTX *SBC, POINT MouseP)
    {
    int  Style, Pos;
    RECT R;

    Style=GWLSTYLE(SBC->hWnd);
    GetClientRect(SBC->hWnd, &R);
    Pos=SBC->Pos;
    if (Style & SBS_VERT)
        {
        int BtnHeight, MoveAreaHeight, ThumbHeight;

        BtnHeight=GetMin(R.right, R.bottom>>1);
        R.top=BtnHeight; R.bottom-=BtnHeight;
        if ((MoveAreaHeight=R.bottom-R.top)>0)
            {
            ThumbHeight=GetMax(R.right, MulDiv(MoveAreaHeight, SBC->PageSize, SBC->DataSize));
            if ((Style & SBS_NOTHUMB)==0 && ThumbHeight<MoveAreaHeight)
                {
                Pos+=MulDiv(MouseP.y-SBC->LBtnDownPos.y, SBC->DataSize-SBC->PageSize, MoveAreaHeight-ThumbHeight);
                }
            }
        }
    else{
        int BtnWidth, MoveAreaWidth, ThumbWidth;

        BtnWidth=GetMin(R.bottom, R.right>>1);
        R.left=BtnWidth; R.right-=BtnWidth;
        if ((MoveAreaWidth=R.right-R.left)>0)
            {
            ThumbWidth=GetMax(R.bottom, MulDiv(MoveAreaWidth, SBC->PageSize, SBC->DataSize));
            if ((Style & SBS_NOTHUMB)==0 && ThumbWidth<MoveAreaWidth)
                {
                Pos+=MulDiv(MouseP.x-SBC->LBtnDownPos.x, SBC->DataSize-SBC->PageSize, MoveAreaWidth-ThumbWidth);
                }
            }
        }
    return Limit(Pos, 0, SBC->DataSize-SBC->PageSize);
    }




//-----------------------------------------------------------------------------
//      ��ũ�ѹ� ��ư�� �׸�
//-----------------------------------------------------------------------------
LOCAL(VOID) SB_DrawBtn(HDC hDC, RECT R, int BtnIconNo, BOOL Pushed)
    {
    int Sx, Sy;
    COLORREF OutlineCol;

    Sx=Sy=0;    //GCC���� �����ŷ���
    OutlineCol=Pushed ? COL_W10ACTIVEOUTLINE:COL_3DLIGHT;
    DrawTwoColRect(hDC, &R, OutlineCol, OutlineCol, DTCR_Box);
    InflateRect(&R, -1, -1);
    FillRectCol(hDC, &R, Pushed ? COL_W10ACTIVEBTNFACE:GetSysColor(COLOR_WINDOW));

    switch (BtnIconNo)
        {
        case HSBLEFTBTNICONNO:  Sx=CXHSBLEFTBTNICON;  Sy=CYHSBLEFTBTNICON; break;
        case HSBRIGHTBTNICONNO: Sx=CXHSBRIGHTBTNICON; Sy=CYHSBRIGHTBTNICON; break;
        case VSBUPBTNICONNO:    Sx=CXVSBUPBTNICON;    Sy=CYVSBUPBTNICON; break;
        case VSBDOWNBTNICONNO:  Sx=CXVSBDOWNBTNICON;  Sy=CYVSBDOWNBTNICON; //break;
        }
    DrawDefaultIcon(hDC, &R, BtnIconNo, Sx, Sy);
    }




//-----------------------------------------------------------------------------
//      ��ũ�ѹ� ���ư�� �׸�
//-----------------------------------------------------------------------------
LOCAL(VOID) SB_DrawThumb(HDC hDC, RECT R, int BtnIconNo, BOOL Pushed)
    {
    int Sx, Sy;
    COLORREF OutlineCol;

    Sx=Sy=0;    //GCC���� �����ŷ���
    OutlineCol=Pushed ? COL_W10ACTIVEOUTLINE:COL_GRAY;
    DrawTwoColRect(hDC, &R, OutlineCol, OutlineCol, DTCR_Box);
    InflateRect(&R, -1, -1);
    FillRectCol(hDC, &R, Pushed ? COL_W10ACTIVEBTNFACE:COL_LIGHTGRAY);
    switch (BtnIconNo)
        {
        case HSBTHUMBBTNICONNO: Sx=CXHSBTHUMBBTNICON; Sy=CYHSBTHUMBBTNICON; break;
        case VSBTHUMBBTNICONNO: Sx=CXVSBTHUMBBTNICON; Sy=CYVSBTHUMBBTNICON; //break;
        }
    DrawDefaultIcon(hDC, &R, BtnIconNo, Sx, Sy);
    }



//-----------------------------------------------------------------------------
//      ���ڷѹ��� ����� �׸�
//-----------------------------------------------------------------------------
LOCAL(VOID) VSB_DrawEmptyPlace(HDC hDC, RECT R)
    {
    DrawTwoColRect(hDC, &R, COL_3DLIGHT, COL_3DLIGHT, DTCR_Left|DTCR_Right);
    InflateRect(&R, -1, 0);
    FillRectCol(hDC, &R, GetSysColor(COLOR_WINDOW));
    }

LOCAL(VOID) HSB_DrawEmptyPlace(HDC hDC, RECT R)
    {
    DrawTwoColRect(hDC, &R, COL_3DLIGHT, COL_3DLIGHT, DTCR_Top|DTCR_Bottom);
    InflateRect(&R, 0, -1);
    FillRectCol(hDC, &R, GetSysColor(COLOR_WINDOW));
    }




LOCAL(VOID) SB_DrawMoveArea(SCROLLBARCTX *SBC, HDC hDC, DWORD Style, RECT R)
    {
    int  AdjPos;

    if (Style & SBS_VERT)
        {
        int ARBottom, MoveAreaHeight, ThumbHeight, ThumbTop;

        ARBottom=R.bottom;
        MoveAreaHeight=R.bottom-R.top;

        ThumbHeight=GetMax(R.right-R.left, MulDiv(MoveAreaHeight, SBC->PageSize, SBC->DataSize));
        if ((Style & SBS_NOTHUMB)!=0 || ThumbHeight>=MoveAreaHeight)
            {
            VSB_DrawEmptyPlace(hDC, R);
            goto ProcExit;
            }

        AdjPos=GetMin(SBC->Pos, SBC->DataSize-SBC->PageSize);
        ThumbTop=MulDiv(MoveAreaHeight-ThumbHeight, AdjPos, SBC->DataSize-SBC->PageSize);
        R.bottom=R.top+ThumbTop;
        if (R.top<R.bottom) VSB_DrawEmptyPlace(hDC, R); //Thumb ���� ����

        R.top=R.bottom; R.bottom=R.top+ThumbHeight;
        SB_DrawThumb(hDC, R, VSBTHUMBBTNICONNO, SBC->PushedBtn==SBBTN_THUMB);

        R.top=R.bottom; R.bottom=ARBottom;
        if (R.top<R.bottom) VSB_DrawEmptyPlace(hDC, R);
        }
    else{
        int ARRight, MoveAreaWidth, ThumbWidth, ThumbLeft;

        ARRight=R.right;
        MoveAreaWidth=R.right-R.left;

        ThumbWidth=GetMax(R.bottom-R.top, MulDiv(MoveAreaWidth, SBC->PageSize, SBC->DataSize));
        if ((Style & SBS_NOTHUMB)!=0 || ThumbWidth>=MoveAreaWidth)
            {
            HSB_DrawEmptyPlace(hDC, R);
            goto ProcExit;
            }

        AdjPos=GetMin(SBC->Pos, SBC->DataSize-SBC->PageSize);
        ThumbLeft=MulDiv(MoveAreaWidth-ThumbWidth, AdjPos, SBC->DataSize-SBC->PageSize);
        R.right=R.left+ThumbLeft;
        if (R.left<R.right) HSB_DrawEmptyPlace(hDC, R); //Thumb ���� ����

        R.left=R.right; R.right=R.left+ThumbWidth;
        SB_DrawThumb(hDC, R, HSBTHUMBBTNICONNO, SBC->PushedBtn==SBBTN_THUMB);

        R.left=R.right; R.right=ARRight;
        if (R.left<R.right) HSB_DrawEmptyPlace(hDC, R);
        }

    ProcExit:;
    }




LOCAL(VOID) DrawScrollBar(SCROLLBARCTX *SBC, HDC hDC)
    {
    #if USEDESIGNUI
    int   PBtn, Style, ImgNo;
    HWND  hWnd;
    RECT  R;
    POINT P;
    HBITMAP hBtm;

    hWnd=SBC->hWnd;
    PBtn=SBC->PushedBtn;
    Style=GWLSTYLE(hWnd);
    GetClientRect(hWnd, &R);

    if ((hBtm=LoadImage("COMMBTN.BMP"))==NULL) goto ProcExit;
    if (SBC->SBTumbScrMem!=0) {LCD_RestoreScreen(SBC->SBTumbScrMem); SBC->SBTumbScrMem=NULL;}
    if (Style & SBS_VERT)
        {
        int Width=R.right;
        if ((ImgNo=SBC->SBImgNo)==WNOTHING) ImgNo=2;
        GetImgOfs(ImgNo, SBBtnImgSpaceX, SBBtnImgSpaceY, PBtn==SBBTN_A, &P);
        DrawBitmap(hDC, 0, 0,              Width, Width, hBtm, P.x, P.y, COL_WHITE);
        GetImgOfs(ImgNo+1, SBBtnImgSpaceX, SBBtnImgSpaceY, PBtn==SBBTN_B, &P);
        DrawBitmap(hDC, 0, R.bottom-Width, Width, Width, hBtm, P.x, P.y, COL_WHITE);

        if ((Style & SBS_NOTHUMB)==0 && R.bottom-Width-Width-VThumbHeight>0)
            {
            R.left=R.right=R.right/2;
            R.top=R.bottom=GetScrlBarPixelPos(SBC, Width, R.bottom, VThumbHeight);
            InflateRect(&R, (VThumbWidth+1)/2, (VThumbHeight+1)/2);
            P=*(POINT*)&R.left;
            ClientToScreen(hWnd, (POINT*)&R.left);
            ClientToScreen(hWnd, (POINT*)&R.right);
            SBC->SBTumbScrMem=LCD_SaveScreen(&R);
            DrawBitmap(hDC, P.x, P.y, VThumbWidth, VThumbHeight, hBtm, 200, 0, COL_WHITE);
            }
        }
    else{
        int Height=R.bottom;
        GetImgOfs(0, SBBtnImgSpaceX, SBBtnImgSpaceY, PBtn==SBBTN_A, &P);
        DrawBitmap(hDC, 0, 0,              Height, Height, hBtm, P.x, P.y, COL_WHITE);
        GetImgOfs(1, SBBtnImgSpaceX, SBBtnImgSpaceY, PBtn==SBBTN_B, &P);
        DrawBitmap(hDC, R.right-Height, 0, Height, Height, hBtm, P.x, P.y, COL_WHITE);

        if ((Style & SBS_NOTHUMB)==0 && R.right-Height-Height-HThumbWidth>0)
            {
            R.left=R.right=GetScrlBarPixelPos(SBC, Height, R.right, HThumbWidth);
            R.top=R.bottom=R.bottom/2;
            InflateRect(&R, (HThumbWidth+1)/2, (HThumbHeight+1)/2);
            P=*(POINT*)&R.left;
            ClientToScreen(hWnd, (POINT*)&R.left);
            ClientToScreen(hWnd, (POINT*)&R.right);
            SBC->SBTumbScrMem=LCD_SaveScreen(&R);
            DrawBitmap(hDC, P.x, P.y, HThumbWidth, HThumbHeight, hBtm, SBBtnImgSpaceX+200, 0, COL_WHITE);
            }
        }
    DeleteObject(hBtm);
    ProcExit:;
    #else   //USEDESIGNUI

    int   Style;
    HWND  hWnd;
    RECT  R;

    hWnd=SBC->hWnd;
    Style=GWLSTYLE(hWnd);
    GetClientRect(hWnd, &R);

    if (Style & SBS_VERT)
        {
        int BtnHeight, WinHeight;

        WinHeight=R.bottom;
        BtnHeight=GetMin(R.right, WinHeight>>1);
        R.bottom=BtnHeight;
        SB_DrawBtn(hDC, R, VSBUPBTNICONNO, SBC->PushedBtn==SBBTN_A);

        R.top=R.bottom;
        R.bottom=WinHeight-BtnHeight;
        if (R.bottom>R.top) SB_DrawMoveArea(SBC, hDC, Style, R);

        R.top=R.bottom; R.bottom=WinHeight;
        SB_DrawBtn(hDC, R, VSBDOWNBTNICONNO, SBC->PushedBtn==SBBTN_B);
        }
    else{
        int BtnWidth, WinWidth;

        WinWidth=R.right;
        BtnWidth=GetMin(R.bottom, WinWidth>>1);
        R.right=BtnWidth;
        SB_DrawBtn(hDC, R, HSBLEFTBTNICONNO, SBC->PushedBtn==SBBTN_A);

        R.left=R.right;
        R.right=WinWidth-BtnWidth;
        if (R.right>R.left) SB_DrawMoveArea(SBC, hDC, Style, R);

        R.left=R.right; R.right=WinWidth;
        SB_DrawBtn(hDC, R, HSBRIGHTBTNICONNO, SBC->PushedBtn==SBBTN_B);
        }
    #endif  //USEDESIGNUI
    }




//-----------------------------------------------------------------------------
//      �־��� ��ġ�� � ��ư�� �ִ��� �˷���
//-----------------------------------------------------------------------------
#if USEDESIGNUI
LOCAL(int) IsPointSbBtn(SCROLLBARCTX *SBC, POINT P)
    {
    int  Style, BtnID=-1;
    RECT R, WR;

    GetClientRect(SBC->hWnd, &WR);
    Style=GWLSTYLE(SBC->hWnd);
    if (Style & SBS_VERT)
        {
        int Width=WR.right;
        SetRect(&R, 0, 0, Width, Width);
        if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_A; goto ProcExit;}
        SetRect(&R, 0, WR.bottom-Width, Width, WR.bottom);
        if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_B; goto ProcExit;}

        if ((Style & SBS_NOTHUMB)==0)
            {
            R.left=R.right=WR.right/2;
            R.top=R.bottom=GetScrlBarPixelPos(SBC, Width, WR.bottom, VThumbHeight);
            InflateRect(&R, VThumbWidth/2, VThumbHeight/2);
            if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_THUMB; goto ProcExit;}
            }
        }
    else{
        int Height=WR.bottom;
        SetRect(&R, 0, 0, Height, Height);
        if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_A; goto ProcExit;}
        SetRect(&R, WR.right-Height, 0, WR.right, Height);
        if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_B; goto ProcExit;}

        if ((Style & SBS_NOTHUMB)==0)
            {
            R.left=R.right=GetScrlBarPixelPos(SBC, Height, WR.right, HThumbWidth);
            R.top=R.bottom=WR.bottom/2;
            InflateRect(&R, HThumbWidth/2, HThumbHeight/2);
            if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_THUMB; goto ProcExit;}
            }
        }
    ProcExit:
    return BtnID;
    }
#else
LOCAL(int) IsPointSbBtn(SCROLLBARCTX *SBC, POINT P)
    {
    int  Style, BtnID=-1, AdjPos;
    RECT R;

    GetClientRect(SBC->hWnd, &R);
    Style=GWLSTYLE(SBC->hWnd);
    if (Style & SBS_VERT)
        {
        int Height, ARBottom, MoveAreaHeight, ThumbHeight, ThumbTop;

        ARBottom=R.bottom;
        Height=GetMin(R.right, R.bottom>>1);
        R.bottom=Height;
        if (PtInRect(&R, P)) {BtnID=SBBTN_A; goto ProcExit;}

        R.top=ARBottom-Height; R.bottom=ARBottom;
        if (PtInRect(&R, P)) {BtnID=SBBTN_B; goto ProcExit;}

        R.top=Height; R.bottom=ARBottom-Height;
        if ((MoveAreaHeight=R.bottom-R.top)>0)
            {
            ThumbHeight=GetMax(R.right, MulDiv(MoveAreaHeight, SBC->PageSize, SBC->DataSize));
            if ((Style & SBS_NOTHUMB)==0 && ThumbHeight<MoveAreaHeight)
                {
                AdjPos=GetMin(SBC->Pos, SBC->DataSize-SBC->PageSize);
                ThumbTop=MulDiv(MoveAreaHeight-ThumbHeight, AdjPos, SBC->DataSize-SBC->PageSize);

                R.top+=ThumbTop; R.bottom=R.top+ThumbHeight;
                if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_THUMB; goto ProcExit;}
                }
            }
        }
    else{
        int Width, ARRight, MoveAreaWidth, ThumbWidth, ThumbLeft;

        ARRight=R.right;
        Width=GetMin(R.bottom, R.right>>1);
        R.right=Width;
        if (PtInRect(&R, P)) {BtnID=SBBTN_A; goto ProcExit;}

        R.left=ARRight-Width; R.right=ARRight;
        if (PtInRect(&R, P)) {BtnID=SBBTN_B; goto ProcExit;}

        R.left=Width; R.right=ARRight-Width;
        if ((MoveAreaWidth=R.right-R.left)>0)
            {
            ThumbWidth=GetMax(R.bottom, MulDiv(MoveAreaWidth, SBC->PageSize, SBC->DataSize));
            if ((Style & SBS_NOTHUMB)==0 && ThumbWidth<MoveAreaWidth)
                {
                AdjPos=GetMin(SBC->Pos, SBC->DataSize-SBC->PageSize);
                ThumbLeft=MulDiv(MoveAreaWidth-ThumbWidth, AdjPos, SBC->DataSize-SBC->PageSize);

                R.left+=ThumbLeft; R.right=R.left+ThumbWidth;
                if (PtInRect(&R, P)!=FALSE) {BtnID=SBBTN_THUMB; goto ProcExit;}
                }
            }
        }

    ProcExit:
    return BtnID;
    }
#endif




//-----------------------------------------------------------------------------
//      ScrollBar Window Proc
//-----------------------------------------------------------------------------
WNDFNC(ScrollBarWndProc)
    {
    int   I;
    POINT P;
    PAINTSTRUCT PS;
    SCROLLBARCTX *SBC;

    SBC=(SCROLLBARCTX*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            I=-1;
            if (((CREATESTRUCT*)lPrm)->lpszName[0]!=0) I=AtoI(((CREATESTRUCT*)lPrm)->lpszName, NULL);

            if ((SBC=AllocMemS(SCROLLBARCTX, MEMOWNER_ScrollBarWM_CREATE))!=NULL)   //���ؽ�Ʈ�� ������ �޸� �Ҵ�
                {
                ZeroMem(SBC, sizeof(SCROLLBARCTX));

                SBC->hWnd=hWnd;
                SBC->PushedBtn=WNOTHING;
                SBC->ImgNo=I;
                }
            SetWindowLongPtr(hWnd, 0, (LONG_PTR)SBC);

            Ret0:
            return 0;

        case WM_DESTROY:
            if (SBC!=NULL)
                {
                //if (SBC->hBr!=NULL) DeleteObject(SBC->hBr);
                FreeMem(SBC);
                }
            goto Ret0;

        case WM_PAINT:
            BeginPaint(hWnd, &PS);
            if (SBC) DrawScrollBar(SBC, PS.hdc);
            EndPaint(hWnd, &PS);
            goto Ret0;

        case WM_KEYDOWN:
            PostParentSpecKeyMsg(hWnd, wPrm, lPrm);
            goto Ret0;

        case WM_LBUTTONDOWN:
            if (SBC==NULL) break;
            P.x=SBC->LBtnDownPos.x=LoInt16(lPrm);
            P.y=SBC->LBtnDownPos.y=HiInt16(lPrm);
            LBtnCtrlFocus(hWnd);
            SBC->PushedBtn=WNOTHING;
            SBC->FirstPBtn=I=IsPointSbBtn(SBC, P);
            if (I>=0) SetCapture(hWnd);
            if (I==SBBTN_THUMB) SBC->TmpPos=SBC->Pos;
            //  ||
            //  \/

        case WM_MOUSEMOVE:
            if (SBC==NULL) break;
            P.x=LoWord(lPrm);
            P.y=HiWord(lPrm);
            if (GetCapture()==hWnd)
                {
                if (SBC->FirstPBtn==SBBTN_THUMB)
                    {
                    if (SBC->PushedBtn!=SBBTN_THUMB)
                        {
                        SBC->PushedBtn=SBBTN_THUMB;
                        InvalidateRect(hWnd, NULL, FALSE);
                        }
                    else if ((I=PixelPosToSBPos(SBC, P))!=SBC->Pos)
                        {
                        SBC->Pos=I;
                        InvalidateRect(hWnd, NULL, FALSE);
                        PostMessage(GetParent(hWnd), GWLSTYLE(hWnd) & SBS_VERT ? WM_VSCROLL:WM_HSCROLL,
                                    MAKELONG(SB_THUMBTRACK, I), (LPARAM)hWnd);
                        }
                    }
                else{
                    if ((I=IsPointSbBtn(SBC, P))!=SBC->FirstPBtn) I=WNOTHING;
                    if (SBC->PushedBtn!=I)
                        {
                        SBC->PushedBtn=I;
                        InvalidateRect(hWnd, NULL, FALSE);
                        }
                    }
                }
            SBC->LBtnDownPos.x=P.x;
            SBC->LBtnDownPos.y=P.y;
            goto Ret0;

        case WM_LBUTTONUP:
            if (SBC==NULL) break;
            if (GetCapture()!=hWnd) break;
            ReleaseCapture();

            Msg=GWLSTYLE(hWnd) & SBS_VERT ? WM_VSCROLL:WM_HSCROLL;
            if (SBC->FirstPBtn!=SBBTN_THUMB)
                {
                wPrm=~0;
                switch (SBC->PushedBtn)
                    {
                    case SBBTN_A:
                        if (SBC->Pos==0) break;
                        wPrm=SB_LINEUP;
                        SoundEffect("USB_1-1");
                        break;

                    case SBBTN_B:
                        if (SBC->Pos>=SBC->DataSize-SBC->PageSize) break;
                        wPrm=SB_LINEDOWN;
                        SoundEffect("DSB_1-1");
                        //break;
                    }
                if (wPrm!=(WPARAM)~0) PostMessage(GetParent(hWnd), Msg, wPrm, (LPARAM)hWnd);
                }
            else{
                PostMessage(GetParent(hWnd), Msg, MAKELONG(SB_THUMBPOSITION, SBC->Pos+SBC->Min), (LPARAM)hWnd);
                SBC->Pos=SBC->TmpPos;
                }
            SBC->PushedBtn=WNOTHING;
            InvalidateRect(hWnd, NULL, FALSE);
            goto Ret0;

        case WM_ERASEBKGND: return 1;
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }


LOCAL(SCROLLBARCTX*) GetSBCTX(HWND hWnd, int fnBar)
    {
    SCROLLBARCTX *SBC=NULL;

    if (fnBar!=SB_CTL) hWnd=GetDlgItem(hWnd, ScrollBarChildID+fnBar);
    if (hWnd!=NULL) SBC=(SCROLLBARCTX*)GetWindowLongPtr(hWnd, 0);
    return SBC;
    }


int WINAPI SetScrollImage(HWND hWnd, int fnBar, int ImgNo, BOOL RepaintFg)
    {
    int  Old=0;
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL)
        {
        Old=SBC->ImgNo;
        SBC->ImgNo=ImgNo;
        if (RepaintFg!=FALSE) InvalidateRect(hWnd, NULL, TRUE);
        }
    return Old;
    }



int WINAPI SetScrollPos(HWND hWnd, int fnBar, int Pos, BOOL RepaintFg)
    {
    int Old=0;
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL)
        {
        Old=SBC->Pos+SBC->Min;
        SBC->Pos=Limit(Pos, 0, SBC->DataSize-SBC->PageSize);
        if (RepaintFg!=FALSE) InvalidateRect(hWnd, NULL, FALSE);
        }
    return Old;
    }


int WINAPI GetScrollPos(HWND hWnd, int fnBar)
    {
    int Rslt=0;
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL) Rslt=SBC->Pos+SBC->Min;
    return Rslt;
    }


VOID WINAPI SetScrollRange(HWND hWnd, int fnBar, int Min, int Max, BOOL RepaintFg)
    {
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL)
        {
        SBC->Min=Min;
        SBC->DataSize=Max-Min;
        SBC->Pos=Limit(SBC->Pos, 0, SBC->DataSize-SBC->PageSize);
        if (RepaintFg) InvalidateRect(hWnd, NULL, FALSE);
        }
    }



//-----------------------------------------------------------------------------
//      ���ڷѹ��� Thumb ũ�⸦ �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI SetScrollPageSize(HWND hWnd, int fnBar, int PageSize, BOOL RedrawFg)
    {
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL)
        {
        SBC->PageSize=PageSize;
        if (RedrawFg) InvalidateRect(hWnd, NULL, FALSE);
        }
    }



VOID WINAPI GetScrollRange(HWND hWnd, int fnBar, int *Min, int *Max)
    {
    SCROLLBARCTX *SBC;

    if ((SBC=GetSBCTX(hWnd, fnBar))!=NULL)
        {
        *Min=SBC->Min;
        *Max=SBC->Min+SBC->DataSize;
        }
    }



///////////////////////////////////////////////////////////////////////////////
//                      ListBox Window                                       //
///////////////////////////////////////////////////////////////////////////////


#define IN_LB   0
#define IN_CB   1


typedef struct _LB_ONELINE
    {
    struct _LB_ONELINE *Next, *Prev;
    int  YLoc;          //ù���� 0������ �ȼ������� Y��ġ
    int  LineNo;
    CHAR String[1];     //������ �������� ��
    } LB_ONELINE;


//-----------------------------------------------------------------------------
//      ListBox Class
//-----------------------------------------------------------------------------
typedef struct _ListBoxClass
    {
    LB_ONELINE *Curr;
    HWND  hWnd;
    POINT VP;                   //�ȼ�������
    HWND  hWndCB;               //�޺��ڽ��� ��ó���� �� hWnd�� ����ϴµ� ���, ���� �� hWnd����
    BYTE  CBModeFg;             //�޺��ڽ����� ���
    } ListBoxClass;



LOCAL(LB_ONELINE*) LB_GetFirst(ListBoxClass *LB)
    {
    LB_ONELINE *OL;

    if ((OL=LB->Curr)!=NULL)
        while (OL->Prev!=NULL) OL=OL->Prev;
    return OL;
    }


LOCAL(VOID) LB_Release(ListBoxClass *LB)
    {
    LB_ONELINE *OL, *Del;

    OL=LB_GetFirst(LB);
    while (OL!=NULL)
        {
        Del=OL;
        OL=OL->Next;
        FreeMem(Del);
        }
    LB->Curr=NULL;
    }


LOCAL(LB_ONELINE*) LB_GetLast(ListBoxClass *LB)
    {
    LB_ONELINE *OL;

    if ((OL=LB->Curr)!=NULL)
        while (OL->Next!=NULL) OL=OL->Next;
    return OL;
    }



LOCAL(VOID) LB_CalcPos(ListBoxClass *LB)
    {
    int  Y, LineCnt;
    LB_ONELINE *OL;

    Y=LineCnt=0;
    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        {
        OL->YLoc=Y;
        OL->LineNo=LineCnt++;
        Y+=LB_ITEMHEIGHT;
        }
    SetScrollRange(LB->hWnd, SB_VERT, 0, Y, FALSE);
    }



//-----------------------------------------------------------------------------
//      �־��� Window�ȿ� ������ ���ԵǴ����� �˷��ݴϴ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) LB_IsViewLine(ListBoxClass *LB, LB_ONELINE *OL)
    {
    int  Y1, Y2;
    RECT R;

    GetClientRect(LB->hWnd, &R);
    OffsetRect(&R, 0, LB->VP.y);
    Y1=OL->YLoc; Y2=Y1+LB_ITEMHEIGHT;
    return Y1<R.top || Y2>R.bottom ? FALSE:TRUE;
    }



LOCAL(int) LB_Draw(ListBoxClass *LB, HDC hDC, LB_ONELINE *OL, CHAR SelFg)
    {
    int   Y1,Y2, RetY=0;
    SIZE  S;
    RECT  R;
    COLORREF BackCol, TextCol;

    BackCol=GetSysColor(SelFg!=0 ? COLOR_HIGHLIGHT:COLOR_WINDOW);
    TextCol=GetSysColor(SelFg!=0 ? COLOR_HIGHLIGHTTEXT:COLOR_WINDOWTEXT);

    GetClientRect(LB->hWnd, &R);
    Y1=OL->YLoc-LB->VP.y;
    Y2=Y1+LB_ITEMHEIGHT;

    if (Y1<R.bottom && Y2>R.top)
        {
        R.top=Y1;
        R.bottom=RetY=Y2;
        FillRectCol(hDC, &R, BackCol);

        if (OL->String[0]!=0)
            {
            MyGetTextExtent(hDC, OL->String, &S);

            SetBkColor(hDC, BackCol);
            SetTextColor(hDC, TextCol);
            MyTextOut(hDC, -LB->VP.x, (Y1+Y2-S.cy)>>1, OL->String);
            }
        }
    return RetY;
    }



LOCAL(VOID) LB_DrawAll(ListBoxClass *LB, HDC hDC)
    {
    int  Y=0;
    RECT R;
    LB_ONELINE *OL;

    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        Y=GetMax(Y, LB_Draw(LB, hDC, OL, LB->Curr==OL));

    //�����Ͱ� ���� �κ��� ä��
    GetClientRect(LB->hWnd, &R);
    if (Y<R.bottom)
        {
        R.top=Y;
        FillRectCol(hDC, &R, GetSysColor(COLOR_WINDOW));
        }
    }



//-----------------------------------------------------------------------------
//      ������ �־��� OL�� ��ȯ��
//-----------------------------------------------------------------------------
LOCAL(VOID) LB_SelChange(ListBoxClass *LB, LB_ONELINE *OL, int CBLB)
    {
    int  Y;
    RECT R;
    HDC  hDC;
    HWND hWnd;
    LB_ONELINE *OLTmp;

    hWnd=LB->hWnd;
    if (OL!=LB->Curr)
        {
        if (CBLB==IN_LB)
            {
            GetClientRect(hWnd, &R);
            if (LB_IsViewLine(LB, OL)!=FALSE)
                {
                if ((hDC=GetDC(hWnd))!=NULL)
                    {
                    LB_Draw(LB, hDC, LB->Curr, 0);
                    LB_Draw(LB, hDC, OL, 1);
                    ReleaseDC(hWnd, hDC);
                    }
                LB->Curr=OL;
                }
            else{
                LB->Curr=OL;
                if (OL->YLoc<LB->VP.y) LB->VP.y=OL->YLoc;
                else if (OL->YLoc+LB_ITEMHEIGHT>LB->VP.y+R.bottom)
                    {
                    LB->VP.y=Y=OL->YLoc+LB_ITEMHEIGHT-R.bottom;
                    OLTmp=OL;
                    while (OLTmp!=NULL)
                        {
                        if (OLTmp->YLoc<Y) break;
                        LB->VP.y=OLTmp->YLoc;
                        OLTmp=OLTmp->Prev;
                        }
                    }
                InvalidateRect(hWnd, NULL, TRUE);
                }
            }
        else{   //IN_CB
            LB->Curr=OL;
            InvalidateRect(hWnd, NULL, FALSE);
            }
        }

    PostParentCmdMsg(hWnd, LBN_SELCHANGE);
    }




LOCAL(VOID) LB_KeyFunc(ListBoxClass *LB, WPARAM wPrm, int LBCB)
    {
    int  Y;
    RECT R;
    HWND hWnd;
    LB_ONELINE *OL, *OLTmp;

    if ((OL=LB->Curr)==NULL) return;
    hWnd=LB->hWnd;
    GetClientRect(hWnd, &R);
    switch (wPrm)
        {
        case VK_HOME: OL=LB_GetFirst(LB); break;
        case VK_END:  OL=LB_GetLast(LB); break;
        case VK_UP:   OL=LB->Curr->Prev; break;
        case VK_DOWN: OL=LB->Curr->Next; break;

        case VK_PRIOR:
            OLTmp=LB->Curr;
            while (OLTmp!=NULL) //���̴� ���� Line�� ã���ϴ�
                {
                if (LB_IsViewLine(LB, OLTmp)==FALSE) break;
                OL=OLTmp;
                OLTmp=OLTmp->Prev;
                }
            Y=OL->YLoc-R.bottom+LB_ITEMHEIGHT;
            if (Y<1) {OL=LB_GetFirst(LB); break;}
            OLTmp=OL;
            while (OLTmp!=NULL)
                {
                if (OLTmp->YLoc<Y) break;
                OL=OLTmp;
                OLTmp=OLTmp->Prev;
                }
            break;

        case VK_NEXT:
            OLTmp=LB->Curr;
            while (OLTmp!=NULL) //���̴� �ǾƷ� Line�� ã���ϴ�
                {
                if (LB_IsViewLine(LB, OLTmp)==FALSE) break;
                OL=OLTmp;
                OLTmp=OLTmp->Next;
                }
            Y=OL->YLoc+R.bottom-LB_ITEMHEIGHT;
            OLTmp=OL;
            while (OLTmp!=NULL)
                {
                if (OLTmp->YLoc>Y) break;
                OL=OLTmp;
                OLTmp=OLTmp->Next;
                }
        }

    if (OL!=NULL) LB_SelChange(LB, OL, LBCB);
    }



LOCAL(int) LB_AddString(ListBoxClass *LB, LPCSTR Text)
    {
    int  Size;
    HWND hWnd;
    LB_ONELINE *OL, *Last;

    hWnd=LB->hWnd;
    Last=LB_GetLast(LB);
    Size=lstrlen(Text)+sizeof(LB_ONELINE);
    if ((OL=(LB_ONELINE*)AllocMem(Size, MEMOWNER_LB_AddString))==NULL) return LB_ERR;

    ZeroMem(OL, Size);
    OL->Prev=Last;
    //OL->Next=NULL;
    lstrcpy(OL->String, Text);
    if (Last!=NULL) Last->Next=OL;
    if (LB->Curr==NULL) LB->Curr=OL;

    LB_CalcPos(LB);
    InvalidateRect(hWnd, NULL, TRUE);
    return OL->LineNo;
    }



LOCAL(int) LB_InsertString(ListBoxClass *LB, int Idx, LPCSTR Text)
    {
    int  Size;
    HWND hWnd;
    LB_ONELINE *OL, *NOL;

    hWnd=LB->hWnd;
    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        if (OL->LineNo==Idx)
            {
            Size=lstrlen(Text)+sizeof(LB_ONELINE);
            if ((NOL=(LB_ONELINE*)AllocMem(Size, MEMOWNER_LB_InsertString))==NULL) break;
            ZeroMem(NOL, Size);
            lstrcpy(NOL->String, Text);

            NOL->Prev=OL->Prev;
            NOL->Next=OL;
            if (NOL->Prev!=NULL) NOL->Prev->Next=NOL;
            OL->Prev=NOL;
            if (LB->Curr==OL) LB->Curr=NOL;

            LB_CalcPos(LB);
            InvalidateRect(hWnd, NULL, TRUE);
            return Idx;
            }
    return LB_ERR;
    }



LOCAL(int) LB_GetLineText(ListBoxClass *LB, int Idx, LPSTR Buff)
    {
    LB_ONELINE *OL;

    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        if (OL->LineNo==Idx)
            {
            lstrcpy(Buff, OL->String);
            return lstrlen(Buff);
            }
    return LB_ERR;
    }



LOCAL(int) LB_GetLineCnt(ListBoxClass *LB)
    {
    int Cnt=0;
    LB_ONELINE *OL;

    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next) Cnt++;
    return Cnt;
    }



LOCAL(VOID) LB_WhatIsPoint(ListBoxClass *LB, POINT P)
    {
    HWND hWnd;
    LB_ONELINE *OL;

    hWnd=LB->hWnd;
    P.y+=LB->VP.y;
    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        if (P.y>=OL->YLoc && P.y<OL->YLoc+LB_ITEMHEIGHT)
            {
            LB_SelChange(LB, OL, IN_LB);
            if (LB->CBModeFg!=0) PostParentCmdMsg(hWnd, LBN_CLICK);
            break;
            }
    }



LOCAL(int) LB_SetCurSel(ListBoxClass *LB, int Idx, int LBCB)
    {
    LB_ONELINE *OL;

    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        if (OL->LineNo==Idx)
            {
            LB_SelChange(LB, OL, LBCB);
            return 0;
            }
    return LB_ERR;
    }



LOCAL(int) LB_SelectString(ListBoxClass *LB, int Idx, LPCSTR CmpStr, int CBLB)
    {
    LB_ONELINE *OL;

    OL=LB_GetFirst(LB);
    if (Idx!=-1)
        {
        Idx++;
        for (; OL!=NULL; OL=OL->Next)
            if (OL->LineNo==Idx) break;
        }

    if (OL!=NULL)
        {
        for (; OL!=NULL; OL=OL->Next)
            if (CompMemStr(OL->String, CmpStr)==0)
                {
                LB_SelChange(LB, OL, CBLB);
                return OL->LineNo;
                }
        }

    return LB_ERR;
    }



LOCAL(int) LB_DeleteString(ListBoxClass *LB, int Idx)
    {
    HWND hWnd;
    LB_ONELINE *OL;

    hWnd=LB->hWnd;
    for (OL=LB_GetFirst(LB); OL!=NULL; OL=OL->Next)
        if (OL->LineNo==Idx)
            {
            if (OL->Prev!=NULL) OL->Prev->Next=OL->Next;
            if (OL->Next!=NULL) OL->Next->Prev=OL->Prev;
            if (LB->Curr==OL)
                {
                LB->Curr=(OL->Next!=NULL) ? OL->Next:OL->Prev;
                PostParentCmdMsg(hWnd, LBN_SELCHANGE);
                }
            FreeMem(OL);
            LB_CalcPos(LB);
            InvalidateRect(hWnd, NULL, TRUE);
            return 0;
            }
    return LB_ERR;
    }



//-----------------------------------------------------------------------------
//      ListBox Window Proc
//-----------------------------------------------------------------------------
WNDFNC(ListBoxWndProc)
    {
    RECT R;
    PAINTSTRUCT   PS;
    ListBoxClass *LB;

    LB=(ListBoxClass*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            if ((LB=(ListBoxClass*)((CREATESTRUCT*)lPrm)->lpCreateParams)==NULL)
                {
                if ((LB=AllocMemS(ListBoxClass, MEMOWNER_LB_WMCREATE))==NULL) return -1;
                ZeroMem(LB, sizeof(ListBoxClass));
                }
            else LB->hWndCB=LB->hWnd;   //�޺��ڽ��� ������ ��

            LB->hWnd=hWnd;
            SetWindowLong(hWnd, 0, (LONG)LB);

            Ret0:
            return 0;

        case WM_DESTROY:
            if (LB!=NULL)
                {
                if (LB->CBModeFg==0)
                    {
                    LB_Release(LB);
                    FreeMem(LB);
                    SetWindowLong(hWnd, 0, 0);
                    }
                else{
                    LB->hWnd=LB->hWndCB;
                    LB->hWndCB=NULL;
                    }
                }
            goto Ret0;

        case LB_INITSCROLLBAR:  //�� �޼����� ��ü������ �޼����̰� �޺��ڽ��� �� ���
            LB_CalcPos(LB);
            SetScrollPos(hWnd, SB_VERT, LB->VP.y, TRUE);

            GetClientRect(hWnd, &R);
            SetScrollPageSize(hWnd, SB_VERT, R.bottom, FALSE);
            goto Ret0;

        case WM_PAINT:
            BeginPaint(hWnd, &PS);
            if (LB) LB_DrawAll(LB, PS.hdc);
            EndPaint(hWnd, &PS);
            goto Ret0;

        case WM_KEYDOWN:
            if (PostParentSpecKeyMsg(hWnd, wPrm, lPrm)==FALSE)
                LB_KeyFunc(LB, wPrm, IN_LB);
            goto Ret0;

        case WM_LBUTTONDOWN:
            {
            POINT P;
            P.x=LoWord(lPrm);
            P.y=HiWord(lPrm);
            LBtnCtrlFocus(hWnd);
            LB_WhatIsPoint(LB, P);
            goto Ret0;
            }

        case WM_VSCROLL:
            {
            int Pos, Min, Max, ScrollCode, NewVP;
            ScrollCode=LoWord(wPrm);
            Pos=GetScrollPos(hWnd, SB_VERT);
            GetScrollRange(hWnd, SB_VERT, &Min, &Max);
            if (ScrollCode==SB_LINEUP) Pos-=LB_ITEMHEIGHT;
            else if (ScrollCode==SB_LINEDOWN) Pos+=LB_ITEMHEIGHT;
            else if (ScrollCode==SB_THUMBTRACK || ScrollCode==SB_THUMBPOSITION) Pos=HiInt16(wPrm);
            if (Pos>=Min && Pos<Max)
                {
                NewVP=(Pos+LB_ITEMHEIGHT-1)/LB_ITEMHEIGHT*LB_ITEMHEIGHT;
                SetScrollPos(hWnd, SB_VERT, Pos, TRUE);
                if (LB->VP.y!=NewVP)
                    {
                    LB->VP.y=NewVP;
                    InvalidateRect(hWnd, NULL, FALSE);
                    }
                }
            goto Ret0;
            }

        case LB_ADDSTRING:      return LB_AddString(LB, (LPSTR)lPrm);
        case LB_INSERTSTRING:   return LB_InsertString(LB, wPrm, (LPSTR)lPrm);
        case LB_DELETESTRING:   return LB_DeleteString(LB, wPrm);
        case LB_GETCURSEL:      return LB->Curr==NULL ? LB_ERR:LB->Curr->LineNo;
        case LB_GETTEXT:        return LB_GetLineText(LB, wPrm, (LPSTR)lPrm);
        case LB_GETCOUNT:       return LB_GetLineCnt(LB);

        case LB_RESETCONTENT:
            LB_Release(LB);
            InvalidateRect(hWnd, NULL, TRUE);
            goto Ret0;

        case LB_SETCURSEL:      return LB_SetCurSel(LB, wPrm, IN_LB);
        case LB_SELECTSTRING:   return LB_SelectString(LB, wPrm, (LPSTR)lPrm, IN_LB);
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




///////////////////////////////////////////////////////////////////////////////
//                      ComboBox Window                                      //
///////////////////////////////////////////////////////////////////////////////

#define ComboViewWndHeight      28
#define ComboDDBtnID            7954
#define ComboDDListID           7955
#define ComboBtnSize            23
#define ComboBtnSpace           25
//#define ComboLBWidth          105
#define ComboLBPosX             0


#define ComboDlgLBID            100
#define ComboDlgUpBTID          101
#define ComboDlgDownBTID        102


typedef struct _ComboBoxDlgArg
    {
    ListBoxClass *LB;
    HWND hWndCombo;
    }ComboBoxDlgArg;


DLGFNC(ComboBoxDlgProc)
    {
    RECT R;
    HWND hWndChild;
    ComboBoxDlgArg *Arg;

    switch (Msg)
        {
        case WM_INITDIALOG:
            SetWindowLong(hWnd, DWL_USER, lPrm);
            Arg=(ComboBoxDlgArg*)lPrm;

            GetClientRect(hWnd, &R);
            hWndChild=CreateWindow("ListBox", "", WS_VISIBLE|WS_CHILD|WS_TABSTOP|WS_VSCROLL, 0, 0, R.right, R.bottom, hWnd, (HMENU)ComboDlgLBID, HInst, (LPVOID)Arg->LB);  //����: ListBoxWndProc()
            SetScrollImage(hWndChild, SB_VERT, 10, FALSE);
            SendMessage(hWndChild, LB_INITSCROLLBAR, 0, 0);
            SetFocus(hWndChild);

            RetTrue:
            return TRUE;

        case WM_OUTSIDELBTNDOWN: goto EndDlg;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case ComboDlgLBID:
                    switch (WMCMDNOTIFY)
                        {
                        case LBN_SELCHANGE:
                            Arg=(ComboBoxDlgArg*)GetWindowLongPtr(hWnd, DWL_USER);
                            InvalidateRect(Arg->hWndCombo, NULL, FALSE);
                            UpdateWindow(Arg->hWndCombo);
                            break;

                        case LBN_CLICK: goto EndDlg;
                        }
                    return 0;

                case IDOK:
                case IDCANCEL:
                    EndDlg:
                    EndDialog(hWnd, 0);
                }
            goto RetTrue;
        }
    return FALSE;
    }



LOCAL(VOID) LB_ComboDraw(ListBoxClass *LB, HWND hWndCB, HDC hDC)
    {
    RECT R;
    SIZE S;
    COLORREF BackCol, TextCol;
    CHAR  Buff[40];
    LB_ONELINE *Curr;

    BackCol=GetSysColor(COLOR_WINDOW);
    TextCol=GetSysColor(COLOR_WINDOWTEXT);

    Curr=LB->Curr;
    GetClientRect(hWndCB, &R);
    MyGetTextExtent(hDC, Curr ? Curr->String:"A", &S);
    R.top=(R.bottom-S.cy)>>1;
    R.bottom=R.top+S.cy;
    R.left=ComboLBPosX;
    R.right-=ComboBtnSize;

    FillRectCol(hDC, &R, BackCol);

    if (Curr!=NULL)
        {
        SetBkColor(hDC, BackCol);
        SetTextColor(hDC, TextCol);
        CutStringLen(hDC, Buff, Curr->String, R.right-R.left);
        MyTextOut(hDC, R.left, R.top, Buff);
        }
    }



//-----------------------------------------------------------------------------
//      ��ȭ���� ȣ��
//-----------------------------------------------------------------------------
LOCAL(int) CallDialogBox(LPCSTR DlgTmp, HWND hWndPar, DLGPROC DlgProc, LPARAM lPrm)
    {
    int  Rslt;
    HWND hWndFocus;

    hWndFocus=GetFocus();
    Rslt=DialogBoxParam(HInst, DlgTmp, hWndPar, DlgProc, lPrm);
    SetFocus(hWndFocus);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ComboBox Window Proc
//-----------------------------------------------------------------------------
WNDFNC(ComboBoxWndProc)
    {
    LRESULT LRslt;
    ListBoxClass *LB;

    LB=(ListBoxClass*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            {
            RECT R;
            CHAR Buff[16];

            GetClientRect(hWnd, &R);
            JsprintfN(Buff, sizeof(Buff), "<%d %d %d>", COMBOBTNICONNO, CXCOMBOBTNIMAGE, CYCOMBOBTNIMAGE);
            CreateWindow(ButtonStr, Buff, BS_PUSHBUTTON|WS_CHILD|WS_VISIBLE,
                        R.right-ComboBtnSize, 0, ComboBtnSize, R.bottom,
                        hWnd, (HMENU)ComboDDBtnID, HInst, NULL);
            LRslt=ListBoxWndProc(hWnd, Msg, wPrm, lPrm);
            if ((LB=(ListBoxClass*)GetWindowLongPtr(hWnd, 0))!=NULL) LB->CBModeFg=1;
            return LRslt;
            }

        case WM_DESTROY:
            if (LB!=NULL) LB->CBModeFg=0;
            return ListBoxWndProc(hWnd, Msg, wPrm, lPrm);

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            LB_ComboDraw(LB, hWnd, PS.hdc);
            EndPaint(hWnd, &PS);
            Ret0:
            return 0;
            }

        case WM_COMMAND:
            if (WMCMDID==ComboDDBtnID)
                {
                RECT R;
                ComboBoxDlgArg Arg;
                LB_ONELINE *OL;
                DIALOGTEMPLATE DlgTemplate[2];

                ZeroMem(DlgTemplate, sizeof(DlgTemplate));
                DlgTemplate[0].Title=NullStr;
                DlgTemplate[0].ID=(HMENU)NullStr;   //�ε���0�� ID���� ��ȭ���� ������ �۲� ���ڿ��� ��, �� (HMENU) "10, \"���� ����\""
                DlgTemplate[0].ClassName="#32770";
                DlgTemplate[0].Style=WS_POPUP|WS_BORDER|WS_VISIBLE;

                if ((OL=LB->Curr)==NULL) goto Ret0;
                Arg.LB=LB;
                Arg.hWndCombo=hWnd;
                GetWindowRect(hWnd, &R);
                DlgTemplate[0].X=R.left;
                DlgTemplate[0].Y=R.bottom;
                DlgTemplate[0].Sx=R.right-R.left;
                DlgTemplate[0].Sy=GetMin(LCD_LogResolutionY-R.bottom-10, LCD_LogResolutionY/2);
                CallDialogBox(MAKEINTRESOURCE(DlgTemplate), hWnd, ComboBoxDlgProc, (LPARAM)&Arg);
                if (OL!=LB->Curr) PostParentCmdMsg(hWnd, CBN_SELCHANGE);
                }
            goto Ret0;

        case WM_LBUTTONDOWN:
            PostMessage(hWnd, WM_COMMAND, ComboDDBtnID, 0);
            //LBtnCtrlFocus(hWnd);
            goto Ret0;

        case WM_KEYDOWN:
            if (PostParentSpecKeyMsg(hWnd, wPrm, lPrm)==FALSE)
                LB_KeyFunc(LB, wPrm, IN_CB);
            goto Ret0;

        case CB_ADDSTRING:      return LB_AddString(LB, (LPSTR)lPrm);
        case CB_INSERTSTRING:   return LB_InsertString(LB, wPrm, (LPSTR)lPrm);
        case CB_DELETESTRING:   return LB_DeleteString(LB, wPrm);
        case CB_GETCURSEL:      return LB->Curr==NULL ? CB_ERR:LB->Curr->LineNo;
        case CB_GETLBTEXT:      return LB_GetLineText(LB, wPrm, (LPSTR)lPrm);
        case CB_GETCOUNT:       return LB_GetLineCnt(LB);
        case CB_SETCURSEL:      return LB_SetCurSel(LB, wPrm, IN_CB);
        case CB_SELECTSTRING:   return LB_SelectString(LB, wPrm, (LPSTR)lPrm, IN_CB);

        case CB_RESETCONTENT:
            LB_Release(LB);
            InvalidateRect(hWnd, NULL, TRUE);
            goto Ret0;
        }
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




//-----------------------------------------------------------------------------
//      ComboBox�� ���ڿ��� �߰��Ѵ�, �߰��� �ε��� ����
//-----------------------------------------------------------------------------
int WINAPI CB_AddString(HWND hWnd, int CBID, LPCSTR ItemStr)
    {
    return (int)SendDlgItemMessage(hWnd, CBID, CB_ADDSTRING, 0, (LPARAM)ItemStr);
    }



//-----------------------------------------------------------------------------
//      ComboBox Item����
//-----------------------------------------------------------------------------
VOID WINAPI CB_SetCurSel(HWND hWnd, int CBID, int Idx)
    {
    if (CBID!=0) hWnd=GetDlgItem(hWnd, CBID);
    SendMessage(hWnd, CB_SETCURSEL, Idx, 0);
    }



//-----------------------------------------------------------------------------
//      �޺��ڽ����� �־��� ���ڿ��� ã��
//      StartIndex ã�� ���� �ε���
//-----------------------------------------------------------------------------
int WINAPI CB_SelectString(HWND hWnd, int CBID, int StartIndex, LPCSTR FindStr)
    {
    if (CBID!=0) hWnd=GetDlgItem(hWnd, CBID);
    return (int)SendMessage(hWnd, CB_SELECTSTRING, StartIndex-1, (LPARAM)FindStr);
    }




//-----------------------------------------------------------------------------
//      ComboBox�� ������ġ�� ���ڿ��� ��´�
//-----------------------------------------------------------------------------
int WINAPI CB_GetCurSelText(HWND hWnd, int ID, LPSTR Buff)
    {
    int I;

    if (Buff!=NULL) Buff[0]=0;
    if (ID==0)
        {
        if ((I=(int)SendMessage(hWnd, CB_GETCURSEL, 0, 0))!=CB_ERR && Buff!=NULL)
            SendMessage(hWnd, CB_GETLBTEXT, I, (LPARAM)Buff);
        }
    else{
        if ((I=(int)SendDlgItemMessage(hWnd, ID, CB_GETCURSEL, 0, 0))!=CB_ERR && Buff!=NULL)
            SendDlgItemMessage(hWnd, ID, CB_GETLBTEXT, I, (LPARAM)Buff);
        }
    return I;
    }




///////////////////////////////////////////////////////////////////////////////
//                      SysHeader Window                                     //
///////////////////////////////////////////////////////////////////////////////



typedef struct _SysHeaderClass
    {
    HWND hWnd;
    WORD ItemCount;
    HDITEM *HdItem;
    } SysHeaderClass;




//-----------------------------------------------------------------------------
//      �ε����� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) HDC_ResetIndex(SysHeaderClass *SH)
    {
    int I;
    HDITEM *HD;

    for (HD=SH->HdItem,I=0; HD!=NULL; HD=HD->Next,I++) HD->iOrder=I;
    SH->ItemCount=I;
    }




//-----------------------------------------------------------------------------
//      Insert Item (�߰��� ��ġ�� ����)
//-----------------------------------------------------------------------------
LOCAL(int) HDC_InsertItem(SysHeaderClass *SH, int Index, HDITEM *HDI)
    {
    int Rslt=-1;
    HDITEM *HD, *PrevHD=NULL, *CopyedHD;

    if (SH==NULL) goto ProcExit;

    if ((CopyedHD=AllocMemS(HDITEM, MEMOWNER_HD_InsertItem1))==NULL) goto ProcExit;
    ZeroMem(CopyedHD, sizeof(HDITEM));
    CopyedHD->mask=HDI->mask;
    if (HDI->mask & HDI_FORMAT) CopyedHD->fmt=HDI->fmt;
    if (HDI->mask & HDI_WIDTH)  CopyedHD->cxy=HDI->cxy;
    if (HDI->mask & HDI_TEXT)   CopyedHD->pszText=CopyStr(HDI->pszText, MEMOWNER_HD_InsertItem2);

    for (HD=SH->HdItem; ;HD=HD->Next)
        {
        if (HD==NULL || HD->iOrder==Index)
            {
            Rslt=HD ? Index:SH->ItemCount;
            if (PrevHD!=NULL) PrevHD->Next=CopyedHD; else SH->HdItem=CopyedHD;
            CopyedHD->Next=HD;
            HDC_ResetIndex(SH);
            break;
            }
        PrevHD=HD;
        }

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Delete Item
//-----------------------------------------------------------------------------
LOCAL(BOOL) HDC_DeleteItem(SysHeaderClass *SH, int Index)
    {
    int Rslt=FALSE;
    HDITEM *HD, *PrevHD=NULL, *DelHD;

    if (SH==NULL) goto ProcExit;
    for (HD=SH->HdItem; HD!=NULL; HD=HD->Next)
        {
        if (HD->iOrder==Index)
            {
            DelHD=HD; HD=HD->Next;
            if (PrevHD!=NULL) PrevHD->Next=HD; else SH->HdItem=HD;
            FreeMem(DelHD->pszText);
            FreeMem(DelHD);
            HDC_ResetIndex(SH);
            Rslt++;
            break;
            }
        PrevHD=HD;
        }

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Get Item
//-----------------------------------------------------------------------------
LOCAL(BOOL) HDC_GetItem(SysHeaderClass *SH, int Index, HDITEM *HDI)
    {
    int Rslt=FALSE;
    HDITEM *HD;

    if (SH==NULL) goto ProcExit;
    for (HD=SH->HdItem; HD!=NULL; HD=HD->Next)
        {
        if (HD->iOrder==Index) {*HDI=*HD; Rslt++; break;}
        }

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Set Item
//-----------------------------------------------------------------------------
LOCAL(BOOL) HDC_SetItem(SysHeaderClass *SH, int Index, HDITEM *HDI)
    {
    int Rslt=FALSE;
    HDITEM *HD;

    if (SH==NULL) goto ProcExit;
    for (HD=SH->HdItem; HD!=NULL; HD=HD->Next)
        {
        if (HD->iOrder==Index)
            {
            if (HDI->mask & HDI_FORMAT) HD->fmt=HDI->fmt;
            if (HDI->mask & HDI_WIDTH)  HD->cxy=HDI->cxy;
            if (HDI->mask & HDI_TEXT)
                {
                FreeMem(HD->pszText);
                HD->pszText=CopyStr(HDI->pszText, MEMOWNER_HD_SetItem);
                }
            Rslt++;
            break;
            }
        }

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Draw SysHeader
//-----------------------------------------------------------------------------
LOCAL(VOID) HDC_Draw(SysHeaderClass *SH, HDC hDC)
    {
    RECT R, AR;
    HWND hWnd;
    HPEN hPenOld;
    HDITEM *HD;

    if (SH==NULL) goto ProcExit;
    hWnd=SH->hWnd;
    GetClientRect(hWnd, &AR);
    SelectObject(hDC, GetStockObject(WHITE_PEN));
    SelectObject(hDC, GetStockObject(NULL_BRUSH));
    Rectangle(hDC, AR.left, AR.top, AR.right, AR.bottom);
    InflateRect(&AR, -1, -1);

    hPenOld=(HPEN)SelectObject(hDC, CreatePen(PS_SOLID, 1, COL_LIGHTGRAY));
    R=AR;
    for (HD=SH->HdItem; HD!=NULL; HD=HD->Next)
        {
        if (R.left>=AR.right) break;
        R.right=R.left+HD->cxy;
        Rectangle(hDC, R.left, R.top, R.right, R.bottom);

        InflateRect(&R, -2, -2);
        if (HD->pszText)
            {
            int Align=DT_LEFT;
            if (HD->fmt==HDF_CENTER) Align=DT_CENTER;
            else if (HD->fmt==HDF_RIGHT) Align=DT_RIGHT;
            DrawText(hDC, HD->pszText, -1, &R, Align|DT_VCENTER|DT_SINGLELINE);
            }
        InflateRect(&R, 2, 2);
        R.left=R.right;
        }
    DeleteObject(SelectObject(hDC, hPenOld));

    ProcExit:;
    }




//-----------------------------------------------------------------------------
//      SysHeader Window Proc
//-----------------------------------------------------------------------------
WNDFNC(SysHeaderWndProc)
    {
    SysHeaderClass *SH;

    SH=(SysHeaderClass*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            {
            if ((SH=AllocMemS(SysHeaderClass, MEMOWNER_SH_WMCREATE))==NULL) return -1;
            ZeroMem(SH, sizeof(SysHeaderClass));
            SH->hWnd=hWnd;
            SetWindowLongPtr(hWnd, 0, (LONG)SH);
            return 0;
            }

        case WM_DESTROY:
            if (SH!=NULL)
                {
                while (HDC_DeleteItem(SH, 0));
                FreeMem(SH);
                SetWindowLongPtr(hWnd, 0, 0);
                }
            goto Ret0;

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            HDC_Draw(SH, PS.hdc);
            EndPaint(hWnd, &PS);
            Ret0:
            return 0;
            }

        //case WM_COMMAND: goto Ret0;
        //case WM_LBUTTONDOWN: goto Ret0;
        //case WM_KEYDOWN: goto Ret0;

        case HDM_GETITEMCOUNT: return SH ? SH->ItemCount:0;
        case HDM_INSERTITEM:   return HDC_InsertItem(SH, wPrm, (HDITEM*)lPrm);
        case HDM_DELETEITEM:   return HDC_DeleteItem(SH, wPrm);
        case HDM_GETITEM:      return HDC_GetItem(SH, wPrm, (HDITEM*)lPrm);
        case HDM_SETITEM:      return HDC_SetItem(SH, wPrm, (HDITEM*)lPrm);
        }
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




//-----------------------------------------------------------------------------
//      ����� �߰���
//-----------------------------------------------------------------------------
int WINAPI HDM_InsertItem(HWND hWnd, int HDID, int Index, LPCSTR Text, int Width, int Format)
    {
    HDITEM HD;

    if (HDID!=0) hWnd=GetDlgItem(hWnd, HDID);

    ZeroMem(&HD, sizeof(HDITEM));
    HD.mask=HDI_FORMAT|HDI_WIDTH|HDI_TEXT;
    HD.fmt=Format;
    HD.cxy=Width;
    HD.pszText=(LPSTR)Text;
    return SendMessage(hWnd, HDM_INSERTITEM, Index, (LPARAM)&HD);
    }




///////////////////////////////////////////////////////////////////////////////
//                          ListView Window
///////////////////////////////////////////////////////////////////////////////


typedef struct _LV_ITEM_INTERNAL
    {
    struct _LV_ITEM_INTERNAL *Next;
    WORD    ItemNo;
    WORD    ColQty;             //Columns�׸��
    WORD    State;
    LPARAM  lParam;
    STRPOOL Columns[1];         //�÷� ���ڿ� ���
    } LV_ITEM_INTERNAL;



typedef struct _ListViewClass
    {
    HWND hWnd;
    HWND hWndHdr;               //����� �ڵ�
    WORD ItemQty;               //������� �� ��
    STRINGPOOL *StrPool;
    WORD ViewPortItemNo;        //ȭ�鿡 ù���� Item ��ȣ
    BYTE ViewPortColmNo;        //ȭ�� �� ������ Column ��ȣ
    BYTE AvgLineHeight;         //���� ����
    LV_ITEM_INTERNAL *LvItem;
    } ListViewClass;




//-----------------------------------------------------------------------------
//      �ε����� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) LVC_ResetIndex(ListViewClass *LVC)
    {
    int I;
    LV_ITEM_INTERNAL *LV;

    for (LV=LVC->LvItem,I=0; LV!=NULL; LV=LV->Next,I++) LV->ItemNo=I;
    LVC->ItemQty=I;
    }




//-----------------------------------------------------------------------------
//      Insert Item (�߰��� ��ġ�� ����)
//-----------------------------------------------------------------------------
LOCAL(int) LVC_InsertItem(ListViewClass *LVC, LV_ITEM *LVI)
    {
    int Rslt=-1, Size, ColQty;
    LV_ITEM_INTERNAL *LV, *PrevLV=NULL, *CopyedLV;

    if (LVC==NULL) goto ProcExit;

    ColQty=SendMessage(LVC->hWndHdr, HDM_GETITEMCOUNT, 0, 0);
    Size=(ColQty-1)*sizeof(STRPOOL)+sizeof(LV_ITEM_INTERNAL);                   //-1�� �� ������ LV_ITEM_INTERNAL �� �ȿ� STRPOOL 1�� �⺻���� ���Ե�
    if ((CopyedLV=(LV_ITEM_INTERNAL*)AllocMem(Size, MEMOWNER_LVC_InsertItem))==NULL) goto ProcExit;
    ZeroMem(CopyedLV, Size);
    CopyedLV->ColQty=ColQty;
    if (LVI->mask & LVIF_TEXT && ColQty>0)  CopyedLV->Columns[0]=StrPool_Add(&LVC->StrPool, LVI->pszText);
    if (LVI->mask & LVIF_PARAM) CopyedLV->lParam=LVI->lParam;

    for (LV=LVC->LvItem; ;LV=LV->Next)
        {
        if (LV==NULL || LV->ItemNo==LVI->iItem)
            {
            Rslt=LV ? LVI->iItem:LVC->ItemQty;
            if (PrevLV!=NULL) PrevLV->Next=CopyedLV; else LVC->LvItem=CopyedLV;
            CopyedLV->Next=LV;
            LVC_ResetIndex(LVC);
            break;
            }
        PrevLV=LV;
        }
    InvalidateRect(LVC->hWnd, NULL, TRUE);

    ProcExit:
    return Rslt;
    }




LOCAL(int) LVC_InsertColumn(ListViewClass *LVC, int Column, LV_COLUMN *LVCM)
    {
    return HDM_InsertItem(LVC->hWndHdr, 0, Column, LVCM->pszText, LVCM->cx, LVCM->fmt);
    }




LOCAL(BOOL) LVC_DeleteItem(ListViewClass *LVC, int ItemNo)
    {
    int Rslt=FALSE;
    LV_ITEM_INTERNAL *LV, *PrevLV=NULL, *DelLV;

    if (LVC==NULL) goto ProcExit;
    for (LV=LVC->LvItem; LV!=NULL; LV=LV->Next)
        {
        if (LV->ItemNo==ItemNo)
            {
            DelLV=LV; LV=LV->Next;
            if (PrevLV!=NULL) PrevLV->Next=LV; else LVC->LvItem=LV;
            FreeMem(DelLV);
            LVC_ResetIndex(LVC);
            Rslt++;
            break;
            }
        PrevLV=LV;
        }
    InvalidateRect(LVC->hWnd, NULL, TRUE);


    ProcExit:
    return Rslt;
    }




LOCAL(LPCSTR) LVC_GetText(ListViewClass *LVC, LV_ITEM_INTERNAL *LV, int ColNo)
    {
    LPCSTR Rslt=NullStr;

    if (ColNo<LV->ColQty) Rslt=StrPool_Get(LVC->StrPool, LV->Columns[ColNo]);
    return Rslt;
    }



LOCAL(BOOL) LVC_GetItemText(ListViewClass *LVC, int ItemNo, LV_ITEM *LVI)
    {
    int Rslt=FALSE, ColNo;
    LV_ITEM_INTERNAL *LV;

    if (LVC==NULL || LVI->cchTextMax==0) goto ProcExit;
    LVI->pszText[0]=0;
    ColNo=LVI->iSubItem;
    for (LV=LVC->LvItem; LV!=NULL; LV=LV->Next)
        {
        if (LV->ItemNo==ItemNo)
            {
            lstrcpyn(LVI->pszText, LVC_GetText(LVC, LV, ColNo), LVI->cchTextMax);
            Rslt++;
            break;
            }
        }
    ProcExit:
    return Rslt;
    }




LOCAL(BOOL) LVC_SetItemText(ListViewClass *LVC, int ItemNo, LV_ITEM *LVI)
    {
    int Rslt=FALSE, ColNo, Size;
    LV_ITEM_INTERNAL *LV, *NewLV, *PrevLV=NULL;

    if (LVC==NULL || (LVI->mask & LVIF_TEXT)==0) goto ProcExit;
    ColNo=LVI->iSubItem;
    for (LV=LVC->LvItem; LV!=NULL; LV=LV->Next)
        {
        if (LV->ItemNo==ItemNo)
            {
            if (ColNo>=LV->ColQty)
                {
                Size=ColNo*sizeof(STRPOOL)+sizeof(LV_ITEM_INTERNAL);            //LV_ITEM_INTERNAL �ȿ� �⺻���� STRPOOL�̰� 1���� ���ԵǾ� ����
                if ((NewLV=(LV_ITEM_INTERNAL*)AllocMem(Size, MEMOWNER_LVC_SetItemText))==NULL) goto ProcExit;
                CopyMem(NewLV, LV, (LV->ColQty-1)*sizeof(STRPOOL)+sizeof(LV_ITEM_INTERNAL));
                NewLV->ColQty=ColNo+1;
                if (PrevLV) PrevLV->Next=NewLV; else LVC->LvItem=NewLV;
                FreeMem(LV);
                LV=NewLV;
                }
            LV->Columns[ColNo]=StrPool_Add(&LVC->StrPool, LVI->pszText);
            Rslt++;
            break;
            }
        PrevLV=LV;
        }
    InvalidateRect(LVC->hWnd, NULL, TRUE);

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �־��� ItemNo�� �ش��ϴ� �������� ����
//-----------------------------------------------------------------------------
LOCAL(LV_ITEM_INTERNAL*) LVC_GetItem(ListViewClass *LVC, int ItemNo)
    {
    LV_ITEM_INTERNAL *LV;

    for (LV=LVC->LvItem; LV!=NULL; LV=LV->Next)
        {
        if (LV->ItemNo==ItemNo) break;
        }
    return LV;
    }




//-----------------------------------------------------------------------------
//      ListView Draw
//-----------------------------------------------------------------------------
LOCAL(VOID) LVC_Draw(ListViewClass *LVC, HDC hDC)
    {
    int  Col, Align;
    RECT R, AR;
    HDITEM HDI;
    LV_ITEM_INTERNAL *LV;

    if ((LV=LVC_GetItem(LVC, LVC->ViewPortItemNo))==NULL) goto ProcExit;

    //if (LVC->hFont) SelectObject(hDC, LVC->hFont);
    GetClientRect(LVC->hWnd, &AR);
    GetClientRect(LVC->hWndHdr, &R);
    for (; LV!=NULL; LV=LV->Next)
        {
        if ((R.top=R.bottom)>=AR.bottom) break;
        R.bottom+=LVC->AvgLineHeight;
        R.right=0;
        for (Col=LVC->ViewPortColmNo; Col<LV->ColQty; Col++)
            {
            if ((R.left=R.right)>=AR.right) break;
            if (SendMessage(LVC->hWndHdr, HDM_GETITEM, Col, (LPARAM)&HDI)==FALSE) break;
            R.right+=HDI.cxy;
            //Rectangle(hDC, R.left, R.top, R.right, R.bottom);

            Align=DT_LEFT;
            if (HDI.fmt==HDF_CENTER) Align=DT_CENTER;
            else if (HDI.fmt==HDF_RIGHT) Align=DT_RIGHT;
            MyDrawText(hDC, LVC_GetText(LVC, LV, Col), &R, Align|DT_VCENTER|DT_SINGLELINE);
            }
        }
    ProcExit:;
    }




//-----------------------------------------------------------------------------
//      ListView Window Proc
//-----------------------------------------------------------------------------
WNDFNC(ListViewWndProc)
    {
    RECT R;
    ListViewClass *LVC;

    LVC=(ListViewClass*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:
            {
            if ((LVC=AllocMemS(ListViewClass, MEMOWNER_LVC_WMCREATE))==NULL) return -1;
            ZeroMem(LVC, sizeof(ListViewClass));
            LVC->hWnd=hWnd;
            SetWindowLongPtr(hWnd, 0, (LONG)LVC);
            GetClientRect(hWnd, &R);

            LVC->AvgLineHeight=GetWindowTextHeight(hWnd)+2;
            LVC->hWndHdr=CreateWindow(WC_HEADER, NullStr, WS_CHILD|WS_VISIBLE,  0, 0, R.right, LVC->AvgLineHeight+4, hWnd, (HMENU)1, HInst, NULL);
            return 0;
            }

        case WM_DESTROY:
            if (LVC!=NULL)
                {
                while (LVC_DeleteItem(LVC, 0));
                StrPool_Free(LVC->StrPool);
                FreeMem(LVC);
                SetWindowLongPtr(hWnd, 0, 0);
                }
            goto Ret0;

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            LVC_Draw(LVC, PS.hdc);
            EndPaint(hWnd, &PS);
            Ret0:
            return 0;
            }

        //case WM_COMMAND: goto Ret0;
        //case WM_LBUTTONDOWN: goto Ret0;
        //case WM_KEYDOWN: goto Ret0;

        case LVM_GETHEADER:
        case LVM_GETITEMSTATE:
        case LVM_DELETEALLITEMS: return 0;

        case LVM_GETITEMCOUNT: return LVC ? LVC->ItemQty:0;
        case LVM_INSERTITEM:   return LVC_InsertItem(LVC, (LV_ITEM*)lPrm);
        case LVM_DELETEITEM:   return LVC_DeleteItem(LVC, wPrm);
        //case LVM_GETITEM:    return LVC_GetItem(LVC, (LV_ITEM*)lPrm);
        //case LVM_SETITEM:    return LVC_SetItem(LVC, (LV_ITEM*)lPrm);
        case LVM_GETITEMTEXT:  return LVC_GetItemText(LVC, wPrm, (LV_ITEM*)lPrm);
        case LVM_SETITEMTEXT:  return LVC_SetItemText(LVC, wPrm, (LV_ITEM*)lPrm);
        case LVM_INSERTCOLUMN: return LVC_InsertColumn(LVC, wPrm, (LV_COLUMN*)lPrm);
        }
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




//-----------------------------------------------------------------------------
//      ListView�� �ķ��߰�
//      Align= LVCFMT_LEFT/LVCFMT_CENTER/LVCFMT_RIGHT
//-----------------------------------------------------------------------------
VOID WINAPI LV_InsertColumn(HWND hWnd, int LVID, int Column, int Width, LPCSTR ColumnName, int Align)
    {
    LV_COLUMN  LVC;

    LVC.mask    = LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM;
    LVC.fmt     = Align;
    LVC.cx      = Width;
    LVC.pszText = (LPSTR)ColumnName;
    //LVC.iSubItem=Column;      //���ص� ��
    SendDlgItemMessage(hWnd, LVID, LVM_INSERTCOLUMN, Column, (LPARAM)&LVC);
    }




//-----------------------------------------------------------------------------
//      LV �÷��� �����մϴ�
//      DefWidths[] �ȿ� ��ġ�� ����̸� ��ȭ���� ��ǥ������ ũ��, �����̸� �ȼ� ũ��
//-----------------------------------------------------------------------------
VOID WINAPI LV_SetColumn(HWND hWnd, int LVID, LPCSTR TitleArays, LPCINT16 DefWidths, LPCBYTE Aligns, int ColumnQty)
    {
    int I;
    LPSTR  LoadTitle=NULL;
    LPCSTR lp;

    if (TitleArays==NULL)
        {
        LoadTitle=GetDlgItemTextMem(hWnd, LVID, MEMOWNER_LV_SetColumn);
        ChangeCha(LoadTitle, '|', 0);
        TitleArays=LoadTitle;
        }

    //SendDlgItemMessage(hWnd, LVID, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);
    for (I=0, lp=TitleArays; I<ColumnQty; I++, lp=GetNextStr(lp))
        LV_InsertColumn(hWnd, LVID, I, DefWidths[I], lp, Aligns!=NULL ? Aligns[I]:LVCFMT_LEFT);

    //LoadLVColumnWidth(hWnd, LVID, ColumnQty);
    FreeMem(LoadTitle);
    }




//-----------------------------------------------------------------------------
//      ListView�� Item���� ����
//-----------------------------------------------------------------------------
int WINAPI LV_GetItemCount(HWND hWnd, int LVID)
    {
    if (LVID!=0) hWnd=GetDlgItem(hWnd, LVID);
    return (int)SendMessage(hWnd, LVM_GETITEMCOUNT, 0, 0);
    }




//-----------------------------------------------------------------------------
//      ListView���� ���� �߰�
//-----------------------------------------------------------------------------
int WINAPI LV_InsertItem(HWND hWnd, int LVID, int Row, LPCSTR DataStr, LPARAM ItemData)
    {
    LV_ITEM LVI;

    if (LVID!=0) hWnd=GetDlgItem(hWnd, LVID);
    if (Row<0) Row=LV_GetItemCount(hWnd, 0);
    ZeroMem(&LVI, sizeof(LV_ITEM));
    LVI.mask    = LVIF_TEXT|LVIF_PARAM;
    LVI.iSubItem= 0;            //�� �ָ� ���� ����
    LVI.iItem   = Row;
    LVI.lParam  = ItemData;     //������ �� ��
    LVI.pszText = (LPSTR)DataStr;
    return (int)SendMessage(hWnd, LVM_INSERTITEM, 0, (LPARAM)&LVI);
    }




//-----------------------------------------------------------------------------
//      ListView Item Text������
//-----------------------------------------------------------------------------
int WINAPI LV_GetItemText(HWND hWnd, int LVID, int Row, int Column, LPSTR lpBuff, int BuffSize)
    {
    LV_ITEM LVI;

    if (LVID!=0) hWnd=GetDlgItem(hWnd, LVID);
    lpBuff[0]=0;
    LVI.iSubItem=Column;
    LVI.pszText=lpBuff;
    LVI.cchTextMax=BuffSize;
    return (int)SendMessage(hWnd, LVM_GETITEMTEXT, Row, (LPARAM)&LVI);
    }

int WINAPI LV_GetItemInt(HWND hWnd, int LVID, int Row, int Column)
    {
    CHAR Buff[16];
    LV_GetItemText(hWnd, LVID, Row, Column, Buff, sizeof(Buff));
    return AtoI(Buff, NULL);
    }




//-----------------------------------------------------------------------------
//      ListView Item Text����
//-----------------------------------------------------------------------------
VOID WINAPI LV_SetItemText(HWND hWnd, int LVID, int Row, int Column, LPCSTR DataStr)
    {
    LV_ITEM LVI;

    if (LVID!=0) hWnd=GetDlgItem(hWnd, LVID);
    ZeroMem(&LVI, sizeof(LV_ITEM));
    LVI.mask    = LVIF_TEXT;
    LVI.iSubItem= Column;
    LVI.pszText = (LPSTR)DataStr;
    SendMessage(hWnd, LVM_SETITEMTEXT, Row, (LPARAM)&LVI);
    }

VOID WINAPI LV_SetItemInt(HWND hWnd, int LVID, int Row, int Column, int Data)
    {
    CHAR Buff[16];
    wsprintf(Buff, Psnt1d, Data);
    LV_SetItemText(hWnd, LVID, Row, Column, Buff);
    }




//-----------------------------------------------------------------------------
//      ��Ʈ���� ����մϴ�
//-----------------------------------------------------------------------------
ATOM WINAPI RegistCtrlWndClass(LPCSTR WClsName, WNDPROC WndProc, int WExtraSize)
    {
    WNDCLASS WC;

    ZeroMem(&WC, sizeof(WNDCLASS));
    WC.lpfnWndProc  = WndProc;
    WC.hbrBackground= (HBRUSH)GetStockObject(WHITE_BRUSH);
    WC.cbWndExtra   = WExtraSize;
    //WC.hInstance  = hInst;
    WC.lpszClassName= WClsName;
    return RegisterClass(&WC);
    }




VOID WINAPI InitCommonControls(VOID)
    {
    RegistCtrlWndClass("Edit", EditWndProc, sizeof(TextEditClass*));
    RegistCtrlWndClass(ButtonStr, ButtonWndProc, sizeof(BUTTONCTX*));
    RegistCtrlWndClass("ManualBtn", ManualBtnWndProc, sizeof(BUTTONCTX*));
    RegistCtrlWndClass("Static", StaticWndProc, sizeof(LPSTR));
    RegistCtrlWndClass("ScrollBar", ScrollBarWndProc, sizeof(SCROLLBARCTX*));
    RegistCtrlWndClass("ListBox", ListBoxWndProc, sizeof(ListBoxClass*));
    RegistCtrlWndClass("ComboBox", ComboBoxWndProc, sizeof(ListBoxClass*));
    RegistCtrlWndClass(WC_HEADER, SysHeaderWndProc, sizeof(SysHeaderClass*));
    RegistCtrlWndClass(WC_LISTVIEW, ListViewWndProc, sizeof(ListViewClass*));
    }


//�۾����� �Լ�: ComboBoxDlgProc() �޺�Ŭ���� ������ ��ȭ����


