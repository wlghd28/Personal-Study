///////////////////////////////////////////////////////////////////////////////
//                              SDRAM
///////////////////////////////////////////////////////////////////////////////
#include "JLIB.H"
#include "DRIVER.H"


#ifdef HAL_SDRAM_MODULE_ENABLED

#define SDRAM_MODEREG_BURST_LENGTH_1             0x0000
#define SDRAM_MODEREG_BURST_LENGTH_2             0x0001
#define SDRAM_MODEREG_BURST_LENGTH_4             0x0002
#define SDRAM_MODEREG_BURST_LENGTH_8             0x0004
#define SDRAM_MODEREG_BURST_TYPE_SEQUENTIAL      0x0000
#define SDRAM_MODEREG_BURST_TYPE_INTERLEAVED     0x0008
#define SDRAM_MODEREG_CAS_LATENCY_2              0x0020
#define SDRAM_MODEREG_CAS_LATENCY_3              0x0030
#define SDRAM_MODEREG_OPERATING_MODE_STANDARD    0x0000
#define SDRAM_MODEREG_WRITEBURST_MODE_PROGRAMMED 0x0000
#define SDRAM_MODEREG_WRITEBURST_MODE_SINGLE     0x0200




HAL_StatusTypeDef FMC_SDRAM_Init(FMC_SDRAM_TypeDef*Device, FMC_SDRAM_InitTypeDef*Init)
    {
    UINT T1, T2;

    if (Init->SDBank!=FMC_SDRAM_BANK2)
        {
        T1=Device->SDCR[FMC_SDRAM_BANK1];
        T1&=~(FMC_SDCR1_NC|FMC_SDCR1_NR|FMC_SDCR1_MWID|
            FMC_SDCR1_NB|FMC_SDCR1_CAS|FMC_SDCR1_WP|
            FMC_SDCR1_SDCLK|FMC_SDCR1_RBURST|FMC_SDCR1_RPIPE);

        T1|=Init->ColumnBitsNumber|
            Init->RowBitsNumber|
            Init->MemoryDataWidth|
            Init->InternalBankNumber|
            Init->CASLatency|
            Init->WriteProtection|
            Init->SDClockPeriod|
            Init->ReadBurst|
            Init->ReadPipeDelay;
        Device->SDCR[FMC_SDRAM_BANK1]=T1;
        }
    else{
        T1=Device->SDCR[FMC_SDRAM_BANK1];
        T1&=~(FMC_SDCR1_SDCLK|FMC_SDCR1_RBURST|FMC_SDCR1_RPIPE);
        T1|=Init->SDClockPeriod|
            Init->ReadBurst|
            Init->ReadPipeDelay;

        T2=Device->SDCR[FMC_SDRAM_BANK2];
        T2&=~(FMC_SDCR1_NC|FMC_SDCR1_NR|FMC_SDCR1_MWID|
            FMC_SDCR1_NB|FMC_SDCR1_CAS|FMC_SDCR1_WP|
            FMC_SDCR1_SDCLK|FMC_SDCR1_RBURST|FMC_SDCR1_RPIPE);

        T2|=Init->ColumnBitsNumber|
            Init->RowBitsNumber|
            Init->MemoryDataWidth|
            Init->InternalBankNumber|
            Init->CASLatency|
            Init->WriteProtection;

        Device->SDCR[FMC_SDRAM_BANK1]=T1;
        Device->SDCR[FMC_SDRAM_BANK2]=T2;
        }
    return HAL_OK;
    }



HAL_StatusTypeDef FMC_SDRAM_Timing_Init(FMC_SDRAM_TypeDef*Device, FMC_SDRAM_TimingTypeDef*Timing, UINT Bank)
    {
    UINT T1, T2;

    if (Bank!=FMC_SDRAM_BANK2)
        {
        T1=Device->SDTR[FMC_SDRAM_BANK1];

        T1&=~(FMC_SDTR1_TMRD|FMC_SDTR1_TXSR|FMC_SDTR1_TRAS|
            FMC_SDTR1_TRC|FMC_SDTR1_TWR|FMC_SDTR1_TRP|
            FMC_SDTR1_TRCD);

        T1|=(Timing->LoadToActiveDelay-1)|
            ((Timing->ExitSelfRefreshDelay-1)<<4)|
            ((Timing->SelfRefreshTime-1)<<8)|
            ((Timing->RowCycleDelay-1)<<12)|
            ((Timing->WriteRecoveryTime-1)<<16)|
            ((Timing->RPDelay-1)<<20)|
            ((Timing->RCDDelay-1)<<24);
            Device->SDTR[FMC_SDRAM_BANK1]=T1;
        }
    else{
        T1=Device->SDTR[FMC_SDRAM_BANK1];
        T2=Device->SDTR[FMC_SDRAM_BANK2];

        T1&=~(FMC_SDTR1_TRC|FMC_SDTR1_TRP);

        T1|=((Timing->RowCycleDelay-1)<<12)|
            ((Timing->RPDelay-1)<<20);

        T2&=~(FMC_SDTR1_TMRD|FMC_SDTR1_TXSR|FMC_SDTR1_TRAS|
            FMC_SDTR1_TRC|FMC_SDTR1_TWR|FMC_SDTR1_TRP|
            FMC_SDTR1_TRCD);

        T2|= (Timing->LoadToActiveDelay-1)|
            ((Timing->ExitSelfRefreshDelay-1)<<4)|
            ((Timing->SelfRefreshTime-1)<<8)|
            ((Timing->WriteRecoveryTime-1)<<16)|
            ((Timing->RCDDelay-1)<<24);

        Device->SDTR[FMC_SDRAM_BANK1]=T1;
        Device->SDTR[FMC_SDRAM_BANK2]=T2;
        }
    return HAL_OK;
    }



LOCAL(VOID) SDRAM_SendCommand(FMC_SDRAM_TypeDef *Sdram, UINT CommandMode, UINT CommandTarget, UINT AutoRefreshNumber, UINT ModeRegisterDefinition)
    {
    Sdram->SDCMR=CommandMode|CommandTarget|((AutoRefreshNumber-1)<<5)|(ModeRegisterDefinition<<9);
    }




LOCAL(VOID) SDRAM_InitSequence(FMC_SDRAM_TypeDef *Sdram, UINT RefreshCount)
    {
    SDRAM_SendCommand(Sdram, FMC_SDRAM_CMD_CLK_ENABLE,       FMC_SDRAM_CMD_TARGET_BANK1, 1, 0);
    HAL_Delay(1);

    SDRAM_SendCommand(Sdram, FMC_SDRAM_CMD_PALL,             FMC_SDRAM_CMD_TARGET_BANK1, 1, 0);
    SDRAM_SendCommand(Sdram, FMC_SDRAM_CMD_AUTOREFRESH_MODE, FMC_SDRAM_CMD_TARGET_BANK1, FMC_SDRAM_AUTOREFRESH_MODE, 0);

    SDRAM_SendCommand(Sdram, FMC_SDRAM_CMD_LOAD_MODE,        FMC_SDRAM_CMD_TARGET_BANK1, 1,
        SDRAM_MODEREG_BURST_LENGTH_1|
        SDRAM_MODEREG_BURST_TYPE_SEQUENTIAL|
        SDRAM_MODEREG_CAS_LATENCY_2|
        SDRAM_MODEREG_OPERATING_MODE_STANDARD|
        SDRAM_MODEREG_WRITEBURST_MODE_SINGLE);

    Sdram->SDRTR|=RefreshCount<<1;              //HAL_SDRAM_ProgramRefreshRate(hsdram, RefreshCount); => FMC_SDRAM_ProgramRefreshRate(hsdram->Instance, RefreshRate);
    }



#if SDRAM_DMA_EN
LOCAL(VOID) SDRAM_MspInit(SDRAM_HandleTypeDef *hSdRam)
    {
    static DMA_HandleTypeDef DmaHandle;

    __HAL_RCC_FMC_CLK_ENABLE();
    SDRAM_DMA_CLK_ENABLE();

    ZeroMem(&DmaHandle, sizeof(DmaHandle));
    DmaHandle.Init.Channel=SDRAM_DMA_CHANNEL;
    DmaHandle.Init.Direction=DMA_MEMORY_TO_MEMORY;
    DmaHandle.Init.PeriphInc=DMA_PINC_ENABLE;
    DmaHandle.Init.MemInc=DMA_MINC_ENABLE;
    DmaHandle.Init.PeriphDataAlignment=DMA_PDATAALIGN_WORD;
    DmaHandle.Init.MemDataAlignment=DMA_MDATAALIGN_WORD;
    DmaHandle.Init.Mode=DMA_NORMAL;
    DmaHandle.Init.Priority=DMA_PRIORITY_HIGH;
    DmaHandle.Init.FIFOMode=DMA_FIFOMODE_DISABLE;
    DmaHandle.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;
    DmaHandle.Init.MemBurst=DMA_MBURST_SINGLE;
    DmaHandle.Init.PeriphBurst=DMA_PBURST_SINGLE;
    DmaHandle.Instance=SDRAM_DMA_STREAM;
    hSdRam->hdma=&DmaHandle; DmaHandle.Parent=hSdRam;   //__HAL_LINKDMA(hSdRam, hdma, DmaHandle);

    HAL_DMA_DeInit(&DmaHandle);
    HAL_DMA_Init(&DmaHandle);

    #ifdef SDRAM_DMA_IRQn
    HAL_NVIC_SetPriority(SDRAM_DMA_IRQn, 0x0F, 0);      //DMA2_Stream0_IRQHandler()
    NVIC_EnableIRQ(SDRAM_DMA_IRQn);
    #endif
    }
#endif




VOID WINAPI SDRAM_Init(VOID)
    {
    FMC_SDRAM_TimingTypeDef Timing;
    SDRAM_HandleTypeDef SdramHandle;

    ZeroMem(&Timing, sizeof(Timing));
    Timing.LoadToActiveDelay=   SDRAM_TIMING_LoadToActiveDelay;         //1~16, Load Mode Register command �� Ȱ���̳� ���÷��� ��ħ ���� ������ ���� (����: �޸� Ŭ����)
    Timing.ExitSelfRefreshDelay=SDRAM_TIMING_ExitSelfRefreshDelay;      //1~16, ��ü ���÷��� ������ Release�� �� Ȱ��ȭ ������ �����ϴ� �� �ɸ��� ����
    Timing.SelfRefreshTime=     SDRAM_TIMING_SelfRefreshTime;           //1~16, �ּ� ��ü ���÷��� �Ⱓ
    Timing.RowCycleDelay=       SDRAM_TIMING_RowCycleDelay;             //1~16, ���÷��� ���ɰ� Ȱ��ȭ ���� ������ ������ �� ���� ���� ���÷��� ���� ������ ����
    Timing.WriteRecoveryTime=   SDRAM_TIMING_WriteRecoveryTime;         //1~16
    Timing.RPDelay=             SDRAM_TIMING_RPDelay;                   //1~16, Precharge ���ɰ� �ٸ� ���� ������ ����
    Timing.RCDDelay=            SDRAM_TIMING_RCDDelay;                  //1~16, Ȱ��ȭ ���ɰ� �б�/���� ���� ������ ����

    ZeroMem(&SdramHandle, sizeof(SdramHandle));
    SdramHandle.Instance=FMC_SDRAM_DEVICE;
    SdramHandle.Init.SDBank=FMC_SDRAM_BANK1;                            //1 or 2
    SdramHandle.Init.ColumnBitsNumber=FMC_SDRAM_COLUMN_BITS_NUM;        //8~11
    SdramHandle.Init.RowBitsNumber=FMC_SDRAM_ROW_BITS_NUM;              //11~13
    SdramHandle.Init.MemoryDataWidth=FMC_SDRAM_MEM_BUS_WIDTH;           //8,16,32
    SdramHandle.Init.InternalBankNumber=FMC_SDRAM_INTERN_BANKS_NUM;     //2 or 4
    SdramHandle.Init.CASLatency=FMC_SDRAM_CAS_LATENCY;                  //1~3, ������ SDRAMŬ����, 3�� Winbond���� �ȵ�
    SdramHandle.Init.WriteProtection=FMC_SDRAM_WRITE_PROTECTION_DISABLE;
    SdramHandle.Init.SDClockPeriod=FMC_SDRAM_CLOCK_PERIOD;              //DISABLE,2,3
    SdramHandle.Init.ReadBurst=FMC_SDRAM_RBURST_ENABLE;
    SdramHandle.Init.ReadPipeDelay=FMC_SDRAM_RPIPE_DELAY;               //0~2
    #if SDRAM_DMA_EN
    SDRAM_MspInit(&SdramHandle);
    #endif

    //HAL_SDRAM_Init(&SdramHandle, &Timing);
    FMC_SDRAM_Init(SdramHandle.Instance, &SdramHandle.Init);
    FMC_SDRAM_Timing_Init(SdramHandle.Instance, &Timing, SdramHandle.Init.SDBank);

    //Refresh count= 64000(us) / 4096(Refresh Cycle) * 90(MHz) - 20(???) = 1386  //64ms: Auto Refresh Time�� Refresh Cycle�� �޴��� ����, 90MHz: SDRAM clock freq
    SDRAM_InitSequence(SdramHandle.Instance, SDRAM_REFRESH_COUNT);
    }

#endif //HAL_SDRAM_MODULE_ENABLED


