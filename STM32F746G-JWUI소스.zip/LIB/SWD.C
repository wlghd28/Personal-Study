///////////////////////////////////////////////////////////////////////////////
//      SWD: Serial Wire Debug
//      DP:  Debug Port
//      AP:  Memory Access Port
//      DAP: Debug Access Port
//      CSW: Control/Status Word
//      TAR: Transfer Address Register
//      DRW: Data Read/Write Register
//      IDR: Identification Register
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "SWD.H"
#include "JFAT.H"
#include "MAIN.H"
#include "DebugCM.h"


#define MEMOWNER_TargetFlash_ProgrammingFile    (MEMOWNER_SWD+0)
#define MEMOWNER_TargetFlash_VerifyFile         (MEMOWNER_SWD+1)


#define TARGETDEVICELISTMAX     10
#define MAX_SWD_RETRY           100     //10
#define WAITFORREADYTIMEOUT     500
#define WAITFORHALTTIMEOUT      3000    //2022-02-21 500->3000
#define TARGET_AUTO_INCREMENT_PAGE_SIZE 1024    //This can vary from target to target and should be in the structure or flash blob
                                                //�̴� ��󸶴� �ٸ� �� ������ ���� �Ǵ� �÷��� ���ӿ� �־�� �մϴ�.

#define NVIC_Addr               0xE000E000
#define DHCSR                   0xE000EDF0  //Debug Halting Control and Status Register (CoreDebug->DHCSR, F4���� ���ǵ�)
#define DCRSR                   0xE000EDF4  //Debug Core Register Selector Register (Write Only)
#define DCRDR                   0xE000EDF8  //Debug Core Register Data Register
#define DEMCR                   0xE000EDFC  //Debug Exception & Monitor Control Register
#define DCRSR_REGWRITE          (1<<16)     //1=Write
#define DCRSR_REGREAD           (0<<16)     //0=Read
//DCRSR_D6-D0                               //Bit6-0�� R0-R12, SP, LR, DebugReturnAddr, xPSR, MSP, PSP�� ������ ARM�ھ� ��������, Ư�� ���� �������� �Ǵ� �ε� �Ҽ��� Ȯ�� �������͸� ����


//Debug Port Register Addresses
#define SWD_DP_IDCODE           (SWD_REG_DP|0x00)   //IDCODE Register (SW Read only)
#define SWD_DP_ABORT            (SWD_REG_DP|0x00)   //Abort Register (SW Write only)
#define SWD_DP_CTRLSTAT         (SWD_REG_DP|0x04)   //Control & Status
#define SWD_DP_WCR              (SWD_REG_DP|0x04)   //Wire Control Register (SW Only)
#define SWD_DP_SELECT           (SWD_REG_DP|0x08)   //Select Register (JTAG R/W & SW W)
#define SWD_DP_RESEND           (SWD_REG_DP|0x08)   //Resend (SW Read Only)
#define SWD_DP_RDBUFF           (SWD_REG_DP|0x0C)   //Read Buffer (Read Only)
#define SWD_AP_TAR              (SWD_REG_AP|AP_TAR)
#define SWD_AP_DRW              (SWD_REG_AP|AP_DRW)


//Flags for program_target
#define kAlgoSingleInitType         (1<<1)


#define TARGET_STATE_T                  int
#define TS_RESET_HOLD                   0       //Hold target in reset
#define TS_RESET_PROGRAM_SW             1       //Reset target and setup for flash programming
#define TS_RESET_PROGRAM_HW             2       //Reset target and setup for flash programming
#define TS_RESET_RUN                    3       //Reset target and run normally
#define TS_NODEBUG                      4       //Disable debug on running target
#define TS_DEBUG                        5       //Enable debug on running target
#define TS_HALT                         6       //Halt the target without resetting it
#define TS_RUN                          7       //Resume the target without resetting it
//#define TS_POST_FLASH_RESET           8       //Reset target after flash programming
#define TS_POWERON                      9       //Poweron the target
#define TS_SHUTDOWN                     10       //Poweroff the target


#define ERROR_T                         int
#define ERROR_SUCCESS                   0
#define ERROR_FAILURE                   1
#define ERROR_INTERNAL                  2
#define ERROR_ERROR_DURING_TRANSFER     3
#define ERROR_TRANSFER_TIMEOUT          4
#define ERROR_FILE_BOUNDS               5
#define ERROR_OOO_SECTOR                6
#define ERROR_RESET                     7
#define ERROR_ALGO_DL                   8
#define ERROR_ALGO_MISSING              9
#define ERROR_ALGO_DATA_SEQ             10
#define ERROR_INIT                      11
#define ERROR_UNINIT                    12
#define ERROR_SECURITY_BITS             13
#define ERROR_UNLOCK                    14
#define ERROR_ERASE_SECTOR              15
#define ERROR_ERASE_ALL                 16
#define ERROR_WRITE                     17
#define ERROR_WRITE_VERIFY              18
#define ERROR_SUCCESS_DONE              19
#define ERROR_SUCCESS_DONE_OR_CONTINUE  20
#define ERROR_HEX_CKSUM                 21
#define ERROR_HEX_PARSER                22
#define ERROR_HEX_PROGRAM               23
#define ERROR_HEX_INVALID_ADDRESS       24
#define ERROR_HEX_INVALID_APP_OFFSET    25

#define SWD_CONNECT_TYPE                int
#define CONNECT_NORMAL                  0
#define CONNECT_UNDER_RESET             1


//DAP Transfer Request
//#define DAP_TRANSFER_APnDP            (1<<0)  //0:DP, 1:AP
//#define DAP_TRANSFER_RnW              (1<<1)  //0:Write, 1:Read
//#define DAP_TRANSFER_A2               (1<<2)
//#define DAP_TRANSFER_A3               (1<<3)
//#define DAP_TRANSFER_MATCH_VALUE      (1<<4)
//#define DAP_TRANSFER_MATCH_MASK       (1<<5)
#define DAP_TRANSFER_TIMESTAMP          (1<<7)




typedef struct
    {
    UINT r[16];
    UINT xpsr;
    } DEBUG_STATE;


typedef enum
    {
    FLASH_FUNC_NOP,
    FLASH_FUNC_ERASE,
    FLASH_FUNC_PROGRAM,
    FLASH_FUNC_VERIFY
    } FLASH_FUNC_T;


typedef struct
    {
    UINT Select;
    UINT Csw;
    } DAP_STATE;


typedef struct
    {
    UINT ClockDelay;
    UINT Timestamp;             //Last captured Timestamp
    struct
        {                       //Transfer Configuration
        BYTE IdleCycles;        //Idle cycles after transfer
        BYTE Padding[3];
        } Tx;                   //Transfer
    BYTE SWD_Turnaround;        //Turnaround period
    BYTE SWD_DataPhase;         //Always generate Data Phase
    } DAP_DATA_T;




static DAP_DATA_T   DAP_Data;
static DAP_STATE    DAP_State;
static FLASH_FUNC_T LastFlashFunc;
static SWD_CONNECT_TYPE ResetConnect=CONNECT_NORMAL;
static UINT SoftReset=SYSRESETREQ;
static UINT FlashStart;
static CONST PROGRAM_TARGET_T   *CurrentFlashAlgo;  //AlgoBlob�� Ÿ�ٿ� ����ϰ� �� ���� AlgoBlob�� ������
static CONST TARGET_CFG_T       *TargetDevice;      //���õ� Ÿ��

static int TargetDeviceQty;
static CONST TARGET_CFG_T* TargetDeviceList[TARGETDEVICELISTMAX];



//-----------------------------------------------------------------------------
//      STM32L083�� 85,788 Bytes Programming �ð�����
//      DAP_Data.ClockDelay�� ... 1:16��, 5:18��, 10:19��
//
//      ����... �߱���������δٿ�δ�:10.5��, KEIL:30��
//-----------------------------------------------------------------------------
LOCAL(VOID) PinDelay(VOID)
    {
    #if defined(__CC_ARM)
    #if 1
    volatile UINT Cnt=DAP_Data.ClockDelay;
    while (--Cnt);
    #else
    //nop�� ������ ������ ���� 1ȸ�� ���Ƶ� 16����
    //nop 1~4:���۾���, 5~13��:15��, 14���̻�:16��
    __ASM("nop");   //1
    __ASM("nop");   //2
    __ASM("nop");   //3
    __ASM("nop");   //4
    __ASM("nop");   //5
    __ASM("nop");   //6
    __ASM("nop");   //7
    __ASM("nop");   //8
    __ASM("nop");   //9
    __ASM("nop");   //10
    #endif
    #else
    __ASM volatile(
        ".syntax unified\n"
        "0:\n\t"
        "subs %0,%0,#1\n\t"
        "bne  0b\n"
        :"+l"(DAP_Data.ClockDelay)::"cc");
    #endif
    }


LOCAL(VOID) SW_ClockCycle(VOID)
    {
    PIN_SWCLK_TCK_CLR(); PinDelay();
    PIN_SWCLK_TCK_SET(); PinDelay();
    }

LOCAL(VOID) SW_WriteBit(UINT Bit)
    {
    PIN_SWDIO_OUT(Bit);
    SW_ClockCycle();
    }

LOCAL(UINT) SW_ReadBit(VOID)
    {
    UINT Bit;

    PIN_SWCLK_TCK_CLR(); PinDelay();
    Bit=PIN_SWDIO_IN();
    PIN_SWCLK_TCK_SET(); PinDelay();
    return Bit;
    }


LOCAL(VOID) PIN_SwdioOutEnable(VOID)    {PIN_SWDIO_OUT_ENABLE();}
LOCAL(VOID) PIN_SwdioOutDisable(VOID)   {PIN_SWDIO_OUT_DISABLE();}
LOCAL(VOID) SWD_InitPort(VOID)          {PORT_SWD_SETUP();}
LOCAL(VOID) SWD_UninitPort(VOID)        {PORT_OFF();}  //Ÿ�� ���� ���⿡ ���




//-----------------------------------------------------------------------------
//      Generate SWJ Sequence
//
//   Cnt:  sequence bit Cnt
//   Data:   pointer to sequence bit Data
//-----------------------------------------------------------------------------
LOCAL(VOID) SWJ_Sequence(LPCBYTE lpData, UINT Cnt)
    {
    int I, Value;

    for (I=Value=0; I<Cnt; I++,Value>>=1)
        {
        if ((I&7)==0) Value=*lpData++;
        SW_WriteBit(Value);
        }
    }




//-----------------------------------------------------------------------------
//      Generate SWD Sequence
//
//   Info:   sequence information
//   SwdO:   pointer to SWDIO generated Data
//   SwdI:   pointer to SWDIO captured Data
//-----------------------------------------------------------------------------
#define SWD_SEQUENCE_CLK                0x3F    //SWCLK Cnt
#define SWD_SEQUENCE_DIN                0x80    //SWDIO Capture
VOID WINAPI SWD_Sequence(UINT Info, LPCBYTE SwdO, LPBYTE SwdI)
    {
    UINT Value, N, K;

    if ((N=Info & SWD_SEQUENCE_CLK)==0) N=64;

    if (Info & SWD_SEQUENCE_DIN)
        {
        while (N)
            {
            Value=0;
            for (K=8; K && N; K--, N--)
                {
                Value>>=1;
                Value|=SW_ReadBit()<<7;
                }
            Value>>=K;
            *SwdI++=(BYTE) Value;
            }
        }
    else{
        while (N)
            {
            Value=*SwdO++;
            for (K=8; K && N; K--, N--)
                {
                SW_WriteBit(Value);
                Value>>=1;
                }
            }
        }
    }




//-----------------------------------------------------------------------------
//     SWD Transfer I/O
//
//  Request: A[3:2] RnW APnDP
//  Data:    DATA[31:0]
//  return:  ACK[2:0]
//-----------------------------------------------------------------------------
#define DAP_TRANSFER_OK         (1<<0)
#define DAP_TRANSFER_WAIT       (1<<1)
#define DAP_TRANSFER_FAULT      (1<<2)
#define DAP_TRANSFER_ERROR      (1<<3)
#define DAP_TRANSFER_MISMATCH   (1<<4)
LOCAL(int) SWD_Transfer(UINT Request, UINT *lpData)
    {
    UINT Ack, Bit, Value, Parity, N;

    //Packet Request
    Parity=0;
    SW_WriteBit(1);                     //Start Bit
    Bit=Request>>0; SW_WriteBit(Bit);   //APnDP Bit
    Parity+=Bit;
    Bit=Request>>1; SW_WriteBit(Bit);   //RnW Bit
    Parity+=Bit;
    Bit=Request>>2; SW_WriteBit(Bit);   //A2 Bit
    Parity+=Bit;
    Bit=Request>>3; SW_WriteBit(Bit);   //A3 Bit
    Parity+=Bit;
    SW_WriteBit(Parity);                //Parity Bit
    SW_WriteBit(0);                     //Stop Bit
    SW_WriteBit(1);                     //Park Bit

    //Turnaround
    PIN_SwdioOutDisable();
    for (N=DAP_Data.SWD_Turnaround; N; N--) SW_ClockCycle();

    //Acknowledge response
    Ack=SW_ReadBit();
    Ack|=SW_ReadBit()<<1;
    Ack|=SW_ReadBit()<<2;
    if (Ack==DAP_TRANSFER_OK)       //OK response
        {                           //Data transfer
        if (Request & SWD_REG_R)
            {
            Value=0;
            Parity=0;
            for (N=32; N; N--)
                {
                Bit=SW_ReadBit();   //Read RDATA[0:31]
                Parity+=Bit;
                Value>>=1;
                Value|=Bit<<31;
                }
            //Read Parity
            if ((SW_ReadBit()^Parity)&1) Ack=DAP_TRANSFER_ERROR;
            if (lpData) *lpData=Value;
            //Turnaround
            for (N=DAP_Data.SWD_Turnaround; N; N--) SW_ClockCycle();
            PIN_SwdioOutEnable();
            }
        else{
            //Turnaround
            for (N=DAP_Data.SWD_Turnaround; N; N--) SW_ClockCycle();
            PIN_SwdioOutEnable();
            //Write Data
            Value=*lpData;
            Parity=0;
            for (N=32; N; N--)
                {
                SW_WriteBit(Value);                                            //Write WDATA[0:31]
                Parity+=Value;
                Value>>=1;
                }
            SW_WriteBit(Parity);                                               //Write Parity Bit
            }

        //Capture Timestamp
        if (Request & DAP_TRANSFER_TIMESTAMP) DAP_Data.Timestamp=TIMESTAMP_GET();
        //Idle cycles
        if ((N=DAP_Data.Tx.IdleCycles)>0)
            {
            PIN_SWDIO_OUT(0);
            for (; N; N--) SW_ClockCycle();
            }
        goto ProcExit;
        }

    if (Ack==DAP_TRANSFER_WAIT || Ack==DAP_TRANSFER_FAULT)
        {
        //WAIT or FAULT response
        if (DAP_Data.SWD_DataPhase && (Request & SWD_REG_R)!=0)
            {
            for (N=32+1; N; N--) SW_ClockCycle();                   //Dummy Read RDATA[0:31] + Parity
            }
        //Turnaround
        for (N=DAP_Data.SWD_Turnaround; N; N--) SW_ClockCycle();
        PIN_SwdioOutEnable();
        if (DAP_Data.SWD_DataPhase && (Request & SWD_REG_R)==0)
            {
            PIN_SWDIO_OUT(0);
            for (N=32+1; N; N--) SW_ClockCycle();                   //Dummy Write WDATA[0:31] + Parity
            }
        goto ProcExit;
        }

    //Protocol error
    for (N=DAP_Data.SWD_Turnaround+32+1; N; N--) SW_ClockCycle();   //Back off Data phase
    PIN_SwdioOutEnable();

    ProcExit:
    PIN_SWDIO_OUT(1);
    return Ack;
    }




LOCAL(UINT) SWD_TransferRetry(UINT Req, UINT *lpData)
    {
    UINT I, Ack;

    //JOS_ENTER_CRITICAL();
    //SysTick->CTRL&=~SysTick_CTRL_ENABLE_Msk;

    for (I=0; I<MAX_SWD_RETRY; I++)
        {
        if ((Ack=SWD_Transfer(Req, lpData))!=DAP_TRANSFER_WAIT) break;
        }
    //Printf("SWD_TransferRetry(%X)=%X"CRLF, Req, *lpData);
    //SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk;
    //JOS_EXIT_CRITICAL();
    return Ack;
    }



//-----------------------------------------------------------------------------
//      ���̸�: swd_get_apsel()
//-----------------------------------------------------------------------------
LOCAL(UINT) SWD_GetApsel(UINT Adr)
    {
    //return 0x01000000;
    return Adr & APSEL;
    }



//-----------------------------------------------------------------------------
//      Read debug port register.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadDP(UINT Adr, UINT *lpValue)
    {
    return SWD_TransferRetry(SWD_REG_R|SWD_REG_ADR(Adr), lpValue)==DAP_TRANSFER_OK;
    }




//-----------------------------------------------------------------------------
//      Write debug port register
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteDP(UINT Adr, UINT Value)
    {
    return SWD_TransferRetry(Adr|SWD_REG_DP|SWD_REG_W, &Value)==DAP_TRANSFER_OK;
    }




LOCAL(BOOL) SWD_WriteDPSelect(UINT Value)
    {
    BOOL Rslt;

    if (DAP_State.Select==Value) return TRUE;   //Check if the right bank is already selected
    if ((Rslt=SWD_WriteDP(SWD_DP_SELECT, Value))!=FALSE) DAP_State.Select=Value;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Write access port register
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteAP(UINT Adr, UINT Value)
    {
    BOOL Rslt=FALSE;

    if (SWD_WriteDPSelect(SWD_GetApsel(Adr)|(Adr & APBANKSEL))==FALSE) goto ProcExit;
    if (SWD_TransferRetry(SWD_REG_AP|SWD_REG_W|SWD_REG_ADR(Adr), &Value)!=DAP_TRANSFER_OK) goto ProcExit;
    if (SWD_TransferRetry(SWD_DP_RDBUFF|SWD_REG_R, NULL)!=DAP_TRANSFER_OK) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }


LOCAL(BOOL) SWD_WriteCSW(UINT AccSize)  //AccSize is CSW_SIZE8 or CSW_SIZE32
    {
    UINT Value;

    Value=AccSize|CSW_RESERVED|CSW_MSTRDBG|CSW_HPROT|CSW_DBGSTAT|CSW_SADDRINC;
    if (DAP_State.Csw==Value) return TRUE;
    DAP_State.Csw=Value;
    return SWD_WriteAP(AP_CSW, Value);
    }


LOCAL(BOOL) SWD_WriteTAR(UINT Addr)
    {
    return SWD_TransferRetry(SWD_AP_TAR|SWD_REG_W, &Addr)==DAP_TRANSFER_OK;
    }


LOCAL(BOOL) SWD_WriteDRW(UINT Data)
    {
    return SWD_TransferRetry(SWD_AP_DRW|SWD_REG_W, &Data)==DAP_TRANSFER_OK;
    }



//-----------------------------------------------------------------------------
//      Write Target Memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteData(UINT Addr, UINT Data)
    {
    BOOL Rslt=FALSE;

    if (SWD_WriteTAR(Addr)==FALSE) goto ProcExit;
    if (SWD_WriteDRW(Data)==FALSE) goto ProcExit;

    //Dummy read
    if (SWD_TransferRetry(SWD_DP_RDBUFF|SWD_REG_R, NULL)!=DAP_TRANSFER_OK) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Read Target Memory
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadData(UINT Addr, UINT *lpValue)
    {
    BOOL Rslt=FALSE;

    if (SWD_WriteTAR(Addr)==FALSE) goto ProcExit;

    //Read data
    if (SWD_TransferRetry(SWD_AP_DRW|SWD_REG_R, NULL)!=DAP_TRANSFER_OK) goto ProcExit;

    //Dummy read
    if (SWD_TransferRetry(SWD_DP_RDBUFF|SWD_REG_R, lpValue)!=DAP_TRANSFER_OK) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Read 32-bit word from target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadDW(UINT Addr, UINT *lpValue)
    {
    return SWD_WriteCSW(CSW_SIZE32) &&
           SWD_ReadData(Addr, lpValue);
    }



//-----------------------------------------------------------------------------
//      Write 32-bit word to target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteDW(UINT Addr, DWORD Value)
    {
    return SWD_WriteCSW(CSW_SIZE32) &&
           SWD_WriteData(Addr, Value);
    }



//-----------------------------------------------------------------------------
//      Write 8-bit byte to target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteByte(UINT Addr, UINT Value)
    {
    return SWD_WriteCSW(CSW_SIZE8) &&
           SWD_WriteData(Addr, Value<<((Addr&3)<<3));
    }



//-----------------------------------------------------------------------------
//      Read 8-bit byte from target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadByte(UINT Addr, LPBYTE Buff)
    {
    BOOL Rslt=FALSE;
    UINT T;

    if (SWD_WriteCSW(CSW_SIZE8) &&
        SWD_ReadData(Addr, &T))
        {
        Buff[0]=(BYTE)(T>>((Addr&3)<<3));
        Rslt++;
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Core���°� Ready���� �˷���
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_IsCoreReady(VOID)
    {
    UINT Value;

    return SWD_ReadDW(DHCSR, &Value)!=FALSE && (Value & S_REGRDY)!=0;           //S_REGRDY=CoreDebug_DHCSR_S_REGRDY_Msk
    }




//-----------------------------------------------------------------------------
//      Wait for target to Ready
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WaitCoreReady(VOID)
    {
    int  Rslt=FALSE;
    UINT Tick;

    Tick=GetTickCount();
    for (;;)
        {
        if (SWD_IsCoreReady()) {Rslt++; break;}
        if (GetTickCount()-Tick>=WAITFORREADYTIMEOUT) break;
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Wait for target to stop
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WaitUntilHalted(VOID)
    {
    int  Rslt=FALSE;
    UINT Value, Tick;

    Tick=GetTickCount();
    for (;;)
        {
        if (SWD_ReadDW(DHCSR, &Value)!=FALSE && (Value & S_HALT)!=0) {Rslt++; break;}
        if (GetTickCount()-Tick>=WAITFORHALTTIMEOUT)
            {
            Printf("SWD_WaitUntilHalted() Timeout"CRLF);
            break;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      RegSel ...  0~15:R0~R15, 16:xPSR, 17:MSP, 18:PSP, 20:CONTROL & PRIMASK
//
//  DCRSR�� ���� ���� S_REGRDY�� HIGH���� Ȯ���ؾ� �մϴ�.
//  C_DEBUGEN=0�� ���õ� �� �� �������Ϳ� ����մϴ�.
//  Word �׼��� �̿��� ����� ������ �ʽ��ϴ�.
//  ���ǵ��� ���� REGSEL�� ����� ����� ������ �ʽ��ϴ�.
//  �� �������Ϳ��� �б�� ������ �ʽ��ϴ�.
//  IPSR�� ���� ����� ���õ˴ϴ�.
//  CONTROL ���������� ��Ʈ[1]�� OS Ȯ���� �ְ� ���μ����� ������ ��忡 �ִ� ��쿡�� ������ �� �ֽ��ϴ�.
//
//  ���� https://developer.arm.com/documentation/ddi0413/c/debug/debug-control/debug-core-register-selector-register
//       https://developer.arm.com/documentation/ddi0413/c/debug/debug-control/debug-halting-control-and-status-register
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteCoreRegister(UINT RegSel, UINT Value)
    {
    int Rslt=FALSE;

    if (SWD_WriteDW(DCRDR, Value)==FALSE)                 {UINT R,V=0; R=SWD_ReadDW(DHCSR, &V); Printf("SWD_WriteDW(DCRDR, %Xh) Error, SWD_ReadDW()=%d,%d" CRLF, Value, R,V); goto ProcExit;}
    if (SWD_WriteDW(DCRSR, RegSel|DCRSR_REGWRITE)==FALSE) {Printf("SWD_WriteDW(DCRSR, %d|DCRSR_REGWRITE) Error"CRLF, RegSel); goto ProcExit;}
    if (SWD_WaitCoreReady()==FALSE) {Printf("SWD_WriteCoreRegister() Timeout"CRLF); goto ProcExit;}
    Rslt++;

    ProcExit:
    return Rslt;
    }



LOCAL(BOOL) SWD_ReadCoreRegister(UINT RegSel, UINT *lpValue)
    {
    int Rslt=FALSE;

    if (SWD_WriteDW(DCRSR, RegSel|DCRSR_REGREAD)==FALSE) goto ProcExit;
    if (SWD_WaitCoreReady()==FALSE) {Printf("SWD_ReadCoreRegister() Timeout"CRLF); goto ProcExit;}
    if (SWD_ReadDW(DCRDR, lpValue)==FALSE) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Execute system call.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteDebugState(DEBUG_STATE *DS)
    {
    BOOL Rslt=FALSE;
    UINT I, Status;

    if (SWD_WriteDPSelect(0)==FALSE) goto ProcExit;

    //R0, R1, R2, R3
    for (I=0; I<4; I++)
        {
        if (SWD_WriteCoreRegister(I, DS->r[I])==FALSE) goto ProcExit;
        }

    //R9
    if (SWD_WriteCoreRegister(9, DS->r[9])==FALSE) goto ProcExit;

    //R13, R14, R15
    for (I=13; I<16; I++)
        {
        if (SWD_WriteCoreRegister(I, DS->r[I])==FALSE) goto ProcExit;
        }

    //xPSR
    if (SWD_WriteCoreRegister(16, DS->xpsr)==FALSE) goto ProcExit;

    if (SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN|C_MASKINTS|C_HALT)==FALSE) goto ProcExit;
    if (SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN|C_MASKINTS)==FALSE) goto ProcExit;

    //Check status
    if (SWD_ReadDP(SWD_DP_CTRLSTAT, &Status)==FALSE) goto ProcExit;
    if (Status & (STICKYERR|WDATAERR)) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ���̸�: swd_flash_syscall_exec()
//      Ÿ�ٿ��� ������ �Լ��� �����Ŵ
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_FlashSyscallRun(CONST PGM_SYSCALL_T *PS, UINT Entry, UINT Arg1, UINT Arg2, UINT Arg3, UINT Arg4)
    {
    int  Rslt=FALSE, Err=0;
    DEBUG_STATE DS;

    ZeroMem(&DS, sizeof(DS));
    //Call flash algorithm function on target and wait for result.
    DS.r[0]=Arg1;                   //R0: Argument 1
    DS.r[1]=Arg2;                   //R1: Argument 2
    DS.r[2]=Arg3;                   //R2: Argument 3
    DS.r[3]=Arg4;                   //R3: Argument 4
    DS.r[9]=PS->StaticBase;         //SB: Static Base
    DS.r[13]=PS->StackPointer;      //SP: Stack Pointer
    DS.r[14]=PS->BreakPoint;        //LR: Exit Point
    DS.r[15]=Entry;                 //PC: Entry Point
    DS.xpsr=0x01000000;             //xPSR: T=1, ISR=0

    //Ÿ�� RUN
    if (SWD_WriteDebugState(&DS)==FALSE) {Printf("SWD_WriteDebugState() Error"CRLF); Err=1; goto ProcExit;}
    Rslt++;

    ProcExit:
    SetLastError(Err);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Ÿ�ٿ��� �����Ų �Լ��� ����Ǿ����� ��ٸ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WaitDoneFlashSyscall(DWORD *lpRetValue)
    {
    int  Rslt=FALSE, Err=0;

    if (SWD_WaitUntilHalted()==FALSE) {Printf("SWD_WaitUntilHalted() Error"CRLF); Err=2; goto ProcExit;}
    if (SWD_ReadCoreRegister(0, (UINT*)lpRetValue)==FALSE) {Printf("SWD_ReadCoreRegister() Error"CRLF); Err=3; goto ProcExit;}

    //Remove the C_MASKINTS
    if (SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN|C_HALT)==FALSE) {Printf("SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN|C_HALT) Error"CRLF); Err=4; goto ProcExit;}
    Rslt++;

    ProcExit:
    SetLastError(Err);
    return Rslt;
    }

LOCAL(BOOL) SWD_FlashSyscallExecEx(CONST PGM_SYSCALL_T *PS, UINT Entry, UINT Arg1, UINT Arg2, UINT Arg3, UINT Arg4)
    {
    BOOL Rslt;
    DWORD TF_Rslt;

    if ((Rslt=SWD_FlashSyscallRun(PS, Entry, Arg1, Arg2, Arg3, Arg4))!=FALSE &&
        (Rslt=SWD_WaitDoneFlashSyscall(&TF_Rslt))!=FALSE)
        {
        if (TF_Rslt!=0)
            {
            Printf("SWD_FlashSyscallExecEx(%X) TargetErrCode=%d"CRLF, Entry, TF_Rslt);
            SetLastError(5);
            Rslt=FALSE;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���̸�: flash_func_start()
//-----------------------------------------------------------------------------
LOCAL(ERROR_T) FlashFuncStart(FLASH_FUNC_T Func)
    {
    CONST PROGRAM_TARGET_T *PT=CurrentFlashAlgo;

    if (LastFlashFunc!=Func)
        {
        //Finish the currently active function.
        if (LastFlashFunc!=FLASH_FUNC_NOP &&
            ((PT->AlgoFlags & kAlgoSingleInitType)==0 || Func==FLASH_FUNC_NOP) &&
            SWD_FlashSyscallExecEx(&PT->SysCall, PT->Uninit, LastFlashFunc, 0, 0, 0)==FALSE) return ERROR_UNINIT;

        //Start a new function.
        if (Func!=FLASH_FUNC_NOP &&
            ((PT->AlgoFlags & kAlgoSingleInitType)==0 || LastFlashFunc==FLASH_FUNC_NOP) &&
            SWD_FlashSyscallExecEx(&PT->SysCall, PT->Init, FlashStart, 0, Func, 0)==FALSE) return ERROR_INIT;

        LastFlashFunc=Func;
        }

    return ERROR_SUCCESS;
    }

LOCAL(VOID) FlashFuncFinish(VOID)
    {
    CONST PROGRAM_TARGET_T *PT;

    if ((PT=CurrentFlashAlgo)!=NULL)
        SWD_FlashSyscallExecEx(&PT->SysCall, PT->Uninit, 0, 0, 0, 0);
    }




//-----------------------------------------------------------------------------
//      Write 32-bit word aligned values to target memory using Addr auto-increment.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteBlock(UINT Addr, CONST UINT *lpData, UINT WrtBytes)
    {
    BOOL Rslt=FALSE;
    UINT I, Len;

    if ((UINT)lpData & 3)
        {
        Printf("lpData of SWD_WriteBlock() must be divided by 4"CRLF);
        goto ProcExit;
        }

    if (SWD_WriteCSW(CSW_SIZE32)==FALSE) goto ProcExit;
    if (SWD_WriteTAR(Addr)==FALSE) goto ProcExit;

    Len=WrtBytes/4;
    for (I=0; I<Len; I++)
        {
        if (SWD_WriteDRW(*lpData++)==FALSE) goto ProcExit;
        }

    //Dummy read
    if (SWD_TransferRetry(SWD_DP_RDBUFF|SWD_REG_R, NULL)!=DAP_TRANSFER_OK) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Read 32-bit word aligned values from target memory using Addr auto-increment.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadBlock(UINT Addr, UINT *lpData, UINT ReadBytes)
    {
    BOOL Rslt=FALSE;
    UINT I, Len;

    if ((UINT)lpData & 3)
        {
        Printf("lpData of SWD_ReadBlock() must be divided by 4"CRLF);
        goto ProcExit;
        }

    if (SWD_WriteCSW(CSW_SIZE32)==FALSE) goto ProcExit;
    if (SWD_WriteTAR(Addr)==FALSE) goto ProcExit;
    if (SWD_TransferRetry(SWD_AP_DRW|SWD_REG_R, NULL)!=DAP_TRANSFER_OK) goto ProcExit;  //Initiate first read, data comes back in next read

    Len=ReadBytes/4;
    for (I=0; I<Len-1; I++)
        {
        if (SWD_TransferRetry(SWD_AP_DRW|SWD_REG_R, lpData)!=DAP_TRANSFER_OK) goto ProcExit;
        lpData++;
        }

    if (SWD_TransferRetry(SWD_DP_RDBUFF|SWD_REG_R, lpData)!=DAP_TRANSFER_OK) goto ProcExit;  //Read last word
    Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Write unaligned data to target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_WriteMemory(UINT Addr, LPCBYTE lpData, UINT WriteBytes)
    {
    BOOL Rslt=FALSE;
    UINT N;

    //Write bytes until word aligned
    while (WriteBytes>0 && (Addr&3)!=0)
        {
        if (SWD_WriteByte(Addr, *lpData)==FALSE) goto ProcExit;
        Addr++;
        lpData++;
        WriteBytes--;
        }

    //Write word aligned blocks
    while (WriteBytes>3)
        {
        N=GetMin(WriteBytes & ~3, TARGET_AUTO_INCREMENT_PAGE_SIZE-(Addr&(TARGET_AUTO_INCREMENT_PAGE_SIZE-1)));
        if (SWD_WriteBlock(Addr, (CONST UINT*)lpData, N)==FALSE) goto ProcExit;
        Addr+=N;
        lpData+=N;
        WriteBytes-=N;
        }

    //Write remaining bytes
    while (WriteBytes>0)
        {
        if (SWD_WriteByte(Addr, *lpData)==FALSE) goto ProcExit;
        Addr++;
        lpData++;
        WriteBytes--;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Read unaligned data from target memory.
//-----------------------------------------------------------------------------
LOCAL(BOOL) SWD_ReadMemory(UINT Addr, LPBYTE lpData, UINT ReadBytes)
    {
    BOOL Rslt=FALSE;
    UINT N;

    //Read bytes until word aligned
    while (ReadBytes>0 && (Addr&3)!=0)
        {
        if (SWD_ReadByte(Addr, lpData)==FALSE) goto ProcExit;
        Addr++;
        lpData++;
        ReadBytes--;
        }

    //Read word aligned blocks
    while (ReadBytes>3)
        {
        N=GetMin(ReadBytes & ~3, TARGET_AUTO_INCREMENT_PAGE_SIZE-(Addr&(TARGET_AUTO_INCREMENT_PAGE_SIZE-1)));
        if (SWD_ReadBlock(Addr, (UINT*)lpData, N)==FALSE) goto ProcExit;
        Addr+=N;
        lpData+=N;
        ReadBytes-=N;
        }

    //Read remaining bytes
    while (ReadBytes>0)
        {
        if (SWD_ReadByte(Addr, lpData)==FALSE) goto ProcExit;
        Addr++;
        lpData++;
        ReadBytes--;
        }

    Rslt++;

    ProcExit:
    return Rslt;
    }




LOCAL(CONST PROGRAM_TARGET_T*) GetFlashAlgo(UINT Addr)
    {
    CONST REGION_INFO_T    *FR;
    CONST PROGRAM_TARGET_T *PT=NULL;

    for (FR=TargetDevice->FlashRegions; FR->Start!=0 || FR->End!=0; FR++)
        {
        if (Addr>=FR->Start && Addr<=FR->End)
            {
            FlashStart=FR->Start;          //save the flash Start
            PT=FR->FlashAlgo;
            break;
            }
        }
    return PT;
    }




//-----------------------------------------------------------------------------
//          Ÿ�� ����̽� ����
//-----------------------------------------------------------------------------
BOOL WINAPI SelectTargetDevice(LPCSTR DeviceName)
    {
    int I, Rslt=FALSE;
    CONST TARGET_CFG_T *T;
    PROGRAM_TARGET_T   *PT;

    for (I=0; I<TargetDeviceQty; I++)
        {
        T=TargetDeviceList[I];
        if (lstrcmp(T->RtBoardId, DeviceName)==0)
            {
            Printf("SelectTargetDevice('%s')" CRLF, DeviceName);

            TargetDevice=T;
            CurrentFlashAlgo=NULL;  //2021-08-18 Ÿ���� ������ϸ� SRAM�� �������� ������ ��ε��ϰ� ���־�� ��

            PT=(PROGRAM_TARGET_T*)T->FlashRegions[0].FlashAlgo;
            if (PT->Init==NULL)
                {
                PT->Init=PT->AlgoBlob[5];
                PT->Uninit=PT->AlgoBlob[6];
                PT->EraseChip=PT->AlgoBlob[7];
                PT->EraseSector=PT->AlgoBlob[8];
                PT->ProgramPage=PT->AlgoBlob[9];
                PT->Verify=PT->AlgoBlob[10];
                PT->InitMcu=PT->AlgoBlob[1];
                PT->GetCRC32=PT->AlgoBlob[12];
                PT->SysCall.BreakPoint=PT->AlgoBlob[13];
                PT->SysCall.StackPointer=PT->AlgoBlob[0];
                PT->PgmBuffer=PT->AlgoBlob[4];
                }
            Rslt++;
            break;
            }
        }
    if (Rslt==FALSE) Printf("SelectTargetDevice('%s') not Support" CRLF, DeviceName);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//          Ÿ�� ����̽� ��� ǥ��
//-----------------------------------------------------------------------------
VOID WINAPI TargetFlash_List(VOID)
    {
    int I;
    CONST TARGET_CFG_T *T;

    for (I=0; I<TargetDeviceQty; I++)
        {
        T=TargetDeviceList[I];
        Printf("%d. %s"CRLF, I+1, T->RtBoardId);
        }
    }




//-----------------------------------------------------------------------------
//          �־��� ����̽��� ���� �� �ִ� �ּ����� Ȯ������
//-----------------------------------------------------------------------------
BOOL WINAPI CheckFlashAddress(LPCSTR TargetDevice, UINT FlashAddress)
    {
    BOOL Rslt=FALSE;

    if (SelectTargetDevice(TargetDevice))
        Rslt=GetFlashAlgo(FlashAddress)!=NULL;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      flash_intf_t.flash_algo_set(), ���̸�: target_flash_set
//-----------------------------------------------------------------------------
LOCAL(BOOL) TargetFlash_SetAlgo(UINT Addr)
    {
    ERROR_T Rslt=ERROR_SUCCESS;
    CONST PROGRAM_TARGET_T *PT;

    if ((PT=GetFlashAlgo(Addr))==NULL) {Rslt=ERROR_ALGO_MISSING; goto ProcExit;}
    if (CurrentFlashAlgo!=PT)
        {
        //run Uninit to last func
        if (CurrentFlashAlgo!=NULL && (Rslt=FlashFuncStart(FLASH_FUNC_NOP))!=ERROR_SUCCESS) goto ProcExit;

        //Download flash programming algorithm to target (8K �о� �ִµ� 211ms �ɸ�)
        if (SWD_WriteMemory(PT->AlgoStart, (LPCBYTE)PT->AlgoBlob, PT->AlgoSize)==FALSE) {Rslt=ERROR_ALGO_DL; goto ProcExit;}

        if (PT->InitMcu!=0)
            {
            BOOL FRslt;
            FRslt=SWD_FlashSyscallExecEx(&PT->SysCall, PT->InitMcu, 0, 0, 0, 0);
            Printf("InitMcu() %s"CRLF, FRslt ? "Ok":"Fail");
            }
        CurrentFlashAlgo=PT;
        }

    ProcExit:
    SetLastError(Rslt);
    return Rslt==ERROR_SUCCESS;
    }




//-----------------------------------------------------------------------------
//      flash_intf_t.program_page(), ���̸�: target_flash_program_page()
//-----------------------------------------------------------------------------
LOCAL(BOOL) TargetFlash_ProgramPage(UINT Addr, LPCBYTE lpData, UINT ToWriteBytes)
    {
    UINT WrtBytes;
    ERROR_T Rslt=ERROR_SUCCESS;
    CONST PROGRAM_TARGET_T *PT;

    //if (g_board_info.target_cfg==0) {Rslt=ERROR_FAILURE; goto ProcExit;}
    if ((PT=CurrentFlashAlgo)==NULL) {Rslt=ERROR_INTERNAL; goto ProcExit;}
    if ((Rslt=FlashFuncStart(FLASH_FUNC_PROGRAM))!=ERROR_SUCCESS) goto ProcExit;

    while (ToWriteBytes>0)
        {
        WrtBytes=GetMin(ToWriteBytes, PT->PgmBuffSize);

        //Write page to buffer
        if (SWD_WriteMemory(PT->PgmBuffer, lpData, WrtBytes)==FALSE) {Rslt=ERROR_ALGO_DATA_SEQ; goto ProcExit;}

        //Run flash programming
        if (SWD_FlashSyscallExecEx(&PT->SysCall, PT->ProgramPage, Addr, WrtBytes, PT->PgmBuffer, 0)==FALSE) {Rslt=ERROR_WRITE; goto ProcExit;}

        Addr+=WrtBytes;
        lpData+=WrtBytes;
        ToWriteBytes-=WrtBytes;
        }

    ProcExit:
    SetLastError(Rslt);
    return Rslt==ERROR_SUCCESS;
    }



//-----------------------------------------------------------------------------
//      flash_intf_t.erase_sector_size, ���̸�:target_flash_erase_sector_size()
//-----------------------------------------------------------------------------
LOCAL(UINT) TargetFlash_GetErasePageSize(UINT Addr)
    {
    int  I;
    UINT Size=0;

    for (I=TargetDevice->SectorInfoLen-1; I>=0; I--)
        {
        if (Addr>=TargetDevice->SectorsInfo[I].Start)
            {
            Size=TargetDevice->SectorsInfo[I].Size;
            break;
            }
        }
    return Size;
    }



//-----------------------------------------------------------------------------
//      �����ؾ��ϴ� ������ �߿� ���� ū ũ�⸦ ����
//-----------------------------------------------------------------------------
LOCAL(UINT) TargetFlash_GetErasePageMax(VOID)
    {
    int  I;
    UINT Size=0;

    for (I=TargetDevice->SectorInfoLen-1; I>=0; I--)
        {
        Size=UGetMax(Size, TargetDevice->SectorsInfo[I].Size);
        }
    return Size;
    }



//-----------------------------------------------------------------------------
//      flash_intf_t.erase_sector, ���̸�: target_flash_erase_sector()
//-----------------------------------------------------------------------------
LOCAL(BOOL) TargetFlash_EraseSector(UINT Addr)
    {
    ERROR_T Rslt;
    CONST PROGRAM_TARGET_T *PT;

    //if (g_board_info.target_cfg==0) return ERROR_FAILURE;
    if ((PT=CurrentFlashAlgo)==NULL) {Rslt=ERROR_INTERNAL; goto ProcExit;}

    //�ּҰ� ���� ��迡 �ִ��� Ȯ��
    if ((Addr % TargetFlash_GetErasePageSize(Addr))!=0) {Rslt=ERROR_ERASE_SECTOR; goto ProcExit;}
    if ((Rslt=FlashFuncStart(FLASH_FUNC_ERASE))!=ERROR_SUCCESS) goto ProcExit;
    if (SWD_FlashSyscallExecEx(&PT->SysCall, PT->EraseSector, Addr, 0, 0, 0)==FALSE) {Rslt=ERROR_ERASE_SECTOR; goto ProcExit;}

    ProcExit:
    SetLastError(Rslt);
    return Rslt==ERROR_SUCCESS;
    }



//target_flash_erase_chip       flash_intf_t.erase_chip
//target_flash_busy             flash_intf_t.flash_busy



LOCAL(VOID) SWD_Reset(VOID)
    {
    BYTE Buff[8];

    FillMem(Buff, sizeof(Buff), 0xFF);
    SWJ_Sequence(Buff, 51);
    }


LOCAL(VOID) SWD_Switch(UINT Value)
    {
    BYTE Buff[4];

    PokeW(Buff, Value);
    SWJ_Sequence(Buff, 16);
    }



LOCAL(BOOL) SWD_ReadID(UINT *lpID)
    {
    BYTE Buff[4];

    Buff[0]=0;
    SWJ_Sequence(Buff, 8);
    return SWD_ReadDP(SWD_DP_IDCODE, lpID);
    }



//-----------------------------------------------------------------------------
//      STM32G071 -> BC11477
//      STM32F091 -> BB11477
//      STM32L083 -> BC11477
//-----------------------------------------------------------------------------
LOCAL(BOOL) JTAG2SWD(UINT *lpID)
    {
    SWD_Reset();
    SWD_Switch(0xE79E);
    SWD_Reset();
    return SWD_ReadID(lpID);
    }



//-----------------------------------------------------------------------------
//      ������ ����
//      ���̸�: swd_set_target_reset
//-----------------------------------------------------------------------------
VOID WINAPI SWD_SetTargetReset(BOOL Asserted)
    {
    if (Asserted) PIN_nRESET_OUT(0); else PIN_nRESET_OUT(1);
    }


LOCAL(VOID) SWD_ResetTarget(VOID)
    {
    SWD_SetTargetReset(1); HAL_Delay(50);
    SWD_SetTargetReset(0); HAL_Delay(50);
    }



LOCAL(BOOL) SWD_ClearErrors(VOID)
    {
    return SWD_WriteDP(SWD_DP_ABORT, STKCMPCLR|STKERRCLR|WDERRCLR|ORUNERRCLR);
    }



LOCAL(BOOL) SWD_InitDebug(VOID)
    {
    int   Retry, Rslt=FALSE, Code=0;
    UINT  T, ID;
    DWORD Time;

    //Init dap state with fake values
    DAP_State.Select=~0;
    DAP_State.Csw=~0;
    LastFlashFunc=FLASH_FUNC_NOP;

    for (Retry=0; Retry<4; Retry++)
        {
        Loop:
        if (Retry>0)
            {
            Printf("ErrCode=%d"CRLF, Code);
            //do an abort on stale target, then reset the device
            SWD_WriteDP(SWD_DP_ABORT, DAPABORT);
            SWD_ResetTarget();
            }

        Code=1;
        if (JTAG2SWD(&ID)==FALSE) {Printf("GetSWDID Error"CRLF, ID); continue;}
        Printf("SWDID=%X" CRLF, ID);

        Code=2;
        if (SWD_ClearErrors()==FALSE) continue;

        Code=3;
        if (SWD_WriteDPSelect(0)==FALSE) continue;

        //Power up
        Code=4;
        if (SWD_WriteDP(SWD_DP_CTRLSTAT, CSYSPWRUPREQ|CDBGPWRUPREQ)==FALSE) continue;

        Code=5;
        Time=GetTickCount();
        for (;;)
            {
            if (SWD_ReadDP(SWD_DP_CTRLSTAT, &T)!=FALSE &&
                (T&(CDBGPWRUPACK|CSYSPWRUPACK))==(CDBGPWRUPACK|CSYSPWRUPACK)) break; //Break from loop if powerup is complete
            if (GetTickCount()-Time>=1000) {Retry++; goto Loop;}                //Unable to powerup DP
            }

        Code=6;
        if (SWD_WriteDP(SWD_DP_CTRLSTAT, CSYSPWRUPREQ|CDBGPWRUPREQ|TRNNORMAL|MASKLANE)==FALSE) continue;

        Code=7;
        if (SWD_WriteDPSelect(0)==FALSE) continue;
        Rslt++;
        break;
        }
    return Rslt;
    }




VOID WINAPI AddTargetDevice(CONST TARGET_CFG_T *TargetDev)
    {
    if (TargetDeviceQty<TARGETDEVICELISTMAX) TargetDeviceList[TargetDeviceQty++]=TargetDev;
    }


LPCSTR WINAPI GetTargetDeviceName(int Index)
    {
    LPCSTR lp=NULL;

    if (Index<TargetDeviceQty) lp=TargetDeviceList[Index]->RtBoardId;
    return lp;
    }


//-----------------------------------------------------------------------------
//      ���̸�: swd_set_target_state_sw / swd_set_target_state_hw
//-----------------------------------------------------------------------------
#define ENTERDEBUGMODERETRY 2
BOOL WINAPI SWD_SetTargetState(TARGET_STATE_T State)
    {
    int  I, Rslt=FALSE;
    UINT Value;

    if (State!=TS_RUN) SWD_InitPort();    //Calling swd_init prior to entering RUN State causes operations to fail.
    switch (State)
        {
        case TS_RESET_HOLD:
            SWD_SetTargetReset(1);
            break;

        case TS_RESET_RUN:
            SWD_ResetTarget();
            SWD_UninitPort();
            break;

        case TS_RESET_PROGRAM_SW:
        case TS_RESET_PROGRAM_HW:
            if (SWD_InitDebug()==FALSE) goto ProcExit;

            if (State==TS_RESET_PROGRAM_SW)
                {
                Value=DBGKEY|C_DEBUGEN|C_HALT;
                }
            else{
                Value=DBGKEY|C_DEBUGEN;
                if (ResetConnect==CONNECT_UNDER_RESET) {SWD_SetTargetReset(1); HAL_Delay(2);}
                }

            for (I=0; I<ENTERDEBUGMODERETRY; I++)
                {
                if (SWD_WriteDW(DHCSR, Value)) break;
                SWD_ResetTarget();
                }

            if (State==TS_RESET_PROGRAM_SW && SWD_WaitUntilHalted()==FALSE) goto ProcExit;
            if (SWD_WriteDW(DEMCR, VC_CORERESET)==FALSE) goto ProcExit;         //Enable halt on reset

            if (State==TS_RESET_PROGRAM_SW)
                {
                if (SWD_ReadDW(NVIC_AIRCR, &Value)==FALSE) goto ProcExit;           //Perform a soft reset
                if (SWD_WriteDW(NVIC_AIRCR, VECTKEY|(Value&SCB_AIRCR_PRIGROUP_Msk)|SoftReset)==FALSE) goto ProcExit;
                HAL_Delay(2);
                }
            else{
                if (ResetConnect==CONNECT_NORMAL) {SWD_SetTargetReset(1); HAL_Delay(2);}
                SWD_SetTargetReset(0); HAL_Delay(2);
                }

            if (SWD_WaitUntilHalted()==FALSE) goto ProcExit;
            if (SWD_WriteDW(DEMCR, 0)==FALSE) goto ProcExit;                    //Disable halt on reset
            break;

        case TS_NODEBUG:
            if (SWD_WriteDW(DHCSR, DBGKEY)==FALSE) goto ProcExit;
            break;

        case TS_DEBUG:
            if (JTAG2SWD(&Value)==FALSE) goto ProcExit;
            if (SWD_ClearErrors()==FALSE) goto ProcExit;
            if (SWD_WriteDPSelect(0)==FALSE) goto ProcExit;                     //Ensure CTRL/STAT register selected in DPBANKSEL
            if (SWD_WriteDP(SWD_DP_CTRLSTAT, CSYSPWRUPREQ|CDBGPWRUPREQ)==FALSE) goto ProcExit; //Power up
            if (SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN)==FALSE) goto ProcExit;     //Enable debug
            break;

        case TS_HALT:
            if (SWD_InitDebug()==FALSE) goto ProcExit;
            if (SWD_WriteDW(DHCSR, DBGKEY|C_DEBUGEN|C_HALT)==FALSE) goto ProcExit;      //Enable debug and halt the core (DHCSR <- 0xA05F0003)
            if (SWD_WaitUntilHalted()==FALSE) goto ProcExit;
            break;

        case TS_RUN:
            if (SWD_WriteDW(DHCSR, DBGKEY)==FALSE) goto ProcExit;
            SWD_UninitPort();
            break;

        default: goto ProcExit;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }




#ifdef USE_JFAT
//-----------------------------------------------------------------------------
//          ������ �о� Ÿ�ٿ� ���α׷�����
//-----------------------------------------------------------------------------
BOOL WINAPI TargetFlash_ProgrammingFile(UINT Addr, LPCSTR TargetDevice, LPCSTR BinFName, ftProgrammingProgress fpProgrammingProgress, LPVOID ProgrammingProgressArg)
    {
    int   Rslt=FALSE, ToReadSize, FileSize, Progress, RemainBytes;
    UINT  StartTime;
    HFILE hFile=HFILE_ERROR;
    LPBYTE Buff=NULL;

    SetLedStatus(LS_PROGRAMMING);
    StartTime=GetTickCount();
    if (SelectTargetDevice(TargetDevice)==FALSE) goto ProcExit;

    if (SWD_SetTargetState(TS_RESET_PROGRAM_SW)==FALSE)
        {
        Printf("SWD_SetTargetState(TS_RESET_PROGRAM_SW) Error"CRLF);
        goto ProcExit;
        }

    if (SWD_IsCoreReady()==FALSE)
        {
        Printf("SWD is not Debug Mode"CRLF);
        goto ProcExit;
        }

    if (TargetFlash_SetAlgo(Addr)==FALSE)
        {
        Printf("TargetFlash_SetAlgo(%Xh) Error=%d"CRLF, Addr, GetLastError());
        goto ProcExit;
        }

    if ((hFile=_lopen(BinFName, OF_READ))==HFILE_ERROR)
        {
        Printf("'%s' not Found"CRLF, BinFName);
        goto ProcExit;
        }

    RemainBytes=FileSize=GetFileSize(hFile);
    if ((Buff=(LPBYTE)AllocMem(TargetFlash_GetErasePageMax(), MEMOWNER_TargetFlash_ProgrammingFile))==NULL) goto ProcExit;

    for (;;)
        {
        if (RemainBytes==0)
            {
            Printf("\r%,d Bytes Programming OK (%d Sec)"CRLF, FileSize, (GetTickCount()-StartTime+500)/1000);
            if (fpProgrammingProgress) fpProgrammingProgress(ProgrammingProgressArg, Addr, 100);
            break;
            }

        if ((Addr & 0xFFF)==0)
            {
            Progress=(FileSize-RemainBytes)*100/FileSize;
            Printf("\rWriting %X (%d%%)...", Addr, Progress);
            if (fpProgrammingProgress!=NULL &&
                fpProgrammingProgress(ProgrammingProgressArg, Addr, Progress)!=FALSE)
                {
                Printf(CRLF "Aborted by user...." CRLF);
                goto ProcExit;
                }
            }

        ToReadSize=TargetFlash_GetErasePageSize(Addr);
        FillMem(Buff, ToReadSize, 0xFF);
        ToReadSize=GetMin(ToReadSize, RemainBytes);
        if (_lread(hFile, Buff, ToReadSize)!=ToReadSize)
            {
            Printf(CRLF "'%s' read Error"CRLF, BinFName);
            goto ProcExit;
            }

        if (TargetFlash_EraseSector(Addr)==FALSE)
            {
            Printf("TargetFlash_EraseSector(%Xh) Error=%d"CRLF, Addr, GetLastError());
            goto ProcExit;
            }

        if (TargetFlash_ProgramPage(Addr, Buff, ToReadSize)==FALSE)
            {
            Printf("TargetFlash_ProgramPage(%Xh) Error=%d"CRLF, Addr, GetLastError());
            goto ProcExit;
            }
        Addr+=ToReadSize;
        RemainBytes-=ToReadSize;
        }

    Printf("Write Flash OK"CRLF);
    Rslt++;

    ProcExit:
    FlashFuncFinish();      //Flash�� Lock�� ��
    SWD_SetTargetState(TS_RESET_RUN);
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    FreeMem(Buff);
    SetLedStatus(Rslt ? LS_RESULTOK:LS_RESULTFAIL);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//          Ÿ�� ��������
//-----------------------------------------------------------------------------
BOOL WINAPI TargetFlash_VerifyFile(UINT Addr, LPCSTR TargetDevice, LPCSTR BinFName, ftProgrammingProgress fpProgrammingProgress, LPVOID ProgrammingProgressArg)
    {
    int   Rslt=FALSE, PageSize, ToReadSize, Progress, FileSize, RemainBytes;
    DWORD StartTime;
    HFILE hFile=HFILE_ERROR;
    LPBYTE DataBuff=NULL, VerifyBuff;
    CONST PROGRAM_TARGET_T *PT;

    SetLedStatus(LS_VERIFYING);
    StartTime=GetTickCount();
    if (SelectTargetDevice(TargetDevice)==FALSE) goto ProcExit;

    if (SWD_SetTargetState(TS_RESET_PROGRAM_SW)==FALSE)
        {
        Printf("SWD_SetTargetState(TS_RESET_PROGRAM_SW) Error"CRLF);
        goto ProcExit;
        }

    if (SWD_IsCoreReady()==FALSE)
        {
        Printf("SWD is not Debug Mode"CRLF);
        goto ProcExit;
        }

    if (TargetFlash_SetAlgo(Addr)==FALSE)
        {
        Printf("TargetFlash_SetAlgo(%Xh) Error=%d"CRLF, Addr, GetLastError());
        goto ProcExit;
        }

    if ((hFile=_lopen(BinFName, OF_READ))==HFILE_ERROR)
        {
        Printf("'%s' not Found"CRLF, BinFName);
        goto ProcExit;
        }
    RemainBytes=FileSize=GetFileSize(hFile);

    PageSize=TargetFlash_GetErasePageMax();
    ALLOCMEM2(DataBuff, PageSize,
              VerifyBuff, PageSize,
              MEMOWNER_TargetFlash_VerifyFile, ProcExit);

    PT=CurrentFlashAlgo;
    if (PT->GetCRC32==NULL)
        {
        for (;;)
            {
            if (RemainBytes==0)
                {
                Printf("\r%,d Bytes Verify OK (%d Sec)"CRLF, FileSize, (GetTickCount()-StartTime+500)/1000);
                if (fpProgrammingProgress) fpProgrammingProgress(ProgrammingProgressArg, Addr, 100);
                break;
                }

            if ((Addr & 0xFFF)==0)
                {
                Progress=(FileSize-RemainBytes)*100/FileSize;
                Printf("\rVerify %X (%d%%)...", Addr, Progress);
                if (fpProgrammingProgress!=NULL &&
                    fpProgrammingProgress(ProgrammingProgressArg, Addr, Progress)!=FALSE)
                    {
                    Printf(CRLF "Aborted by user...." CRLF);
                    goto ProcExit;
                    }
                }

            ToReadSize=GetMin(TargetFlash_GetErasePageSize(Addr), RemainBytes);
            if (_lread(hFile, DataBuff, ToReadSize)!=ToReadSize)
                {
                Printf("'%s' read Error"CRLF, BinFName);
                goto ProcExit;
                }

            if (SWD_ReadMemory(Addr, VerifyBuff, ToReadSize)==FALSE) goto VerifyFail;
            if (CompMem(DataBuff, VerifyBuff, ToReadSize)!=0)
                {
                VerifyFail:
                Printf(" FAIL (Error=%d)"CRLF, GetLastError());
                goto ProcExit;
                }

            Addr+=ToReadSize;
            RemainBytes-=ToReadSize;
            }
        }
    else{
        DWORD Crc32=~0, TF_Rslt, Tick;

        if (SWD_FlashSyscallRun(&PT->SysCall, PT->GetCRC32, Addr, RemainBytes, 0, 0)==FALSE)
            {
            Printf("Verify FAIL (SWD_FlashSyscallRun() Error)"CRLF);
            goto ProcExit;
            }

        Tick=GetTickCount();
        for (;;)
            {
            if (RemainBytes==0 || (Addr & 0xFFFF)==0) Printf("\rCalc CRC: %X (%d%%)", Addr, (FileSize-RemainBytes)*100/FileSize);
            if (RemainBytes==0) break;
            ToReadSize=GetMin(PageSize, RemainBytes);

            if (_lread(hFile, DataBuff, ToReadSize)!=ToReadSize)
                {
                Printf(CRLF "'%s' read Error"CRLF, BinFName);
                goto ProcExit;
                }
            Crc32=CalculateCRC(DataBuff, ToReadSize, Crc32);

            Addr+=ToReadSize;
            RemainBytes-=ToReadSize;
            }
        Printf(CRLF "Source CRC=%X, %d ms"CRLF, Crc32, GetTickCount()-Tick);

        if (SWD_WaitDoneFlashSyscall(&TF_Rslt)==FALSE)
            {
            Printf("Verify FAIL (SWD_WaitDoneFlashSyscall() Error)"CRLF);
            goto ProcExit;
            }

        if (TF_Rslt!=Crc32)
            {
            Printf("Verify FAIL (Src=%X, Target=%X)"CRLF, Crc32, TF_Rslt);
            goto ProcExit;
            }
        }

    Printf("Verify OK"CRLF);
    Rslt++;

    ProcExit:
    FlashFuncFinish();      //Flash�� Lock�� ��
    SWD_SetTargetState(TS_RESET_RUN);
    FreeMem(DataBuff);
    SetLedStatus(Rslt ? LS_RESULTOK:LS_RESULTFAIL);
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    return Rslt;
    }
#endif //USE_JFAT



VOID WINAPI ReadFlashTest(LPCSTR DevName)
    {
    BYTE Buff[16];
    static CONST CHAR TestStr[]="Hello Mr.JEONG";

    SWD_InitPort();
    if (SWD_InitDebug()==FALSE)
        {
        Printf("SWD_InitDebug() Error" CRLF);
        goto ProcExit;
        }

    SWD_ReadMemory(0x20000000, Buff, 16); DumpMem(Buff, 16);
    SWD_WriteMemory(0x20000000, (LPCBYTE)TestStr, 16);
    SWD_ReadMemory(0x20000000, Buff, 16); DumpMem(Buff, 16);

    //Printf("FlashAlgo=%X"CRLF, GetFlashAlgo(0x0801F000)->AlgoBlob);
    //Printf("TargetFlash_GetErasePageMax()=%Xh"CRLF, TargetFlash_GetErasePageMax());

    if (SelectTargetDevice(DevName)==FALSE) goto ProcExit;
    if (SWD_SetTargetState(TS_RESET_PROGRAM_HW)==FALSE)
        {
        Printf("SWD_SetTargetState(TS_RESET_PROGRAM_HW) Error"CRLF);
        goto ProcExit;
        }

    if (SWD_IsCoreReady()==FALSE)
        {
        Printf("SWD is not Debug Mode"CRLF);
        goto ProcExit;
        }
    TargetFlash_SetAlgo(0x08000000);

    ProcExit:;
    }




#define CLOCK_DELAY(SwjClk)     (CPU_CLOCK/2/SwjClk - IO_PORT_WRITE_CYCLES)
VOID WINAPI DAP_Setup(VOID)
    {
    //Default settings
    DAP_Data.ClockDelay=1;  //1:16��, 5:18��, 10:19��, CLOCK_DELAY(DAP_DEFAULT_SWJ_CLOCK);
                            //�߱���������δٿ�δ�:10.5��, KEIL:30��
                            //-----O3 ������
                            //  1: 3.9MHz (85KB, 14Sec)
                            // 10: 2.4MHz (85KB, 18Sec)
                            // 20: 1.6MHz (85KB, 20Sec)
                            // 50: 1MHz   (85KB, 30Sec)
                            //100: 500KHz (85KB, 53Sec)
                            //-----O0 ������
                            //  1: 2.6MHz (85KB, 16Sec)
    DAP_Data.Tx.IdleCycles=0;
    DAP_Data.SWD_Turnaround=1;
    DAP_Data.SWD_DataPhase=0;

    INITTARGET();
    }



VOID WINAPI SWD_SetDelay(int Delay)
    {
    DAP_Data.ClockDelay=Delay;
    }


