///////////////////////////////////////////////////////////////////////////////
//          ��ġ�е� ����̹�
//          FT5336 ... ������ġ 5��, ������ġ
///////////////////////////////////////////////////////////////////////////////
#include "JLIB.H"
#include "DRIVER.H"
#include "FT5336.H"

#define TS_MULTI_TOUCH_SUPPORTED            1

#define FT5336_I2C_SLAVEADDR                0x70

#define FT5336_MAX_WIDTH                    480
#define FT5336_MAX_HEIGHT                   272

#define FT5336_STATUS_OK                    0x00
#define FT5336_STATUS_NOT_OK                0x01

#define FT5336_I2C_NOT_INITIALIZED          0x00
#define FT5336_I2C_INITIALIZED              0x01

//#define FT5336_MAX_DETECTABLE_TOUCH       0x05


#define FT5336_DEV_MODE_REG                 0x00
#define FT5336_DEV_MODE_WORKING             0x00
#define FT5336_DEV_MODE_FACTORY             0x04
#define FT5336_DEV_MODE_MASK                0x07
#define FT5336_DEV_MODE_SHIFT               0x04

#define FT5336_GEST_ID_REG                  0x01
#define FT5336_GEST_ID_NO_GESTURE           0x00
#define FT5336_GEST_ID_MOVE_UP              0x10
#define FT5336_GEST_ID_MOVE_RIGHT           0x14
#define FT5336_GEST_ID_MOVE_DOWN            0x18
#define FT5336_GEST_ID_MOVE_LEFT            0x1C
#define FT5336_GEST_ID_SINGLE_CLICK         0x20
#define FT5336_GEST_ID_DOUBLE_CLICK         0x22
#define FT5336_GEST_ID_ROTATE_CLOCKWISE     0x28
#define FT5336_GEST_ID_ROTATE_C_CLOCKWISE   0x29
#define FT5336_GEST_ID_ZOOM_IN              0x40
#define FT5336_GEST_ID_ZOOM_OUT             0x49

#define FT5336_TD_STAT_REG                  0x02
#define FT5336_TD_STAT_MASK                 0x0F
#define FT5336_TD_STAT_SHIFT                0x00

#define FT5336_TOUCH_EVT_FLAG_PRESS_DOWN    0x00
#define FT5336_TOUCH_EVT_FLAG_LIFT_UP       0x01
#define FT5336_TOUCH_EVT_FLAG_CONTACT       0x02
#define FT5336_TOUCH_EVT_FLAG_NO_EVENT      0x03
#define FT5336_TOUCH_EVT_FLAG_SHIFT         6
#define FT5336_TOUCH_EVT_FLAG_MASK          (3<<FT5336_TOUCH_EVT_FLAG_SHIFT)
#define FT5336_TOUCH_POS_MSB_MASK           0x0F
#define FT5336_TOUCH_POS_MSB_SHIFT          0x00
#define FT5336_TOUCH_POS_LSB_MASK           0xFF
#define FT5336_TOUCH_POS_LSB_SHIFT          0x00

#define FT5336_P1_XH_REG                    0x03
#define FT5336_P1_XL_REG                    0x04
#define FT5336_P1_YH_REG                    0x05
#define FT5336_P1_YL_REG                    0x06

#define FT5336_P1_WEIGHT_REG                0x07

#define FT5336_P1_MISC_REG                  0x08
#define FT5336_TOUCH_AREA_MASK              (0x04<<4)
#define FT5336_TOUCH_AREA_SHIFT             4

#define FT5336_P2_XH_REG                    0x09
#define FT5336_P2_XL_REG                    0x0A
#define FT5336_P2_YH_REG                    0x0B
#define FT5336_P2_YL_REG                    0x0C
#define FT5336_P2_WEIGHT_REG                0x0D
#define FT5336_P2_MISC_REG                  0x0E

#define FT5336_P3_XH_REG                    0x0F
#define FT5336_P3_XL_REG                    0x10
#define FT5336_P3_YH_REG                    0x11
#define FT5336_P3_YL_REG                    0x12
#define FT5336_P3_WEIGHT_REG                0x13
#define FT5336_P3_MISC_REG                  0x14

#define FT5336_P4_XH_REG                    0x15
#define FT5336_P4_XL_REG                    0x16
#define FT5336_P4_YH_REG                    0x17
#define FT5336_P4_YL_REG                    0x18
#define FT5336_P4_WEIGHT_REG                0x19
#define FT5336_P4_MISC_REG                  0x1A

#define FT5336_P5_XH_REG                    0x1B
#define FT5336_P5_XL_REG                    0x1C
#define FT5336_P5_YH_REG                    0x1D
#define FT5336_P5_YL_REG                    0x1E
#define FT5336_P5_WEIGHT_REG                0x1F
#define FT5336_P5_MISC_REG                  0x20

#define FT5336_P6_XH_REG                    0x21
#define FT5336_P6_XL_REG                    0x22
#define FT5336_P6_YH_REG                    0x23
#define FT5336_P6_YL_REG                    0x24
#define FT5336_P6_WEIGHT_REG                0x25
#define FT5336_P6_MISC_REG                  0x26

#define FT5336_P7_XH_REG                    0x27
#define FT5336_P7_XL_REG                    0x28
#define FT5336_P7_YH_REG                    0x29
#define FT5336_P7_YL_REG                    0x2A
#define FT5336_P7_WEIGHT_REG                0x2B
#define FT5336_P7_MISC_REG                  0x2C

#define FT5336_P8_XH_REG                    0x2D
#define FT5336_P8_XL_REG                    0x2E
#define FT5336_P8_YH_REG                    0x2F
#define FT5336_P8_YL_REG                    0x30
#define FT5336_P8_WEIGHT_REG                0x31
#define FT5336_P8_MISC_REG                  0x32

#define FT5336_P9_XH_REG                    0x33
#define FT5336_P9_XL_REG                    0x34
#define FT5336_P9_YH_REG                    0x35
#define FT5336_P9_YL_REG                    0x36
#define FT5336_P9_WEIGHT_REG                0x37
#define FT5336_P9_MISC_REG                  0x38

#define FT5336_P10_XH_REG                   0x39
#define FT5336_P10_XL_REG                   0x3A
#define FT5336_P10_YH_REG                   0x3B
#define FT5336_P10_YL_REG                   0x3C
#define FT5336_P10_WEIGHT_REG               0x3D
#define FT5336_P10_MISC_REG                 0x3E

#define FT5336_TH_GROUP_REG                 0x80
#define FT5336_THRESHOLD_MASK               0xFF
#define FT5336_THRESHOLD_SHIFT              0x00

#define FT5336_TH_DIFF_REG                  0x85
#define FT5336_CTRL_REG                     0x86

#define FT5336_CTRL_KEEP_ACTIVE_MODE        0x00

#define FT5336_CTRL_KEEP_AUTO_SWITCH_MONITOR_MODE  0x01

#define FT5336_TIMEENTERMONITOR_REG         0x87
#define FT5336_PERIODACTIVE_REG             0x88
#define FT5336_PERIODMONITOR_REG            0x89
#define FT5336_RADIAN_VALUE_REG             0x91
#define FT5336_OFFSET_LEFT_RIGHT_REG        0x92
#define FT5336_OFFSET_UP_DOWN_REG           0x93
#define FT5336_DISTANCE_LEFT_RIGHT_REG      0x94
#define FT5336_DISTANCE_UP_DOWN_REG         0x95
#define FT5336_DISTANCE_ZOOM_REG            0x96
#define FT5336_LIB_VER_H_REG                0xA1
#define FT5336_LIB_VER_L_REG                0xA2
#define FT5336_CIPHER_REG                   0xA3

#define FT5336_GMODE_REG                    0xA4
#define FT5336_G_MODE_INTERRUPT_MASK        0x03
#define FT5336_G_MODE_INTERRUPT_SHIFT       0x00
#define FT5336_G_MODE_INTERRUPT_POLLING     0x00
#define FT5336_G_MODE_INTERRUPT_TRIGGER     0x01

#define FT5336_PWR_MODE_REG                 0xA5
#define FT5336_FIRMID_REG                   0xA6
#define FT5336_CHIP_ID_REG                  0xA8
#define FT5336_ID_VALUE                     0x51
#define FT5336_RELEASE_CODE_ID_REG          0xAF
#define FT5336_STATE_REG                    0xBC


#define TS_MAX_NB_TOUCH                     FT5336_MAX_DETECTABLE_TOUCH
#define TS_NO_IRQ_PENDING                   0
#define TS_IRQ_PENDING                      1



typedef enum
    {
    TS_OK=0x00,
    TS_ERROR=0x01,
    TS_TIMEOUT=0x02,
    TS_DEVICE_NOT_FOUND=0x03
    } TS_StatusTypeDef;


typedef enum
    {
    TOUCH_EVENT_NO_EVT=0x00,
    TOUCH_EVENT_PRESS_DOWN=0x01,
    TOUCH_EVENT_LIFT_UP=0x02,
    TOUCH_EVENT_CONTACT=0x03,
    TOUCH_EVENT_NB_MAX=0x04
    } TS_TouchEventTypeDef;


typedef enum
    {
    GEST_ID_NO_GESTURE=0x00,
    GEST_ID_MOVE_UP=0x01,
    GEST_ID_MOVE_RIGHT=0x02,
    GEST_ID_MOVE_DOWN=0x03,
    GEST_ID_MOVE_LEFT=0x04,
    GEST_ID_ZOOM_IN=0x05,
    GEST_ID_ZOOM_OUT=0x06,
    GEST_ID_NB_MAX=0x07
    } TS_GestureIdTypeDef;




#define FT5336_MAX_DETECTABLE_TOUCH     5

typedef struct
    {
    BYTE TouchDetectQty;
    BYTE GestureId;
    WORD TouchX[FT5336_MAX_DETECTABLE_TOUCH];
    WORD TouchY[FT5336_MAX_DETECTABLE_TOUCH];
    BYTE TouchWeight[FT5336_MAX_DETECTABLE_TOUCH];
    BYTE TouchEventId[FT5336_MAX_DETECTABLE_TOUCH];
    BYTE TouchArea[FT5336_MAX_DETECTABLE_TOUCH];
    } TS_StateTypeDef;



//static WORD TS_BoundaryX, TS_BoundaryY;
static BYTE TS_Orientation;




LOCAL(VOID) TOUCH_Write(UINT Reg, UINT Value)
    {
    BYTE Buff[4];

    Buff[0]=Reg;
    Buff[1]=Value;
    if (I2C_MasterTx(TOUCH_I2C_NO, FT5336_I2C_SLAVEADDR, Buff, 2, 100)!=HAL_OK)
    //if (I2C_MemWrite(TOUCH_I2C_NO, FT5336_I2C_SLAVEADDR, Reg, I2C_MEMADD_SIZE_8BIT, (LPCBYTE)&Value, 1, 100)!=HAL_OK)
        I2C_Init(TOUCH_I2C_NO, TOUCH_I2C_TIMING);
    }


LOCAL(UINT) TOUCH_Read(UINT Reg)
    {
    UINT Data=0;
    BYTE Buff[4];

    Buff[0]=Reg;
    I2C_MasterTx(TOUCH_I2C_NO, FT5336_I2C_SLAVEADDR, Buff, 1, 100);
    if (I2C_MasterRx(TOUCH_I2C_NO, FT5336_I2C_SLAVEADDR, (LPBYTE)&Data, 1, 100)!=HAL_OK)
    //if (I2C_MemRead(TOUCH_I2C_NO, FT5336_I2C_SLAVEADDR, Reg, I2C_MEMADD_SIZE_8BIT, (LPBYTE)&Data, 1, 100)!=HAL_OK)
        I2C_Init(TOUCH_I2C_NO, TOUCH_I2C_TIMING);
    return Data;
    }


#ifdef PI_TOUCH_IT
LOCAL(VOID) FT5336_EnableIT(VOID)
    {
    TOUCH_Write(FT5336_GMODE_REG, FT5336_G_MODE_INTERRUPT_TRIGGER & FT5336_G_MODE_INTERRUPT_MASK);
    }
#endif



LOCAL(VOID) FT5336_DisableIT(VOID)
    {
    TOUCH_Write(FT5336_GMODE_REG, FT5336_G_MODE_INTERRUPT_POLLING & FT5336_G_MODE_INTERRUPT_MASK);
    }



LOCAL(UINT) FT5336_ReadID(VOID)
    {
    UINT I, ReadId=0;

    for (I=0; I<3; I++)
        {
        if ((ReadId=TOUCH_Read(FT5336_CHIP_ID_REG))==FT5336_ID_VALUE) break;
        }
    return ReadId;
    }




LOCAL(VOID) FT5336_GetXY(int Index, WORD *lpX, WORD *lpY)
    {
    UINT RegXL, RegXH, RegYL, RegYH;

    RegXL=RegXH=RegYL=RegYH=0;
    switch (Index)
        {
        case 0:
            RegXL=FT5336_P1_XL_REG;
            RegXH=FT5336_P1_XH_REG;
            RegYL=FT5336_P1_YL_REG;
            RegYH=FT5336_P1_YH_REG;
            break;

        case 1:
            RegXL=FT5336_P2_XL_REG;
            RegXH=FT5336_P2_XH_REG;
            RegYL=FT5336_P2_YL_REG;
            RegYH=FT5336_P2_YH_REG;
            break;

        case 2:
            RegXL=FT5336_P3_XL_REG;
            RegXH=FT5336_P3_XH_REG;
            RegYL=FT5336_P3_YL_REG;
            RegYH=FT5336_P3_YH_REG;
            break;

        case 3:
            RegXL=FT5336_P4_XL_REG;
            RegXH=FT5336_P4_XH_REG;
            RegYL=FT5336_P4_YL_REG;
            RegYH=FT5336_P4_YH_REG;
            break;

        case 4:
            RegXL=FT5336_P5_XL_REG;
            RegXH=FT5336_P5_XH_REG;
            RegYL=FT5336_P5_YL_REG;
            RegYH=FT5336_P5_YH_REG;
            break;

        case 5:
            RegXL=FT5336_P6_XL_REG;
            RegXH=FT5336_P6_XH_REG;
            RegYL=FT5336_P6_YL_REG;
            RegYH=FT5336_P6_YH_REG;
            break;

        case 6:
            RegXL=FT5336_P7_XL_REG;
            RegXH=FT5336_P7_XH_REG;
            RegYL=FT5336_P7_YL_REG;
            RegYH=FT5336_P7_YH_REG;
            break;

        case 7:
            RegXL=FT5336_P8_XL_REG;
            RegXH=FT5336_P8_XH_REG;
            RegYL=FT5336_P8_YL_REG;
            RegYH=FT5336_P8_YH_REG;
            break;

        case 8:
            RegXL=FT5336_P9_XL_REG;
            RegXH=FT5336_P9_XH_REG;
            RegYL=FT5336_P9_YL_REG;
            RegYH=FT5336_P9_YH_REG;
            break;

        case 9:
            RegXL=FT5336_P10_XL_REG;
            RegXH=FT5336_P10_XH_REG;
            RegYL=FT5336_P10_YL_REG;
            RegYH=FT5336_P10_YH_REG;
            //break;
        }

    *lpX=TOUCH_Read(RegXL) | ((TOUCH_Read(RegXH)&0x0F)<<8);
    *lpY=TOUCH_Read(RegYL) | ((TOUCH_Read(RegYH)&0x0F)<<8);
    }




#if TS_MULTI_TOUCH_SUPPORTED==1

LOCAL(UINT) FT5336_GetGestureID(VOID)
    {
    return TOUCH_Read(FT5336_GEST_ID_REG);
    }



LOCAL(VOID) FT5336_GetTouchInfo(UINT TouchIdx, UINT *lpWeight, UINT *lpArea, UINT *lpEvent)
    {
    UINT RegXH, RegPWeight, RegPMisc;

    RegXH=RegPWeight=RegPMisc=0;
    switch (TouchIdx)
        {
        case 0:
            RegXH=FT5336_P1_XH_REG;
            RegPWeight=FT5336_P1_WEIGHT_REG;
            RegPMisc=FT5336_P1_MISC_REG;
            break;

        case 1:
            RegXH=FT5336_P2_XH_REG;
            RegPWeight=FT5336_P2_WEIGHT_REG;
            RegPMisc=FT5336_P2_MISC_REG;
            break;

        case 2:
            RegXH=FT5336_P3_XH_REG;
            RegPWeight=FT5336_P3_WEIGHT_REG;
            RegPMisc=FT5336_P3_MISC_REG;
            break;

        case 3:
            RegXH=FT5336_P4_XH_REG;
            RegPWeight=FT5336_P4_WEIGHT_REG;
            RegPMisc=FT5336_P4_MISC_REG;
            break;

        case 4:
            RegXH=FT5336_P5_XH_REG;
            RegPWeight=FT5336_P5_WEIGHT_REG;
            RegPMisc=FT5336_P5_MISC_REG;
            break;

        case 5:
            RegXH=FT5336_P6_XH_REG;
            RegPWeight=FT5336_P6_WEIGHT_REG;
            RegPMisc=FT5336_P6_MISC_REG;
            break;

        case 6:
            RegXH=FT5336_P7_XH_REG;
            RegPWeight=FT5336_P7_WEIGHT_REG;
            RegPMisc=FT5336_P7_MISC_REG;
            break;

        case 7:
            RegXH=FT5336_P8_XH_REG;
            RegPWeight=FT5336_P8_WEIGHT_REG;
            RegPMisc=FT5336_P8_MISC_REG;
            break;

        case 8:
            RegXH=FT5336_P9_XH_REG;
            RegPWeight=FT5336_P9_WEIGHT_REG;
            RegPMisc=FT5336_P9_MISC_REG;
            break;

        case 9:
            RegXH=FT5336_P10_XH_REG;
            RegPWeight=FT5336_P10_WEIGHT_REG;
            RegPMisc=FT5336_P10_MISC_REG;
            //break;
        }

    *lpEvent=(TOUCH_Read(RegXH) & FT5336_TOUCH_EVT_FLAG_MASK)>>FT5336_TOUCH_EVT_FLAG_SHIFT;
    *lpWeight=TOUCH_Read(RegPWeight);
    *lpArea=(TOUCH_Read(RegPMisc) & FT5336_TOUCH_AREA_MASK)>>FT5336_TOUCH_AREA_SHIFT;
    }
#endif //TS_MULTI_TOUCH_SUPPORTED




#if TS_MULTI_TOUCH_SUPPORTED==1
LOCAL(UINT) TOUCH_GetGestureId(VOID)
    {
    UINT GestureId=GEST_ID_NO_GESTURE;

    switch (FT5336_GetGestureID())
        {
        case FT5336_GEST_ID_MOVE_UP:    GestureId=GEST_ID_MOVE_UP; break;
        case FT5336_GEST_ID_MOVE_RIGHT: GestureId=GEST_ID_MOVE_RIGHT; break;
        case FT5336_GEST_ID_MOVE_DOWN:  GestureId=GEST_ID_MOVE_DOWN; break;
        case FT5336_GEST_ID_MOVE_LEFT:  GestureId=GEST_ID_MOVE_LEFT; break;
        case FT5336_GEST_ID_ZOOM_IN:    GestureId=GEST_ID_ZOOM_IN; break;
        case FT5336_GEST_ID_ZOOM_OUT:   GestureId=GEST_ID_ZOOM_OUT; //break;
        }
    return GestureId;
    }
#endif




LOCAL(VOID) TOUCH_GetState(TS_StateTypeDef*TS)
    {
    UINT I, TouchQty;
    WORD DiffX, DiffY;
    WORD X[TS_MAX_NB_TOUCH];
    WORD Y[TS_MAX_NB_TOUCH];
    WORD BruteX[TS_MAX_NB_TOUCH];
    WORD BruteY[TS_MAX_NB_TOUCH];
    #if TS_MULTI_TOUCH_SUPPORTED==1
    UINT Weight, Area, Event;
    #endif
    static UINT Gx[TS_MAX_NB_TOUCH];
    static UINT Gy[TS_MAX_NB_TOUCH];

    if ((TouchQty=TOUCH_Read(FT5336_TD_STAT_REG)&0x0F) > FT5336_MAX_DETECTABLE_TOUCH) TouchQty=0;
    TS->TouchDetectQty=TouchQty;

    for (I=0; I<TouchQty; I++)
        {
        FT5336_GetXY(I, &BruteX[I], &BruteY[I]);

        if (TS_Orientation==TS_SWAP_NONE) {X[I]=BruteX[I]; Y[I]=BruteY[I];}
        if (TS_Orientation&TS_SWAP_X) X[I]=4096-BruteX[I];
        if (TS_Orientation&TS_SWAP_Y) Y[I]=4096-BruteY[I];
        if (TS_Orientation&TS_SWAP_XY) {Y[I]=BruteX[I]; X[I]=BruteY[I];}

        DiffX=GetDiff(X[I], Gx[I]);
        DiffY=GetDiff(Y[I], Gy[I]);
        if (DiffX+DiffY>5) {Gx[I]=X[I]; Gy[I]=Y[I];}

        TS->TouchX[I]=X[I];
        TS->TouchY[I]=Y[I];
        //TS->TouchX[I]=(TS_BoundaryX*Gx[I])>>12;
        //TS->TouchY[I]=(TS_BoundaryY*Gy[I])>>12;

        #if TS_MULTI_TOUCH_SUPPORTED==1
        Weight=Area=Event=0;
        FT5336_GetTouchInfo(I, &Weight, &Area, &Event);
        TS->TouchWeight[I]=Weight;
        TS->TouchArea[I]=Area;
        switch (Event)
            {
            case FT5336_TOUCH_EVT_FLAG_PRESS_DOWN:  TS->TouchEventId[I]=TOUCH_EVENT_PRESS_DOWN;   break;
            case FT5336_TOUCH_EVT_FLAG_LIFT_UP:     TS->TouchEventId[I]=TOUCH_EVENT_LIFT_UP;      break;
            case FT5336_TOUCH_EVT_FLAG_CONTACT:     TS->TouchEventId[I]=TOUCH_EVENT_CONTACT;      break;
            case FT5336_TOUCH_EVT_FLAG_NO_EVENT:    TS->TouchEventId[I]=TOUCH_EVENT_NO_EVT;       break;
            }
        #endif
        }

    #if TS_MULTI_TOUCH_SUPPORTED==1
    TS->GestureId=TOUCH_GetGestureId();
    #endif
    }




BOOL WINAPI FT5336_Init(UINT ScrSizeX, UINT ScrSizeY, UINT Orientation)
    {
    BOOL Rslt=FALSE;

    //TS_BoundaryX=ScrSizeX;
    //TS_BoundaryY=ScrSizeY;
    TS_Orientation=Orientation;

    HAL_Delay(200);
    I2C_Init(TOUCH_I2C_NO, TOUCH_I2C_TIMING);

    if (FT5336_ReadID()==FT5336_ID_VALUE)
        {
        FT5336_DisableIT();
        Rslt++;
        }

    return Rslt;
    }



VOID WINAPI TOUCH_ITConfig(VOID)
    {
    #ifdef PI_TOUCH_IT
    InitPortEx(PI_TOUCH_IT, GPIO_MODE_IT_RISING, GPIO_NOPULL, 0, GPIO_SPEED_FAST);

    HAL_NVIC_SetPriority(TOUCH_EXTI_IRQn, 0x0F, 0x00);
    NVIC_EnableIRQ(TOUCH_EXTI_IRQn);

    FT5336_EnableIT();
    #endif
    }



VOID WINAPI TOUCH_ResetData(TS_StateTypeDef *TS)
    {
    ZeroMem(TS, sizeof(TS_StateTypeDef));
    }




//-----------------------------------------------------------------------------
//          ��ġ ��ǥ������ ��
//-----------------------------------------------------------------------------
static POINT TouchScrPos;           //ȭ����ǥ
VOID WINAPI GetCursorPos(POINT *P) {*P=TouchScrPos;}

UINT WINAPI GetTouchStatus(POINT *P)
    {
    UINT TouchBtnStat=0;
    TS_StateTypeDef TS;

    TOUCH_GetState(&TS);
    if (TS.TouchDetectQty>0)
        {
        #if LCD_ResolutionX==LCD_LogResolutionX
        TouchScrPos.x=TS.TouchX[0];
        TouchScrPos.y=TS.TouchY[0];
        #else
        TouchScrPos.x=LCD_LogResolutionX-TS.TouchY[0];
        TouchScrPos.y=TS.TouchX[0];
        #endif
        TouchBtnStat++;
        }
    *P=TouchScrPos;
    return TouchBtnStat;
    }


