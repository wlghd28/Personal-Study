///////////////////////////////////////////////////////////////////////////////
//              inflate
//
// Copyright[]=" inflate 1.1.4 Copyright 1995-2002 Mark Adler ";
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "ZLIB.H"


//#define BUILDFIXED
#define PRESET_DICT     0x20
#define MANY            1440
#define Z_DEFLATED      8


#define Assert(cond,msg)
#define Tracev(x)
#define Tracevv(x)


typedef DWORD(WINAPI *check_func) (DWORD check, LPCBYTE buf, UINT len);


#define MEMOWNER_INFLATE                4000
#define MEMOWNER_InflateCodesNew        (MEMOWNER_INFLATE+0)
#define MEMOWNER_InflateTreesBits       (MEMOWNER_INFLATE+1)
#define MEMOWNER_InflateTreesDynamic    (MEMOWNER_INFLATE+2)
#define MEMOWNER_InflateTreesFixed1     (MEMOWNER_INFLATE+3)
#define MEMOWNER_InflateTreesFixed2     (MEMOWNER_INFLATE+4)
#define MEMOWNER_InflateBlocksNew1      (MEMOWNER_INFLATE+5)
#define MEMOWNER_InflateBlocksNew2      (MEMOWNER_INFLATE+6)
#define MEMOWNER_InflateBlocksNew3      (MEMOWNER_INFLATE+7)
#define MEMOWNER_InflateBlocks          (MEMOWNER_INFLATE+8)
#define MEMOWNER_inflateInit2           (MEMOWNER_INFLATE+9)


typedef struct inflate_huft_s
    {
    union{
        struct
            {
            BYTE Exop;
            BYTE Bits;
            } what;
        UINT pad;
        } word;
    UINT base;
    } InflateHuft;


typedef enum
    {
    TYPE,
    LENS,
    STORED,
    TABLE,
    BTREE,
    DTREE,
    CODES,
    DRY,
    DONE,
    BAD
    } InflateBlockMode;


typedef enum
    {
    START,
    LEN,
    LENEXT,
    DIST,
    DISTEXT,
    COPY,
    LIT,
    WASH,
    END,
    BADCODE
    } InflateCodesMode;


typedef struct InflateCodesState
    {
    InflateCodesMode Mode;

    UINT len;
    union{
        struct
            {
            InflateHuft*tree;
            UINT need;
            } code;
        UINT lit;
        struct
            {
            UINT get;
            UINT dist;
            } copy;
        } sub;

    BYTE lbits;
    BYTE dbits;
    InflateHuft*ltree;
    InflateHuft*dtree;
    } InflateCodesState;


typedef enum
    {
    METHOD,
    DICT0,
    BLOCKS,
    IM_DONE,
    IM_BAD
    } InflateMode;

typedef struct _InternalState
    {
    InflateMode Mode;
    int  nowrap;
    int  wbits;

    //InflateBlocksState Blocks;
    InflateBlockMode IBMode;

    union{
        UINT left;
        struct
            {
            UINT table;
            UINT index;
            UINT*blens;
            UINT bb;
            InflateHuft*tb;
            } trees;
        InflateCodesState *codes;
        } sub;

    UINT last;
    InflateHuft*hufts;

    LPBYTE OutBuff, EndPos, GetPos, PutPos;
    check_func checkfn;
    DWORD check;

    UINT  BitQty;
    DWORD BitData;

    //Z ����ü ���� �� ����ü������ �Էµ����͸� ������ ó���ϱ� ����
    BYTE *InPtr;
    UINT  InDataQty;
    } InternalState;


#define exop word.what.Exop
#define bits word.what.Bits


static UINT InflateMask[17]=
    {
    0x0000,
    0x0001, 0x0003, 0x0007, 0x000f, 0x001f, 0x003f, 0x007f, 0x00ff,
    0x01ff, 0x03ff, 0x07ff, 0x0fff, 0x1fff, 0x3fff, 0x7fff, 0xffff
    };




LOCAL(DWORD) adler32(DWORD adler, LPCBYTE buf, UINT len)
    {
    int k;
    DWORD s1=adler&0xffff;
    DWORD s2=adler>>16;

    if (buf==NULL) return 1;

    while (len>0)
        {
        k=len<5552 ? len:5552;
        len-=k;
        while (k>=16)
            {
            s1+=buf[0]; s2+=s1;
            s1+=buf[1]; s2+=s1;
            s1+=buf[2]; s2+=s1;
            s1+=buf[3]; s2+=s1;
            s1+=buf[4]; s2+=s1;
            s1+=buf[5]; s2+=s1;
            s1+=buf[6]; s2+=s1;
            s1+=buf[7]; s2+=s1;
            s1+=buf[8]; s2+=s1;
            s1+=buf[9]; s2+=s1;
            s1+=buf[10]; s2+=s1;
            s1+=buf[11]; s2+=s1;
            s1+=buf[12]; s2+=s1;
            s1+=buf[13]; s2+=s1;
            s1+=buf[14]; s2+=s1;
            s1+=buf[15]; s2+=s1;
            buf+=16;
            k-=16;
            }

        while (k--) {s1+=*buf++; s2+=s1;}

        s1%=65521;
        s2%=65521;
        }

    return (s2<<16)|s1;
    }




///////////////////////////////////////////////////////////////////////////////
//                      INFFAST.CPP
///////////////////////////////////////////////////////////////////////////////




//-----------------------------------------------------------------------------
//      ���̻� Data�� ������ -1���� (���̸�: INEXTBYTE)
//-----------------------------------------------------------------------------
LOCAL(int) GetByte(InternalState *IS)
    {
    if (IS->InDataQty==0) return -1;
    IS->InDataQty--;
    return *IS->InPtr++;
    }



//-----------------------------------------------------------------------------
//      ���̸�: NEEDBITS ... BitData�� Data�غ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) PrepareBits(InternalState *IS, UINT Bits)
    {
    int  B;
    BOOL Rslt=TRUE;

    while (IS->BitQty<Bits)
        {
        if ((B=GetByte(IS))<0) {Rslt=FALSE; break;}
        IS->BitData|=B << IS->BitQty;
        IS->BitQty+=8;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
LOCAL(UINT) GetBits(InternalState *IS, UINT Bits)
    {
    UINT D;

    D=IS->BitData & InflateMask[Bits];
    IS->BitData>>=Bits;
    IS->BitQty-=Bits;
    return D;
    }



LOCAL(int) GetOutputAvialSize(InternalState*IS)
    {
    if (IS->PutPos==IS->EndPos && IS->GetPos!=IS->OutBuff) IS->PutPos=IS->OutBuff;
    return IS->PutPos<IS->GetPos ? (PTR2INT)(IS->GetPos-IS->PutPos-1) : (PTR2INT)(IS->EndPos-IS->PutPos);
    }



LOCAL(int) InflateFast(z_stream *Z, UINT bl, UINT bd, InflateHuft*tl, InflateHuft*td, InternalState*IS)
    {
    int   Rslt, OldInQty;
    UINT  c,d,e,m,ml,md;
    LPBYTE lp;
    InflateHuft*t;

    OldInQty=IS->InDataQty;
    m=GetOutputAvialSize(IS);

    ml=InflateMask[bl];
    md=InflateMask[bd];

    do  {
        PrepareBits(IS, 20);
        if ((e=(t=tl+(IS->BitData&ml))->exop)==0)
            {
            GetBits(IS, t->bits);
            Tracevv((t->base>=0x20 && t->base<0x7f ? "inflate: * literal '%c'\n":"inflate: * literal 0x%02x\n", t->base));
            *IS->PutPos++=(BYTE)t->base; m--;
            continue;
            }

        for (;;)
            {
            GetBits(IS, t->bits);
            if (e&16)
                {
                e&=15;
                c=t->base+GetBits(IS, e);
                Tracevv(("inflate: * length %u\n", c));

                PrepareBits(IS, 15);
                e=(t=td+((UINT) IS->BitData&md))->exop;

                for (;;)
                    {
                    GetBits(IS, t->bits);
                    if (e&16)
                        {
                        e&=15;
                        PrepareBits(IS, e);
                        d=t->base+GetBits(IS, e);
                        Tracevv(("inflate: * distance %u\n", d));

                        m-=c;
                        lp=IS->PutPos-d;
                        if (lp<IS->OutBuff)
                            {
                            do  lp+=IS->EndPos-IS->OutBuff; while (lp<IS->OutBuff);
                            e=(PTR2UINT)(IS->EndPos-lp);
                            if (c>e)
                                {
                                c-=e;
                                while (e--) *IS->PutPos++=*lp++;
                                lp=IS->OutBuff;
                                }
                            }

                        while (c--) *IS->PutPos++=*lp++;        //CopyMem()���� �ٲٸ� �����߻�
                        break;
                        }
                    else if ((e&64)==0)
                        {
                        t+=t->base;
                        e=(t+=((UINT) IS->BitData & InflateMask[e]))->exop;
                        }
                    else{
                        Z->msg=(LPSTR)"invalid distance code";
                        Rslt=Z_DATA_ERROR;
                        goto ProcExit;
                        }
                    }
                break;
                }

            if ((e&64)==0)
                {
                t+=t->base;
                if ((e=(t+=((UINT) IS->BitData & InflateMask[e]))->exop)==0)
                    {
                    GetBits(IS, t->bits);
                    Tracevv((t->base>=0x20 && t->base<0x7f ? "inflate: * literal '%c'\n" : "inflate: * literal 0x%02x\n", t->base));
                    *IS->PutPos++=(BYTE)t->base; m--;
                    break;
                    }
                }
            else if (e&32)
                {
                Tracevv(("inflate: * EndPos of block\n"));
                Rslt=Z_STREAM_END;
                goto ProcExit;
                }
            else{
                Z->msg=(LPSTR)"invalid literal/length code";
                Rslt=Z_DATA_ERROR;
                goto ProcExit;
                }
            }
        } while (m>=258 && IS->InDataQty>=10);
    Rslt=Z_OK;

    ProcExit:
    c=GetMin(IS->BitQty>>3, OldInQty-IS->InDataQty);
    IS->InPtr-=c;
    IS->InDataQty+=c;
    IS->BitQty-=c<<3;
    return Rslt;
    }




///////////////////////////////////////////////////////////////////////////////
//                      INFCODES.CPP
///////////////////////////////////////////////////////////////////////////////




LOCAL(InflateCodesState*) InflateCodesNew(UINT bl, UINT bd, InflateHuft*tl, InflateHuft*td)
    {
    InflateCodesState*c;

    if ((c=(InflateCodesState*)AllocMem(sizeof(struct InflateCodesState), MEMOWNER_InflateCodesNew))!=NULL)
        {
        ZeroMem(c, sizeof(struct InflateCodesState));
        c->Mode=START;
        c->lbits=(BYTE)bl;
        c->dbits=(BYTE)bd;
        c->ltree=tl;
        c->dtree=td;
        }
    return c;
    }



LOCAL(VOID) MoveOutBuff(z_stream* Z, InternalState*IS, int Bytes)
    {
    if (IS->checkfn!=NULL) IS->check=IS->checkfn(IS->check, IS->GetPos, Bytes);

    CopyMem(Z->next_out, IS->GetPos, Bytes);
    Z->next_out+=Bytes;
    Z->avail_out-=Bytes;
    Z->total_out+=Bytes;
    IS->GetPos+=Bytes;
    }



LOCAL(int) InflateFlush(z_stream* Z, InternalState*IS, int Rslt)
    {
    UINT n;

    if ((n=GetMin((UINT)((IS->GetPos<=IS->PutPos ? IS->PutPos:IS->EndPos)-IS->GetPos), Z->avail_out))>0)
        {
        if (Rslt==Z_BUF_ERROR) Rslt=Z_OK;
        MoveOutBuff(Z, IS, n);
        }

    if (IS->GetPos==IS->EndPos)
        {
        IS->GetPos=IS->OutBuff;
        if (IS->PutPos==IS->EndPos) IS->PutPos=IS->OutBuff;

        if ((n=GetMin((UINT)(IS->PutPos-IS->GetPos), Z->avail_out))>0)
            {
            if (Rslt==Z_BUF_ERROR) Rslt=Z_OK;
            MoveOutBuff(Z, IS, n);
            }
        }

    return Rslt;
    }



//-----------------------------------------------------------------------------
//              ���̸�: NEEDOUT ... �������۸� Ȯ����
//-----------------------------------------------------------------------------
LOCAL(BOOL) PrepareOutBuff(z_stream* Z, InternalState*IS, int Rslt)
    {
    int Size;

    if ((Size=GetOutputAvialSize(IS))==0)
        {
        Rslt=InflateFlush(Z, IS, Rslt);
        Size=GetOutputAvialSize(IS);
        }
    return Size;
    }



LOCAL(int) InflateCodes(z_stream* Z, InternalState*IS, int Rslt)
    {
    UINT J;
    InflateHuft*t;
    UINT e;
    BYTE*f;
    InflateCodesState*c=IS->sub.codes;

    for (;;)
        {
        switch (c->Mode)
            {
            case START:
                #ifndef SLOW
                if (GetOutputAvialSize(IS)>=258 && IS->InDataQty>=10)
                    {
                    if ((Rslt=InflateFast(Z, c->lbits, c->dbits, c->ltree, c->dtree, IS))!=Z_OK)
                        {
                        c->Mode=Rslt==Z_STREAM_END?WASH:BADCODE;
                        break;
                        }
                    }
                #endif
                c->sub.code.need=c->lbits;
                c->sub.code.tree=c->ltree;
                c->Mode=LEN;

            case LEN:
                J=c->sub.code.need;
                if (PrepareBits(IS, J)==FALSE) goto Leave;
                Rslt=Z_OK;
                t=c->sub.code.tree+((UINT) IS->BitData&InflateMask[J]);
                GetBits(IS, t->bits);
                if ((e=t->exop)==0)
                    {
                    c->sub.lit=t->base;
                    Tracevv((t->base>=0x20 && t->base<0x7f ? "inflate: literal '%c'\n":"inflate: literal 0x%02x\n", t->base));
                    c->Mode=LIT;
                    break;
                    }
                if (e&16)
                    {
                    c->sub.copy.get=e&15;
                    c->len=t->base;
                    c->Mode=LENEXT;
                    break;
                    }
                if ((e&64)==0)
                    {
                    c->sub.code.need=e;
                    c->sub.code.tree=t+t->base;
                    break;
                    }
                if (e&32)
                    {
                    Tracevv(("inflate: EndPos of block\n"));
                    c->Mode=WASH;
                    break;
                    }
                c->Mode=BADCODE;
                Z->msg=(LPSTR)"invalid literal/length code";
                Rslt=Z_DATA_ERROR;
                goto Leave;

            case LENEXT:
                J=c->sub.copy.get;
                if (PrepareBits(IS, J)==FALSE) goto Leave;
                Rslt=Z_OK;
                c->len+=GetBits(IS, J);
                c->sub.code.need=c->dbits;
                c->sub.code.tree=c->dtree;
                Tracevv(("inflate: length %u\n", c->len));
                c->Mode=DIST;

            case DIST:
                J=c->sub.code.need;
                if (PrepareBits(IS, J)==FALSE) goto Leave;
                Rslt=Z_OK;
                t=c->sub.code.tree+(IS->BitData&InflateMask[J]);
                GetBits(IS, t->bits);
                e=t->exop;
                if (e&16)
                    {
                    c->sub.copy.get=e&15;
                    c->sub.copy.dist=t->base;
                    c->Mode=DISTEXT;
                    break;
                    }
                if ((e&64)==0)
                    {
                    c->sub.code.need=e;
                    c->sub.code.tree=t+t->base;
                    break;
                    }
                c->Mode=BADCODE;
                Z->msg=(LPSTR)"invalid distance code";
                Rslt=Z_DATA_ERROR;
                goto Leave;

            case DISTEXT:
                J=c->sub.copy.get;
                if (PrepareBits(IS, J)==FALSE) goto Leave;
                Rslt=Z_OK;
                c->sub.copy.dist+=GetBits(IS, J);
                Tracevv(("inflate: distance %u\n", c->sub.copy.dist));
                c->Mode=COPY;

            case COPY:
                f=IS->PutPos - c->sub.copy.dist;
                while (f<IS->OutBuff) f+=IS->EndPos-IS->OutBuff;

                J=0;
                while (c->len)
                    {
                    if (J==0 && (J=PrepareOutBuff(Z, IS, Rslt))==0) goto Leave;
                    J--;
                    Rslt=Z_OK;
                    *IS->PutPos++=(BYTE)(*f++);
                    if (f==IS->EndPos) f=IS->OutBuff;
                    c->len--;
                    }
                c->Mode=START;
                break;

            case LIT:
                if (PrepareOutBuff(Z, IS, Rslt)==0) goto Leave;
                *IS->PutPos++=(BYTE)c->sub.lit;
                c->Mode=START;
                Rslt=Z_OK;
                break;

            case WASH:
                if (IS->BitQty>7)
                    {
                    Assert(IS->BitQty<16, "InflateCodes grabbed too many bytes")
                    IS->BitQty-=8;
                    IS->InPtr--;
                    IS->InDataQty++;
                    }
                Rslt=InflateFlush(Z,IS,Rslt);
                if (IS->GetPos!=IS->PutPos) goto Leave;

            case END:     Rslt=Z_STREAM_END; goto Leave;
            case BADCODE: Rslt=Z_DATA_ERROR; goto Leave;
            default:      Rslt=Z_STREAM_ERROR; goto Leave;
            } //switch (c->Mode)
        } //for (;;)

    Leave:
    return InflateFlush(Z,IS,Rslt);
    }




///////////////////////////////////////////////////////////////////////////////
//                      INFTREES.CPP
///////////////////////////////////////////////////////////////////////////////



static const UINT cplens[31]=
    {
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
    35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0
    };




static const UINT cplext[31]=
    {
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 112, 112
    };




static const UINT cpdist[30]=
    {
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
    257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
    8193, 12289, 16385, 24577
    };




static const UINT cpdext[30]=
    {
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10, 11, 11,
    12, 12, 13, 13
    };






#define BMAX 15

LOCAL(int) HuftBuild(UINT*b, UINT n, UINT IS, const UINT*d, const UINT*e, InflateHuft**t, UINT*m, InflateHuft*hp, UINT*hn, UINT*v)
    {
    UINT a;
    UINT c[BMAX+1];
    UINT f;
    int g;
    int h;
    register UINT I;
    register UINT J;
    register int k;
    int l;
    UINT mask;
    register UINT*p;
    InflateHuft*q;
    InflateHuft r;
    InflateHuft*u[BMAX];
    register int w;
    UINT x[BMAX+1];
    UINT*xp;
    int y;
    UINT Z;

    ZeroMem(c, sizeof(c));
    ZeroMem(&r, sizeof(r));

    p=b; I=n;
    do  c[*p++]++; while (--I);
    if (c[0]==n)
        {
        *t=NULL;
        *m=0;
        return Z_OK;
        }


    l=*m;
    for (J=1; J<=BMAX; J++) if (c[J]) break;
    k=J;
    if ((UINT)l<J) l=J;
    for (I=BMAX; I; I--) if (c[I]) break;
    g=I;
    if ((UINT)l>I) l=I;
    *m=l;


    for (y=1<<J; J<I; J++, y<<=1) if ((y-=c[J])<0) return Z_DATA_ERROR;
    if ((y-=c[I])<0) return Z_DATA_ERROR;
    c[I]+=y;


    x[1]=J=0;
    p=c+1; xp=x+2;
    while (--I) *xp++=(J+=*p++);

    p=b; I=0;
    do  {
        if ((J=*p++)!=0) v[x[J]++]=I;
        } while (++I<n);
    n=x[g];


    x[0]=I=0;
    p=v;
    h=-1;
    w=-l;
    u[0]=NULL;
    q=NULL;
    Z=0;

    for (; k<=g; k++)
        {
        a=c[k];
        while (a--)
            {
            while (k>w+l)
                {
                h++;
                w+=l;

                Z=g-w;
                Z=Z>(UINT) l?l:Z;
                if ((f=1<<(J=k-w))>a+1)
                    {
                    f-=a+1;
                    xp=c+k;
                    if (J<Z)
                    while (++J<Z)
                        {
                        if ((f<<=1)<=*++xp) break;
                        f-=*xp;
                        }
                    }
                Z=1<<J;

                if (*hn+Z>MANY) return Z_DATA_ERROR;
                u[h]=q=hp+ *hn;
                *hn+=Z;

                if (h)
                    {
                    x[h]=I;
                    r.bits=(BYTE) l;
                    r.exop=(BYTE) J;
                    J=I>>(w-l);
                    r.base=(UINT)(q-u[h-1]-J);
                    u[h-1][J]=r;
                    }
                else
                    *t=q;
                }

            r.bits=(BYTE)(k-w);
            if (p>=v+n) r.exop=128+64;
            else if (*p<IS)
                {
                r.exop=(BYTE)(*p<256?0:32+64);
                r.base=*p++;
                }
            else{
                r.exop=(BYTE)(e[*p-IS]+16+64);
                r.base=d[*p++ -IS];
                }

            f=1<<(k-w);
            for (J=I>>w; J<Z; J+=f) q[J]=r;
            for (J=1<<(k-1); I&J; J>>=1) I^=J;
            I^=J;

            mask=(1<<w)-1;
            while ((I&mask)!=x[h])
                {
                h--;
                w-=l;
                mask=(1<<w)-1;
                }
            }
        }

    return y!=0 && g!=1?Z_BUF_ERROR:Z_OK;
    }




LOCAL(int) InflateTreesBits(UINT*c, UINT*bb, InflateHuft**tb, InflateHuft*hp, z_stream* Z)
    {
    int Rslt;
    UINT hn=0;
    UINT*v;

    if ((v=(UINT*)AllocMem(19*sizeof(UINT), MEMOWNER_InflateTreesBits))==NULL) return Z_MEM_ERROR;
    ZeroMem(v, 19*sizeof(UINT));
    Rslt=HuftBuild(c, 19, 19, NULL, NULL, tb, bb, hp, &hn, v);
    if (Rslt==Z_DATA_ERROR) Z->msg=(LPSTR)"oversubscribed dynamic bit lengths tree";
    else if (Rslt==Z_BUF_ERROR || *bb==0)
        {
        Z->msg=(LPSTR)"incomplete dynamic bit lengths tree";
        Rslt=Z_DATA_ERROR;
        }
    FreeMem(v);
    return Rslt;
    }




LOCAL(int) InflateTreesDynamic(UINT nl, UINT nd, UINT*c, UINT*bl, UINT*bd, InflateHuft**tl, InflateHuft**td, InflateHuft*hp, z_stream* Z)
    {
    int Rslt;
    UINT hn=0;
    UINT*v;

    if ((v=(UINT*)AllocMem(288*sizeof(UINT), MEMOWNER_InflateTreesDynamic))==NULL) return Z_MEM_ERROR;
    ZeroMem(v, 288*sizeof(UINT));

    Rslt=HuftBuild(c, nl, 257, cplens, cplext, tl, bl, hp, &hn, v);
    if (Rslt!=Z_OK || *bl==0)
        {
        if (Rslt==Z_DATA_ERROR) Z->msg=(LPSTR)"oversubscribed literal/length tree";
        else if (Rslt!=Z_MEM_ERROR)
            {
            Z->msg=(LPSTR)"incomplete literal/length tree";
            Rslt=Z_DATA_ERROR;
            }
        goto ProcExit;
        }

    Rslt=HuftBuild(c+nl, nd, 0, cpdist, cpdext, td, bd, hp, &hn, v);
    if (Rslt!=Z_OK || (*bd==0 && nl>257))
        {
        if (Rslt==Z_DATA_ERROR) Z->msg=(LPSTR)"oversubscribed distance tree";
        else if (Rslt==Z_BUF_ERROR)
            {
        #ifdef PKZIP_BUG_WORKAROUND
            Rslt=Z_OK;
            }
        #else
            Z->msg=(LPSTR)"incomplete distance tree";
            Rslt=Z_DATA_ERROR;
            }
        else if (Rslt!=Z_MEM_ERROR)
            {
            Z->msg=(LPSTR)"empty distance tree with lengths";
            Rslt=Z_DATA_ERROR;
            }
        goto ProcExit;
        #endif
        }
    Rslt=Z_OK;

    ProcExit:
    FreeMem(v);
    return Rslt;
    }




#ifdef BUILDFIXED
static int fixed_built=0;
#define FIXEDH 544
static InflateHuft fixed_mem[FIXEDH];
static UINT fixed_bl;
static UINT fixed_bd;
static InflateHuft*fixed_tl;
static InflateHuft*fixed_td;
#else //BUILDFIXED
static UINT fixed_bl=9;
static UINT fixed_bd=5;
static InflateHuft fixed_tl[]=
    {
    {{{96, 7}}, 256}, {{{0, 8}}, 80}, {{{0, 8}}, 16}, {{{84, 8}}, 115},
    {{{82, 7}}, 31}, {{{0, 8}}, 112}, {{{0, 8}}, 48}, {{{0, 9}}, 192},
    {{{80, 7}}, 10}, {{{0, 8}}, 96}, {{{0, 8}}, 32}, {{{0, 9}}, 160},
    {{{0, 8}}, 0}, {{{0, 8}}, 128}, {{{0, 8}}, 64}, {{{0, 9}}, 224},
    {{{80, 7}}, 6}, {{{0, 8}}, 88}, {{{0, 8}}, 24}, {{{0, 9}}, 144},
    {{{83, 7}}, 59}, {{{0, 8}}, 120}, {{{0, 8}}, 56}, {{{0, 9}}, 208},
    {{{81, 7}}, 17}, {{{0, 8}}, 104}, {{{0, 8}}, 40}, {{{0, 9}}, 176},
    {{{0, 8}}, 8}, {{{0, 8}}, 136}, {{{0, 8}}, 72}, {{{0, 9}}, 240},
    {{{80, 7}}, 4}, {{{0, 8}}, 84}, {{{0, 8}}, 20}, {{{85, 8}}, 227},
    {{{83, 7}}, 43}, {{{0, 8}}, 116}, {{{0, 8}}, 52}, {{{0, 9}}, 200},
    {{{81, 7}}, 13}, {{{0, 8}}, 100}, {{{0, 8}}, 36}, {{{0, 9}}, 168},
    {{{0, 8}}, 4}, {{{0, 8}}, 132}, {{{0, 8}}, 68}, {{{0, 9}}, 232},
    {{{80, 7}}, 8}, {{{0, 8}}, 92}, {{{0, 8}}, 28}, {{{0, 9}}, 152},
    {{{84, 7}}, 83}, {{{0, 8}}, 124}, {{{0, 8}}, 60}, {{{0, 9}}, 216},
    {{{82, 7}}, 23}, {{{0, 8}}, 108}, {{{0, 8}}, 44}, {{{0, 9}}, 184},
    {{{0, 8}}, 12}, {{{0, 8}}, 140}, {{{0, 8}}, 76}, {{{0, 9}}, 248},
    {{{80, 7}}, 3}, {{{0, 8}}, 82}, {{{0, 8}}, 18}, {{{85, 8}}, 163},
    {{{83, 7}}, 35}, {{{0, 8}}, 114}, {{{0, 8}}, 50}, {{{0, 9}}, 196},
    {{{81, 7}}, 11}, {{{0, 8}}, 98}, {{{0, 8}}, 34}, {{{0, 9}}, 164},
    {{{0, 8}}, 2}, {{{0, 8}}, 130}, {{{0, 8}}, 66}, {{{0, 9}}, 228},
    {{{80, 7}}, 7}, {{{0, 8}}, 90}, {{{0, 8}}, 26}, {{{0, 9}}, 148},
    {{{84, 7}}, 67}, {{{0, 8}}, 122}, {{{0, 8}}, 58}, {{{0, 9}}, 212},
    {{{82, 7}}, 19}, {{{0, 8}}, 106}, {{{0, 8}}, 42}, {{{0, 9}}, 180},
    {{{0, 8}}, 10}, {{{0, 8}}, 138}, {{{0, 8}}, 74}, {{{0, 9}}, 244},
    {{{80, 7}}, 5}, {{{0, 8}}, 86}, {{{0, 8}}, 22}, {{{192, 8}}, 0},
    {{{83, 7}}, 51}, {{{0, 8}}, 118}, {{{0, 8}}, 54}, {{{0, 9}}, 204},
    {{{81, 7}}, 15}, {{{0, 8}}, 102}, {{{0, 8}}, 38}, {{{0, 9}}, 172},
    {{{0, 8}}, 6}, {{{0, 8}}, 134}, {{{0, 8}}, 70}, {{{0, 9}}, 236},
    {{{80, 7}}, 9}, {{{0, 8}}, 94}, {{{0, 8}}, 30}, {{{0, 9}}, 156},
    {{{84, 7}}, 99}, {{{0, 8}}, 126}, {{{0, 8}}, 62}, {{{0, 9}}, 220},
    {{{82, 7}}, 27}, {{{0, 8}}, 110}, {{{0, 8}}, 46}, {{{0, 9}}, 188},
    {{{0, 8}}, 14}, {{{0, 8}}, 142}, {{{0, 8}}, 78}, {{{0, 9}}, 252},
    {{{96, 7}}, 256}, {{{0, 8}}, 81}, {{{0, 8}}, 17}, {{{85, 8}}, 131},
    {{{82, 7}}, 31}, {{{0, 8}}, 113}, {{{0, 8}}, 49}, {{{0, 9}}, 194},
    {{{80, 7}}, 10}, {{{0, 8}}, 97}, {{{0, 8}}, 33}, {{{0, 9}}, 162},
    {{{0, 8}}, 1}, {{{0, 8}}, 129}, {{{0, 8}}, 65}, {{{0, 9}}, 226},
    {{{80, 7}}, 6}, {{{0, 8}}, 89}, {{{0, 8}}, 25}, {{{0, 9}}, 146},
    {{{83, 7}}, 59}, {{{0, 8}}, 121}, {{{0, 8}}, 57}, {{{0, 9}}, 210},
    {{{81, 7}}, 17}, {{{0, 8}}, 105}, {{{0, 8}}, 41}, {{{0, 9}}, 178},
    {{{0, 8}}, 9}, {{{0, 8}}, 137}, {{{0, 8}}, 73}, {{{0, 9}}, 242},
    {{{80, 7}}, 4}, {{{0, 8}}, 85}, {{{0, 8}}, 21}, {{{80, 8}}, 258},
    {{{83, 7}}, 43}, {{{0, 8}}, 117}, {{{0, 8}}, 53}, {{{0, 9}}, 202},
    {{{81, 7}}, 13}, {{{0, 8}}, 101}, {{{0, 8}}, 37}, {{{0, 9}}, 170},
    {{{0, 8}}, 5}, {{{0, 8}}, 133}, {{{0, 8}}, 69}, {{{0, 9}}, 234},
    {{{80, 7}}, 8}, {{{0, 8}}, 93}, {{{0, 8}}, 29}, {{{0, 9}}, 154},
    {{{84, 7}}, 83}, {{{0, 8}}, 125}, {{{0, 8}}, 61}, {{{0, 9}}, 218},
    {{{82, 7}}, 23}, {{{0, 8}}, 109}, {{{0, 8}}, 45}, {{{0, 9}}, 186},
    {{{0, 8}}, 13}, {{{0, 8}}, 141}, {{{0, 8}}, 77}, {{{0, 9}}, 250},
    {{{80, 7}}, 3}, {{{0, 8}}, 83}, {{{0, 8}}, 19}, {{{85, 8}}, 195},
    {{{83, 7}}, 35}, {{{0, 8}}, 115}, {{{0, 8}}, 51}, {{{0, 9}}, 198},
    {{{81, 7}}, 11}, {{{0, 8}}, 99}, {{{0, 8}}, 35}, {{{0, 9}}, 166},
    {{{0, 8}}, 3}, {{{0, 8}}, 131}, {{{0, 8}}, 67}, {{{0, 9}}, 230},
    {{{80, 7}}, 7}, {{{0, 8}}, 91}, {{{0, 8}}, 27}, {{{0, 9}}, 150},
    {{{84, 7}}, 67}, {{{0, 8}}, 123}, {{{0, 8}}, 59}, {{{0, 9}}, 214},
    {{{82, 7}}, 19}, {{{0, 8}}, 107}, {{{0, 8}}, 43}, {{{0, 9}}, 182},
    {{{0, 8}}, 11}, {{{0, 8}}, 139}, {{{0, 8}}, 75}, {{{0, 9}}, 246},
    {{{80, 7}}, 5}, {{{0, 8}}, 87}, {{{0, 8}}, 23}, {{{192, 8}}, 0},
    {{{83, 7}}, 51}, {{{0, 8}}, 119}, {{{0, 8}}, 55}, {{{0, 9}}, 206},
    {{{81, 7}}, 15}, {{{0, 8}}, 103}, {{{0, 8}}, 39}, {{{0, 9}}, 174},
    {{{0, 8}}, 7}, {{{0, 8}}, 135}, {{{0, 8}}, 71}, {{{0, 9}}, 238},
    {{{80, 7}}, 9}, {{{0, 8}}, 95}, {{{0, 8}}, 31}, {{{0, 9}}, 158},
    {{{84, 7}}, 99}, {{{0, 8}}, 127}, {{{0, 8}}, 63}, {{{0, 9}}, 222},
    {{{82, 7}}, 27}, {{{0, 8}}, 111}, {{{0, 8}}, 47}, {{{0, 9}}, 190},
    {{{0, 8}}, 15}, {{{0, 8}}, 143}, {{{0, 8}}, 79}, {{{0, 9}}, 254},
    {{{96, 7}}, 256}, {{{0, 8}}, 80}, {{{0, 8}}, 16}, {{{84, 8}}, 115},
    {{{82, 7}}, 31}, {{{0, 8}}, 112}, {{{0, 8}}, 48}, {{{0, 9}}, 193},
    {{{80, 7}}, 10}, {{{0, 8}}, 96}, {{{0, 8}}, 32}, {{{0, 9}}, 161},
    {{{0, 8}}, 0}, {{{0, 8}}, 128}, {{{0, 8}}, 64}, {{{0, 9}}, 225},
    {{{80, 7}}, 6}, {{{0, 8}}, 88}, {{{0, 8}}, 24}, {{{0, 9}}, 145},
    {{{83, 7}}, 59}, {{{0, 8}}, 120}, {{{0, 8}}, 56}, {{{0, 9}}, 209},
    {{{81, 7}}, 17}, {{{0, 8}}, 104}, {{{0, 8}}, 40}, {{{0, 9}}, 177},
    {{{0, 8}}, 8}, {{{0, 8}}, 136}, {{{0, 8}}, 72}, {{{0, 9}}, 241},
    {{{80, 7}}, 4}, {{{0, 8}}, 84}, {{{0, 8}}, 20}, {{{85, 8}}, 227},
    {{{83, 7}}, 43}, {{{0, 8}}, 116}, {{{0, 8}}, 52}, {{{0, 9}}, 201},
    {{{81, 7}}, 13}, {{{0, 8}}, 100}, {{{0, 8}}, 36}, {{{0, 9}}, 169},
    {{{0, 8}}, 4}, {{{0, 8}}, 132}, {{{0, 8}}, 68}, {{{0, 9}}, 233},
    {{{80, 7}}, 8}, {{{0, 8}}, 92}, {{{0, 8}}, 28}, {{{0, 9}}, 153},
    {{{84, 7}}, 83}, {{{0, 8}}, 124}, {{{0, 8}}, 60}, {{{0, 9}}, 217},
    {{{82, 7}}, 23}, {{{0, 8}}, 108}, {{{0, 8}}, 44}, {{{0, 9}}, 185},
    {{{0, 8}}, 12}, {{{0, 8}}, 140}, {{{0, 8}}, 76}, {{{0, 9}}, 249},
    {{{80, 7}}, 3}, {{{0, 8}}, 82}, {{{0, 8}}, 18}, {{{85, 8}}, 163},
    {{{83, 7}}, 35}, {{{0, 8}}, 114}, {{{0, 8}}, 50}, {{{0, 9}}, 197},
    {{{81, 7}}, 11}, {{{0, 8}}, 98}, {{{0, 8}}, 34}, {{{0, 9}}, 165},
    {{{0, 8}}, 2}, {{{0, 8}}, 130}, {{{0, 8}}, 66}, {{{0, 9}}, 229},
    {{{80, 7}}, 7}, {{{0, 8}}, 90}, {{{0, 8}}, 26}, {{{0, 9}}, 149},
    {{{84, 7}}, 67}, {{{0, 8}}, 122}, {{{0, 8}}, 58}, {{{0, 9}}, 213},
    {{{82, 7}}, 19}, {{{0, 8}}, 106}, {{{0, 8}}, 42}, {{{0, 9}}, 181},
    {{{0, 8}}, 10}, {{{0, 8}}, 138}, {{{0, 8}}, 74}, {{{0, 9}}, 245},
    {{{80, 7}}, 5}, {{{0, 8}}, 86}, {{{0, 8}}, 22}, {{{192, 8}}, 0},
    {{{83, 7}}, 51}, {{{0, 8}}, 118}, {{{0, 8}}, 54}, {{{0, 9}}, 205},
    {{{81, 7}}, 15}, {{{0, 8}}, 102}, {{{0, 8}}, 38}, {{{0, 9}}, 173},
    {{{0, 8}}, 6}, {{{0, 8}}, 134}, {{{0, 8}}, 70}, {{{0, 9}}, 237},
    {{{80, 7}}, 9}, {{{0, 8}}, 94}, {{{0, 8}}, 30}, {{{0, 9}}, 157},
    {{{84, 7}}, 99}, {{{0, 8}}, 126}, {{{0, 8}}, 62}, {{{0, 9}}, 221},
    {{{82, 7}}, 27}, {{{0, 8}}, 110}, {{{0, 8}}, 46}, {{{0, 9}}, 189},
    {{{0, 8}}, 14}, {{{0, 8}}, 142}, {{{0, 8}}, 78}, {{{0, 9}}, 253},
    {{{96, 7}}, 256}, {{{0, 8}}, 81}, {{{0, 8}}, 17}, {{{85, 8}}, 131},
    {{{82, 7}}, 31}, {{{0, 8}}, 113}, {{{0, 8}}, 49}, {{{0, 9}}, 195},
    {{{80, 7}}, 10}, {{{0, 8}}, 97}, {{{0, 8}}, 33}, {{{0, 9}}, 163},
    {{{0, 8}}, 1}, {{{0, 8}}, 129}, {{{0, 8}}, 65}, {{{0, 9}}, 227},
    {{{80, 7}}, 6}, {{{0, 8}}, 89}, {{{0, 8}}, 25}, {{{0, 9}}, 147},
    {{{83, 7}}, 59}, {{{0, 8}}, 121}, {{{0, 8}}, 57}, {{{0, 9}}, 211},
    {{{81, 7}}, 17}, {{{0, 8}}, 105}, {{{0, 8}}, 41}, {{{0, 9}}, 179},
    {{{0, 8}}, 9}, {{{0, 8}}, 137}, {{{0, 8}}, 73}, {{{0, 9}}, 243},
    {{{80, 7}}, 4}, {{{0, 8}}, 85}, {{{0, 8}}, 21}, {{{80, 8}}, 258},
    {{{83, 7}}, 43}, {{{0, 8}}, 117}, {{{0, 8}}, 53}, {{{0, 9}}, 203},
    {{{81, 7}}, 13}, {{{0, 8}}, 101}, {{{0, 8}}, 37}, {{{0, 9}}, 171},
    {{{0, 8}}, 5}, {{{0, 8}}, 133}, {{{0, 8}}, 69}, {{{0, 9}}, 235},
    {{{80, 7}}, 8}, {{{0, 8}}, 93}, {{{0, 8}}, 29}, {{{0, 9}}, 155},
    {{{84, 7}}, 83}, {{{0, 8}}, 125}, {{{0, 8}}, 61}, {{{0, 9}}, 219},
    {{{82, 7}}, 23}, {{{0, 8}}, 109}, {{{0, 8}}, 45}, {{{0, 9}}, 187},
    {{{0, 8}}, 13}, {{{0, 8}}, 141}, {{{0, 8}}, 77}, {{{0, 9}}, 251},
    {{{80, 7}}, 3}, {{{0, 8}}, 83}, {{{0, 8}}, 19}, {{{85, 8}}, 195},
    {{{83, 7}}, 35}, {{{0, 8}}, 115}, {{{0, 8}}, 51}, {{{0, 9}}, 199},
    {{{81, 7}}, 11}, {{{0, 8}}, 99}, {{{0, 8}}, 35}, {{{0, 9}}, 167},
    {{{0, 8}}, 3}, {{{0, 8}}, 131}, {{{0, 8}}, 67}, {{{0, 9}}, 231},
    {{{80, 7}}, 7}, {{{0, 8}}, 91}, {{{0, 8}}, 27}, {{{0, 9}}, 151},
    {{{84, 7}}, 67}, {{{0, 8}}, 123}, {{{0, 8}}, 59}, {{{0, 9}}, 215},
    {{{82, 7}}, 19}, {{{0, 8}}, 107}, {{{0, 8}}, 43}, {{{0, 9}}, 183},
    {{{0, 8}}, 11}, {{{0, 8}}, 139}, {{{0, 8}}, 75}, {{{0, 9}}, 247},
    {{{80, 7}}, 5}, {{{0, 8}}, 87}, {{{0, 8}}, 23}, {{{192, 8}}, 0},
    {{{83, 7}}, 51}, {{{0, 8}}, 119}, {{{0, 8}}, 55}, {{{0, 9}}, 207},
    {{{81, 7}}, 15}, {{{0, 8}}, 103}, {{{0, 8}}, 39}, {{{0, 9}}, 175},
    {{{0, 8}}, 7}, {{{0, 8}}, 135}, {{{0, 8}}, 71}, {{{0, 9}}, 239},
    {{{80, 7}}, 9}, {{{0, 8}}, 95}, {{{0, 8}}, 31}, {{{0, 9}}, 159},
    {{{84, 7}}, 99}, {{{0, 8}}, 127}, {{{0, 8}}, 63}, {{{0, 9}}, 223},
    {{{82, 7}}, 27}, {{{0, 8}}, 111}, {{{0, 8}}, 47}, {{{0, 9}}, 191},
    {{{0, 8}}, 15}, {{{0, 8}}, 143}, {{{0, 8}}, 79}, {{{0, 9}}, 255}
    };


static InflateHuft fixed_td[]=
    {
    {{{80, 5}}, 1}, {{{87, 5}}, 257}, {{{83, 5}}, 17}, {{{91, 5}}, 4097},
    {{{81, 5}}, 5}, {{{89, 5}}, 1025}, {{{85, 5}}, 65}, {{{93, 5}}, 16385},
    {{{80, 5}}, 3}, {{{88, 5}}, 513}, {{{84, 5}}, 33}, {{{92, 5}}, 8193},
    {{{82, 5}}, 9}, {{{90, 5}}, 2049}, {{{86, 5}}, 129}, {{{192, 5}}, 24577},
    {{{80, 5}}, 2}, {{{87, 5}}, 385}, {{{83, 5}}, 25}, {{{91, 5}}, 6145},
    {{{81, 5}}, 7}, {{{89, 5}}, 1537}, {{{85, 5}}, 97}, {{{93, 5}}, 24577},
    {{{80, 5}}, 4}, {{{88, 5}}, 769}, {{{84, 5}}, 49}, {{{92, 5}}, 12289},
    {{{82, 5}}, 13}, {{{90, 5}}, 3073}, {{{86, 5}}, 193}, {{{192, 5}}, 24577}
    };
#endif //BUILDFIXED


LOCAL(int) InflateTreesFixed(UINT*bl, UINT*bd, InflateHuft**tl, InflateHuft**td)
    {
    #ifdef BUILDFIXED
    if (!fixed_built)
        {
        int k;
        UINT f=0;
        UINT*c;
        UINT*v;

        if ((c=(UINT*)AllocMem(288*sizeof(UINT), MEMOWNER_InflateTreesFixed1))!=NULL) ZeroMem(c, 288*sizeof(UINT));
        if ((v=(UINT*)AllocMem(288*sizeof(UINT), MEMOWNER_InflateTreesFixed2))!=NULL) ZeroMem(v, 288*sizeof(UINT));
        if (c==NULL || v==NULL) {FreeMem(c); FreeMem(v); return Z_MEM_ERROR;}

        for (k=0; k<144; k++) c[k]=8;
        for (; k<256; k++) c[k]=9;
        for (; k<280; k++) c[k]=7;
        for (; k<288; k++) c[k]=8;
        fixed_bl=9;
        HuftBuild(c, 288, 257, cplens, cplext, &fixed_tl, &fixed_bl, fixed_mem, &f, v);

        for (k=0; k<30; k++) c[k]=5;
        fixed_bd=5;
        HuftBuild(c, 30, 0, cpdist, cpdext, &fixed_td, &fixed_bd, fixed_mem, &f, v);

        FreeMem(v);
        FreeMem(c);
        fixed_built=1;
        }
    #endif
    *bl=fixed_bl;
    *bd=fixed_bd;
    *tl=fixed_tl;
    *td=fixed_td;
    return Z_OK;
    }




///////////////////////////////////////////////////////////////////////////////
//                      Inflate.cpp
///////////////////////////////////////////////////////////////////////////////


static const UINT border[]=
    {
    16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15
    };




LOCAL(VOID) InflateBlocksReset(z_stream* Z, InternalState*IS)
    {
    if (IS->IBMode==BTREE || IS->IBMode==DTREE) FreeMem(IS->sub.trees.blens);
    if (IS->IBMode==CODES) FreeMem(IS->sub.codes);
    IS->IBMode=TYPE;
    IS->BitQty=0;
    IS->BitData=0;
    IS->GetPos=IS->PutPos=IS->OutBuff;
    if (IS->checkfn!=NULL) IS->check=IS->checkfn(0, NULL, 0);
    }



LOCAL(int) InflateBlocks(z_stream *Z, int Rslt)
    {
    UINT t;
    UINT m;
    InternalState *IS=Z->State;

    for (;;)
        {
        switch (IS->IBMode)
            {
            case TYPE:
                if (PrepareBits(IS, 3)==FALSE) goto Leave;
                Rslt=Z_OK;
                t=IS->BitData&7;
                IS->last=t&1;
                switch (t>>1)
                    {
                    case 0:
                        Tracev(("inflate: stored block%IS\n", IS->last?" (last)":""));
                        GetBits(IS, 3);
                        GetBits(IS, IS->BitQty&7);
                        IS->IBMode=LENS;
                        break;

                    case 1:
                        Tracev(("inflate: fixed codes block%IS\n", IS->last?" (last)":""));
                        {
                        UINT bl, bd;
                        InflateHuft*tl, *td;

                        InflateTreesFixed(&bl, &bd, &tl, &td);
                        IS->sub.codes=InflateCodesNew(bl, bd, tl, td);
                        if (IS->sub.codes==NULL) {Rslt=Z_MEM_ERROR; goto Leave;}
                        GetBits(IS, 3);
                        IS->IBMode=CODES;
                        break;
                        }

                    case 2:
                        Tracev(("inflate: dynamic codes block%IS\n", IS->last?" (last)":""));
                        GetBits(IS, 3);
                        IS->IBMode=TABLE;
                        break;

                    case 3:
                        GetBits(IS, 3);
                        IS->IBMode=BAD;
                        Z->msg=(LPSTR)"invalid block type";
                        Rslt=Z_DATA_ERROR;
                        goto Leave;
                    }
                break;

            case LENS:
                if (PrepareBits(IS, 32)==FALSE) goto Leave;
                if ((~IS->BitData>>16)!=(IS->BitData&0xffff))
                    {
                    IS->IBMode=BAD;
                    Z->msg=(LPSTR)"invalid stored block lengths";
                    Rslt=Z_DATA_ERROR;
                    goto Leave;
                    }
                IS->sub.left=IS->BitData&0xffff;
                IS->BitData=IS->BitQty=0;
                Tracev(("inflate: stored length %u\n", IS->sub.left));
                IS->IBMode=IS->sub.left?STORED:(IS->last?DRY:TYPE);
                Rslt=Z_OK;
                break;

            case STORED:
                if (IS->InDataQty==0) goto Leave;
                if ((m=PrepareOutBuff(Z, IS, Rslt))==0) goto Leave;
                t=GetMin(GetMin(IS->sub.left, IS->InDataQty), m);
                CopyMem(IS->PutPos, IS->InPtr, t);
                IS->PutPos+=t;
                IS->InPtr+=t;
                IS->InDataQty-=t;
                if ((IS->sub.left-=t)==0) IS->IBMode=IS->last ? DRY:TYPE;
                Rslt=Z_OK;
                break;

            case TABLE:
                if (PrepareBits(IS, 14)==FALSE) goto Leave;
                Rslt=Z_OK;
                IS->sub.trees.table=t=(UINT) IS->BitData&0x3fff;
                #ifndef PKZIP_BUG_WORKAROUND
                if ((t&0x1f)>29 || ((t>>5)&0x1f)>29)
                    {
                    IS->IBMode=BAD;
                    Z->msg=(LPSTR)"too many length or distance symbols";
                    Rslt=Z_DATA_ERROR;
                    goto Leave;
                    }
                #endif
                t=258+(t&0x1f)+((t>>5)&0x1f);
                if ((IS->sub.trees.blens=(UINT*)AllocMem(t*sizeof(UINT), MEMOWNER_InflateBlocks))==NULL)
                    {
                    Rslt=Z_MEM_ERROR;
                    goto Leave;
                    }
                ZeroMem(IS->sub.trees.blens, t*sizeof(UINT));
                GetBits(IS, 14);
                IS->sub.trees.index=0;
                Tracev(("inflate: table sizes ok\n"));
                IS->IBMode=BTREE;

            case BTREE:
                while (IS->sub.trees.index<4+(IS->sub.trees.table>>10))
                    {
                    if (PrepareBits(IS, 3)==FALSE) goto Leave;
                    Rslt=Z_OK;
                    IS->sub.trees.blens[border[IS->sub.trees.index++]]=GetBits(IS, 3);
                    }
                while (IS->sub.trees.index<19) IS->sub.trees.blens[border[IS->sub.trees.index++]]=0;
                IS->sub.trees.bb=7;

                if ((t=InflateTreesBits(IS->sub.trees.blens, &IS->sub.trees.bb, &IS->sub.trees.tb, IS->hufts, Z))!=Z_OK)
                    {
                    Rslt=t;
                    if (Rslt==Z_DATA_ERROR)
                        {
                        FreeMem(IS->sub.trees.blens);
                        IS->IBMode=BAD;
                        }
                    goto Leave;
                    }
                IS->sub.trees.index=0;
                Tracev(("inflate: bits tree ok\n"));
                IS->IBMode=DTREE;

                while (t=IS->sub.trees.table, IS->sub.trees.index<258+(t&0x1f)+((t>>5)&0x1f))
                    {
                    InflateHuft*h;
                    UINT I, J, c;

                    t=IS->sub.trees.bb;
                    if (PrepareBits(IS, t)==FALSE) goto Leave;
                    Rslt=Z_OK;

                    h=IS->sub.trees.tb+(IS->BitData&InflateMask[t]);
                    t=h->bits;
                    c=h->base;
                    if (c<16)
                        {
                        GetBits(IS, t);
                        IS->sub.trees.blens[IS->sub.trees.index++]=c;
                        }
                    else{
                        I=c==18?7:c-14;
                        J=c==18?11:3;
                        if (PrepareBits(IS, t+I)==FALSE) goto Leave;
                        Rslt=Z_OK;
                        GetBits(IS, t);
                        J+=GetBits(IS, I);
                        I=IS->sub.trees.index;
                        t=IS->sub.trees.table;
                        if (I+J>258+(t&0x1f)+((t>>5)&0x1f) || (c==16 && I<1))
                            {
                            FreeMem(IS->sub.trees.blens);
                            IS->IBMode=BAD;
                            Z->msg=(LPSTR)"invalid bit length repeat";
                            Rslt=Z_DATA_ERROR;
                            goto Leave;
                            }
                        c=c==16?IS->sub.trees.blens[I-1]:0;
                        do  IS->sub.trees.blens[I++]=c; while (--J);
                        IS->sub.trees.index=I;
                        }
                    }
                IS->sub.trees.tb=NULL;
                    {
                    UINT bl, bd;
                    InflateHuft*tl, *td;
                    InflateCodesState*c;

                    bl=9;
                    bd=6;
                    t=IS->sub.trees.table;
                    t=InflateTreesDynamic(257+(t&0x1f), 1+((t>>5)&0x1f), IS->sub.trees.blens, &bl, &bd, &tl, &td, IS->hufts, Z);
                    if (t!=Z_OK)
                        {
                        if (t==(UINT)Z_DATA_ERROR)
                            {
                            FreeMem(IS->sub.trees.blens);
                            IS->IBMode=BAD;
                            }
                        Rslt=t;
                        goto Leave;
                        }
                    Tracev(("inflate: trees ok\n"));
                    if ((c=InflateCodesNew(bl, bd, tl, td))==NULL) {Rslt=Z_MEM_ERROR; goto Leave;}
                    IS->sub.codes=c;
                    }
                FreeMem(IS->sub.trees.blens);
                IS->IBMode=CODES;

            case CODES:
                if ((Rslt=InflateCodes(Z, IS, Rslt))!=Z_STREAM_END) goto Leave;
                Rslt=Z_OK;
                FreeMem(IS->sub.codes);
                if (IS->last==0) {IS->IBMode=TYPE; break;}
                IS->IBMode=DRY;

            case DRY:
                Rslt=InflateFlush(Z,IS,Rslt);
                if (IS->GetPos!=IS->PutPos) goto Leave;
                IS->IBMode=DONE;

            case DONE:  Rslt=Z_STREAM_END; goto Leave;
            case BAD:   Rslt=Z_DATA_ERROR; goto Leave;
            default:    Rslt=Z_STREAM_ERROR; goto Leave;
            } //switch (IS->IBMode)
        } //for (;;)

    Leave:
    return InflateFlush(Z,IS,Rslt);
    }




int WINAPI inflate(z_stream* Z, int f)
    {
    int I, B, Rslt, Method;
    DWORD ChkNeed=0, ChkCalc;
    InternalState *IS;

    if (Z==NULL || Z->State==NULL || Z->next_in==NULL) return Z_STREAM_ERROR;

    IS=Z->State;
    IS->InPtr=Z->next_in;
    IS->InDataQty=Z->avail_in;

    f=(f==Z_FINISH) ? Z_BUF_ERROR:Z_OK;
    Rslt=Z_BUF_ERROR;

    for (;;)
        {
        switch (IS->Mode)
            {
            case METHOD:
                if ((B=GetByte(IS))<0) {BuffErr: Rslt=Z_BUF_ERROR; goto ProcExit;}

                Rslt=f;
                if (((Method=B)&0xf)!=Z_DEFLATED)
                    {
                    IS->Mode=IM_BAD;
                    Z->msg=(LPSTR)"unknown compression method";
                    break;
                    }
                if ((Method>>4)+8 > IS->wbits)
                    {
                    IS->Mode=IM_BAD;
                    Z->msg=(LPSTR)"invalid OutBuff size";
                    break;
                    }

                if ((B=GetByte(IS))<0) goto BuffErr;
                if (((Method<<8)+B)%31)
                    {
                    IS->Mode=IM_BAD;
                    Z->msg=(LPSTR)"incorrect header check";
                    break;
                    }

                if ((B & PRESET_DICT)==0)
                    {
                    IS->Mode=BLOCKS;
                    break;
                    }

                for (I=4; I--;)
                    {
                    if ((B=GetByte(IS))<0) goto BuffErr;
                    ChkNeed<<=8; ChkNeed|=B;
                    }

                //Z->adler=ChkNeed;
                IS->Mode=DICT0;
                Rslt=Z_NEED_DICT;
                goto ProcExit;

            case DICT0:
                IS->Mode=IM_BAD;
                Z->msg=(LPSTR)"need dictionary";
                Rslt=Z_STREAM_ERROR;
                goto ProcExit;

            case BLOCKS:
                if ((Rslt=InflateBlocks(Z, Rslt))==Z_DATA_ERROR)
                    {
                    IS->Mode=IM_BAD;
                    break;
                    }
                if (Rslt==Z_OK) Rslt=f;
                if (Rslt!=Z_STREAM_END) goto ProcExit;

                ChkCalc=IS->check;
                InflateBlocksReset(Z, IS);
                if (IS->nowrap)
                    {
                    IS->Mode=IM_DONE;
                    Rslt=f;
                    break;
                    }

                for (I=4; I--;)
                    {
                    if ((B=GetByte(IS))<0) goto BuffErr;
                    ChkNeed<<=8; ChkNeed|=B;
                    }

                //DebugOut(0,-1,"NeedCheck=%X, CalcCheck=%X", ChkNeed, ChkCalc);
                if (ChkCalc!=ChkNeed)   //üũ�� �˻�
                    {
                    IS->Mode=IM_BAD;
                    Z->msg=(LPSTR)"incorrect data check";
                    Rslt=f;
                    break;
                    }

            case IM_DONE: Rslt=Z_STREAM_END; goto ProcExit;
            case IM_BAD:  Rslt=Z_DATA_ERROR; goto ProcExit;
            default:      Rslt=Z_STREAM_ERROR; goto ProcExit;
            } //switch (IS->Mode)
        } //for (;;)

    ProcExit:
    Z->avail_in=IS->InDataQty;
    Z->total_in=(PTR2UINT)(IS->InPtr-Z->next_in);
    Z->next_in=IS->InPtr;
    return Rslt;
    }



int WINAPI inflateEnd(z_stream* Z)
    {
    InternalState*IS;

    if (Z==NULL) return Z_STREAM_ERROR;

    if ((IS=Z->State)!=NULL)
        {
        InflateBlocksReset(Z, IS);
        FreeMem(IS->OutBuff);
        FreeMem(IS->hufts);
        }

    FreeMem(Z->State); Z->State=NULL;
    return Z_OK;
    }




int WINAPI inflateInit2(z_stream* Z, int w, LPCSTR Version, int StreamSize)
    {
    int Rslt, BuffSize;
    InternalState *IS;

    if (Version==NULL || Version[0]!=ZLIB_VERSION[0] || StreamSize!=sizeof(z_stream)) return Z_VERSION_ERROR;
    if (Z==NULL) return Z_STREAM_ERROR;

    ZeroMem(Z, sizeof(z_stream));

    if ((Z->State=IS=AllocMemS(InternalState, MEMOWNER_inflateInit2))==NULL) return Z_MEM_ERROR;
    ZeroMem(IS, sizeof(InternalState));

    if (w<0) {w=-w; IS->nowrap=1;}
    if (w<8 || w>15) {Rslt=Z_STREAM_ERROR; goto ProcExit;}
    IS->wbits=w;

    Rslt=Z_MEM_ERROR;
    if ((IS->hufts=(InflateHuft*)AllocMem(sizeof(InflateHuft)*MANY, MEMOWNER_InflateBlocksNew2))==NULL) goto ProcExit;
    ZeroMem(IS->hufts, sizeof(InflateHuft)*MANY);

    BuffSize=(UINT)1<<w;
    if ((IS->OutBuff=(BYTE*)AllocMem(BuffSize, MEMOWNER_InflateBlocksNew3))==NULL) goto ProcExit;
    IS->EndPos=IS->OutBuff+BuffSize;
    IS->checkfn=IS->nowrap ? NULL:adler32;
    IS->IBMode=TYPE;

    IS->Mode=(IS->nowrap) ? BLOCKS:METHOD;
    InflateBlocksReset(Z, IS);
    Rslt=Z_OK;

    ProcExit:
    if (Rslt!=Z_OK) inflateEnd(Z);
    return Rslt;
    }





