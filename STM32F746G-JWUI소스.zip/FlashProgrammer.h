int WINAPI FlashProgrammer(HWND);

