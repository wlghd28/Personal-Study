﻿
#include "JLIB.H"
#include "DRIVER.H"
#include "JWUI.H"
#include "JOS.H"
#include "COMMCTL.H"
#include "JFAT.H"
#include "SWD.H"
#include "MAIN.H"
#include "RESOURCE.H"
#include "INIDATA.H"


#define MEMOWNER_TargetPgmStatusWndProc (MEMOWNER_FlashProgrammer+0)
#define MEMOWNER_FlashProgrammingTask   (MEMOWNER_FlashProgrammer+1)

extern HWND HwndMain;   //MAIN.C
static HWND hWndFlashPgming;
static CONST CHAR SetStr[]="Set";



///////////////////////////////////////////////////////////////////////////////
//              타겟 프로그래밍 상태 표시 창 커스텀 콘트롤
///////////////////////////////////////////////////////////////////////////////



#define TS_IDLE     0
#define TS_PGMING   1
#define TS_PGMOK    2
#define TS_PGMFAIL  3
#define TS_ItemQty  4

typedef struct _TARGETPGMSTATCTX
    {
    HWND  hWnd;
    BYTE  CurrProgress;
    BYTE  TargetStatus;
    HFONT hFontScale;
    HBRUSH hBrProgressActive, hBrProgressBkgnd;
    HBRUSH hBrPgmStatus[TS_ItemQty];
    } TARGETPGMSTATCTX;



#define SCALEWIDTH      15      //좌측에 디바이스 번호 쓰는 자리
#define SCALEHEIGHT     20      //맨위 디바이스 번호 쓰는 자리
#define EDGEMARGIN      10
#define PROGRESSGAP     10

#define ONEDEVICEWIDTH  50




//-----------------------------------------------------------------------------
//      타겟상태 표시영역을 구함
//-----------------------------------------------------------------------------
LOCAL(VOID) GetTargetArea(TARGETPGMSTATCTX *TPSC, RECT *TR)
    {
    GetClientRect(TPSC->hWnd, TR);
    InflateRect(TR, -EDGEMARGIN, -EDGEMARGIN);
    }




//-----------------------------------------------------------------------------
//      현재 프로그래밍 진행률을 표시함
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawPgmProgress(TARGETPGMSTATCTX *TPSC, HDC hDC)
    {
    int  Cx;
    RECT R;
    CHAR Buff[20];

    GetTargetArea(TPSC, &R);
    R.top=((R.top+R.bottom)>>1)+PROGRESSGAP;

    SelectObject(hDC, TPSC->hFontScale);

    #ifdef WIN32
    DrawProgressBar(hDC, R, TPSC->CurrProgress, RGB(0,0,128), RGB(255,255,255), RGB(192,192,192), RGB(0,0,0));
    #else
    Cx=MulDiv(R.right-R.left, TPSC->CurrProgress, 100)+R.left;
    SelectObject(hDC, TPSC->hBrProgressActive); Rectangle(hDC, R.left, R.top, Cx, R.bottom);
    SelectObject(hDC, TPSC->hBrProgressBkgnd);  Rectangle(hDC, Cx, R.top, R.right, R.bottom);

    wsprintf(Buff, "%d %%", TPSC->CurrProgress);
    SetBkMode(hDC, TRANSPARENT);
    SetTextColor(hDC, RGB(255,0,0));
    DrawText(hDC, Buff, -1, &R, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
    #endif
    }




//-----------------------------------------------------------------------------
//      타켓을 그림
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawOneTarget(TARGETPGMSTATCTX *TPSC, HDC hDC, RECT TR, BOOL ForceIdle)
    {
    int X, State;

    X=(TR.right-TR.left-ONEDEVICEWIDTH)>>1;
    InflateRect(&TR, -X, 0);
    TR.bottom=(TR.top+TR.bottom)>>1;

    State=TPSC->TargetStatus;
    if (State==TS_PGMING && ForceIdle) State=TS_IDLE;
    SelectObject(hDC, TPSC->hBrPgmStatus[State]);
    Rectangle(hDC, TR.left, TR.top, TR.right, TR.bottom);

    if (State==TS_PGMOK || State==TS_PGMFAIL)
        {
        SetBkMode(hDC, TRANSPARENT);
        SetTextColor(hDC, State==TS_PGMOK ? COL_BLACK:COL_WHITE);
        DrawText(hDC, State==TS_PGMOK ? "성공":"실패", -1, &TR, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
        }
    }

LOCAL(VOID) DrawOneTargetII(TARGETPGMSTATCTX *TPSC, BOOL ForceIdle)
    {
    HDC  hDC;
    RECT TR;

    hDC=GetDC(TPSC->hWnd);
    GetTargetArea(TPSC, &TR);
    DrawOneTarget(TPSC, hDC, TR, ForceIdle);
    ReleaseDC(TPSC->hWnd, hDC);
    }




//-----------------------------------------------------------------------------
//      DRAW 타겟 프로그래밍 상태
//-----------------------------------------------------------------------------
LOCAL(VOID) DrawTargetStatus(TARGETPGMSTATCTX *TPSC, HDC hDC)
    {
    RECT R;

    GetTargetArea(TPSC, &R);
    SelectObject(hDC, TPSC->hFontScale);
    DrawOneTarget(TPSC, hDC, R, FALSE);
    }




//-----------------------------------------------------------------------------
//      타겟 프로그래밍 상태 윈도우 처리
//-----------------------------------------------------------------------------
#define TargetFlashTmr          1
#define TPSCCMD_SetProgress     100
#define TPSCCMD_SetTargetStatus 101
WNDFNC(TargetPgmStatusWndProc)
    {
    int I;
    TARGETPGMSTATCTX *TPSC;

    TPSC=(TARGETPGMSTATCTX*)GetWindowLongPtr(hWnd, 0);
    switch (Msg)
        {
        case WM_CREATE:         //윈도우 생성시 한번 옴
            if ((TPSC=AllocMemS(TARGETPGMSTATCTX, MEMOWNER_TargetPgmStatusWndProc))!=NULL)      //컨텍스트를 저장할 메모리 할당
                {
                ZeroMem(TPSC, sizeof(TARGETPGMSTATCTX));

                TPSC->hWnd=hWnd;
                TPSC->hFontScale=(HFONT)SendMessage(HwndMain, WM_GETFONT, 0, 0);
                TPSC->hBrPgmStatus[TS_IDLE]=CreateSolidBrush(RGB(255,255,255));
                TPSC->hBrPgmStatus[TS_PGMING]=CreateSolidBrush(RGB(0,255,255));
                TPSC->hBrPgmStatus[TS_PGMOK]=CreateSolidBrush(RGB(0,255,0));
                TPSC->hBrPgmStatus[TS_PGMFAIL]=CreateSolidBrush(RGB(255,0,0));
                TPSC->hBrProgressActive=CreateSolidBrush(RGB(0,0,128));
                TPSC->hBrProgressBkgnd=CreateSolidBrush(RGB(192,192,192));
                TPSC->TargetStatus=TS_IDLE;
                }
            SetWindowLongPtr(hWnd, 0, (LONG_PTR)TPSC);           //컨텍스트 포인터를 이 윈도우 클래스의 엑스트라 영역에 저장
            SetTimer(hWnd, TargetFlashTmr, 500, NULL);
            Ret0:
            return 0;

        case WM_DESTROY:        //이 윈도우가 파기될 때 한번 옴
            if (TPSC!=NULL)
                {
                for (I=0; I<TS_ItemQty; I++)
                    {
                    if (TPSC->hBrPgmStatus[I]!=NULL) DeleteObject(TPSC->hBrPgmStatus[I]);
                    }
                if (TPSC->hBrProgressActive!=NULL) DeleteObject(TPSC->hBrProgressActive);
                if (TPSC->hBrProgressBkgnd!=NULL) DeleteObject(TPSC->hBrProgressBkgnd);
                FreeMem(TPSC);
                }
            goto Ret0;

        case WM_TIMER:
            if (wPrm==TargetFlashTmr)
                {
                if (TPSC!=NULL)
                    {
                    static BYTE Toggle;
                    DrawOneTargetII(TPSC, Toggle);
                    Toggle^=1;
                    }
                }
            goto Ret0;

        case WM_PAINT:          //화면을 그릴 필요가 있을 때마다 오는 메세지
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            if (TPSC!=NULL)
                {
                DrawTargetStatus(TPSC, PS.hdc);
                DrawPgmProgress(TPSC, PS.hdc);
                }
            EndPaint(hWnd, &PS);
            goto Ret0;
            }

        case WM_COMMAND:
            if (TPSC==NULL) goto Ret0;
            switch (WMCMDID)
                {
                case TPSCCMD_SetProgress:
                    {
                    HDC hDC;

                    hDC=GetDC(hWnd);
                    TPSC->CurrProgress=(BYTE)lPrm;
                    DrawPgmProgress(TPSC, hDC);
                    ReleaseDC(hWnd, hDC);
                    break;
                    }

                case TPSCCMD_SetTargetStatus:
                    {
                    TPSC->TargetStatus=lPrm;
                    DrawOneTargetII(TPSC, FALSE);
                    break;
                    }
                }
            goto Ret0;
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);        //위에서 처리하지 않는 모든 메세지 처리
    }




///////////////////////////////////////////////////////////////////////////////
//                      Flash 쓰레드
///////////////////////////////////////////////////////////////////////////////

static BYTE FlashPgmTaskRunFg;
static BYTE FlashVerifyFg;
static UINT ToPgmAddress;
static CHAR ToPfmFilePath[80];
static CHAR TargetDevice[32];


//-----------------------------------------------------------------------------
//      진행률 설정 (SWD 플래시 기록모듈에서 호출함)
//-----------------------------------------------------------------------------
VOID WINAPI TPSC_SetProgress(int Psnt)
    {
    if (hWndFlashPgming!=NULL)
        PostMessage(hWndFlashPgming, WM_COMMAND, SetPgmProgressCmdID, Psnt);
    }



//-----------------------------------------------------------------------------
//      타겟 상태 설정
//-----------------------------------------------------------------------------
LOCAL(VOID) TPSC_SetTargetStatus(HWND hWnd, int Status)
    {
    SendDlgItemMessage(hWnd, ProgrammingTargetCCID, WM_COMMAND, TPSCCMD_SetTargetStatus, Status);
    }



//-----------------------------------------------------------------------------
//      플래시 프로그래밍 Task (TRUE를 리턴하면 중단시킴)
//-----------------------------------------------------------------------------
LOCAL(BOOL) ProgrammingProgressCB(LPVOID Arg, UINT Addr, int Psnt)
    {
    TPSC_SetProgress(Psnt);
    Sleep(5);       //UI스레드에서 표시할 시간를 줌
    return FALSE;
    }



//-----------------------------------------------------------------------------
//      플래시 프로그래밍 Task
//-----------------------------------------------------------------------------
static VOID CALLBACK FlashProgrammingTask(LPVOID lpArg)
    {
    int Rslt=FALSE;

    FlashPgmTaskRunFg=1;
    Rslt=TargetFlash_ProgrammingFile(ToPgmAddress, TargetDevice, ToPfmFilePath, ProgrammingProgressCB, NULL);

    if (Rslt && FlashVerifyFg)
        Rslt=TargetFlash_VerifyFile(ToPgmAddress, TargetDevice, ToPfmFilePath, ProgrammingProgressCB, NULL);

    PostMessage(hWndFlashPgming, WM_COMMAND, Rslt ? ProgrammingSuccessCmdID:ProgrammingFailCmdID, 0);
    FlashPgmTaskRunFg=0;
    }




//-----------------------------------------------------------------------------
//      프로그래밍 대화상자 Proc
//-----------------------------------------------------------------------------
#define RUNST_IDLE      0
#define RUNST_SUCCESS   1
#define RUNST_FAIL      2
DLGFNC(FlashProgrammingDlgProc)
    {
    switch (Msg)
        {
        case WM_INITDIALOG:
            hWndFlashPgming=hWnd;
            return TRUE;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case SetPgmProgressCmdID:
                    SendDlgItemMessage(hWnd, ProgrammingTargetCCID, WM_COMMAND, TPSCCMD_SetProgress, lPrm);
                    break;

                case ProgrammingSuccessCmdID:
                    SetDlgItemText(hWnd, IDOK, "계속");
                    TPSC_SetTargetStatus(hWnd, TS_PGMOK);
                    break;

                case ProgrammingFailCmdID:
                    SetDlgItemText(hWnd, IDOK, "재시도");
                    TPSC_SetTargetStatus(hWnd, TS_PGMFAIL);
                    //I=DispMsg(hWnd, "오류 발생: 다시 시도할까요?", MB_OKCANCEL);
                    //PostMessage(hWnd, WM_COMMAND, I, 0);
                    break;

                case IDOK:
                    if (FlashPgmTaskRunFg!=0) break;
                    SetDlgItemText(hWnd, IDOK, "중단");
                    TPSC_SetTargetStatus(hWnd, TS_PGMING);

                    FlushIniFile();     //FLASH 기록을 방해할까봐

                    //FlashProgrammingTask(NULL);
                    CreateThread("FlashPgm", FLASHPGM_TASK_STK_SIZE, FlashProgrammingTask, NULL, PRIO_FLASHPGMTASK);
                    break;

                case IDCANCEL:
                    if (FlashPgmTaskRunFg!=0) break;
                    hWndFlashPgming=NULL;
                    EndDialog(hWnd, FALSE);
                    break;
                }
            return TRUE;
        }

    return FALSE;
    }




//-----------------------------------------------------------------------------
//      INI 파일을 읽어보고 변경된 경우 저장
//-----------------------------------------------------------------------------
LOCAL(VOID) CheckChangedSave(LPCSTR SecName, LPCSTR VarName, LPCSTR Data)
    {
    CHAR Buff[80];

    GetIniStr(SecName, VarName, Buff, sizeof(Buff));
    if (lstrcmp(Buff, Data)!=0) WriteIniStr(SecName, VarName, Data);
    }

LOCAL(VOID) CheckChangedSaveInt(LPCSTR SecName, LPCSTR VarName, int Data)
    {
    if (GetIniInt(SecName, VarName, 0)!=Data) WriteIniInt(SecName, VarName, Data);
    }



//-----------------------------------------------------------------------------
//      프로그래머 대화상자 Proc
//-----------------------------------------------------------------------------
DLGFNC(FlashProgrammerDlgProc)
    {
    int  I, Def, Delay;
    LPCSTR lp;
    CHAR Buff[80];
    WIN32_FIND_DATA *WFD;
    static int LastFocusEBID;
    static CONST CHAR DefBinStr[]="DefBin";
    static CONST CHAR DefDevStr[]="DefDev";
    static CONST CHAR DelayStr[]="Delay";
    static CONST CHAR VerifyStr[]="Verify";
    static CONST CHAR PgmAddrStr[]="PgmAddr";


    switch (Msg)
        {
        case WM_INITDIALOG:
            GetIniStr(SetStr, DefBinStr, Buff, sizeof(Buff));

            Def=0;
            if ((WFD=FindFirstFile("B:/*.BIN"))!=NULL)
                {
                do  {
                    I=CB_AddString(hWnd, FlashPgmSrcFileCBID, WFD->cFileName);
                    if (lstrcmpi(WFD->cFileName, Buff)==0) Def=I;
                    } while (FindNextFile(WFD)!=FALSE);
                FindClose(WFD);
                }
            CB_SetCurSel(hWnd, FlashPgmSrcFileCBID, Def);

            for (I=0; ;I++)
                {
                if ((lp=GetTargetDeviceName(I))==NULL) break;
                CB_AddString(hWnd, FlashPgmDeviceCBID, lp);
                }

            if (GetIniStr(SetStr, DefDevStr, Buff, sizeof(Buff))==0) lstrcpy(Buff, "STM32L082CZ");
            CB_SelectString(hWnd, FlashPgmDeviceCBID, 0, Buff);
            SetDlgItemInt(hWnd, FlashPgmDelayEBID, GetIniInt(Buff, DelayStr, 1), FALSE);

            if (GetIniStr(SetStr, PgmAddrStr, Buff, sizeof(Buff))==0) lstrcpy(Buff, "8000000");
            SetDlgItemText(hWnd, FlashPgmAddressEBID, Buff);
            CheckDlgButton(hWnd, FlashPgmVerifyCKID, GetIniInt(SetStr, VerifyStr, 1));
            return TRUE;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case FlashPgmNumber0BTID:
                case FlashPgmNumber1BTID:
                case FlashPgmNumber2BTID:
                case FlashPgmNumber3BTID:
                case FlashPgmNumber4BTID:
                case FlashPgmNumber5BTID:
                case FlashPgmNumber6BTID:
                case FlashPgmNumber7BTID:
                case FlashPgmNumber8BTID:
                case FlashPgmNumber9BTID:
                case FlashPgmSpaceBTID:
                case FlashPgmBkSpcBTID:
                case FlashPgmCharABTID:
                case FlashPgmCharBBTID:
                case FlashPgmCharCBTID:
                case FlashPgmCharDBTID:
                case FlashPgmCharEBTID:
                case FlashPgmCharFBTID:
                    if (LastFocusEBID!=0)
                        {
                        SetFocusDlgItem(hWnd, LastFocusEBID);
                        PostMessage(GetDlgItem(hWnd, LastFocusEBID), WM_CHAR, WMCMDID, 1);
                        }
                    break;

                case FlashPgmAddressEBID:
                case FlashPgmDelayEBID:
                    if (WMCMDNOTIFY==EN_SETFOCUS) LastFocusEBID=WMCMDID;
                    break;

                case FlashPgmSrcFileCBID:
                    if (WMCMDNOTIFY!=CBN_SELCHANGE) break;
                    if (CB_GetCurSelText(hWnd, FlashPgmSrcFileCBID, Buff)==CB_ERR) break;
                    CheckChangedSave(SetStr, DefBinStr, Buff);
                    break;

                case FlashPgmDeviceCBID:
                    if (WMCMDNOTIFY!=CBN_SELCHANGE) break;
                    if (CB_GetCurSelText(hWnd, FlashPgmDeviceCBID, Buff)==CB_ERR) break;
                    CheckChangedSave(SetStr, DefDevStr, Buff);
                    SetDlgItemInt(hWnd, FlashPgmDelayEBID, GetIniInt(Buff, DelayStr, 1), FALSE);
                    break;

                case IDOK:
                    GetDlgItemText(hWnd, FlashPgmAddressEBID, Buff, sizeof(Buff));
                    CheckChangedSave(SetStr, PgmAddrStr, Buff);
                    ToPgmAddress=AtoH(Buff, NULL);
                    lstrcpy(ToPfmFilePath, "B:/");
                    if (CB_GetCurSelText(hWnd, FlashPgmSrcFileCBID, GetStrLast(ToPfmFilePath))==CB_ERR)
                        {
                        DispMsg(hWnd, "바이너리 파일을 지정하세요.", MB_OK);
                        break;
                        }
                    if (CB_GetCurSelText(hWnd, FlashPgmDeviceCBID, TargetDevice)==CB_ERR)
                        {
                        DispMsg(hWnd, "타겟 디바이스를 지정하세요.", MB_OK);
                        break;
                        }
                    if (CheckFlashAddress(TargetDevice, ToPgmAddress)==FALSE)
                        {
                        DispMsg(hWnd, "주소가 잘못되었습니다.", MB_OK);
                        break;
                        }

                    if ((Delay=GetDlgItemInt(hWnd, FlashPgmDelayEBID, NULL, FALSE))!=0)
                        {
                        CheckChangedSaveInt(TargetDevice, DelayStr, Delay);
                        SWD_SetDelay(Delay);
                        }

                    FlashVerifyFg=IsDlgButtonChecked(hWnd, FlashPgmVerifyCKID);
                    CheckChangedSaveInt(SetStr, VerifyStr, FlashVerifyFg);

                    DialogBox(HInst, MAKEINTRESOURCE(FlashProgrammingDialog), hWnd, FlashProgrammingDlgProc);
                    break;

                case IDCANCEL:
                    EndDialog(hWnd, WMCMDID);
                }
            return TRUE;
        }
    return FALSE;
    }




//-----------------------------------------------------------------------------
//      플래시 프로그래밍 대화상자
//-----------------------------------------------------------------------------
int WINAPI FlashProgrammer(HWND hWnd)
    {
    static BYTE AlreadyFg;

    if (AlreadyFg==0)
        {
        RegistCtrlWndClass("TargetPgmStatus", TargetPgmStatusWndProc, sizeof(LPVOID));
        AlreadyFg=1;
        }
    return DialogBox(HInst, MAKEINTRESOURCE(FlashProgrammerDialog), hWnd, FlashProgrammerDlgProc);
    }



