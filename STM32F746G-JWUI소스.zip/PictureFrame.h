
#define SPM_ONCE	0
#define SPM_ROR1	1
#define SPM_ROR2	2
#define SPM_RANDOM	3
#define SPM_QTY		4


void WINAPI RotateRightPut(int BoxSize, int Mode);
void WINAPI RandomPut(int BoxSize);
