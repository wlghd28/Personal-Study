﻿
#include "JLIB.H"
#include "JOS.H"
#include "JWUI.H"
#include "DRIVER.H"
#include "RESOURCE.H"


static CONST CHAR SetStr[]="Set";
static CONST CHAR InternalStr[]="Internal";
static CONST CHAR GroupStr[]="Group";
static CONST CHAR ChannelStr[]="Channel";
static CONST CHAR DevNoStr[]="DevNo";
static CONST CHAR PowerStr[]="Power";
static CONST CHAR SyncVctStr[]="SyncVct";



//-----------------------------------------------------------------------------
//      버퍼에 있는 내용을 모두 읽어 버림
//-----------------------------------------------------------------------------
VOID WINAPI ReadFlush(int PortNo)
    {
    while (UART_RxByteIT(PortNo)>=0);
    }



//-----------------------------------------------------------------------------
//      한줄을 읽음
//-----------------------------------------------------------------------------
LOCAL(BOOL) ReadLineFromTarget(LPSTR Buff, int BuffSize, int TimeOut)
    {
    int   Cha, Rslt=FALSE, RcvBytes=0;
    DWORD Time;

    Time=GetTickCount();
    while (GetTickCount()-Time<(DWORD)TimeOut)
        {
        if ((Cha=UART_RxByteIT(COM_TARGET))<0) Sleep(1);
        else{
            if (Cha==13 || Cha==10 || Cha==0)
                {
                if (RcvBytes==0) continue;  //이전 명령에 대한 응답으로 \r만 들어옴
                Rslt++;
                break;
                }
            if (BuffSize>1) {Buff[RcvBytes++]=Cha; BuffSize--;}
            }
        }
    if (BuffSize>0) Buff[RcvBytes]=0;
    if (RcvBytes>0) Printf("TARGET->'%s'\r\n", Buff);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      주어진 시간동안 원하는 문자열이 나오기를 기다림
//-----------------------------------------------------------------------------
LOCAL(BOOL) CheckReplyFromTarget(LPCSTR WantReply, int TimeOut)
    {
    BOOL Rslt=FALSE;
    CHAR Buff[40];
    DWORD Time;

    Time=GetTickCount();
    while (GetTickCount()-Time<(DWORD)TimeOut)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (lstrcmp(Buff, WantReply)==0) {Rslt++; break;}
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      디버거 명령을 전송함
//-----------------------------------------------------------------------------
LOCAL(BOOL) Target_SendCommand(LPCSTR Cmd)
    {
    ReadFlush(COM_TARGET);
    PrintfII(COM_TARGET, Cmd);
    PrintfII(COM_TARGET, CRLF);
    return CheckReplyFromTarget(Cmd, 3000);
    }



//-----------------------------------------------------------------------------
//      타겟을 리셋하고 디버거 설정모드로 진입함
//-----------------------------------------------------------------------------
#define UNKNOWNTARGET   0
#define JWCNSREPEATER   1
#define JWCNSDETECTOR   2
LOCAL(int) ResetTargetAndSetMode(VOID)
    {
    DWORD Time;
    CHAR Buff[80];
    static CHAR CONST SysCoreClkStr[]="SENSOR: SystemCoreClock=";

    InitPortOutputOD(PO_RESET);
    PortOut(PO_RESET, LOW); Sleep(100);
    PortOut(PO_RESET, HIGH);

    Time=GetTickCount();
    while (GetTickCount()-Time<1000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (CompMemStr(Buff, SysCoreClkStr)==0)
            {
            if (AtoI(lstrlen(SysCoreClkStr)+Buff, NULL)==48000000) return JWCNSREPEATER;
            break;
            }
        }
    if (Target_SendCommand("SET INSLEEP OFF")) return JWCNSDETECTOR;
    return UNKNOWNTARGET;
    }




//-----------------------------------------------------------------------------
//  "SENSOR: Group=201124, DevNo=2, Channel=200, Power=13, Repeater=0, BoardID=0"
//  위와 같은 문구에서 주어진 변수명 뒤에 값을 추출해줌
//-----------------------------------------------------------------------------
LOCAL(int) GetCommaStrToInt(LPCSTR InStr, LPCSTR VarName)
    {
    int  I, Rslt=0;
    CHAR VarNameEQ[32];

    lstrcpyn(VarNameEQ, VarName, sizeof(VarNameEQ)-1);
    AddCha(VarNameEQ, '=');
    if ((I=SearchStr(InStr, VarNameEQ))>=0) Rslt=AtoI(InStr+lstrlen(VarNameEQ)+I, NULL);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      타겟의 설정값을 가져옴
//      INI Internal Group
//      Value='201124
//-----------------------------------------------------------------------------
LOCAL(int) GetIniIntFromTarget(LPCSTR SecName, LPCSTR VarName)
    {
    int  Rslt=0;
    DWORD Time;
    CHAR Buff[40];

    ReadFlush(COM_TARGET);
    wsprintf(Buff, "INI %s %s"CRLF, SecName, VarName);
    PrintfII(COM_TARGET, Buff);

    Time=GetTickCount();
    while (GetTickCount()-Time<1000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (CompMemStr(Buff, "Value='")==0) {Rslt=AtoI(Buff+7, NULL); break;}
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      '17134820220222' -> 'TIME 17 13 48 2022 02 22'
//-----------------------------------------------------------------------------
LOCAL(VOID) MakeSetTimeCmd(LPSTR Buff, LPCSTR Date)
    {
    lstrcpy(Buff, "TIME");
    AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date, 2+1);
    AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date+2, 2+1);
    AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date+4, 2+1);
    if (Date[6]!=0)
        {
        AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date+6, 4+1);
        AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date+10, 2+1);
        AddCha(Buff, ' '); lstrcpyn(GetStrLast(Buff), Date+12, 2+1);
        }
    }




//-----------------------------------------------------------------------------
//      'SENSOR: RV3032 Rtc 2022-02-22 18:11:31' 에서 날짜의 시작을 리턴
//-----------------------------------------------------------------------------
LOCAL(LPCSTR) SearchDateStr(LPCSTR DateStr)
    {
    int    I,J,Y;
    LPCSTR lp=NULL;

    J=lstrlen(DateStr)-5;   //5=Len("2022-")
    for (I=0; I<=J; I++)
        {
        if (DateStr[I+4]=='-')
            {
            Y=AtoIN(DateStr+I, 4);
            if (Y>=2000 && Y<=2136) {lp=DateStr+I; break;}
            }
        }
    return lp;
    }




//-----------------------------------------------------------------------------
//      시간을 가져옴
//-----------------------------------------------------------------------------
LOCAL(BOOL) GetTimeFromBoard(LPSTR Date, LPSTR Time)
    {
    BOOL  Rslt=FALSE;
    DWORD Tick;
    LPCSTR lp;
    CHAR  Buff[80];

    //PrintfII(COM_TARGET, "TIME"CRLF);

    Tick=GetTickCount();
    while (GetTickCount()-Tick<3000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);    //2022-02-22 18:00:50
        if ((CompMemStr(Buff, "SENSOR: RV3032 Rtc")==0 || CompMemStr(Buff, "SENSOR: Internal Rtc")==0 || CompMemStr(Buff, "SENSOR: DS1337 Rtc")==0) &&
            (lp=SearchDateStr(Buff))!=NULL)
            {
            lstrcpyn(Date+0, lp+0, 4+1);
            lstrcpyn(Date+4, lp+5, 2+1);
            lstrcpyn(Date+6, lp+8, 2+1);

            lstrcpyn(Time+0, lp+11, 2+1);
            lstrcpyn(Time+2, lp+14, 2+1);
            lstrcpyn(Time+4, lp+17, 2+1);

            Rslt++;
            break;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      타겟에 설정을 함
//-----------------------------------------------------------------------------
LOCAL(BOOL) SetValueToTarget(HWND hWnd, int GroupNo, int Channel, int DevNo, int RfPower, int SyncVct, LPCSTR ToSetTime)
    {
    int   Rslt=FALSE, Target, Err=0;
    DWORD Tick;
    CHAR  Buff[80], Date[12], Time[8];

    if ((Target=ResetTargetAndSetMode())==UNKNOWNTARGET)
        {
        DispMsg(hWnd, "타겟을 연결하세요.", MB_OK);
        goto ProcExit;
        }

    wsprintf(Buff, "INI Internal Group %u", GroupNo);
    if (Target_SendCommand(Buff)==FALSE) {Err=1; goto ProcExit;}
    Sleep(100); //볼케이노에서 이거 안하면 OverRun발생


    wsprintf(Buff, "INI Internal Channel %u", Channel);
    if (Target_SendCommand(Buff)==FALSE) {Err=2; goto ProcExit;}
    Sleep(100);

    wsprintf(Buff, "INI Internal DevNo %u", DevNo);
    if (Target_SendCommand(Buff)==FALSE) {Err=3; goto ProcExit;}
    Sleep(100);

    wsprintf(Buff, "INI Internal Power %u", RfPower);
    if (Target_SendCommand(Buff)==FALSE) {Err=4; goto ProcExit;}
    Sleep(100);

    if (Target==JWCNSREPEATER)
        {
        wsprintf(Buff, "INI Internal SyncVct %u", SyncVct);
        if (Target_SendCommand(Buff)==FALSE) {Err=5; goto ProcExit;}
        }

    if (ToSetTime[0]!=0)
        {
        //부팅직 후라서 외부 RTC초기화 후에 시간을 설정해야 함
        if (Target==JWCNSREPEATER && GetTimeFromBoard(Date, Time)==FALSE) {Err=6; goto ProcExit;}

        MakeSetTimeCmd(Buff, ToSetTime);
        if (Target_SendCommand(Buff)==FALSE) {Err=7; goto ProcExit;}
        Sleep(100);

        if (CheckReplyFromTarget("SENSOR: Ok", 3000)==FALSE) {Err=8; goto ProcExit;}
        }

    if (Target_SendCommand("INI FLUSH")==FALSE) {Err=9; goto ProcExit;}
    if (CheckReplyFromTarget("SENSOR: Cfg Save OK", 3000)==FALSE) {Err=10; goto ProcExit;}
    Sleep(100);

    //설정값 확인
    ReadFlush(COM_TARGET);
    PortOut(PO_RESET, LOW); Sleep(100);
    PortOut(PO_RESET, HIGH);

    Err=11;
    Tick=GetTickCount();
    while (GetTickCount()-Tick<3000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (CompMemStr(Buff, "SENSOR: Group=")==0)
            {
            if (GetCommaStrToInt(Buff, GroupStr)==GroupNo &&
                GetCommaStrToInt(Buff, ChannelStr)==Channel &&
                GetCommaStrToInt(Buff, DevNoStr)==DevNo &&
                GetCommaStrToInt(Buff, PowerStr)==RfPower)
                {
                DispMsg(hWnd, "베리파이 성공.", MB_OK);
                Rslt++;
                }
            else DispMsg(hWnd, "베리파이 실패.", MB_OK);
            Err=0;
            break;
            }
        }

    ProcExit:
    if (Err)
        {
        wsprintf(Buff, "타겟과 통신 오류 발생 (%d).", Err);
        DispMsg(hWnd, Buff, MB_OK);
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      타겟의 설정을 가져옴
//-----------------------------------------------------------------------------
LOCAL(BOOL) GetCurrentSetting(HWND hWnd)
    {
    int   Rslt=FALSE;
    DWORD Tick;
    CHAR  Buff[80], Date[12], Time[8];

    InitPortOutputOD(PO_RESET);
    ReadFlush(COM_TARGET);
    PortOut(PO_RESET, LOW); Sleep(100);
    PortOut(PO_RESET, HIGH);

    Tick=GetTickCount();
    while (GetTickCount()-Tick<3000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (CompMemStr(Buff, "SENSOR: Group=")==0)
            {
            SetDlgItemInt(hWnd, SettingGroupEBID, GetCommaStrToInt(Buff, GroupStr), FALSE);
            SetDlgItemInt(hWnd, SettingChannelEBID, GetCommaStrToInt(Buff, ChannelStr), FALSE);
            SetDlgItemInt(hWnd, SettingDeviceNoEBID, GetCommaStrToInt(Buff, DevNoStr), FALSE);
            SetDlgItemInt(hWnd, SettingRfPowerEBID, GetCommaStrToInt(Buff, PowerStr), FALSE);
            SetDlgItemInt(hWnd, SettingTrafficVectorEBID, GetIniIntFromTarget(InternalStr, SyncVctStr), FALSE);

            if (GetTimeFromBoard(Date, Time)!=FALSE)
                {
                SetDlgItemText(hWnd, SettingYMDEBID, Date);
                SetDlgItemText(hWnd, SettingHMSEBID, Time);
                UpdateWindow(GetDlgItem(hWnd, SettingYMDEBID)); //이걸 안해주면 이후 뜨는 메세지 박스 위에 잔상을 남김, JWUI로직 문제 같음
                UpdateWindow(GetDlgItem(hWnd, SettingHMSEBID)); //      "
                }
            Rslt++;
            break;
            }
        }
    return Rslt;
    }



LOCAL(VOID) LoadFromIni(HWND hWnd, int EBID, LPCSTR VarName, int DefValue)
    {
    SetDlgItemInt(hWnd, EBID, GetIniInt(SetStr, VarName, DefValue), FALSE);
    }


LOCAL(VOID) SaveToIni(HWND hWnd, int EBID, LPCSTR VarName)
    {
    WriteIniInt(SetStr, VarName, GetDlgItemInt(hWnd, EBID, NULL, FALSE));
    }



LOCAL(BOOL) EB_InputValue(HWND hWnd, int EBID, int *lpValue, LPCSTR ErrMsg)
    {
    BOOL Err;

    *lpValue=GetDlgItemInt(hWnd, EBID, &Err, FALSE);
    if (Err)
        {
        DispMsg(hWnd, ErrMsg, MB_OK);
        SetFocusDlgItem(hWnd, EBID);
        }
    return Err==0;
    }



//-----------------------------------------------------------------------------
//      입력받은 시간문자열의 형식을 확인함
//-----------------------------------------------------------------------------
LOCAL(BOOL) CheckTime(LPCSTR Time)
    {
    int Rslt=FALSE;

    if (lstrlen(Time)!=6) goto ProcExit;
    if (AtoIN(Time, 2)>23) goto ProcExit;
    if (AtoIN(Time+2, 2)>59) goto ProcExit;
    if (AtoIN(Time+4, 2)>59) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }

LOCAL(BOOL) CheckDate(LPCSTR Date)
    {
    int Y, M, D, Rslt=FALSE;

    if (lstrlen(Date)!=8) goto ProcExit;
    Y=AtoIN(Date, 4);
    if (Y<2000 || Y>2136) goto ProcExit;
    M=AtoIN(Date+4, 2);
    if (M<1 || M>12) goto ProcExit;
    D=AtoIN(Date+6, 2);
    if (D<1 || D>GetMonthLastDay(Y,M)) goto ProcExit;
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      설정 대화상자 Proc
//-----------------------------------------------------------------------------
DLGFNC(SettingDlgProc)
    {
    int  GroupNo, Channel, DevNo, RfPower, SyncVct;
    CHAR Date[12], Time[16];
    static int  LastFocusEBID;
    static BYTE HaveBeenSet;

    switch (Msg)
        {
        case WM_INITDIALOG:
            HaveBeenSet=0;
            LastFocusEBID=0;
            LoadFromIni(hWnd, SettingGroupEBID, GroupStr, 0);
            LoadFromIni(hWnd, SettingChannelEBID, ChannelStr, 25);
            LoadFromIni(hWnd, SettingDeviceNoEBID, DevNoStr, 1);
            LoadFromIni(hWnd, SettingRfPowerEBID, PowerStr, 10);
            LoadFromIni(hWnd, SettingRfPowerEBID, PowerStr, 10);
            LoadFromIni(hWnd, SettingTrafficVectorEBID, SyncVctStr, 0);
            return TRUE;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case SettingNumber0BTID:
                case SettingNumber1BTID:
                case SettingNumber2BTID:
                case SettingNumber3BTID:
                case SettingNumber4BTID:
                case SettingNumber5BTID:
                case SettingNumber6BTID:
                case SettingNumber7BTID:
                case SettingNumber8BTID:
                case SettingNumber9BTID:
                case SettingSpaceBTID:
                case SettingBkSpcBTID:
                    if (LastFocusEBID!=0)
                        {
                        SetFocusDlgItem(hWnd, LastFocusEBID);
                        PostMessage(GetDlgItem(hWnd, LastFocusEBID), WM_CHAR, WMCMDID, 1);
                        }
                    break;

                case SettingGroupEBID:
                case SettingChannelEBID:
                case SettingDeviceNoEBID:
                case SettingRfPowerEBID:
                case SettingHMSEBID:
                case SettingYMDEBID:
                case SettingTrafficVectorEBID:
                    if (WMCMDNOTIFY==EN_SETFOCUS) LastFocusEBID=WMCMDID;
                    break;

                case SettingGetCurrentBTID: //타겟보드 설정값 가져오기
                    lPrm=GetCurrentSetting(hWnd);
                    DispMsg(hWnd, lPrm ? "설정값 가져오기 성공.":"설정값 가져오기 실패.", MB_OK);
                    break;

                case IDOK:
                    if (EB_InputValue(hWnd, SettingGroupEBID, &GroupNo, "그룹 번호를 입력하세요.")==FALSE) break;
                    if (EB_InputValue(hWnd, SettingChannelEBID, &Channel, "채널 번호를 입력하세요.")==FALSE) break;
                    if (EB_InputValue(hWnd, SettingDeviceNoEBID, &DevNo, "감지기 번호를 입력하세요.")==FALSE) break;
                    if (EB_InputValue(hWnd, SettingRfPowerEBID, &RfPower, "RF 파워를 입력하세요.")==FALSE) break;
                    SyncVct=GetDlgItemInt(hWnd, SettingTrafficVectorEBID, NULL, FALSE);

                    Time[0]=0;
                    if (IsDlgButtonChecked(hWnd, SettingTimeCKID))
                        {
                        GetDlgItemText(hWnd, SettingHMSEBID, Time, sizeof(Time));
                        GetDlgItemText(hWnd, SettingYMDEBID, Date, sizeof(Date));
                        if (Time[0]!=0)
                            {
                            if (CheckTime(Time)==FALSE)
                                {
                                DispMsg(hWnd, "시간 형식은 hhmmdd", MB_OK);
                                SetFocusDlgItem(hWnd, SettingHMSEBID);
                                break;
                                }
                            if (Date[0]!=0 && CheckDate(Date)==FALSE)
                                {
                                DispMsg(hWnd, "날짜 형식은 YYYYMMDD", MB_OK);
                                SetFocusDlgItem(hWnd, SettingYMDEBID);
                                break;
                                }
                            }
                        else if (Date[0]!=0)
                            {
                            DispMsg(hWnd, "날짜만은 설정할 수 없습니다", MB_OK);
                            SetFocusDlgItem(hWnd, SettingHMSEBID);
                            break;
                            }
                        lstrcat(Time, Date);
                        }

                    if (SetValueToTarget(hWnd, GroupNo, Channel, DevNo, RfPower, SyncVct, Time))
                        {
                        HaveBeenSet=1;
                        SetDlgItemInt(hWnd, SettingDeviceNoEBID, DevNo+1, FALSE);
                        }
                    break;

                case IDCANCEL:
                    if (HaveBeenSet)
                        {
                        SaveToIni(hWnd, SettingGroupEBID, GroupStr);
                        SaveToIni(hWnd, SettingChannelEBID, ChannelStr);
                        SaveToIni(hWnd, SettingDeviceNoEBID, DevNoStr);
                        SaveToIni(hWnd, SettingRfPowerEBID, PowerStr);
                        SaveToIni(hWnd, SettingTrafficVectorEBID, SyncVctStr);
                        }
                    EndDialog(hWnd, WMCMDID);
                }
            return TRUE;
        }
    return FALSE;
    }




//-----------------------------------------------------------------------------
//      설정 대화상자
//-----------------------------------------------------------------------------
int WINAPI SettingDlg(HWND hWnd)
    {
    return DialogBox(HInst, MAKEINTRESOURCE(SettingDialog), hWnd, SettingDlgProc);
    }



///////////////////////////////////////////////////////////////////////////////
//                      RF수신 모듈 설정
///////////////////////////////////////////////////////////////////////////////
#ifdef SETMODULES


#define MODULEQTY   10
static DWORD ModuleGroupNo[MODULEQTY]={321,322,323,324,325,326,327,328,329,330};
static BYTE  ModuleChannelNo[MODULEQTY]={11,12,13,14,15,16,17,18,19,20};



//-----------------------------------------------------------------------------
//      타겟에 그룹과 채널을 설정을 함
//-----------------------------------------------------------------------------
LOCAL(BOOL) SetGroupChannel(HWND hWnd, int GroupNo, int Channel)
    {
    int   Rslt=FALSE;
    DWORD Time;
    CHAR  Buff[80];

    wsprintf(Buff, "INI Internal Group %u", GroupNo);
    if (Target_SendCommand(Buff)==FALSE) goto ProcExit;

    wsprintf(Buff, "INI Internal Channel %u", Channel);
    if (Target_SendCommand(Buff)==FALSE) goto ProcExit;

    if (Target_SendCommand("INI FLUSH")==FALSE) goto ProcExit;
    if (CheckReplyFromTarget("SENSOR: Cfg Save OK", 3000)==FALSE) goto ProcExit;
    Sleep(100);

    //설정값 확인
    if (Target_SendCommand("BOOT")==FALSE) goto ProcExit;

    Time=GetTickCount();
    while (GetTickCount()-Time<3000)
        {
        ReadLineFromTarget(Buff, sizeof(Buff), 100);
        if (CompMemStr(Buff, "SENSOR: Group=")==0)
            {
            if (GetCommaStrToInt(Buff, GroupStr)==GroupNo &&
                GetCommaStrToInt(Buff, ChannelStr)==Channel) Rslt++;
            break;
            }
        }

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      모든 모듈을 설정함
//-----------------------------------------------------------------------------
LOCAL(VOID) SetAllModule(HWND hWnd)
    {
    int I;

    for (I=0; I<MODULEQTY; I++)
        {
        SetGroupChannel(hWnd, ModuleGroupNo[I], ModuleChannelNo[I]);
        }
    }



//-----------------------------------------------------------------------------
//      페이지 설정
//-----------------------------------------------------------------------------
LOCAL(VOID) SetModulePage(HWND hWnd, int PageNo)
    {
    int I, No;
    CHAR Buff[16];

    No=(PageNo==0) ? 5:0;
    for (I=0; I<5; I++,No++)
        {
        ModuleGroupNo[No]=GetDlgItemInt(hWnd, I+SetModuleGroupEBID, NULL, FALSE);
        ModuleChannelNo[No]=GetDlgItemInt(hWnd, I+SetModuleChannelEBID, NULL, FALSE);
        }

    No=PageNo*5;
    for (I=0; I<5; I++,No++)
        {
        wsprintf(Buff, "그룹%X", No+1);
        SetDlgItemText(hWnd, I+SetModuleGroupTXID, Buff);
        SetDlgItemInt(hWnd, I+SetModuleGroupEBID, ModuleGroupNo[No], FALSE);

        wsprintf(Buff, "채널%X", No+1);
        SetDlgItemText(hWnd, I+SetModuleChannelTXID, Buff);
        SetDlgItemInt(hWnd, I+SetModuleChannelEBID, ModuleChannelNo[No], FALSE);
        }
    }



//-----------------------------------------------------------------------------
//      모듈 설정 대화상자 Proc
//-----------------------------------------------------------------------------
DLGFNC(SetModuleDlgProc)
    {
    int I;
    static int LastFocusEBID, PageNo;

    switch (Msg)
        {
        case WM_INITDIALOG:
            LastFocusEBID=PageNo=0;

            for (I=0; I<5; I++)
                {
                SetDlgItemInt(hWnd, I+SetModuleGroupEBID, ModuleGroupNo[I], FALSE);
                SetDlgItemInt(hWnd, I+SetModuleChannelEBID, ModuleChannelNo[I], FALSE);
                }
            return TRUE;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case GetModuleValueBTID:        //모듈의 현재값 가져오기
                    break;

                case SetModuleNumber0BTID:
                case SetModuleNumber1BTID:
                case SetModuleNumber2BTID:
                case SetModuleNumber3BTID:
                case SetModuleNumber4BTID:
                case SetModuleNumber5BTID:
                case SetModuleNumber6BTID:
                case SetModuleNumber7BTID:
                case SetModuleNumber8BTID:
                case SetModuleNumber9BTID:
                case SetModuleSpaceBTID:
                case SetModuleBkSpcBTID:
                    if (LastFocusEBID!=0)
                        {
                        SetFocusDlgItem(hWnd, LastFocusEBID);
                        PostMessage(GetDlgItem(hWnd, LastFocusEBID), WM_CHAR, WMCMDID, 1);
                        }
                    break;

                case SetModuleGroupEBID+0:
                case SetModuleChannelEBID+0:
                case SetModuleGroupEBID+1:
                case SetModuleChannelEBID+1:
                case SetModuleGroupEBID+2:
                case SetModuleChannelEBID+2:
                case SetModuleGroupEBID+3:
                case SetModuleChannelEBID+3:
                case SetModuleGroupEBID+4:
                case SetModuleChannelEBID+4:
                    if (WMCMDNOTIFY==EN_SETFOCUS) LastFocusEBID=WMCMDID;
                    break;

                case SetPrevModuleBTID:
                    if (PageNo==0) break;
                    SetModulePage(hWnd, PageNo=0);
                    break;

                case SetNextModuleBTID:
                    if (PageNo!=0) break;
                    SetModulePage(hWnd, PageNo=1);
                    break;

                case IDOK:
                    SetAllModule(hWnd);
                    break;

                case IDCANCEL:
                    EndDialog(hWnd, WMCMDID);
                }
            return TRUE;
        }
    return FALSE;
    }




//-----------------------------------------------------------------------------
//      모듈 설정 대화상자
//-----------------------------------------------------------------------------
int WINAPI SetModuleDlg(HWND hWnd)
    {
    return DialogBox(HInst, MAKEINTRESOURCE(SetModuleDialog), hWnd, SetModuleDlgProc);
    }


#endif //SETMODULES

