#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "LCD.H"
#include "MAIN.H"


#define MEMOWNER_RotateRightPut (MEMOWNER_PicFrame+0)
#define MEMOWNER_RandomPut      (MEMOWNER_PicFrame+1)



//-----------------------------------------------------------------------------
//      Viewer �ڽ�ũ�⸦ ����
//-----------------------------------------------------------------------------
LOCAL(UINT) AdjBoxSize(UINT BoxSize)
    {
    UINT Min, Max;

    Min=LCD_ResolutionY/32;
    Max=LCD_ResolutionY/4;
    if (BoxSize==0) BoxSize=MyRand(1234);
    BoxSize=BoxSize%(Max-Min+1)+Min;
    return BoxSize & (~1);
    }



//-----------------------------------------------------------------------------
//              ���������� ���ư��� ȭ�鿡 ǥ����
//              Mode==0�̸� �ܰ����� ǥ���ϰ� �ƴϸ� �߾Ӻ��� ǥ����
//-----------------------------------------------------------------------------
VOID WINAPI RotateRightPut(int BoxSize, int Mode)
    {
    int I, Dir=-1, BoxQty, T;
    RECT R, AR, *Rl;
    RECTLIST RL;

    ZeroMem(&RL, sizeof(RL));
    BoxSize=AdjBoxSize(BoxSize);
    BoxQty=(LCD_ResolutionX*LCD_ResolutionY)/(BoxSize*BoxSize);

    while (1)
        {
        switch (Dir)
            {
            case -1:
                SetRect(&R, 0,0, BoxSize, BoxSize);
                SetRect(&AR, 0, 0, LCD_ResolutionX, LCD_ResolutionY);
                Dir=0;
                break;

            case 0:     //����������
                OffsetRect(&R, BoxSize, 0);
                if (R.left>=AR.right)
                    {
                    OffsetRect(&R, -BoxSize, BoxSize);
                    AR.top=R.top;
                    Dir=1;
                    }
                break;

            case 1:     //�Ʒ���
                OffsetRect(&R, 0, BoxSize);
                if (R.top>=AR.bottom)
                    {
                    OffsetRect(&R, -BoxSize, -BoxSize);
                    AR.right=R.right;
                    Dir=2;
                    }
                break;

            case 2:     //��������
                OffsetRect(&R, -BoxSize, 0);
                if (R.left<AR.left)
                    {
                    OffsetRect(&R, BoxSize, -BoxSize);
                    AR.bottom=R.bottom;
                    Dir=3;
                    }
                break;

            case 3:     //����
                OffsetRect(&R, 0, -BoxSize);
                if (R.top<AR.top)
                    {
                    OffsetRect(&R, BoxSize, BoxSize);
                    AR.left=R.left;
                    Dir=0;
                    }
            }
        if (AR.left>=AR.right || AR.top>=AR.bottom) break;
        if (Mode==0) AddRectList(&RL, &R); else AddRectListFront(&RL, &R);
        }

    for (I=0; I<RL.CurrQty; I++)
        {
        Rl=RL.RectList+I;
        LCD_CopyFBMem(Rl->left, Rl->top, Rl->right-Rl->left, Rl->bottom-Rl->top);
        if ((T=1000/BoxQty)>=0) Sleep(T);
        }
    FreeMem(RL.RectList);
    }



//-----------------------------------------------------------------------------
//              �������� �ڽ��� ����
//-----------------------------------------------------------------------------
VOID WINAPI RandomPut(int BoxSize)
    {
    int I, T, BoxQtyX, BoxQtyY, TotalQty;
    BYTE *PutChkMem;

    BoxSize=AdjBoxSize(BoxSize);

    BoxQtyX=(LCD_ResolutionX+BoxSize-1)/BoxSize;
    BoxQtyY=(LCD_ResolutionY+BoxSize-1)/BoxSize;
    TotalQty=BoxQtyX*BoxQtyY;
    if ((PutChkMem=(BYTE*)AllocMem(TotalQty, MEMOWNER_RandomPut))==NULL) goto ProcExit;
    ZeroMem(PutChkMem, TotalQty);

    while (SearchByte(PutChkMem, TotalQty, 0)!=-1)
        {
        //if ((T=GetRepeatQty(PutChkMem, TotalQty, 0))==0) break;
        //I=MyRand() % T;
        //I=SearchByteII(PutChkMem, TotalQty, 0, I);

        do I=MyRand(1234) % TotalQty; while (PutChkMem[I]!=0);
        PutChkMem[I]=1;

        LCD_CopyFBMem((I % BoxQtyX) * BoxSize, (I / BoxQtyX) * BoxSize, BoxSize, BoxSize);
        if ((T=1000/(BoxQtyX*BoxQtyY))>=0) Sleep(T);
        }
    ProcExit:
    if (PutChkMem!=NULL) FreeMem(PutChkMem);
    }

