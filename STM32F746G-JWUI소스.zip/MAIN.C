﻿
#if defined(__GNUC__)
//#pragma GCC optimize ("O0")     //GCC에서 -Os로 컴파일하면 비정상동작
#endif


#include "JLIB.H"
#include "JOS.H"
#include "DRIVER.H"
#include "MONITOR.H"
#include "KEY.H"
#include "MAIN.H"
#include "JWUI.H"
#include "JFAT.H"
#include "COMMCTL.H"
#include "FT5336.H"
#include "USBD/USBD_MSC.H"
#include "Setting.h"
#include "FlashProgrammer.h"
#include "SWD.H"


#if 0// defined(__GNUC__)
#undef WINAPI
#define WINAPI __attribute__((optimize("O0")))
#endif


HWND HwndMain;
static CONST CHAR FirstBootMsg[]="\r\nIFI Sensor Gateway RozetaTech (Build %s)\r\n\r\n";
static HWND HwndSub;

const char* const MessageStrList[]=
    {
    "FIRE=Fire Detection:"
    };


#define MainGoHomeCMDID         100
#define SUB_GoHomeBTID          101
#define MainSettingBTID         102
#define MainInputBoxEBID        103
#define MainFlashPgmBTID        104


//-----------------------------------------------------------------------------
//      치명적인 오류가 생겼을 때 LED 번쩍거림
//-----------------------------------------------------------------------------
VOID WINAPI FatalError(int Err)
    {
    switch (Err)
        {
        case FERR_SYSCLKCFG:    //1초에 두번 짧게 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(10);
                PortOut(PO_STATUSLED, OFF); Delay_ms(490);
                }

        case FERR_EXCEPTION:    //1초에 10번 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, PO_NOT);
                Delay_ms(50);
                }

        case FERR_MEMORY:       //빠르게 두번을 깜빡이는데 1초마다 반복함
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(150);
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(750);
                }
        }
    }

VOID WINAPI UART_ErrUsrHandler(int Port, int ErrCode) {}




//-----------------------------------------------------------------------------
//      키상태 수집
//-----------------------------------------------------------------------------
static KEYCODETABLE KeyCodeTable[]=
    {//DownCode,    DblClickCode,       LongDown1Code,  LongDown2Code,  KeyUpCode
    {KC_TestDown,   KC_TestDblClk,      KC_TestLong1,    KC_TestLong2,  KC_TestUp},
    };

LOCAL(UINT) CollectKeyState(VOID)
    {
    UINT Key=0;

    if (PortIn(PI_TESTKEY)!=0) Key|=1;
    return Key;
    }



//-----------------------------------------------------------------------------
//      전원 켜기전에 이미 눌려있는 키를 어떻게 할지를 결정해줌
//      ScanKey() 에서 호출함
//-----------------------------------------------------------------------------
UINT WINAPI IgnoreFirstPushedKey(int Key)
    {
    return 0;
    }



//-----------------------------------------------------------------------------
//      키클릭음 처리, ScanKey()에서 호출함
//-----------------------------------------------------------------------------
VOID WINAPI PlayKeyClickSound(int KeyCode)
    {
    }



//-----------------------------------------------------------------------------
//      1ms 마다 처리 (틱 인터럽트에서 호출함)
//-----------------------------------------------------------------------------
VOID WINAPI _1msProc(VOID)
    {
    static BYTE _10ms;

    if (++_10ms>=10)
        {
        _10ms=0;
        ScanKey(CollectKeyState(), KeyCodeTable, countof(KeyCodeTable));
        K_TimerProc();
        //PlaySoundProc();
        //RFM_10msProc();
        }
    }




//-----------------------------------------------------------------------------
//      JWUI에서 이미지 파일을 로딩할 때 호출함
//-----------------------------------------------------------------------------
VOID WINAPI MakeUIPath(LPSTR FilePath, LPCSTR ImgFileName)
    {
    //wsprintf(FilePath, "/root/KOR/%s", ImgFileName);
    lstrcpy(FilePath, ImgFileName);
    }



///////////////////////////////////////////////////////////////////////////////
//              H/W Event Q
///////////////////////////////////////////////////////////////////////////////


typedef struct _EVENTENTRY
    {
    UINT Msg;
    //WPARAM wPrm;
    LPARAM lPrm;
    } EVENTENTRY;

#define EVENTQQTY 16
typedef struct _EVENTQ
    {
    int GetPos, PutPos;
    EVENTENTRY Q[EVENTQQTY];
    } EVENTQ;

static EVENTQ HWEvQ;
static EVENTQ PopupMsgQ;


LOCAL(BOOL) GetEventQ(EVENTQ *EVQ, EVENTENTRY *Entry, BOOL RemoveFg)
    {
    BOOL Rslt=FALSE;
    JOS_CRITICAL_VAR;

    if (GetCapture()==NULL)             //버튼을 누른동안 하드웨어 메세지를 처리하면 UI가 얽힘
        {
        JOS_ENTER_CRITICAL();
        if (EVQ->GetPos!=EVQ->PutPos)   //읽을곳과 넣을위치가 같으면 빈것임
            {
            CopyMem(Entry, EVQ->Q+EVQ->GetPos, sizeof(EVENTENTRY));
            if (RemoveFg!=0)
                {
                if (++EVQ->GetPos>=EVENTQQTY) EVQ->GetPos=0;
                }
            Rslt=TRUE;
            }
        JOS_EXIT_CRITICAL();
        }
    return Rslt;
    }



VOID WINAPI PostEventQ(EVENTQ *EVQ, UINT Msg, /*WPARAM wPrm,*/ LPARAM lPrm)
    {
    int NextPutPos;
    EVENTENTRY *lpM;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if ((NextPutPos=EVQ->PutPos+1)>=EVENTQQTY) NextPutPos=0;
    if (NextPutPos!=EVQ->GetPos)        //다음 넣을 곳이 읽을 곳과 같으면 꽉참
        {
        lpM=EVQ->Q+EVQ->PutPos; EVQ->PutPos=NextPutPos;
        lpM->Msg=Msg;
        //lpM->wPrm=wPrm;
        lpM->lPrm=lPrm;
        //Rslt++;
        }
    JOS_EXIT_CRITICAL();
    //return TRUE;
    }

VOID WINAPI SendToTgmEx(UINT Msg, LPARAM lPrm) {PostEventQ(&HWEvQ, Msg, lPrm);}
VOID WINAPI SendToTgm(int EvCode) {SendToTgmEx(EvCode, 0);}




#define SCRSAVER_OFF            0
#define SCRSAVER_ISTIMEOUT      1
#define SCRSAVER_SETEVENT       2
#define SCRSAVER_NOWIDLE        3
#define SCRSAVER_ENABLE         4
#define SCRSAVER_DISABLE        5
#define SCRSAVER_GETSTATUS      6

#define SCRSAVECODE_NOWSAVE     -1
#define SCRSAVECODE_DISABLE     -2


static int  PowerSaveTime=60;

VOID WINAPI EnterScreenSaver(VOID)
    {
    //PortOut(LCDBKLIGHT_N, OFF);
    //LedOut(BACKLIGHTLED, OFF);
    //LedOut(POWERLED, OFF);
    }

VOID WINAPI ReleaseScreenSaver(VOID)
    {
    //PortOut(LCDBKLIGHT_N, ON);
    //LedOut(BACKLIGHTLED, ON);
    //LedOut(POWERLED, ON);
    //if (IsExistTalkingUnit()) LedOut(TALKLED, ON);      //서브폰이 도어 모니터링중일 경우
    }



//-----------------------------------------------------------------------------
//      스크린 세이버
//-----------------------------------------------------------------------------
int WINAPI ScreenSaver(int Cmd)
    {
    int Rslt=0;
    static int  SSTmr=SCRSAVECODE_DISABLE;

    //Printf(COM1, "Cmd=%d, Timer=%d\r\n", Cmd, SSTmr);
    switch (Cmd)
        {
        case SCRSAVER_GETSTATUS:
            Rslt=SSTmr;
            break;

        case SCRSAVER_ISTIMEOUT:
            Rslt=SSTmr==0;
            break;

        case SCRSAVER_NOWIDLE:
            if (SSTmr>0) SSTmr--;
            break;

        case SCRSAVER_SETEVENT:
            if (SSTmr==SCRSAVECODE_NOWSAVE)
                {
                ReleaseScreenSaver();
                Rslt++;
                }
            if (SSTmr!=SCRSAVECODE_DISABLE && PowerSaveTime>0) SSTmr=PowerSaveTime;
            break;

        case SCRSAVER_DISABLE:
            if (SSTmr!=SCRSAVECODE_NOWSAVE) SSTmr=SCRSAVECODE_DISABLE;
            break;

        case SCRSAVER_ENABLE:
            if (PowerSaveTime>0 && SSTmr!=SCRSAVECODE_NOWSAVE) SSTmr=PowerSaveTime;
            break;

        case SCRSAVER_OFF:
            SSTmr=SCRSAVECODE_NOWSAVE;
            EnterScreenSaver();
        }
    return Rslt;
    }




LOCAL(VOID) SystemClock_Config(VOID)
    {
    RCC_ClkInitTypeDef CI;
    RCC_OscInitTypeDef OI;

    OI.OscillatorType=RCC_OSCILLATORTYPE_HSE;
    OI.HSEState=RCC_HSE_ON;
    OI.HSIState=RCC_HSI_OFF;
    OI.PLL.PLLState=RCC_PLL_ON;
    OI.PLL.PLLSource=RCC_PLLSOURCE_HSE;
    OI.PLL.PLLM=25;                 //2~63
    OI.PLL.PLLN=384;                //40~432
    OI.PLL.PLLP=RCC_PLLP_DIV2;      //HSE_VALUE(25000000)/25*384/RCC_PLLP_DIV2 = 192M (SDRAM은 200M를 초과하면 동작안함)
    OI.PLL.PLLQ=8;                  //HSE_VALUE(25000000)/25*384/8 = 48M (USB를 위해 48M를 맞추어야 함)
    if (HAL_RCC_OscConfig(&OI)!=HAL_OK) FatalError(FERR_SYSCLKCFG);
    if (HAL_PWREx_EnableOverDrive()!=HAL_OK) FatalError(FERR_SYSCLKCFG);

    CI.ClockType=(RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2);
    CI.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;
    CI.AHBCLKDivider=RCC_SYSCLK_DIV1;   //HCLK = SYSCLK / 1
    CI.APB1CLKDivider=RCC_HCLK_DIV4;    //PCLK1 = HCLK / 4
    CI.APB2CLKDivider=RCC_HCLK_DIV2;    //PCLK2 = HCLK / 2
    if (HAL_RCC_ClockConfig(&CI, FLASH_LATENCY_7)!=HAL_OK) FatalError(FERR_SYSCLKCFG);
    }





LOCAL(VOID) MPU_Config(VOID)
    {
    MPU_Region_InitTypeDef MRI;

    HAL_MPU_Disable();

    ZeroMem(&MRI, sizeof(MRI));
    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=SRAM1_BASE;
    MRI.Size=MPU_REGION_SIZE_256KB;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_NOT_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER0;
    MRI.TypeExtField=MPU_TEX_LEVEL0;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=0x2004C000;
    MRI.Size=MPU_REGION_SIZE_16KB;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER1;
    MRI.TypeExtField=MPU_TEX_LEVEL1;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=0x2004C000;
    MRI.Size=MPU_REGION_SIZE_256B;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER2;
    MRI.TypeExtField=MPU_TEX_LEVEL0;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
    }



//-----------------------------------------------------------------------------
//      루프딜레이 캘리브레이션
//-----------------------------------------------------------------------------
VOID CalLoopDelay(VOID)
    {
    DWORD Tick;

    Tick=GetTickCount();
    Delay_ms(1000);
    Printf("Delay_ms=%d\r\n", GetTickCount()-Tick);
    }




LOCAL(VOID) CloseAllPop(VOID)
    {
    HWND hWndPopup;

    if ((hWndPopup=GetMostTopWindow())!=NULL) DestroyWindow(hWndPopup);
    }



WNDFNC(TestWinProc)
    {
    switch (Msg)
        {
        case WM_CREATE:
            return 0;

        case WM_DESTROY:
            return 0;

        case WM_LBUTTONDOWN:
            Printf("Test WM_LBUTTONDOWN %d %d"CRLF, LoWord(lPrm), HiWord(lPrm));
            return 0;

        case WM_MOUSEACTIVATE:
            SetFocus(hWnd);
            break;

        case WM_KEYDOWN:
            Printf("Test WM_KEYDOWN %d"CRLF, wPrm);
            return 0;

        case WM_ERASEBKGND:
            //DrawGif((HDC)wPrm, 0, 0, "FbScrCleanN.gif", COL_TRANSPARENT);
            return 1;
        }
    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }




//-----------------------------------------------------------------------------
//      7세그먼트로 시계 표시
//-----------------------------------------------------------------------------
#define SEG7HEIGHT  70
#define SEG7WIDTH   50
LOCAL(VOID) Draw7Segment(HDC hDC, POINTS P, int Cha, HBITMAP hBtm7Seg)
    {
    DrawBitmap(hDC, P.x, P.y, SEG7HEIGHT, SEG7WIDTH,
                       hBtm7Seg, 0, Cha==':' ? SEG7WIDTH*10:(Cha-'0')*SEG7WIDTH, COL_TRANSPARENT);
    }



//-----------------------------------------------------------------------------
//      7세그먼트로 시계 표시
//-----------------------------------------------------------------------------
#define CLOCKPOSX   30
#define CLOCKPOSY   100
LOCAL(VOID) DrawClock(HDC hDC, LPCSTR ClockStr, HBITMAP hBtmBkgnd, HBITMAP hBtm7Seg)
    {
    int I, Cha;
    static CONST POINTS Coord[]=
        {
        {CLOCKPOSY, CLOCKPOSX},
        {CLOCKPOSY, CLOCKPOSX+50},
        {CLOCKPOSY, CLOCKPOSX+95},  //':'
        {CLOCKPOSY, CLOCKPOSX+125},
        {CLOCKPOSY, CLOCKPOSX+175},
        {CLOCKPOSY, CLOCKPOSX+225}, //':'
        {CLOCKPOSY, CLOCKPOSX+255},
        {CLOCKPOSY, CLOCKPOSX+305}
        };

    if (hBtmBkgnd!=NULL)
        {
        DrawBitmap(hDC, CLOCKPOSY, CLOCKPOSX, CLOCKPOSY+SEG7HEIGHT, CLOCKPOSX+360,
                           hBtmBkgnd, CLOCKPOSY, CLOCKPOSX, COL_NOTRANSPARENT);
        }

    for (I=0; ;I++)
        {
        if ((Cha=ClockStr[I])==0) break;
        Draw7Segment(hDC, Coord[I], Cha, hBtm7Seg);
        }
    }



#define MyPhoneBookLVID 110
#define LVC_NUMBER      0
#define LVC_NAME        1
#define LVC_PHONE       2
#define LVC_CHAR        3
#define LVC_ITEMQTY     4


//-----------------------------------------------------------------------------
//              홈 화면 처리
//-----------------------------------------------------------------------------
#define MAINWINTMR_TimeDisp     1
#define MAINWINTMR_ChkHcu       2
#define MAINWINTMR_ShowAlarmDlg 3
#define MAINWINTMR_ShowBurgDlg  4
#define MAINWINTMR_OpenGRCallDlg 5
#define MAINWINTMR_CheckNetwork 6
WNDFNC(MainWinProc)
    {
    static int SeledMainMenu;
    static HBITMAP hBtmBkgnd, hBtm7Seg;
    static HFONT hFontDefault;
    static HFONT hFont24;
    static CONST INT16 DefWidths[]={30,60,95,60};
    static CONST BYTE  HeadAligns[]={0,0,0,0,0};
    static CONST DIALOGTEMPLATE WndChilds[]=
        {
        {"설정",     (HMENU)MainSettingBTID,     "Button", BS_PUSHBUTTON|WS_CHILD|WS_VISIBLE,   51, 396, 80, 50},
        {"프로그램", (HMENU)MainFlashPgmBTID,    "Button", BS_PUSHBUTTON|WS_CHILD|WS_VISIBLE,  141, 396, 80, 50},

        {"번호|이름|전화번호|성격", (HMENU)MyPhoneBookLVID,  WC_LISTVIEW, WS_CHILD|WS_VISIBLE,  10, 10, 250, 200},

        //{"",     (HMENU)MainInputBoxEBID,    "Edit",   ES_WANTRETURN|ES_MULTILINE|WS_CHILD|WS_VISIBLE,   190,40,111,58},  //에디트박스
        };

    switch (Msg)
        {
        case WM_CREATE:
            CreateChilds(hWnd, WndChilds, countof(WndChilds));

            hBtmBkgnd=LoadImage("BATANG.PNG");
            hBtm7Seg=LoadImage("7Segment.png");
            hFontDefault=LoadFont("F12.FNT");
            hFont24=LoadFont("F28.FNT");
            SetTimer(hWnd, MAINWINTMR_TimeDisp, 1000, NULL);

            LV_SetColumn(hWnd, MyPhoneBookLVID, NULL, DefWidths, HeadAligns, LVC_ITEMQTY);

            LV_InsertItem(hWnd, MyPhoneBookLVID, 0, "1", 0);    //LVC_NUMBER
            LV_SetItemText(hWnd, MyPhoneBookLVID, 0, LVC_NAME,  "죠우저프");
            LV_SetItemText(hWnd, MyPhoneBookLVID, 0, LVC_PHONE, "010-1111-2222");
            LV_SetItemText(hWnd, MyPhoneBookLVID, 0, LVC_CHAR,  "지랄같음");

            LV_InsertItem(hWnd, MyPhoneBookLVID, 1, "2", 0);    //LVC_NUMBER
            LV_SetItemText(hWnd, MyPhoneBookLVID, 1, LVC_NAME,  "다이소");
            LV_SetItemText(hWnd, MyPhoneBookLVID, 1, LVC_PHONE, "019-231-9823");
            LV_SetItemText(hWnd, MyPhoneBookLVID, 1, LVC_CHAR,  "몽땅");

            Ret0:
            return 0;

        case WM_ACTIVATE:
            if (wPrm==WA_ACTIVE) PostMessage(hWnd, WM_TIMER, 1, 0);             //시계갱신을 위해
            break;

        case WM_LBUTTONDOWN:
            MessageBox(hWnd, "안녕하세요.", "인사", MB_ICONINFORMATION|MB_OK);
            goto Ret0;

        case WM_KEYDOWN:
            //Printf("Main WM_KEYDOWN %d"CRLF, wPrm);
            switch (wPrm)
                {
                case 1: ShowWindow(GetDlgItem(hWnd, 1234), SW_SHOW); break;
                case 2: ShowWindow(GetDlgItem(hWnd, 1234), SW_HIDE); break;
                case 3: InvalidateRect(hWnd, NULL, TRUE); break;
                case 4: {RECT R; SetRect(&R, 200,100,300,200); LCD_FillRect(&R, COL_RED);}
                }
            goto Ret0;

        case WM_TIMER:
            switch (wPrm)
                {
                case MAINWINTMR_TimeDisp:
                    {
                    HDC hDC;
                    SYSTEMTIME ST;
                    CHAR Buff[40];

                    GetLocalTime(&ST);
                    wsprintf(Buff, "%02d:%02d:%02d", ST.wHour, ST.wMinute, ST.wSecond);

                    hDC=GetDC(hWnd);
                    if (hBtm7Seg==NULL)
                        {
                        SelectObject(hDC, hFontDefault);
                        SetTextColor(hDC, COL_RED);
                        SetBkColor(hDC, COL_GREEN);
                        MyTextOut(hDC, 114, 54, Buff);
                        }
                    else DrawClock(hDC, Buff, hBtmBkgnd, hBtm7Seg);
                    ReleaseDC(hWnd, hDC);
                    break;
                    }
                }
            goto Ret0;

        case WM_PAINT:
            {
            PAINTSTRUCT PS;

            BeginPaint(hWnd, &PS);
            //PrintRect("Main rcPaint:", &PS.rcPaint);
            EndPaint(hWnd, &PS);
            goto Ret0;
            }

        case WM_ERASEBKGND:
            if (hBtmBkgnd) DrawBitmap((HDC)wPrm, 0,0,0,0, hBtmBkgnd, 0,0, COL_NOTRANSPARENT);

            SetTextColor((HDC)wPrm, COL_RED);
            SetBkMode((HDC)wPrm, TRANSPARENT);
            //SelectObject((HDC)wPrm, hFontDefault);
            //MyTextOut((HDC)wPrm, 3, 3, "Welcome Kg 한글");
            //SelectObject((HDC)wPrm, hFont24);
            //MyTextOut((HDC)wPrm, 0, LCD_LogResolutionY-24-4, "ٱلسَّلَامُ عَلَيْكُمْ (안녕, Hellow) لا ...");  // ...");
            return 1;

        case WM_GETFONT: return (LRESULT)hFontDefault;

        case WM_COMMAND:
            //CloseAllPop();
            switch (WMCMDID)
                {
                case MainGoHomeCMDID:
                    if (SeledMainMenu) SendDlgItemMessage(hWnd, SeledMainMenu, BM_INITANIGIF, FALSE,0);
                    //ViewFuncBtns(hWnd, SeledMainMenu, FALSE);
                    SeledMainMenu=0;
                    break;

                case MainSettingBTID:
                    #ifdef SETMODULES
                    SetModuleDlg(hWnd);
                    #else
                    SettingDlg(hWnd);
                    #endif
                    break;

                case MainFlashPgmBTID:
                    FlashProgrammer(hWnd);
                    //break;
                }
            goto Ret0;

        case WM_DESTROY:
            if (hFontDefault) DeleteObject(hFontDefault);
            if (hBtmBkgnd)    DeleteObject(hBtmBkgnd);
            if (hBtm7Seg)     DeleteObject(hBtm7Seg);
            if (hFont24) DeleteObject(hFont24);
            PostQuitMessage(0);
            goto Ret0;
        }

    return DefWindowProc(hWnd, Msg, wPrm, lPrm);
    }



//-----------------------------------------------------------------------------
//      윈도우를 등록함
//-----------------------------------------------------------------------------
LOCAL(ATOM) RegistWnd(HINSTANCE hInst, LPCSTR ClsName, WNDPROC WndProc)
    {
    WNDCLASS WC;

    ZeroMem(&WC, sizeof(WNDCLASS));
    WC.lpfnWndProc =WndProc;
    WC.hInstance   =hInst;
    WC.lpszClassName= ClsName;
    //WC.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
    return RegisterClass(&WC);
    }




//-----------------------------------------------------------------------------
//      MAIN TASK
//-----------------------------------------------------------------------------
static VOID MainTask(LPVOID lpData)
    {
    MSG M;
    //DWORD StartTick;

    Printf("SENSOR: JOS Ver=%s\r\n", lpData);

    //CreateMonitorTask();
    LCD_Init();
    Printf("LCD %u x %u"CRLF, LCD_LogResolutionX, LCD_LogResolutionY);
    //TIM_UpCounterSetup(TIM2, 32*1000, 1);

    if (FT5336_Init(LCD_ResolutionX, LCD_ResolutionY, TS_SWAP_XY)==FALSE)
        Printf("Touchscreen cannot be initialized"CRLF);

    DAP_Setup();

    JWUI_Init();
    InitCommonControls();

    RegistWnd(HInst, "TestClass", TestWinProc);
    if (RegistWnd(HInst, "MAIN", MainWinProc)==0) {Printf("'MAIN' Wndclass Not Registed\r\n"); goto ProcExit;}
    if ((HwndMain=CreateWindow("MAIN", "", WS_NOBKUPPA, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), (HWND)NULL, (HMENU)NULL, HInst, NULL))==NULL)
        {Printf("MAIN Window Not Created\r\n"); goto ProcExit;}

    ScreenSaver(SCRSAVER_ENABLE);               //스크린세이버 시작
    //InitWatchDog();

    while (GetMessage(&M, 0, 0, 0))
        {
        int Rslt;

        if ((Rslt=HangulAutomata(&M))==0) TranslateMessage(&M);
        if (Rslt!=2) DispatchMessage(&M);
        WatchDogOut();
        }

    ProcExit:
    Printf("Ok\r\n");
    }




//-----------------------------------------------------------------------------
//      JOS 초기화 추가 처리
//      JOSStartHighRdy()함수를 삭제하는 대신 여기서 처리
//
//      JOS는 문맥전환을 PendSV를 이용하는데
//      핸들러 처리 중에 PendSV가 처리되면 안되므로 (이유:MSP가 계속 소모됨)
//      PendSV의 우선순위를 최하로 설정해야 함
//-----------------------------------------------------------------------------
VOID WINAPI JOSInitHookBegin(VOID)
    {
    //NVIC_SetPriority(PendSV_IRQn, 15);
    SCB->SHPR[10]=0xFF;
    }




LOCAL(VOID) IniPortFmc(int PinNo) {InitPortEx(PinNo, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_FMC, GPIO_SPEED_FAST);}
LOCAL(VOID) IniPortLcd(int PinNo) {InitPortEx(PinNo, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF14_LTDC, GPIO_SPEED_FAST);}
LOCAL(VOID) IniPortEth(int PinNo) {InitPort(PinNo, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF11_ETH);}
LOCAL(VOID) IniPortOTGHS(int PinNo) {InitPort(PinNo, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF10_OTG_HS);}




//-----------------------------------------------------------------------------
//          Main
//-----------------------------------------------------------------------------
int main(void)
    {
    //CHAR  Buff[40];
    static BYTE AllocMemory[192*1024];
    //static BYTE AllocMemory[20000];   //250000까지도 가능

    __disable_irq();
    InitPortOutputPP(PO_STATUSLED);     //치명적 오류를 표시해야 하므로 맨위에 초기화 필요
    MPU_Config();
    SCB_EnableICache();
    SCB_EnableDCache();
    HAL_Init();
    SystemClock_Config();

    if (MemAllocInit((UINT)AllocMemory, sizeof(AllocMemory))==FALSE) FatalError(FERR_MEMORY);

    //디버깅
    InitPort(PO_COM6TX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF8_USART6);     //CN4-1번핀
    InitPort(PI_COM6RX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF8_USART6);     //CN4-2번핀
    InitPort(PO_COM1TX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF7_USART1);
    InitPort(PI_COM1RX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF7_USART1);
    InitPortInput(PI_TESTKEY, GPIO_NOPULL);

    //Ethernet
    IniPortEth(RMII_REFCLK);
    IniPortEth(RMII_MDIO);
    IniPortEth(RMII_CRSDV);
    IniPortEth(RMII_MDC);
    IniPortEth(RMII_RXD0);
    IniPortEth(RMII_RXD1);
    IniPortEth(RMII_RXER);
    IniPortEth(RMII_TXEN);
    IniPortEth(RMII_TXD0);
    IniPortEth(RMII_TXD1);


    //SDRAM
    IniPortFmc(PO_FMC_D0);
    IniPortFmc(PO_FMC_D1);
    IniPortFmc(PO_FMC_D2);
    IniPortFmc(PO_FMC_D3);
    IniPortFmc(PO_FMC_D4);
    IniPortFmc(PO_FMC_D5);
    IniPortFmc(PO_FMC_D6);
    IniPortFmc(PO_FMC_D7);
    IniPortFmc(PO_FMC_D8);
    IniPortFmc(PO_FMC_D9);
    IniPortFmc(PO_FMC_D10);
    IniPortFmc(PO_FMC_D11);
    IniPortFmc(PO_FMC_D12);
    IniPortFmc(PO_FMC_D13);
    IniPortFmc(PO_FMC_D14);
    IniPortFmc(PO_FMC_D15);

    IniPortFmc(PO_FMC_A0);
    IniPortFmc(PO_FMC_A1);
    IniPortFmc(PO_FMC_A2);
    IniPortFmc(PO_FMC_A3);
    IniPortFmc(PO_FMC_A4);
    IniPortFmc(PO_FMC_A5);
    IniPortFmc(PO_FMC_A6);
    IniPortFmc(PO_FMC_A7);
    IniPortFmc(PO_FMC_A8);
    IniPortFmc(PO_FMC_A9);
    IniPortFmc(PO_FMC_A10);
    IniPortFmc(PO_FMC_A11);

    IniPortFmc(PO_FMC_BA0);
    IniPortFmc(PO_FMC_BA1);
    IniPortFmc(PO_FMC_NBL0);
    IniPortFmc(PO_FMC_NBL1);
    IniPortFmc(PO_FMC_SDNRAS);
    IniPortFmc(PO_FMC_SDNCAS);
    IniPortFmc(PO_FMC_SDCLK);
    IniPortFmc(PO_FMC_SDNE0);
    IniPortFmc(PO_FMC_SDNWE);
    IniPortFmc(PO_FMC_SDCKE0);

    //TFT LCD
    IniPortLcd(PO_LCD_R0);
    IniPortLcd(PO_LCD_R1);
    IniPortLcd(PO_LCD_R2);
    IniPortLcd(PO_LCD_R3);
    IniPortLcd(PO_LCD_R4);
    IniPortLcd(PO_LCD_R5);
    IniPortLcd(PO_LCD_R6);
    IniPortLcd(PO_LCD_R7);

    IniPortLcd(PO_LCD_G0);
    IniPortLcd(PO_LCD_G1);
    IniPortLcd(PO_LCD_G2);
    IniPortLcd(PO_LCD_G3);
    IniPortLcd(PO_LCD_G4);
    IniPortLcd(PO_LCD_G5);
    IniPortLcd(PO_LCD_G6);
    IniPortLcd(PO_LCD_G7);

    IniPortLcd(PO_LCD_B0);
    IniPortLcd(PO_LCD_B1);
    IniPortLcd(PO_LCD_B2);
    IniPortLcd(PO_LCD_B3);
    InitPortEx(PO_LCD_B4, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_LTDC, GPIO_SPEED_FAST);
    IniPortLcd(PO_LCD_B5);
    IniPortLcd(PO_LCD_B6);
    IniPortLcd(PO_LCD_B7);

    IniPortLcd(PO_LCD_VSYNC);
    IniPortLcd(PO_LCD_HSYNC);
    IniPortLcd(PO_LCD_INT);
    IniPortLcd(PO_LCD_CLK);
    IniPortLcd(PO_LCD_DE);
    InitPortOutputPP(PO_LCD_DISP);
    InitPortOutputPP(PO_LCD_BL_CTRL);

    //QSPI - N25Q128A
    InitPort(PIO_QSPIDO, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_QUADSPI);
    InitPort(PIO_QSPID1, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_QUADSPI);
    InitPort(PIO_QSPID2, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_QUADSPI);
    InitPort(PIO_QSPID3, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_QUADSPI);
    InitPort(PO_QSPICS,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF10_QUADSPI);
    InitPort(PO_QSPICLK, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF9_QUADSPI);

    //SD
    InitPort(PO_SDD0,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPort(PO_SDD1,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPort(PO_SDD2,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPort(PO_SDD3,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPort(PO_SDCLK, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPort(PO_SDCMD, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF12_SDMMC1);
    InitPortInput(PI_SDDETECT, GPIO_PULLUP);

    #ifdef USE_USB_FS
    InitPort(PIO_USBOTG_N, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF10_OTG_FS);
    InitPort(PIO_USBOTG_P, GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF10_OTG_FS);
    #endif

    #ifdef USE_USB_HS
    IniPortOTGHS(PI_ULPI_CK);
    IniPortOTGHS(PIO_ULPI_D0);
    IniPortOTGHS(PIO_ULPI_D1);
    IniPortOTGHS(PIO_ULPI_D2);
    IniPortOTGHS(PIO_ULPI_D7);
    IniPortOTGHS(PIO_ULPI_D3);
    IniPortOTGHS(PIO_ULPI_D4);
    IniPortOTGHS(PIO_ULPI_D5);
    IniPortOTGHS(PIO_ULPI_D6);
    IniPortOTGHS(PO_ULPI_STP);
    IniPortOTGHS(PI_ULPI_NXT);
    IniPortOTGHS(PI_ULPI_DIR);
    #endif

    //I2C - Touch
    InitPortEx(PO_I2C3SCL, GPIO_MODE_AF_OD, GPIO_NOPULL, GPIO_AF4_I2C3, GPIO_SPEED_FAST);
    InitPortEx(PO_I2C3SDA, GPIO_MODE_AF_OD, GPIO_NOPULL, GPIO_AF4_I2C3, GPIO_SPEED_FAST);

    InitUart(COM_DEBUG,  115200, UART_PARITY_NONE, UART_WORDLENGTH_8B, UART_STOPBITS_1);
    InitUart(COM_TARGET, 115200, UART_PARITY_NONE, UART_WORDLENGTH_8B, UART_STOPBITS_1);    //COM6, UART6
    __enable_irq();

    InitRTC();
    //GetAppCompileDateStr(Buff);
    Printf(FirstBootMsg, "Dev"); //Buff);
    Printf("SENSOR: SystemCoreClock=%uHz\r\n", SystemCoreClock);

    JFAT_Init(0, FALSE);    //N25Q128A
    JFAT_Init(1, FALSE);    //SDCARD

    if (PortIn(PI_TESTKEY)!=0)
        {
        UINT StartTick;

        Printf("USB MSC Device (High Speed)" CRLF);
        USBD_MSC_Start();

        StartTick=GetTickCount();
        for (;;)
            {
            MonitorProc();
            if (GetTickCount()-StartTick>=500)
                {
                PortOut(PO_STATUSLED, PO_NOT);
                StartTick=GetTickCount();
                }
            STORAGE_AutoFlush(0, FALSE);
            Sleep(10);
            }
        }

    //CalLoopDelay();

    JOSInit();      //JOS 초기화
    CreateThread("Main", MAIN_TASK_STK_SIZE, MainTask, "v100", PRIO_MAINTASK);  //최초 태스크 생성
    JOSStart();     //JOS 기동
    }




//-----------------------------------------------------------------------------
//      타겟 DEBUG UART 수신 처리
//      'SENSOR: 2022-10-11 21:16:40 T=40' 파싱하여 시간 설정
//-----------------------------------------------------------------------------
LOCAL(VOID) ReceiveTargetUartProc(VOID)
    {
    int Cha;
    static DWORD RecvTime;
    static BYTE  RecvCnt;
    static CHAR  RcvBuff[80];

    for (;;)
        {
        if ((Cha=UART_RxByteIT(COM_TARGET))<0) break;

        if (RecvCnt!=0 && GetTickCount()-RecvTime>=100) RecvCnt=0;
        RecvTime=GetTickCount();
        if (Cha!=13 && Cha!=10)
            {
            if (RecvCnt<sizeof(RcvBuff)-1) RcvBuff[RecvCnt++]=Cha;
            continue;
            }

        RcvBuff[RecvCnt]=0; RecvCnt=0;

        if (CompMemStr(RcvBuff, "SENSOR: 20")==0 && RcvBuff[28]=='T' && RcvBuff[29]=='=')
            {
            SYSTEMTIME ST;

            ST.wYear=AtoIN(RcvBuff+8, 4);
            ST.wMonth=AtoIN(RcvBuff+13, 2);
            ST.wDay=AtoIN(RcvBuff+16, 2);
            ST.wHour=AtoIN(RcvBuff+19, 2);
            ST.wMinute=AtoIN(RcvBuff+22, 2);
            ST.wSecond=AtoIN(RcvBuff+25, 2);
            ST.wMilliseconds=0;
            SetLocalTime(&ST);

            Printf("TARGET> '%s'"CRLF, RcvBuff);
            }
        }
    }




//-----------------------------------------------------------------------------
//      이미지를 미리 압축을 풀어 놓음
//-----------------------------------------------------------------------------
VOID WINAPI JWUI_IdleHook()
    {
    DWORD CurrTime;
    EVENTENTRY Ev;
    static LPCSTR CacheFP;
    static DWORD  ChkTalkInfoOldTime, ChkMornCallOldTime, ServerCmdChkOldTime, SystemChkOldTime;

    static char CacheFileList[]=
        "\0";    // 서브배경
        //"RSRC\\MAIN\\01SubConfig.gif\0";

    CurrTime=GetTickCount();
    if (ServerCmdChkOldTime==0) ServerCmdChkOldTime=CurrTime;
    //if (InPW(GPR0)==0x1111) while (1) DebugCnt++;
    WatchDogOut();

    if (CacheFP==NULL) CacheFP=CacheFileList;
    if (CacheFP[0]!=0)
        {
        //CacheImage(CacheFP);
        CacheFP=GetToken(CacheFP, 1);
        }

    if (ScreenSaver(SCRSAVER_ISTIMEOUT))
        {
        CloseAllPop();
        if (HwndSub!=NULL) PostMessage(HwndSub, WM_COMMAND, SUB_GoHomeBTID, 0);
        PostMessage(HwndMain, WM_COMMAND, MainGoHomeCMDID, 0);
        ScreenSaver(SCRSAVER_OFF);
        }

    //if (GetEventQ(&HWEvQ, &Ev, TRUE)!=FALSE) PostMessage(HwndMain, WM_HCUEVENT, Ev.Msg, Ev.lPrm);

    if (CurrTime-ChkTalkInfoOldTime>500)
        {
        ChkTalkInfoOldTime=CurrTime;
        #if 0
        if (AllowDraw(HwndMain))            //상태아이콘 표시
            {
            POINT P;
            P.x=390;    //홈제어버튼 위에쯤
            P.y=100;
            if (WindowFromPoint(P)==HwndMain) StatusIconProc(HwndMain);
            }
        #endif
        }

    if (CurrTime-ChkMornCallOldTime>5000)               //5초마다
        {
        ChkMornCallOldTime=CurrTime;
        //MorningCallProc();
        }

    if (CurrTime-ServerCmdChkOldTime>10*60*1000)        //10분마다
        {
        ServerCmdChkOldTime=CurrTime;
        }

    if (CurrTime-SystemChkOldTime>3*60*1000)            //3분마다
        {
        SystemChkOldTime=CurrTime;
        }

    if (GetMostTopWindow()==NULL && GetEventQ(&PopupMsgQ, &Ev, TRUE)!=FALSE)
        {
        PostMessage(HwndMain, WM_COMMAND, Ev.Msg, Ev.lPrm);
        }

    STORAGE_AutoFlush(0, FALSE);
    ReceiveTargetUartProc();

    //if (JOSRunning==0)
        MonitorProc();
    }




//-----------------------------------------------------------------------------
//      Key 처리
//-----------------------------------------------------------------------------
BOOL WINAPI KeyProcHook(int Key)
    {
    BOOL  Rslt=FALSE;
    //DWORD Dw;
    int   FileNo;
    HFILE hFile;
    CHAR  Buff[16];

    Printf("Key=%d\r\n", Key);

    switch (Key)
        {
        case KC_TestDown:
            #if 0
            Dw=GetTickCount();
            Rslt=TestChangeReg(100000000);
            Printf("TestChangeReg()=%d (%ums)"CRLF, Rslt, GetTickCount()-Dw);

            Dw=GetTickCount();
            Rslt=TestChangeReg2(100000000);
            Printf("TestChangeReg2()=%d (%ums)"CRLF, Rslt, GetTickCount()-Dw);
            #endif

            for (FileNo=0; ;FileNo++)
                {
                wsprintf(Buff, "SCREEN%02d.BMP", FileNo);
                if ((hFile=_lopen(Buff, OF_READ))==HFILE_ERROR) break;
                _lclose(hFile);
                }
            if (LCD_CaptureScreen(Buff)) Printf("'%s' Save OK" CRLF, Buff);
            break;
        }
    return Rslt;
    }



BOOL WINAPI SDCARD_Read(LPBYTE Buff, DWORD BlockAddr, UINT BlockLen);
int WINAPI Mon_FuncTest(int PortNo, LPCSTR MonCmd, LPCSTR lpArg, LPCSTR CmdLine)
    {
    int Cmd=0, Delay=0;

    if (lpArg[0]=='?') return MONRSLT_EXIT;

    if (CompMemStrI(lpArg, "SD")==0)
        {
        static BYTE SctBuff[512];
        SDCARD_Read(SctBuff, AtoI(SkipSpace(lpArg+2), NULL), 1);
        DumpMem(SctBuff, 512);
        return MONRSLT_EXIT;
        }
    if (CompMemStrI(lpArg, "CREATE")==0)
        {
        HFILE hFile;

        lpArg=SkipSpace(lpArg+6);
        if ((hFile=_lcreat(lpArg[0]==0 ? "B:/KMP/Abcdefghijklmnopqrstuvwxyz.123":lpArg, 0))!=HFILE_ERROR)
            {
            Printf("File Create OK"CRLF);
            _lclose(hFile);
            }
        else Printf("File Create FAIL"CRLF);
        return MONRSLT_EXIT;
        }

    lpArg=ScanInt(lpArg, &Cmd);
    lpArg=ScanInt(lpArg, &Delay);
    if (Delay!=0) SWD_SetDelay(Delay);

    switch (Cmd)
        {
        case 0: ReadFlashTest("STM32L083xZ"); break;
        case 1: ReadFlashTest("STM32F091xC"); break;
        case 2: TargetFlash_ProgrammingFile(0x8000000, "STM32L083xZ", "B:/RT-400VT.BIN", NULL, NULL); break;
        case 3: TargetFlash_VerifyFile     (0x8000000, "STM32L083xZ", "B:/RT-400VT.BIN", NULL, NULL); break;
        case 4: TargetFlash_ProgrammingFile(0x8000000, "STM32F091xC", "B:/FRP423S.BIN", NULL, NULL); break;
        case 5: TargetFlash_VerifyFile     (0x8000000, "STM32F091xC", "B:/FRP423S.BIN", NULL, NULL); break;
        }
    return MONRSLT_OK;
    }




VOID WINAPI SetLedStatus(int State) {}

