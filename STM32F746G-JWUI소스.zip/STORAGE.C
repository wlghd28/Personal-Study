
#include "JLIB.H"
#include "N25Q128A.H"
#include "SD.H"

//LogUnitNo: Logical unit number (lun)
#define STORAGE_N25Q128A    0
#define STORAGE_SD          1
#define STORAGE_LUNQTY      1   //2����� �ϸ� USB-STORAGE���� �ν� ����


BOOL WINAPI STORAGE_Init(UINT Lun)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_Init():
            SDCARD_Init();
    }


BOOL WINAPI STORAGE_GetCapacity(UINT Lun, DWORD *lpBlockQty, UINT *lpBlockSize)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_GetCapacity(lpBlockQty, lpBlockSize):
            SDCARD_GetCapacity(lpBlockQty, lpBlockSize);
    }


BOOL WINAPI STORAGE_IsReady(UINT Lun)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_IsReady():
            SDCARD_IsReady();
    }


BOOL WINAPI STORAGE_Read(UINT Lun, LPBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_Read(Buff, BlockAddr, BlockLen):
            SDCARD_Read(Buff, BlockAddr, BlockLen);
    }


BOOL WINAPI STORAGE_Write(UINT Lun, LPCBYTE Buff, DWORD BlockAddr, UINT BlockLen)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_Write(Buff, BlockAddr, BlockLen):
            SDCARD_Write(Buff, BlockAddr, BlockLen);
    }



VOID WINAPI STORAGE_AutoFlush(UINT Lun, BOOL NowFlush)
    {
    if (Lun==STORAGE_N25Q128A) N25Q128A_AutoFlush(NowFlush);
    //SD�� ���ʿ�
    }



BOOL WINAPI STORAGE_IsWriteProtected(UINT Lun)
    {
    return (Lun==STORAGE_N25Q128A) ?
            N25Q128A_IsWriteProtected():
            SDCARD_IsWriteProtected();
    }


int  WINAPI STORAGE_GetMaxLun(VOID) {return STORAGE_LUNQTY-1;}







