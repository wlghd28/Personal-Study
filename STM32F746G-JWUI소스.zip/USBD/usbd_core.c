
#include "JLIB.H"
#include "usbd_core.h"


VOID USBD_CtlSendData(USBD_HandleTypeDef*USBD, LPBYTE Buff, UINT Len)
    {
    USBD->Ep0State=USBD_EP0_DATA_IN;
    USBD->EpIn[0].total_length=Len;
    USBD->EpIn[0].rem_length=Len;
    USBD_LL_Transmit(USBD, 0, Buff, Len);
    }



LOCAL(VOID) USBD_CtlContinueSendData(USBD_HandleTypeDef*USBD, LPBYTE Buff, UINT Len)
    {
    USBD_LL_Transmit(USBD, 0, Buff, Len);
    }



VOID USBD_CtlPrepareRx(USBD_HandleTypeDef*USBD, LPBYTE Buff, UINT Len)
    {
    USBD->Ep0State=USBD_EP0_DATA_OUT;
    USBD->EpOut[0].total_length=Len;
    USBD->EpOut[0].rem_length=Len;
    USBD_LL_PrepareReceive(USBD, 0, Buff, Len);
    }



LOCAL(VOID) USBD_CtlContinueRx(USBD_HandleTypeDef*USBD, LPBYTE Buff, UINT Len)
    {
    USBD_LL_PrepareReceive(USBD, 0, Buff, Len);
    }



LOCAL(VOID) USBD_CtlSendStatus(USBD_HandleTypeDef*USBD)
    {
    USBD->Ep0State=USBD_EP0_STATUS_IN;
    USBD_LL_Transmit(USBD, 0, NULL, 0);
    }



LOCAL(VOID) USBD_CtlReceiveStatus(USBD_HandleTypeDef*USBD)
    {
    USBD->Ep0State=USBD_EP0_STATUS_OUT;
    USBD_LL_PrepareReceive(USBD, 0, NULL, 0);
    }


#if 0
UINT USBD_GetRxCount(USBD_HandleTypeDef*USBD, UINT EpAddr)
    {
    return USBD_LL_GetRxDataSize(USBD, EpAddr);
    }
#endif



LOCAL(VOID) USBD_StdItfReq(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    USBD_StatusTypeDef Rslt;

    switch (Req->bmRequest&USB_REQ_TYPE_MASK)
        {
        case USB_REQ_TYPE_CLASS:
        case USB_REQ_TYPE_VENDOR:
        case USB_REQ_TYPE_STANDARD:
            switch (USBD->DevState)
                {
                case USBD_STATE_DEFAULT:
                case USBD_STATE_ADDRESSED:
                case USBD_STATE_CONFIGURED:
                    if (LoByte(Req->wIndex)<=USBD_MAX_NUM_INTERFACES)
                        {
                        Rslt=(USBD_StatusTypeDef)USBD->Class->Setup(USBD, Req);
                        if (Req->wLength==0 && Rslt==USBD_OK)
                            USBD_CtlSendStatus(USBD);
                        }
                    else
                        USBD_CtlError(USBD, Req);
                    break;

                default:
                    USBD_CtlError(USBD, Req);
                    //break;
                }
            break;

        default:
            USBD_CtlError(USBD, Req);
            //break;
        }
    }



LOCAL(VOID) USBD_StdEPReq(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    UINT EpAddr;
    USBD_EndpointTypeDef*pep;

    EpAddr=LoByte(Req->wIndex);
    switch (Req->bmRequest&USB_REQ_TYPE_MASK)
        {
        case USB_REQ_TYPE_CLASS:
        case USB_REQ_TYPE_VENDOR:
            USBD->Class->Setup(USBD, Req);
            break;

        case USB_REQ_TYPE_STANDARD:
            if ((Req->bmRequest&0x60)==0x20)
                {
                USBD->Class->Setup(USBD, Req);
                break;
                }

            switch (Req->bRequest)
                {
                case USB_REQ_SET_FEATURE:
                    switch (USBD->DevState)
                        {
                        case USBD_STATE_ADDRESSED:
                            if (EpAddr!=0 && EpAddr!=0x80)
                                {
                                USBD_LL_StallEP(USBD, EpAddr);
                                USBD_LL_StallEP(USBD, 0x80);
                                }
                            else
                                USBD_CtlError(USBD, Req);
                            break;

                        case USBD_STATE_CONFIGURED:
                            if (Req->wValue==USB_FEATURE_EP_HALT)
                                {
                                if (EpAddr!=0 && EpAddr!=0x80 && Req->wLength==0)
                                    USBD_LL_StallEP(USBD, EpAddr);
                                }
                            USBD_CtlSendStatus(USBD);
                            break;

                        default:
                            USBD_CtlError(USBD, Req);
                            //break;
                        }
                    break;

                case USB_REQ_CLEAR_FEATURE:
                    switch (USBD->DevState)
                        {
                        case USBD_STATE_ADDRESSED:
                            if ((EpAddr!=0) && (EpAddr!=0x80))
                                {
                                USBD_LL_StallEP(USBD, EpAddr);
                                USBD_LL_StallEP(USBD, 0x80);
                                }
                            else
                                USBD_CtlError(USBD, Req);
                            break;

                        case USBD_STATE_CONFIGURED:
                            if (Req->wValue==USB_FEATURE_EP_HALT)
                                {
                                if ((EpAddr&0x7F)!=0) USBD_LL_ClearStallEP(USBD, EpAddr);
                                USBD_CtlSendStatus(USBD);
                                }
                            break;

                        default:
                            USBD_CtlError(USBD, Req);
                            //break;
                        }
                    break;

                case USB_REQ_GET_STATUS:
                    switch (USBD->DevState)
                        {
                        case USBD_STATE_ADDRESSED:
                            if (EpAddr!=0 && EpAddr!=0x80)
                                {
                                USBD_CtlError(USBD, Req);
                                break;
                                }
                            pep=(EpAddr&0x80)==0x80 ? &USBD->EpIn[EpAddr&0x7F]:&USBD->EpOut[EpAddr&0x7F];
                            pep->status=0;

                            USBD_CtlSendData(USBD, (LPBYTE)&pep->status, 2);
                            break;

                        case USBD_STATE_CONFIGURED:
                            if ((EpAddr&0x80)==0x80)
                                {
                                if (USBD->EpIn[EpAddr&0x0F].is_used==0)
                                    {
                                    USBD_CtlError(USBD, Req);
                                    break;
                                    }
                                }
                            else{
                                if (USBD->EpOut[EpAddr&0x0F].is_used==0)
                                    {
                                    USBD_CtlError(USBD, Req);
                                    break;
                                    }
                                }

                            pep=(EpAddr&0x80)==0x80 ? &USBD->EpIn[EpAddr&0x7F]:&USBD->EpOut[EpAddr&0x7F];
                            if (EpAddr==0 || EpAddr==0x80)
                                pep->status=0;
                            else if (USBD_LL_IsStallEP(USBD, EpAddr))
                                pep->status=1;
                            else
                                pep->status=0;

                            USBD_CtlSendData(USBD, (LPBYTE)&pep->status, 2);
                            break;

                        default:
                            USBD_CtlError(USBD, Req);
                            //break;
                        }
                    break;

                default:
                    USBD_CtlError(USBD, Req);
                    //break;
                }
            break;

        default:
            USBD_CtlError(USBD, Req);
            //break;
        }
    }


LOCAL(VOID) USBD_GetDescriptor(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    UINT Len;
    LPBYTE Buff;

    switch (Req->wValue>>8)
        {
        #if (USBD_LPM_ENABLED == 1)
        case USB_DESC_TYPE_BOS:
            Buff=USBD->Desc->GetBOSDescriptor(USBD->DevSpeed, &Len);
            break;
        #endif

        case USB_DESC_TYPE_DEVICE:
            Buff=USBD->Desc->GetDeviceDescriptor(USBD->DevSpeed, &Len);
            break;

        case USB_DESC_TYPE_CONFIGURATION:
            if (USBD->DevSpeed==USBD_SPEED_HIGH)
                Buff=(LPBYTE)USBD->Class->GetHSConfigDescriptor(&Len);
            else
                Buff=(LPBYTE)USBD->Class->GetFSConfigDescriptor(&Len);

            Buff[1]=USB_DESC_TYPE_CONFIGURATION;
            break;

        case USB_DESC_TYPE_STRING:
            switch ((BYTE)Req->wValue)
                {
                case USBD_IDX_LANGID_STR:
                    Buff=USBD->Desc->GetLangIDStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                case USBD_IDX_MFC_STR:
                    Buff=USBD->Desc->GetManufacturerStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                case USBD_IDX_PRODUCT_STR:
                    Buff=USBD->Desc->GetProductStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                case USBD_IDX_SERIAL_STR:
                    Buff=USBD->Desc->GetSerialStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                case USBD_IDX_CONFIG_STR:
                    Buff=USBD->Desc->GetConfigurationStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                case USBD_IDX_INTERFACE_STR:
                    Buff=USBD->Desc->GetInterfaceStrDescriptor(USBD->DevSpeed, &Len);
                    break;

                default:
                    #if (USBD_SUPPORT_USER_STRING == 1)
                    Buff=USBD->Class->GetUsrStrDescriptor(USBD, (Req->wValue), &Len);
                    break;
                    #else
                    USBD_CtlError(USBD, Req);
                    return;
                    #endif
                }
            break;

        case USB_DESC_TYPE_DEVICE_QUALIFIER:
            if (USBD->DevSpeed==USBD_SPEED_HIGH)
                {
                Buff=(LPBYTE)USBD->Class->GetDeviceQualifierDescriptor(&Len);
                break;
                }
            USBD_CtlError(USBD, Req);
            return;

        case USB_DESC_TYPE_OTHER_SPEED_CONFIGURATION:
            if (USBD->DevSpeed==USBD_SPEED_HIGH)
                {
                Buff=(LPBYTE)USBD->Class->GetOtherSpeedConfigDescriptor(&Len);
                Buff[1]=USB_DESC_TYPE_OTHER_SPEED_CONFIGURATION;
                break;
                }
            USBD_CtlError(USBD, Req);
            return;

        default:
            USBD_CtlError(USBD, Req);
            return;
        }

    if (Len!=0 && Req->wLength!=0)
        {
        USBD_CtlSendData(USBD, Buff, GetMin(Len, Req->wLength));
        }

    if (Req->wLength==0)
        {
        USBD_CtlSendStatus(USBD);
        }
    }



LOCAL(VOID) USBD_SetAddress(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    UINT DevAddr;

    if (Req->wIndex==0 && Req->wLength==0 && Req->wValue<128)
        {
        DevAddr=Req->wValue&0x7F;

        if (USBD->DevState==USBD_STATE_CONFIGURED)
            {
            USBD_CtlError(USBD, Req);
            }
        else{
            USBD->DevAddress=DevAddr;
            USBD_LL_SetUSBAddress(USBD, DevAddr);
            USBD_CtlSendStatus(USBD);

            if (DevAddr!=0)
                USBD->DevState=USBD_STATE_ADDRESSED;
            else
                USBD->DevState=USBD_STATE_DEFAULT;
            }
        }
    else
        USBD_CtlError(USBD, Req);
    }



LOCAL(VOID) USBD_ClrClassConfig(USBD_HandleTypeDef*USBD, UINT cfgidx)
    {
    USBD->Class->DeInit(USBD, cfgidx);
    }



LOCAL(USBD_StatusTypeDef) USBD_SetClassConfig(USBD_HandleTypeDef*USBD, UINT cfgidx)
    {
    USBD_StatusTypeDef Rslt=USBD_FAIL;

    if (USBD->Class!=NULL)
        {
        if (USBD->Class->Init(USBD, cfgidx)==0) Rslt=USBD_OK;
        }
    return Rslt;
    }




LOCAL(VOID) USBD_SetConfig(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    static BYTE CfgIdx;

    CfgIdx=(BYTE)Req->wValue;

    if (CfgIdx>USBD_MAX_NUM_CONFIGURATION) USBD_CtlError(USBD, Req);
    else{
        switch (USBD->DevState)
            {
            case USBD_STATE_ADDRESSED:
                if (CfgIdx)
                    {
                    USBD->DevConfig=CfgIdx;
                    USBD->DevState=USBD_STATE_CONFIGURED;
                    if (USBD_SetClassConfig(USBD, CfgIdx)==USBD_FAIL)
                        {
                        USBD_CtlError(USBD, Req);
                        return;
                        }
                    }
                USBD_CtlSendStatus(USBD);
                break;

            case USBD_STATE_CONFIGURED:
                if (CfgIdx==0)
                    {
                    USBD->DevState=USBD_STATE_ADDRESSED;
                    USBD->DevConfig=CfgIdx;
                    USBD_ClrClassConfig(USBD, CfgIdx);
                    }
                else if (CfgIdx!=USBD->DevConfig)
                    {
                    USBD_ClrClassConfig(USBD, USBD->DevConfig);

                    USBD->DevConfig=CfgIdx;
                    if (USBD_SetClassConfig(USBD, CfgIdx)==USBD_FAIL)
                        {
                        USBD_CtlError(USBD, Req);
                        return;
                        }
                    }
                USBD_CtlSendStatus(USBD);
                break;

            default:
                USBD_CtlError(USBD, Req);
                USBD_ClrClassConfig(USBD, CfgIdx);
                //break;
            }
        }
    }



LOCAL(VOID) USBD_GetConfig(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    if (Req->wLength!=1) USBD_CtlError(USBD, Req);
    else{
        switch (USBD->DevState)
            {
            case USBD_STATE_DEFAULT:
            case USBD_STATE_ADDRESSED:
                USBD->DevDefaultConfig=0;
                USBD_CtlSendData(USBD, (LPBYTE)&USBD->DevDefaultConfig, 1);
                break;

            case USBD_STATE_CONFIGURED:
                USBD_CtlSendData(USBD, (LPBYTE)&USBD->DevConfig, 1);
                break;

            default:
                USBD_CtlError(USBD, Req);
                //break;
            }
        }
    }



LOCAL(VOID) USBD_GetStatus(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    switch (USBD->DevState)
        {
        case USBD_STATE_DEFAULT:
        case USBD_STATE_ADDRESSED:
        case USBD_STATE_CONFIGURED:
            if (Req->wLength!=2)
                {
                USBD_CtlError(USBD, Req);
                break;
                }

            #if ( USBD_SELF_POWERED == 1)
            USBD->DevConfigStatus=USB_CONFIG_SELF_POWERED;
            #else
            USBD->DevConfigStatus=0;
            #endif

            if (USBD->DevRemoteWakeup)
                {
                USBD->DevConfigStatus|=USB_CONFIG_REMOTE_WAKEUP;
                }

            USBD_CtlSendData(USBD, (LPBYTE)&USBD->DevConfigStatus, 2);
            break;

        default:
            USBD_CtlError(USBD, Req);
            //break;
        }
    }




LOCAL(VOID) USBD_SetFeature(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    if (Req->wValue==USB_FEATURE_REMOTE_WAKEUP)
        {
        USBD->DevRemoteWakeup=1;
        USBD_CtlSendStatus(USBD);
        }
    }




LOCAL(VOID) USBD_ClrFeature(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    switch (USBD->DevState)
        {
        case USBD_STATE_DEFAULT:
        case USBD_STATE_ADDRESSED:
        case USBD_STATE_CONFIGURED:
            if (Req->wValue==USB_FEATURE_REMOTE_WAKEUP)
                {
                USBD->DevRemoteWakeup=0;
                USBD_CtlSendStatus(USBD);
                }
            break;

        default:
            USBD_CtlError(USBD, Req);
            //break;
        }
    }




LOCAL(VOID) USBD_ParseSetupRequest(USBD_SetupReq*Req, LPBYTE lp)
    {
    Req->bmRequest=*(LPBYTE)lp;
    Req->bRequest=*(LPBYTE)(lp+1);
    Req->wValue=PeekW(lp+2);
    Req->wIndex=PeekW(lp+4);
    Req->wLength=PeekW(lp+6);
    }




VOID USBD_CtlError(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    USBD_LL_StallEP(USBD, 0x80);
    USBD_LL_StallEP(USBD, 0);
    }




LOCAL(VOID) USBD_StdDevReq(USBD_HandleTypeDef*USBD, USBD_SetupReq*Req)
    {
    switch (Req->bmRequest&USB_REQ_TYPE_MASK)
        {
        case USB_REQ_TYPE_CLASS:
        case USB_REQ_TYPE_VENDOR:
            USBD->Class->Setup(USBD, Req);
            break;

        case USB_REQ_TYPE_STANDARD:
            switch (Req->bRequest)
                {
                case USB_REQ_GET_DESCRIPTOR:    USBD_GetDescriptor(USBD, Req); break;
                case USB_REQ_SET_ADDRESS:       USBD_SetAddress(USBD, Req); break;
                case USB_REQ_SET_CONFIGURATION: USBD_SetConfig(USBD, Req); break;
                case USB_REQ_GET_CONFIGURATION: USBD_GetConfig(USBD, Req); break;
                case USB_REQ_GET_STATUS:        USBD_GetStatus(USBD, Req); break;
                case USB_REQ_SET_FEATURE:       USBD_SetFeature(USBD, Req); break;
                case USB_REQ_CLEAR_FEATURE:     USBD_ClrFeature(USBD, Req); break;
                default:                        USBD_CtlError(USBD, Req); //break;
                }
            break;

        default:
            USBD_CtlError(USBD, Req);
            //break;
        }
    }




///////////////////////////////////////////////////////////////////////////////
//                              usbd_core.c
///////////////////////////////////////////////////////////////////////////////



VOID USBD_Init(USBD_HandleTypeDef*USBD, USBD_DescriptorsTypeDef *Desc, UINT Id)
    {
    if (Desc!=NULL) USBD->Desc=Desc;
    USBD->Class=NULL;
    USBD->DevState=USBD_STATE_DEFAULT;
    USBD->Id=Id;
    USBD_LL_Init(USBD);
    }



VOID USBD_DeInit(USBD_HandleTypeDef*USBD)
    {
    USBD->DevState=USBD_STATE_DEFAULT;
    USBD->Class->DeInit(USBD, USBD->DevConfig);
    USBD_LL_Stop(USBD);
    USBD_LL_DeInit(USBD);
    }



VOID USBD_RegisterClass(USBD_HandleTypeDef*USBD, USBD_ClassTypeDef *Cls)
    {
    USBD->Class=Cls;
    }



VOID USBD_Start(USBD_HandleTypeDef*USBD)
    {
    USBD_LL_Start(USBD);
    }



VOID USBD_Stop(USBD_HandleTypeDef*USBD)
    {
    USBD->Class->DeInit(USBD, USBD->DevConfig);
    USBD_LL_Stop(USBD);
    }




USBD_StatusTypeDef USBD_LL_SetupStage(USBD_HandleTypeDef*USBD, LPBYTE psetup)
    {
    USBD_ParseSetupRequest(&USBD->Request, psetup);

    USBD->Ep0State=USBD_EP0_SETUP;
    USBD->Ep0DataLen=USBD->Request.wLength;

    switch (USBD->Request.bmRequest&0x1F)
        {
        case USB_REQ_RECIPIENT_DEVICE:
            USBD_StdDevReq(USBD, &USBD->Request);
            break;

        case USB_REQ_RECIPIENT_INTERFACE:
            USBD_StdItfReq(USBD, &USBD->Request);
            break;

        case USB_REQ_RECIPIENT_ENDPOINT:
            USBD_StdEPReq(USBD, &USBD->Request);
            break;

        default:
            USBD_LL_StallEP(USBD, USBD->Request.bmRequest&0x80);
            //break;
        }
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_DataOutStage(USBD_HandleTypeDef*USBD, UINT EpNo, LPBYTE pdata)
    {
    USBD_EndpointTypeDef *EP;

    if (EpNo==0)
        {
        EP=USBD->EpOut;

        if (USBD->Ep0State==USBD_EP0_DATA_OUT)
            {
            if (EP->rem_length>EP->maxpacket)
                {
                EP->rem_length-=EP->maxpacket;
                USBD_CtlContinueRx(USBD, pdata, GetMin(EP->rem_length, EP->maxpacket));
                }
            else{
                if (USBD->Class->EP0_RxReady!=NULL &&
                    USBD->DevState==USBD_STATE_CONFIGURED)
                    {
                    USBD->Class->EP0_RxReady(USBD);
                    }
                USBD_CtlSendStatus(USBD);
                }
            }
        else{
            if (USBD->Ep0State==USBD_EP0_STATUS_OUT)
                {
                USBD->Ep0State=USBD_EP0_IDLE;
                USBD_LL_StallEP(USBD, 0);
                }
            }
        }
    else if (USBD->Class->DataOut!=NULL && USBD->DevState==USBD_STATE_CONFIGURED)
        USBD->Class->DataOut(USBD, EpNo);
    else
        return USBD_FAIL;

    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_DataInStage(USBD_HandleTypeDef*USBD, UINT EpNo, LPBYTE pdata)
    {
    USBD_EndpointTypeDef*EP;

    if (EpNo==0)
        {
        EP=USBD->EpIn;

        if (USBD->Ep0State==USBD_EP0_DATA_IN)
            {
            if (EP->rem_length>EP->maxpacket)
                {
                EP->rem_length-=EP->maxpacket;

                USBD_CtlContinueSendData(USBD, pdata, EP->rem_length);
                USBD_LL_PrepareReceive(USBD, 0, NULL, 0);
                }
            else{
                if (EP->total_length%EP->maxpacket==0 &&
                    EP->total_length>=EP->maxpacket &&
                    EP->total_length<USBD->Ep0DataLen)
                    {
                    USBD_CtlContinueSendData(USBD, NULL, 0);
                    USBD->Ep0DataLen=0;
                    USBD_LL_PrepareReceive(USBD, 0, NULL, 0);
                    }
                else{
                    if (USBD->Class->EP0_TxSent!=NULL &&
                        USBD->DevState==USBD_STATE_CONFIGURED)
                        {
                        USBD->Class->EP0_TxSent(USBD);
                        }
                    USBD_LL_StallEP(USBD, 0x80);
                    USBD_CtlReceiveStatus(USBD);
                    }
                }
            }
        else{
            if (USBD->Ep0State==USBD_EP0_STATUS_IN ||
                USBD->Ep0State==USBD_EP0_IDLE)
                {
                USBD_LL_StallEP(USBD, 0x80);
                }
            }

        if (USBD->DevTestMode==1)
            {
            //USBD_RunTestMode(USBD);
            USBD->DevTestMode=0;
            }
        }
    else if (USBD->Class->DataIn!=NULL && USBD->DevState==USBD_STATE_CONFIGURED)
        USBD->Class->DataIn(USBD, EpNo);
    else
        return USBD_FAIL;

    return USBD_OK;
    }




VOID USBD_LL_Reset(USBD_HandleTypeDef*USBD)
    {
    USBD_LL_OpenEP(USBD, 0, USBD_EP_TYPE_CTRL, USB_MAX_EP0_SIZE);
    USBD->EpOut[0].is_used=1;
    USBD->EpOut[0].maxpacket=USB_MAX_EP0_SIZE;

    USBD_LL_OpenEP(USBD, 0x80, USBD_EP_TYPE_CTRL, USB_MAX_EP0_SIZE);
    USBD->EpIn[0x80&0x0F].is_used=1;

    USBD->EpIn[0].maxpacket=USB_MAX_EP0_SIZE;
    USBD->DevState=USBD_STATE_DEFAULT;
    USBD->Ep0State=USBD_EP0_IDLE;
    USBD->DevConfig=0;
    USBD->DevRemoteWakeup=0;
    if (USBD->ClassData) USBD->Class->DeInit(USBD, USBD->DevConfig);
    }



VOID USBD_LL_SetSpeed(USBD_HandleTypeDef*USBD, USBD_SpeedTypeDef Speed)
    {
    USBD->DevSpeed=Speed;
    }



VOID USBD_LL_Suspend(USBD_HandleTypeDef*USBD)
    {
    USBD->DevOldState=USBD->DevState;
    USBD->DevState=USBD_STATE_SUSPENDED;
    }




VOID USBD_LL_Resume(USBD_HandleTypeDef*USBD)
    {
    USBD->DevState=USBD->DevOldState;
    }




VOID USBD_LL_SOF(USBD_HandleTypeDef*USBD)
    {
    if (USBD->DevState==USBD_STATE_CONFIGURED && USBD->Class->SOF!=NULL)
        USBD->Class->SOF(USBD);
    }




VOID USBD_LL_DevDisconnected(USBD_HandleTypeDef*USBD)
    {
    USBD->DevState=USBD_STATE_DEFAULT;
    USBD->Class->DeInit(USBD, USBD->DevConfig);
    }



