///////////////////////////////////////////////////////////////////////////////
//                  PCD (Peripheral controller driver)
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"



///////////////////////////////////////////////////////////////////////////////
//                          STM32F7xx_ll_usb.c
///////////////////////////////////////////////////////////////////////////////


UINT USB_GetMode(USB_OTG_GlobalTypeDef*USBx)
    {
    return (USBx->GINTSTS) & 1;
    }


UINT USB_ReadInterrupts(USB_OTG_GlobalTypeDef*USBx)
    {
    return USBx->GINTSTS & USBx->GINTMSK;
    }


HAL_StatusTypeDef USB_EnableGlobalInt(USB_OTG_GlobalTypeDef*USBx)   //__HAL_PCD_ENABLE()
    {
    USBx->GAHBCFG|=USB_OTG_GAHBCFG_GINT;
    return HAL_OK;
    }


HAL_StatusTypeDef USB_DisableGlobalInt(USB_OTG_GlobalTypeDef*USBx)  //__HAL_PCD_DISABLE()
    {
    USBx->GAHBCFG&=~USB_OTG_GAHBCFG_GINT;
    return HAL_OK;
    }


UINT USB_ReadDevAllOutEpInterrupt(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT T;

    T=USBx_DEVICE->DAINT;
    T&=USBx_DEVICE->DAINTMSK;
    return T>>16;
    }



UINT USB_ReadDevAllInEpInterrupt(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT T;

    T=USBx_DEVICE->DAINT;
    T&=USBx_DEVICE->DAINTMSK;
    return (T&0xFFFF);
    }



//���̸�: USB_ReadDevOutEPInterrupt
LOCAL(UINT) USB_ReadDevOutEPIT(USB_OTG_GlobalTypeDef*USBx, UINT EpNo)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT T;

    T=USBx_OUTEP(EpNo)->DOEPINT;
    T&=USBx_DEVICE->DOEPMSK;
    return T;
    }



//���̸�: USB_ReadDevInEPInterrupt
LOCAL(UINT) USB_ReadDevInEPIT(USB_OTG_GlobalTypeDef*USBx, UINT EpNo)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT T, Msk, Emp;

    Msk=USBx_DEVICE->DIEPMSK;
    Emp=USBx_DEVICE->DIEPEMPMSK;
    Msk|=((Emp>>(EpNo&EP_ADDR_MSK))&1)<<7;
    T=USBx_INEP(EpNo)->DIEPINT&Msk;
    return T;
    }



HAL_StatusTypeDef USB_DevDisconnect(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;

    USBx_DEVICE->DCTL|=USB_OTG_DCTL_SDIS;
    HAL_Delay(3);
    return HAL_OK;
    }



HAL_StatusTypeDef USB_DevConnect(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;

    USBx_DEVICE->DCTL&=~USB_OTG_DCTL_SDIS;
    HAL_Delay(3);

    return HAL_OK;
    }



HAL_StatusTypeDef USB_DeActivateRemoteWakeup(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;

    USBx_DEVICE->DCTL&=~USB_OTG_DCTL_RWUSIG;
    return HAL_OK;
    }



HAL_StatusTypeDef USB_ActivateRemoteWakeup(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;

    if (USBx_DEVICE->DSTS & USB_OTG_DSTS_SUSPSTS)
        USBx_DEVICE->DCTL|=USB_OTG_DCTL_RWUSIG;
    return HAL_OK;
    }



HAL_StatusTypeDef USB_ActivateSetup(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;

    USBx_INEP(0)->DIEPCTL&=~USB_OTG_DIEPCTL_MPSIZ;
    USBx_DEVICE->DCTL|=USB_OTG_DCTL_CGINAK;
    return HAL_OK;
    }




LOCAL(UINT) USB_GetDevSpeed_(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT Speed=0xF, DevEnumSpeed=USBx_DEVICE->DSTS&USB_OTG_DSTS_ENUMSPD;

    if (DevEnumSpeed==DSTS_ENUMSPD_HS_PHY_30MHZ_OR_60MHZ) Speed=USBD_HS_SPEED;
    else if (DevEnumSpeed==DSTS_ENUMSPD_FS_PHY_30MHZ_OR_60MHZ ||
             DevEnumSpeed==DSTS_ENUMSPD_FS_PHY_48MHZ)     Speed=USBD_FS_SPEED;
    return Speed;
    }



HAL_StatusTypeDef USB_ActivateEndpoint(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;

    if (Ep->is_in==1)
        {
        USBx_DEVICE->DAINTMSK|=USB_OTG_DAINTMSK_IEPM & (1<<(Ep->num&EP_ADDR_MSK));

        if ((USBx_INEP(EpNo)->DIEPCTL & USB_OTG_DIEPCTL_USBAEP)==0)
            {
            USBx_INEP(EpNo)->DIEPCTL|=(Ep->maxpacket&USB_OTG_DIEPCTL_MPSIZ)|
                (Ep->type<<18)|(EpNo<<22)|
                USB_OTG_DIEPCTL_SD0PID_SEVNFRM|
                USB_OTG_DIEPCTL_USBAEP;
            }
        }
    else
        {
        USBx_DEVICE->DAINTMSK|=USB_OTG_DAINTMSK_OEPM & ((1<<(Ep->num&EP_ADDR_MSK))<<16);

        if (((USBx_OUTEP(EpNo)->DOEPCTL) & USB_OTG_DOEPCTL_USBAEP)==0)
            {
            USBx_OUTEP(EpNo)->DOEPCTL|=(Ep->maxpacket&USB_OTG_DOEPCTL_MPSIZ)|
                (Ep->type<<18)|
                USB_OTG_DIEPCTL_SD0PID_SEVNFRM|
                USB_OTG_DOEPCTL_USBAEP;
            }
        }
    return HAL_OK;
    }





HAL_StatusTypeDef USB_DeactivateEndpoint(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;

    if (Ep->is_in==1)
        {
        if (USBx_INEP(EpNo)->DIEPCTL & USB_OTG_DIEPCTL_EPENA)
            {
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SNAK;
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_EPDIS;
            }

        USBx_DEVICE->DEACHMSK&=~(USB_OTG_DAINTMSK_IEPM & (1<<(Ep->num&EP_ADDR_MSK)));
        USBx_DEVICE->DAINTMSK&=~(USB_OTG_DAINTMSK_IEPM & (1<<(Ep->num&EP_ADDR_MSK)));
        USBx_INEP(EpNo)->DIEPCTL&=~(USB_OTG_DIEPCTL_USBAEP|
                                    USB_OTG_DIEPCTL_MPSIZ|
                                    USB_OTG_DIEPCTL_TXFNUM|
                                    USB_OTG_DIEPCTL_SD0PID_SEVNFRM|
                                    USB_OTG_DIEPCTL_EPTYP);
        }
    else{
        if (USBx_OUTEP(EpNo)->DOEPCTL & USB_OTG_DOEPCTL_EPENA)
            {
            USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_SNAK;
            USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_EPDIS;
            }

        USBx_DEVICE->DEACHMSK&=~(USB_OTG_DAINTMSK_OEPM&((1<<(Ep->num&EP_ADDR_MSK))<<16));
        USBx_DEVICE->DAINTMSK&=~(USB_OTG_DAINTMSK_OEPM&((1<<(Ep->num&EP_ADDR_MSK))<<16));
        USBx_OUTEP(EpNo)->DOEPCTL&=~(USB_OTG_DOEPCTL_USBAEP|
                                    USB_OTG_DOEPCTL_MPSIZ|
                                    USB_OTG_DOEPCTL_SD0PID_SEVNFRM|
                                    USB_OTG_DOEPCTL_EPTYP);
        }
    return HAL_OK;
    }



//���̸�: USB_EP0_OutStart
LOCAL(HAL_StatusTypeDef) USB_Ep0OutStart(USB_OTG_GlobalTypeDef*USBx, UINT Dma, LPBYTE psetup)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT gSNPSiD=*(__IO UINT*)(&USBx->CID+1);

    if (gSNPSiD>USB_OTG_CORE_ID_300A)
        {
        if (USBx_OUTEP(0)->DOEPCTL & USB_OTG_DOEPCTL_EPENA) return HAL_OK;
        }

    USBx_OUTEP(0)->DOEPTSIZ=0;
    USBx_OUTEP(0)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_PKTCNT & (1<<19);
    USBx_OUTEP(0)->DOEPTSIZ|=3*8;
    USBx_OUTEP(0)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_STUPCNT;

    if (Dma==1)
        {
        USBx_OUTEP(0)->DOEPDMA=(UINT)psetup;
        USBx_OUTEP(0)->DOEPCTL|=USB_OTG_DOEPCTL_EPENA|USB_OTG_DOEPCTL_USBAEP;
        }

    return HAL_OK;
    }



//���̸�: USB_WritePacket
LOCAL(HAL_StatusTypeDef) USB_WritePkt(USB_OTG_GlobalTypeDef*USBx, LPBYTE src, UINT EpNo, UINT Len, UINT Dma)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT*pSrc=(UINT*)src;
    UINT I, J;

    if (Dma==0)
        {
        J=(Len+3)/4;
        for (I=0; I<J; I++)
            {
            USBx_DFIFO(EpNo)=__UNALIGNED_UINT32_READ(pSrc);
            pSrc++;
            }
        }

    return HAL_OK;
    }



//���̸�: USB_ReadPacket
LOCAL(LPVOID) USB_ReadPkt(USB_OTG_GlobalTypeDef*USBx, LPBYTE dest, UINT Len)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT*pDest=(UINT*)dest;
    UINT I, J=(Len+3)/4;

    for (I=0; I<J; I++)
        {
        __UNALIGNED_UINT32_WRITE(pDest, USBx_DFIFO(0));
        pDest++;
        }

    return (LPVOID)pDest;
    }



HAL_StatusTypeDef USB_EPSetStall(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;

    if (Ep->is_in==1)
        {
        if ((USBx_INEP(EpNo)->DIEPCTL&USB_OTG_DIEPCTL_EPENA)==0 && EpNo!=0)
            {
            USBx_INEP(EpNo)->DIEPCTL&=~USB_OTG_DIEPCTL_EPDIS;
            }
        USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_STALL;
        }
    else{
        if ((USBx_OUTEP(EpNo)->DOEPCTL&USB_OTG_DOEPCTL_EPENA)==0 && EpNo!=0)
            {
            USBx_OUTEP(EpNo)->DOEPCTL&=~USB_OTG_DOEPCTL_EPDIS;
            }
        USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_STALL;
        }

    return HAL_OK;
    }



HAL_StatusTypeDef USB_EPClearStall(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;

    if (Ep->is_in==1)
        {
        USBx_INEP(EpNo)->DIEPCTL&=~USB_OTG_DIEPCTL_STALL;
        if (Ep->type==EP_TYPE_INTR || Ep->type==EP_TYPE_BULK)
            {
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SD0PID_SEVNFRM;
            }
        }
    else{
        USBx_OUTEP(EpNo)->DOEPCTL&=~USB_OTG_DOEPCTL_STALL;
        if (Ep->type==EP_TYPE_INTR || Ep->type==EP_TYPE_BULK)
            {
            USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_SD0PID_SEVNFRM;
            }
        }
    return HAL_OK;
    }



//���̸�: USB_EP0StartXfer
LOCAL(HAL_StatusTypeDef) USB_Ep0StartXfer(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep, UINT Dma)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;

    if (Ep->is_in==1)
        {
        if (Ep->xfer_len==0)
            {
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_PKTCNT;
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_PKTCNT&(1<<19);
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_XFRSIZ;
            }
        else{
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_XFRSIZ;
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_PKTCNT;

            if (Ep->xfer_len>Ep->maxpacket) Ep->xfer_len=Ep->maxpacket;
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_PKTCNT & (1<<19);
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_XFRSIZ & Ep->xfer_len;
            }

        if (Dma==1)
            {
            if (Ep->dma_addr!=0) USBx_INEP(EpNo)->DIEPDMA=Ep->dma_addr;
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_CNAK|USB_OTG_DIEPCTL_EPENA;
            }
        else{
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_CNAK|USB_OTG_DIEPCTL_EPENA;
            if (Ep->xfer_len>0) USBx_DEVICE->DIEPEMPMSK|=1<<(Ep->num&EP_ADDR_MSK);
            }
        }
    else{
        USBx_OUTEP(EpNo)->DOEPTSIZ&=~USB_OTG_DOEPTSIZ_XFRSIZ;
        USBx_OUTEP(EpNo)->DOEPTSIZ&=~USB_OTG_DOEPTSIZ_PKTCNT;

        if (Ep->xfer_len>0) Ep->xfer_len=Ep->maxpacket;

        USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_PKTCNT & (1<<19);
        USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_XFRSIZ & Ep->maxpacket;

        if (Dma==1)
            {
            if (Ep->xfer_buff!=NULL) USBx_OUTEP(EpNo)->DOEPDMA=(UINT)Ep->xfer_buff;
            }
        USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_CNAK|USB_OTG_DOEPCTL_EPENA;
        }

    return HAL_OK;
    }



//���̸�: USB_EPStartXfer
LOCAL(HAL_StatusTypeDef) USB_EpStartXfer(USB_OTG_GlobalTypeDef*USBx, USB_OTG_EPTypeDef*Ep, UINT Dma)
    {
    UINT USBx_BASE=(UINT)USBx;
    UINT EpNo=Ep->num;
    UINT pktcnt;

    if (Ep->is_in==1)
        {
        if (Ep->xfer_len==0)
            {
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_PKTCNT;
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_PKTCNT & (1<<19);
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_XFRSIZ;
            }
        else{
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_XFRSIZ;
            USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_PKTCNT;
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_PKTCNT & (((Ep->xfer_len+Ep->maxpacket-1)/Ep->maxpacket)<<19);
            USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_XFRSIZ & Ep->xfer_len;

            if (Ep->type==EP_TYPE_ISOC)
                {
                USBx_INEP(EpNo)->DIEPTSIZ&=~USB_OTG_DIEPTSIZ_MULCNT;
                USBx_INEP(EpNo)->DIEPTSIZ|=USB_OTG_DIEPTSIZ_MULCNT & (1<<29);
                }
            }

        if (Dma==1)
            {
            if (Ep->dma_addr!=0) USBx_INEP(EpNo)->DIEPDMA=Ep->dma_addr;

            if (Ep->type==EP_TYPE_ISOC)
                {
                if ((USBx_DEVICE->DSTS & (1<<8))==0)
                    USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SODDFRM;
                else
                    USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SD0PID_SEVNFRM;
                }

            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_CNAK|USB_OTG_DIEPCTL_EPENA;
            }
        else{
            USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_CNAK|USB_OTG_DIEPCTL_EPENA;

            if (Ep->type!=EP_TYPE_ISOC)
                {
                if (Ep->xfer_len>0)
                    USBx_DEVICE->DIEPEMPMSK|=1<<(Ep->num&EP_ADDR_MSK);
                }
            else{
                if ((USBx_DEVICE->DSTS&(1<<8))==0)
                    USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SODDFRM;
                else
                    USBx_INEP(EpNo)->DIEPCTL|=USB_OTG_DIEPCTL_SD0PID_SEVNFRM;

                USB_WritePkt(USBx, Ep->xfer_buff, Ep->num, Ep->xfer_len, Dma);
                }
            }
        }
    else{
        USBx_OUTEP(EpNo)->DOEPTSIZ&=~USB_OTG_DOEPTSIZ_XFRSIZ;
        USBx_OUTEP(EpNo)->DOEPTSIZ&=~USB_OTG_DOEPTSIZ_PKTCNT;

        if (Ep->xfer_len==0)
            {
            USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_XFRSIZ & Ep->maxpacket;
            USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_PKTCNT & (1<<19);
            }
        else{
            pktcnt=(Ep->xfer_len+Ep->maxpacket-1)/Ep->maxpacket;
            USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_PKTCNT & (pktcnt<<19);
            USBx_OUTEP(EpNo)->DOEPTSIZ|=USB_OTG_DOEPTSIZ_XFRSIZ & (Ep->maxpacket*pktcnt);
            }

        if (Dma==1)
            {
            if (Ep->xfer_buff!=NULL) USBx_OUTEP(EpNo)->DOEPDMA=(UINT)Ep->xfer_buff;
            }

        if (Ep->type==EP_TYPE_ISOC)
            {
            if ((USBx_DEVICE->DSTS&(1<<8))==0)
                USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_SODDFRM;
            else
                USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_SD0PID_SEVNFRM;
            }
        USBx_OUTEP(EpNo)->DOEPCTL|=USB_OTG_DOEPCTL_CNAK|USB_OTG_DOEPCTL_EPENA;
        }

    return HAL_OK;
    }





LOCAL(HAL_StatusTypeDef) USB_CoreReset(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT Cnt=0;

    do  {
        if (++Cnt>200000) return HAL_TIMEOUT;
        } while ((USBx->GRSTCTL&USB_OTG_GRSTCTL_AHBIDL)==0);

    Cnt=0;
    USBx->GRSTCTL|=USB_OTG_GRSTCTL_CSRST;

    do  {
        if (++Cnt>200000) return HAL_TIMEOUT;
        } while (USBx->GRSTCTL & USB_OTG_GRSTCTL_CSRST);

    return HAL_OK;
    }





HAL_StatusTypeDef USB_CoreInit(USB_OTG_GlobalTypeDef*USBx, USB_OTG_CfgTypeDef cfg)
    {
    HAL_StatusTypeDef ret;

    if (cfg.phy_itface==USB_OTG_ULPI_PHY)
        {
        USBx->GCCFG&=~USB_OTG_GCCFG_PWRDWN;
        USBx->GUSBCFG&=~(USB_OTG_GUSBCFG_TSDPS|USB_OTG_GUSBCFG_ULPIFSLS|USB_OTG_GUSBCFG_PHYSEL);
        #if defined(STM32F722xx) || defined(STM32F723xx) || defined(STM32F730xx) || defined(STM32F732xx) || defined(STM32F733xx)
        USBx->GUSBCFG|=USB_OTG_GUSBCFG_ULPI_UTMI_SEL;
        #endif
        USBx->GUSBCFG&=~(USB_OTG_GUSBCFG_ULPIEVBUSD|USB_OTG_GUSBCFG_ULPIEVBUSI);
        if (cfg.use_external_vbus==1) USBx->GUSBCFG|=USB_OTG_GUSBCFG_ULPIEVBUSD;
        ret=USB_CoreReset(USBx);
        }
    #ifdef USB_HS_PHYC
    else if (cfg.phy_itface==USB_OTG_HS_EMBEDDED_PHY)
        {
        USBx->GCCFG&=~USB_OTG_GCCFG_PWRDWN;
        USBx->GUSBCFG&=~(USB_OTG_GUSBCFG_TSDPS|USB_OTG_GUSBCFG_ULPIFSLS|USB_OTG_GUSBCFG_PHYSEL);
        USBx->GUSBCFG&=~(USB_OTG_GUSBCFG_ULPIEVBUSD|USB_OTG_GUSBCFG_ULPIEVBUSI);
        USBx->GUSBCFG&=~USB_OTG_GUSBCFG_ULPI_UTMI_SEL;
        USBx->GCCFG|=USB_OTG_GCCFG_PHYHSEN;

        if (USB_HS_PHYCInit(USBx)!=HAL_OK) return HAL_ERROR;
        if (cfg.use_external_vbus==1) USBx->GUSBCFG|=USB_OTG_GUSBCFG_ULPIEVBUSD;
        ret=USB_CoreReset(USBx);
        }
    #endif
    else{
        USBx->GUSBCFG|=USB_OTG_GUSBCFG_PHYSEL;
        ret=USB_CoreReset(USBx);
        USBx->GCCFG|=USB_OTG_GCCFG_PWRDWN;
        }

    if (cfg.dma_enable==1)
        {
        USBx->GAHBCFG|=USB_OTG_GAHBCFG_HBSTLEN_2;
        USBx->GAHBCFG|=USB_OTG_GAHBCFG_DMAEN;
        }
    return ret;
    }




HAL_StatusTypeDef USB_FlushRxFifo(USB_OTG_GlobalTypeDef*USBx)
    {
    UINT Cnt=0;

    USBx->GRSTCTL=USB_OTG_GRSTCTL_RXFFLSH;

    do  {
        if (++Cnt>200000) return HAL_TIMEOUT;
        } while (USBx->GRSTCTL & USB_OTG_GRSTCTL_RXFFLSH);

    return HAL_OK;
    }




HAL_StatusTypeDef USB_FlushTxFifo(USB_OTG_GlobalTypeDef*USBx, UINT num)
    {
    UINT Cnt=0;

    USBx->GRSTCTL=USB_OTG_GRSTCTL_TXFFLSH|(num<<6);

    do  {
        if (++Cnt>200000) return HAL_TIMEOUT;
        } while (USBx->GRSTCTL & USB_OTG_GRSTCTL_TXFFLSH);

    return HAL_OK;
    }




LOCAL(VOID) USB_SetDevSpeed_(USB_OTG_GlobalTypeDef*USBx, UINT Speed)
    {
    UINT USBx_BASE=(UINT)USBx;
    USBx_DEVICE->DCFG|=Speed;
    }



//���̸�: USB_SetDevAddress
HAL_StatusTypeDef USB_SetDevAddr(USB_OTG_GlobalTypeDef*USBx, UINT Addr)
    {
    UINT USBx_BASE=(UINT)USBx;

    USBx_DEVICE->DCFG&=~USB_OTG_DCFG_DAD;
    USBx_DEVICE->DCFG|=(Addr<<4) & USB_OTG_DCFG_DAD;
    return HAL_OK;
    }


//���̸�:USB_SetTurnaroundTime
HAL_StatusTypeDef USB_SetTurnAroundTime(USB_OTG_GlobalTypeDef*USBx, UINT hclk, UINT Speed)
    {
    UINT UsbTrd=6;

    if (Speed==USBD_FS_SPEED)
        {
        if      (hclk<14200000) UsbTrd=6;
        else if (hclk<15000000) UsbTrd=15;
        else if (hclk<16000000) UsbTrd=14;
        else if (hclk<17200000) UsbTrd=13;
        else if (hclk<18500000) UsbTrd=12;
        else if (hclk<20000000) UsbTrd=11;
        else if (hclk<21800000) UsbTrd=10;
        else if (hclk<24000000) UsbTrd=9;
        else if (hclk<27700000) UsbTrd=8;
        else if (hclk<32000000) UsbTrd=7;
        }
    else if (Speed==USBD_HS_SPEED)
        UsbTrd=USBD_HS_TRDT_VALUE;
    else
        UsbTrd=USBD_DEFAULT_TRDT_VALUE;

    USBx->GUSBCFG&=~USB_OTG_GUSBCFG_TRDT;
    USBx->GUSBCFG|=(UsbTrd<<10) & USB_OTG_GUSBCFG_TRDT;
    return HAL_OK;
    }



HAL_StatusTypeDef USB_SetCurrentMode(USB_OTG_GlobalTypeDef*USBx, USB_OTG_ModeTypeDef mode)
    {
    USBx->GUSBCFG&=~(USB_OTG_GUSBCFG_FHMOD|USB_OTG_GUSBCFG_FDMOD);

    if (mode==USB_HOST_MODE) USBx->GUSBCFG|=USB_OTG_GUSBCFG_FHMOD;
    else if (mode==USB_DEVICE_MODE) USBx->GUSBCFG|=USB_OTG_GUSBCFG_FDMOD;
    else return HAL_ERROR;

    HAL_Delay(50);
    return HAL_OK;
    }



HAL_StatusTypeDef USB_DevInit(USB_OTG_GlobalTypeDef*USBx, USB_OTG_CfgTypeDef cfg)
    {
    HAL_StatusTypeDef ret=HAL_OK;
    UINT USBx_BASE=(UINT)USBx;
    UINT I;

    for (I=0; I<15; I++) USBx->DIEPTXF[I]=0;

    if (cfg.vbus_sensing_enable==0)
        {
        USBx_DEVICE->DCTL|=USB_OTG_DCTL_SDIS;
        USBx->GCCFG&=~USB_OTG_GCCFG_VBDEN;
        USBx->GOTGCTL|=USB_OTG_GOTGCTL_BVALOEN;
        USBx->GOTGCTL|=USB_OTG_GOTGCTL_BVALOVAL;
        }
    else USBx->GCCFG|=USB_OTG_GCCFG_VBDEN;

    USBx_PCGCCTL=0;

    USBx_DEVICE->DCFG|=DCFG_FRAME_INTERVAL_80;

    if (cfg.phy_itface==USB_OTG_ULPI_PHY ||
        cfg.phy_itface==USB_OTG_HS_EMBEDDED_PHY)
        {
        USB_SetDevSpeed_(USBx, cfg.speed==USBD_HS_SPEED ? USB_OTG_SPEED_HIGH:USB_OTG_SPEED_HIGH_IN_FULL);
        }
    else USB_SetDevSpeed_(USBx, USB_OTG_SPEED_FULL);


    if (USB_FlushTxFifo(USBx, 0x10)!=HAL_OK) ret=HAL_ERROR;
    if (USB_FlushRxFifo(USBx)!=HAL_OK) ret=HAL_ERROR;


    USBx_DEVICE->DIEPMSK=0;
    USBx_DEVICE->DOEPMSK=0;
    USBx_DEVICE->DAINTMSK=0;

    for (I=0; I<cfg.dev_endpoints; I++)
        {
        if (USBx_INEP(I)->DIEPCTL & USB_OTG_DIEPCTL_EPENA)
            {
            if (I==0)
                USBx_INEP(I)->DIEPCTL=USB_OTG_DIEPCTL_SNAK;
            else
                USBx_INEP(I)->DIEPCTL=USB_OTG_DIEPCTL_EPDIS|USB_OTG_DIEPCTL_SNAK;
            }
        else USBx_INEP(I)->DIEPCTL=0;

        USBx_INEP(I)->DIEPTSIZ=0;
        USBx_INEP(I)->DIEPINT=0xFB7F;
        }

    for (I=0; I<cfg.dev_endpoints; I++)
        {
        if (USBx_OUTEP(I)->DOEPCTL & USB_OTG_DOEPCTL_EPENA)
            {
            if (I==0)
                USBx_OUTEP(I)->DOEPCTL=USB_OTG_DOEPCTL_SNAK;
            else
                USBx_OUTEP(I)->DOEPCTL=USB_OTG_DOEPCTL_EPDIS|USB_OTG_DOEPCTL_SNAK;
            }
        else USBx_OUTEP(I)->DOEPCTL=0;

        USBx_OUTEP(I)->DOEPTSIZ=0;
        USBx_OUTEP(I)->DOEPINT=0xFB7F;
        }

    USBx_DEVICE->DIEPMSK&=~USB_OTG_DIEPMSK_TXFURM;
    USBx->GINTMSK=0;
    USBx->GINTSTS=0xBFFFFFFF;

    if (cfg.dma_enable==0) USBx->GINTMSK|=USB_OTG_GINTMSK_RXFLVLM;

    USBx->GINTMSK|=USB_OTG_GINTMSK_USBSUSPM|USB_OTG_GINTMSK_USBRST|
        USB_OTG_GINTMSK_ENUMDNEM|USB_OTG_GINTMSK_IEPINT|
        USB_OTG_GINTMSK_OEPINT|USB_OTG_GINTMSK_IISOIXFRM|
        USB_OTG_GINTMSK_PXFRM_IISOOXFRM|USB_OTG_GINTMSK_WUIM;

    if (cfg.Sof_enable!=0) USBx->GINTMSK|=USB_OTG_GINTMSK_SOFM;
    if (cfg.vbus_sensing_enable==1) USBx->GINTMSK|=USB_OTG_GINTMSK_SRQIM|USB_OTG_GINTMSK_OTGINT;
    return ret;
    }




HAL_StatusTypeDef USB_StopDevice(USB_OTG_GlobalTypeDef*USBx)
    {
    HAL_StatusTypeDef ret;
    UINT USBx_BASE=(UINT)USBx;
    UINT I;

    for (I=0; I<15; I++)
        {
        USBx_INEP(I)->DIEPINT=0xFB7F;
        USBx_OUTEP(I)->DOEPINT=0xFB7F;
        }

    USBx_DEVICE->DIEPMSK=0;
    USBx_DEVICE->DOEPMSK=0;
    USBx_DEVICE->DAINTMSK=0;

    ret=USB_FlushRxFifo(USBx);
    if (ret!=HAL_OK) return ret;

    ret=USB_FlushTxFifo(USBx, 0x10);
    if (ret!=HAL_OK) return ret;

    return ret;
    }




///////////////////////////////////////////////////////////////////////////////
//                          STM32F7xx_hal_pcd_ex.c
///////////////////////////////////////////////////////////////////////////////



//���̸�: HAL_PCDEx_SetTxFiFo
VOID WINAPI PCDEx_SetTxFiFo(PCD_TypeDef *PcdInst, UINT Fifo, UINT Size)
    {
    UINT I, TxOffset;

    TxOffset=PcdInst->GRXFSIZ;
    if (Fifo==0)
        {
        PcdInst->DIEPTXF0_HNPTXFSIZ=(Size<<16)|TxOffset;
        }
    else{
        TxOffset+=(PcdInst->DIEPTXF0_HNPTXFSIZ)>>16;
        for (I=0; I<Fifo-1; I++) TxOffset+=(PcdInst->DIEPTXF[I]>>16);
        PcdInst->DIEPTXF[Fifo-1]=(Size<<16)|TxOffset;
        }
    }



//���̸�: HAL_PCDEx_SetRxFiFo
VOID WINAPI PCDEx_SetRxFiFo(PCD_TypeDef *PcdInst, UINT Size)
    {
    PcdInst->GRXFSIZ=Size;
    }



///////////////////////////////////////////////////////////////////////////////
//                          STM32F7xx_hal_pcd_ex.c
///////////////////////////////////////////////////////////////////////////////
#ifdef HAL_PCD_MODULE_ENABLED



LOCAL(VOID) HAL_PCD_DataOutStageCB(PCD_HandleTypeDef *hPcd, UINT EpNo);
LOCAL(VOID) HAL_PCD_DataInStageCB(PCD_HandleTypeDef *hPcd, UINT EpNo);
LOCAL(VOID) HAL_PCD_ISOOUTIncompleteCB(PCD_HandleTypeDef *hPcd, UINT EpNo);
LOCAL(VOID) HAL_PCD_ISOINIncompleteCB(PCD_HandleTypeDef *hPcd, UINT EpNo);
__weak VOID HAL_PCDEx_LPM_Callback(PCD_HandleTypeDef *hPcd, PCD_LPM_MsgTypeDef msg) {}
__weak VOID HAL_PCD_MspInit(PCD_HandleTypeDef *hPcd) {}
__weak VOID HAL_PCD_MspDeInit(PCD_HandleTypeDef *hPcd) {}




HAL_StatusTypeDef HAL_PCDEx_ActivateLPM(PCD_HandleTypeDef *hPcd)
    {
    USB_OTG_GlobalTypeDef*USBx=hPcd->Instance;

    hPcd->lpm_active=1;
    hPcd->LPM_State=LPM_L0;
    USBx->GINTMSK|=USB_OTG_GINTMSK_LPMINTM;
    USBx->GLPMCFG|=USB_OTG_GLPMCFG_LPMEN|USB_OTG_GLPMCFG_LPMACK|USB_OTG_GLPMCFG_ENBESL;
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_PCDEx_DeActivateLPM(PCD_HandleTypeDef *hPcd)
    {
    USB_OTG_GlobalTypeDef*USBx=hPcd->Instance;

    hPcd->lpm_active=0;
    USBx->GINTMSK&=~USB_OTG_GINTMSK_LPMINTM;
    USBx->GLPMCFG&=~(USB_OTG_GLPMCFG_LPMEN|USB_OTG_GLPMCFG_LPMACK|USB_OTG_GLPMCFG_ENBESL);
    return HAL_OK;
    }




HAL_StatusTypeDef HAL_PCD_ActivateRemoteWakeup(PCD_HandleTypeDef *hPcd)
    {
    return USB_ActivateRemoteWakeup(hPcd->Instance);
    }


HAL_StatusTypeDef HAL_PCD_DeActivateRemoteWakeup(PCD_HandleTypeDef *hPcd)
    {
    return USB_DeActivateRemoteWakeup(hPcd->Instance);
    }



//���̸�: HAL_PCD_EP_GetRxCount
LOCAL(UINT) PCD_EP_GetRxCount(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    return hPcd->OUT_ep[EpNo&EP_ADDR_MSK].xfer_count;
    }



//���̸�: HAL_PCD_EP_Open
LOCAL(HAL_StatusTypeDef) PCD_EP_Open(PCD_HandleTypeDef *hPcd, UINT EpNo, UINT EpMps, UINT EpType)
    {
    HAL_StatusTypeDef ret=HAL_OK;
    PCD_EPTypeDef*Ep;

    if (EpNo & 0x80)
        {
        Ep=&hPcd->IN_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=1;
        }
    else{
        Ep=&hPcd->OUT_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=0;
        }

    Ep->num=EpNo&EP_ADDR_MSK;
    Ep->maxpacket=EpMps;
    Ep->type=EpType;

    if (Ep->is_in!=0) Ep->tx_fifo_num=Ep->num;
    if (EpType==EP_TYPE_BULK) Ep->data_pid_start=0;

    __HAL_LOCK(hPcd);
    USB_ActivateEndpoint(hPcd->Instance, Ep);
    __HAL_UNLOCK(hPcd);

    return ret;
    }




HAL_StatusTypeDef HAL_PCD_Start(PCD_HandleTypeDef *hPcd)
    {
    __HAL_LOCK(hPcd);
    USB_DevConnect(hPcd->Instance);
    USB_EnableGlobalInt(hPcd->Instance);
    __HAL_UNLOCK(hPcd);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_PCD_Stop(PCD_HandleTypeDef *hPcd)
    {
    HAL_StatusTypeDef Rslt;
    USB_OTG_GlobalTypeDef *USBx;

    __HAL_LOCK(hPcd);
    USBx=hPcd->Instance;
    USB_DisableGlobalInt(USBx);
    if ((Rslt=USB_StopDevice(USBx))==HAL_OK) USB_DevDisconnect(USBx);
    __HAL_UNLOCK(hPcd);
    return Rslt;
    }



//���̸�: HAL_PCD_SetAddress
LOCAL(HAL_StatusTypeDef) PCD_SetAddress(PCD_HandleTypeDef *hPcd, UINT address)
    {
    __HAL_LOCK(hPcd);
    hPcd->USB_Address=address;
    USB_SetDevAddr(hPcd->Instance, address);
    __HAL_UNLOCK(hPcd);
    return HAL_OK;
    }


//���̸�: HAL_PCD_EP_Transmit
LOCAL(VOID) PCD_EP_Transmit(PCD_HandleTypeDef *hPcd, UINT EpNo, LPBYTE Buff, UINT Len)
    {
    PCD_EPTypeDef*Ep;

    Ep=&hPcd->IN_ep[EpNo&EP_ADDR_MSK];

    Ep->xfer_buff=Buff;
    Ep->xfer_len=Len;
    Ep->xfer_count=0;
    Ep->is_in=1;
    Ep->num=EpNo&EP_ADDR_MSK;

    if (hPcd->Init.dma_enable==1) Ep->dma_addr=(UINT)Buff;

    if ((EpNo&EP_ADDR_MSK)==0)
        USB_Ep0StartXfer(hPcd->Instance, Ep, hPcd->Init.dma_enable);
    else
        USB_EpStartXfer(hPcd->Instance, Ep, hPcd->Init.dma_enable);
    }



//���̸�: HAL_PCD_EP_SetStall
LOCAL(HAL_StatusTypeDef) PCD_EP_SetStall(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    PCD_EPTypeDef*Ep;

    if ((EpNo&EP_ADDR_MSK)>hPcd->Init.dev_endpoints) return HAL_ERROR;

    if (EpNo & 0x80)
        {
        Ep=&hPcd->IN_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=1;
        }
    else{
        Ep=&hPcd->OUT_ep[EpNo];
        Ep->is_in=0;
        }

    Ep->is_stall=1;
    Ep->num=EpNo&EP_ADDR_MSK;

    __HAL_LOCK(hPcd);

    USB_EPSetStall(hPcd->Instance, Ep);
    if ((EpNo & EP_ADDR_MSK)==0) USB_Ep0OutStart(hPcd->Instance, hPcd->Init.dma_enable, (LPBYTE)hPcd->Setup);

    __HAL_UNLOCK(hPcd);
    return HAL_OK;
    }




//���̸�: HAL_PCD_EP_Receive
LOCAL(VOID) PCD_EP_Receive(PCD_HandleTypeDef *hPcd, UINT EpNo, LPBYTE Buff, UINT Len)
    {
    PCD_EPTypeDef *Ep;

    Ep=&hPcd->OUT_ep[EpNo&EP_ADDR_MSK];

    Ep->xfer_buff=Buff;
    Ep->xfer_len=Len;
    Ep->xfer_count=0;
    Ep->is_in=0;
    Ep->num=EpNo&EP_ADDR_MSK;

    if (hPcd->Init.dma_enable==1) Ep->dma_addr=(UINT)Buff;

    if ((EpNo&EP_ADDR_MSK)==0)
        USB_Ep0StartXfer(hPcd->Instance, Ep, hPcd->Init.dma_enable);
    else
        USB_EpStartXfer(hPcd->Instance, Ep, hPcd->Init.dma_enable);
    }



//���̸�:HAL_PCD_EP_Close
LOCAL(HAL_StatusTypeDef) PCD_EP_Close(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    PCD_EPTypeDef*Ep;

    if (EpNo & 0x80)
        {
        Ep=&hPcd->IN_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=1;
        }
    else{
        Ep=&hPcd->OUT_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=0;
        }
    Ep->num=EpNo&EP_ADDR_MSK;

    __HAL_LOCK(hPcd);
    USB_DeactivateEndpoint(hPcd->Instance, Ep);
    __HAL_UNLOCK(hPcd);
    return HAL_OK;
    }



//���̸�:HAL_PCD_EP_Flush
LOCAL(HAL_StatusTypeDef) PCD_EP_Flush(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    __HAL_LOCK(hPcd);

    if (EpNo & 0x80)
        USB_FlushTxFifo(hPcd->Instance, EpNo&EP_ADDR_MSK);
    else
        USB_FlushRxFifo(hPcd->Instance);
    __HAL_UNLOCK(hPcd);

    return HAL_OK;
    }



//���̸�: HAL_PCD_EP_ClrStall
LOCAL(HAL_StatusTypeDef) PCD_EP_ClrStall(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    PCD_EPTypeDef*Ep;

    if ((EpNo&0x0F)>hPcd->Init.dev_endpoints) return HAL_ERROR;

    if (EpNo & 0x80)
        {
        Ep=&hPcd->IN_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=1;
        }
    else{
        Ep=&hPcd->OUT_ep[EpNo&EP_ADDR_MSK];
        Ep->is_in=0;
        }

    Ep->is_stall=0;
    Ep->num=EpNo&EP_ADDR_MSK;

    __HAL_LOCK(hPcd);
    USB_EPClearStall(hPcd->Instance, Ep);
    __HAL_UNLOCK(hPcd);

    return HAL_OK;
    }






LOCAL(HAL_StatusTypeDef) PCD_EP_OutXfrComplete_int(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    USB_OTG_GlobalTypeDef*USBx=hPcd->Instance;
    UINT USBx_BASE=(UINT)USBx;
    UINT gSNPSiD=*(__IO UINT*)(&USBx->CID+1);
    UINT DoepintReg=USBx_OUTEP(EpNo)->DOEPINT;

    if (hPcd->Init.dma_enable==1)
        {
        if (DoepintReg & USB_OTG_DOEPINT_STUP)
            {
            if (gSNPSiD>USB_OTG_CORE_ID_300A &&
                (DoepintReg & USB_OTG_DOEPINT_STPKTRX)!=0)
                {
                CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_STPKTRX);
                }
            }
        else if (DoepintReg & USB_OTG_DOEPINT_OTEPSPR)
            {
            CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_OTEPSPR);
            }
        else if ((DoepintReg & (USB_OTG_DOEPINT_STUP|USB_OTG_DOEPINT_OTEPSPR))==0)
            {
            if (gSNPSiD>USB_OTG_CORE_ID_300A &&
                (DoepintReg & USB_OTG_DOEPINT_STPKTRX)!=0)
                {
                CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_STPKTRX);
                }
            else{
                hPcd->OUT_ep[EpNo].xfer_count=hPcd->OUT_ep[EpNo].maxpacket - (USBx_OUTEP(EpNo)->DOEPTSIZ & USB_OTG_DOEPTSIZ_XFRSIZ);
                hPcd->OUT_ep[EpNo].xfer_buff+=hPcd->OUT_ep[EpNo].maxpacket;

                if (EpNo==0 && hPcd->OUT_ep[EpNo].xfer_len==0)
                    USB_Ep0OutStart(hPcd->Instance, 1, (LPBYTE)hPcd->Setup);

                HAL_PCD_DataOutStageCB(hPcd, EpNo);
                }
            }
        }
    else{
        if (gSNPSiD==USB_OTG_CORE_ID_310A)
            {
            if (DoepintReg & USB_OTG_DOEPINT_STPKTRX)
                CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_STPKTRX);
            else{
                if (DoepintReg & USB_OTG_DOEPINT_OTEPSPR)
                    CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_OTEPSPR);

                HAL_PCD_DataOutStageCB(hPcd, EpNo);
                }
            }
        else{
            if (EpNo==0 && hPcd->OUT_ep[EpNo].xfer_len==0)
                USB_Ep0OutStart(hPcd->Instance, 0, (LPBYTE)hPcd->Setup);

            HAL_PCD_DataOutStageCB(hPcd, EpNo);
            }
        }

    return HAL_OK;
    }




LOCAL(HAL_StatusTypeDef) PCD_EP_OutSetupPacket_int(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    USB_OTG_GlobalTypeDef*USBx=hPcd->Instance;
    UINT USBx_BASE=(UINT)USBx;
    UINT gSNPSiD=*(__IO UINT*)(&USBx->CID+1);
    UINT DoepintReg=USBx_OUTEP(EpNo)->DOEPINT;

    if (gSNPSiD>USB_OTG_CORE_ID_300A &&
        (DoepintReg & USB_OTG_DOEPINT_STPKTRX)!=0)
        {
        CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_STPKTRX);
        }

    HAL_PCD_SetupStageCallback(hPcd);

    if (gSNPSiD>USB_OTG_CORE_ID_300A && hPcd->Init.dma_enable==1)
        USB_Ep0OutStart(hPcd->Instance, 1, (LPBYTE)hPcd->Setup);

    return HAL_OK;
    }




LOCAL(HAL_StatusTypeDef) PCD_WriteEmptyTxFifo(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    USB_OTG_GlobalTypeDef*USBx=hPcd->Instance;
    UINT USBx_BASE=(UINT)USBx;
    USB_OTG_EPTypeDef*Ep;
    UINT Len;
    UINT len32b;
    UINT fifoemptymsk;

    Ep=&hPcd->IN_ep[EpNo];

    if (Ep->xfer_count>Ep->xfer_len) return HAL_ERROR;

    Len=Ep->xfer_len-Ep->xfer_count;
    if (Len>Ep->maxpacket) Len=Ep->maxpacket;

    len32b=(Len+3)/4;

    while ((USBx_INEP(EpNo)->DTXFSTS&USB_OTG_DTXFSTS_INEPTFSAV)>=len32b &&
        Ep->xfer_count<Ep->xfer_len && Ep->xfer_len!=0)
        {
        Len=Ep->xfer_len-Ep->xfer_count;
        if (Len>Ep->maxpacket) Len=Ep->maxpacket;
        len32b=(Len+3)/4;

        USB_WritePkt(USBx, Ep->xfer_buff, EpNo, Len, hPcd->Init.dma_enable);

        Ep->xfer_buff+=Len;
        Ep->xfer_count+=Len;
        }

    if (Ep->xfer_len<=Ep->xfer_count)
        {
        fifoemptymsk=1<<(EpNo&EP_ADDR_MSK);
        USBx_DEVICE->DIEPEMPMSK&=~fifoemptymsk;
        }

    return HAL_OK;
    }




VOID HAL_PCD_IRQHandler(PCD_HandleTypeDef *hPcd)
    {
    USB_OTG_GlobalTypeDef *USBx=hPcd->Instance;
    UINT USBx_BASE=(UINT)USBx;
    UINT I, EpIntr, EpInt, EpNo, GintSts;
    UINT fifoemptymsk, T;
    USB_OTG_EPTypeDef *Ep;

    GintSts=USB_ReadInterrupts(USBx);
    if (USB_GetMode(USBx)==USB_OTG_MODE_DEVICE)
        {
        if (__HAL_PCD_IS_INVALID_INTERRUPT(hPcd)) return;

        if (GintSts & USB_OTG_GINTSTS_MMIS)                     //__HAL_PCD_GET_FLAG()
            USBx->GINTSTS&=USB_OTG_GINTSTS_MMIS;                //__HAL_PCD_CLEAR_FLAG()

        if (GintSts & USB_OTG_GINTSTS_RXFLVL)
            {
            USBx->GINTMSK&=~USB_OTG_GINTSTS_RXFLVL;             //USB_MASK_INTERRUPT()

            T=USBx->GRXSTSP;
            Ep=&hPcd->OUT_ep[T & USB_OTG_GRXSTSP_EPNUM];

            if (((T & USB_OTG_GRXSTSP_PKTSTS)>>17)==STS_DATA_UPDT)
                {
                if (T & USB_OTG_GRXSTSP_BCNT)
                    {
                    USB_ReadPkt(USBx, Ep->xfer_buff, (T & USB_OTG_GRXSTSP_BCNT)>>4);

                    Ep->xfer_buff+=(T & USB_OTG_GRXSTSP_BCNT)>>4;
                    Ep->xfer_count+=(T & USB_OTG_GRXSTSP_BCNT)>>4;
                    }
                }
            else if (((T & USB_OTG_GRXSTSP_PKTSTS)>>17)==STS_SETUP_UPDT)
                {
                USB_ReadPkt(USBx, (LPBYTE)hPcd->Setup, 8);
                Ep->xfer_count+=(T & USB_OTG_GRXSTSP_BCNT)>>4;
                }
            USBx->GINTMSK|=USB_OTG_GINTSTS_RXFLVL;              //USB_UNMASK_INTERRUPT()
            }

        if (GintSts & USB_OTG_GINTSTS_OEPINT)
            {
            EpIntr=USB_ReadDevAllOutEpInterrupt(USBx);
            for (EpNo=0; EpIntr!=0; EpNo++, EpIntr>>=1)
                {
                if (EpIntr&1)
                    {
                    EpInt=USB_ReadDevOutEPIT(USBx, EpNo);

                    if (EpInt & USB_OTG_DOEPINT_XFRC)
                        {
                        CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_XFRC);
                        PCD_EP_OutXfrComplete_int(hPcd, EpNo);
                        }

                    if (EpInt & USB_OTG_DOEPINT_STUP)
                        {
                        CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_STUP);
                        PCD_EP_OutSetupPacket_int(hPcd, EpNo);
                        }

                    if (EpInt & USB_OTG_DOEPINT_OTEPDIS) CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_OTEPDIS);
                    if (EpInt & USB_OTG_DOEPINT_OTEPSPR) CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_OTEPSPR);
                    if (EpInt & USB_OTG_DOEPINT_NAK)     CLEAR_OUT_EP_INTR(EpNo, USB_OTG_DOEPINT_NAK);
                    }
                }
            }

        if (GintSts & USB_OTG_GINTSTS_IEPINT)
            {
            EpIntr=USB_ReadDevAllInEpInterrupt(USBx);
            for (EpNo=0; EpIntr!=0; EpNo++,EpIntr>>=1)
                {
                if (EpIntr & 1)
                    {
                    EpInt=USB_ReadDevInEPIT(USBx, EpNo);

                    if (EpInt & USB_OTG_DIEPINT_XFRC)
                        {
                        fifoemptymsk=1<<(EpNo&EP_ADDR_MSK);
                        USBx_DEVICE->DIEPEMPMSK&=~fifoemptymsk;
                        USBx_INEP(EpNo)->DIEPINT=USB_OTG_DIEPINT_XFRC;  //CLEAR_IN_EP_INTR()

                        if (hPcd->Init.dma_enable==1)
                            {
                            hPcd->IN_ep[EpNo].xfer_buff+=hPcd->IN_ep[EpNo].maxpacket;
                            if (EpNo==0 && hPcd->IN_ep[EpNo].xfer_len==0)
                                USB_Ep0OutStart(USBx, 1, (LPBYTE)hPcd->Setup);
                            }
                        HAL_PCD_DataInStageCB(hPcd, EpNo);
                        }
                    if (EpInt & USB_OTG_DIEPINT_TOC)    USBx_INEP(EpNo)->DIEPINT=USB_OTG_DIEPINT_TOC;
                    if (EpInt & USB_OTG_DIEPINT_ITTXFE) USBx_INEP(EpNo)->DIEPINT=USB_OTG_DIEPINT_ITTXFE;
                    if (EpInt & USB_OTG_DIEPINT_INEPNE) USBx_INEP(EpNo)->DIEPINT=USB_OTG_DIEPINT_INEPNE;
                    if (EpInt & USB_OTG_DIEPINT_EPDISD) USBx_INEP(EpNo)->DIEPINT=USB_OTG_DIEPINT_EPDISD;
                    if (EpInt & USB_OTG_DIEPINT_TXFE)   PCD_WriteEmptyTxFifo(hPcd, EpNo);
                    }
                }
            }

        if (GintSts & USB_OTG_GINTSTS_WKUINT)
            {
            USBx_DEVICE->DCTL&=~USB_OTG_DCTL_RWUSIG;

            if (hPcd->LPM_State==LPM_L1)
                {
                hPcd->LPM_State=LPM_L0;
                HAL_PCDEx_LPM_Callback(hPcd, PCD_LPM_L0_ACTIVE);
                }
            else
                HAL_PCD_ResumeCallback(hPcd);

            USBx->GINTSTS&=USB_OTG_GINTSTS_WKUINT;
            }

        if (GintSts & USB_OTG_GINTSTS_USBSUSP)
            {
            if (USBx_DEVICE->DSTS & USB_OTG_DSTS_SUSPSTS)
                HAL_PCD_SuspendCallback(hPcd);

            USBx->GINTSTS&=USB_OTG_GINTSTS_USBSUSP;
            }

        if (GintSts & USB_OTG_GINTSTS_LPMINT)
            {
            USBx->GINTSTS&=USB_OTG_GINTSTS_LPMINT;

            if (hPcd->LPM_State==LPM_L0)
                {
                hPcd->LPM_State=LPM_L1;
                hPcd->BESL=(USBx->GLPMCFG&USB_OTG_GLPMCFG_BESL)>>2;

                HAL_PCDEx_LPM_Callback(hPcd, PCD_LPM_L1_ACTIVE);
                }
            else
                HAL_PCD_SuspendCallback(hPcd);
            }

        if (GintSts & USB_OTG_GINTSTS_USBRST)
            {
            USBx_DEVICE->DCTL&=~USB_OTG_DCTL_RWUSIG;
            USB_FlushTxFifo(USBx, 0x10);

            for (I=0; I<hPcd->Init.dev_endpoints; I++)
                {
                USBx_INEP(I)->DIEPINT=0xFB7F;
                USBx_INEP(I)->DIEPCTL&=~USB_OTG_DIEPCTL_STALL;
                USBx_INEP(I)->DIEPCTL|=USB_OTG_DIEPCTL_SNAK;
                USBx_OUTEP(I)->DOEPINT=0xFB7F;
                USBx_OUTEP(I)->DOEPCTL&=~USB_OTG_DOEPCTL_STALL;
                USBx_OUTEP(I)->DOEPCTL|=USB_OTG_DOEPCTL_SNAK;
                }
            USBx_DEVICE->DAINTMSK|=0x10001;

            if (hPcd->Init.use_dedicated_ep1!=0)
                {
                USBx_DEVICE->DOUTEP1MSK|=USB_OTG_DOEPMSK_STUPM|
                    USB_OTG_DOEPMSK_XFRCM|
                    USB_OTG_DOEPMSK_EPDM;

                USBx_DEVICE->DINEP1MSK|=USB_OTG_DIEPMSK_TOM|
                    USB_OTG_DIEPMSK_XFRCM|
                    USB_OTG_DIEPMSK_EPDM;
                }
            else{
                USBx_DEVICE->DOEPMSK|=USB_OTG_DOEPMSK_STUPM|
                    USB_OTG_DOEPMSK_XFRCM|
                    USB_OTG_DOEPMSK_EPDM|
                    USB_OTG_DOEPMSK_OTEPSPRM|
                    USB_OTG_DOEPMSK_NAKM;

                USBx_DEVICE->DIEPMSK|=USB_OTG_DIEPMSK_TOM|
                    USB_OTG_DIEPMSK_XFRCM|
                    USB_OTG_DIEPMSK_EPDM;
                }

            USBx_DEVICE->DCFG&=~USB_OTG_DCFG_DAD;
            USB_Ep0OutStart(USBx, hPcd->Init.dma_enable, (LPBYTE)hPcd->Setup);
            USBx->GINTSTS&=USB_OTG_GINTSTS_USBRST;
            }

        if (GintSts & USB_OTG_GINTSTS_ENUMDNE)
            {
            USB_ActivateSetup(USBx);
            hPcd->Init.speed=USB_GetDevSpeed_(USBx);
            USB_SetTurnAroundTime(USBx, HAL_RCC_GetHCLKFreq(), hPcd->Init.speed);
            HAL_PCD_ResetCallback(hPcd);
            USBx->GINTSTS&=USB_OTG_GINTSTS_ENUMDNE;
            }

        if (GintSts & USB_OTG_GINTSTS_SOF)
            {
            HAL_PCD_SOFCallback(hPcd);
            USBx->GINTSTS&=USB_OTG_GINTSTS_SOF;
            }

        if (GintSts & USB_OTG_GINTSTS_IISOIXFR)
            {
            HAL_PCD_ISOINIncompleteCB(hPcd, EpNo=0);
            USBx->GINTSTS&=USB_OTG_GINTSTS_IISOIXFR;
            }

        if (GintSts & USB_OTG_GINTSTS_PXFR_INCOMPISOOUT)
            {
            HAL_PCD_ISOOUTIncompleteCB(hPcd, EpNo=0);
            USBx->GINTSTS&=USB_OTG_GINTSTS_PXFR_INCOMPISOOUT;
            }

        if (GintSts & USB_OTG_GINTSTS_SRQINT)
            {
            HAL_PCD_ConnectCallback(hPcd);
            USBx->GINTSTS&=USB_OTG_GINTSTS_SRQINT;
            }

        if (GintSts & USB_OTG_GINTSTS_OTGINT)
            {
            T=USBx->GOTGINT;
            if (T & USB_OTG_GOTGINT_SEDET) HAL_PCD_DisconnectCallback(hPcd);
            USBx->GOTGINT|=T;
            }
        }
    }




HAL_StatusTypeDef HAL_PCD_Init(PCD_HandleTypeDef *hPcd)
    {
    UINT I;
    USB_OTG_GlobalTypeDef *USBx;

    if (hPcd==NULL) return HAL_ERROR;

    USBx=hPcd->Instance;
    if (hPcd->State==HAL_PCD_STATE_RESET)
        {
        hPcd->Lock=HAL_UNLOCKED;
        HAL_PCD_MspInit(hPcd);
        }

    hPcd->State=HAL_PCD_STATE_BUSY;

    if ((USBx->CID & (1<<8))==0) hPcd->Init.dma_enable=0;

    USB_DisableGlobalInt(USBx);

    if (USB_CoreInit(USBx, hPcd->Init)!=HAL_OK)
        {
        hPcd->State=HAL_PCD_STATE_ERROR;
        return HAL_ERROR;
        }

    USB_SetCurrentMode(USBx, USB_DEVICE_MODE);

    for (I=0; I<hPcd->Init.dev_endpoints; I++)
        {
        hPcd->IN_ep[I].is_in=1;
        hPcd->IN_ep[I].num=I;
        hPcd->IN_ep[I].tx_fifo_num=I;
        hPcd->IN_ep[I].type=EP_TYPE_CTRL;
        hPcd->IN_ep[I].maxpacket=0;
        hPcd->IN_ep[I].xfer_buff=0;
        hPcd->IN_ep[I].xfer_len=0;
        }

    for (I=0; I<hPcd->Init.dev_endpoints; I++)
        {
        hPcd->OUT_ep[I].is_in=0;
        hPcd->OUT_ep[I].num=I;
        hPcd->OUT_ep[I].type=EP_TYPE_CTRL;
        hPcd->OUT_ep[I].maxpacket=0;
        hPcd->OUT_ep[I].xfer_buff=0;
        hPcd->OUT_ep[I].xfer_len=0;
        }

    if (USB_DevInit(USBx, hPcd->Init)!=HAL_OK)
        {
        hPcd->State=HAL_PCD_STATE_ERROR;
        return HAL_ERROR;
        }

    hPcd->USB_Address=0;
    hPcd->State=HAL_PCD_STATE_READY;

    if (hPcd->Init.lpm_enable==1) HAL_PCDEx_ActivateLPM(hPcd);
    USB_DevDisconnect(USBx);
    return HAL_OK;
    }



HAL_StatusTypeDef HAL_PCD_DeInit(PCD_HandleTypeDef *hPcd)
    {
    if (hPcd==NULL) return HAL_ERROR;

    hPcd->State=HAL_PCD_STATE_BUSY;
    HAL_PCD_Stop(hPcd);
    HAL_PCD_MspDeInit(hPcd);
    hPcd->State=HAL_PCD_STATE_RESET;
    return HAL_OK;
    }



///////////////////////////////////////////////////////////////////////////////
//                      Usbd_Conf.c
///////////////////////////////////////////////////////////////////////////////
#include "usbd_core.h"

static BYTE ConnectedUsb;


//-----------------------------------------------------------------------------
//      usbd_core.c ... USBD_DeInit() ���� ȣ����
//-----------------------------------------------------------------------------
USBD_StatusTypeDef USBD_LL_DeInit(USBD_HandleTypeDef *USBD)
    {
    #ifdef USE_USB_FS
    __HAL_RCC_USB_OTG_FS_CLK_DISABLE();
    __HAL_RCC_SYSCFG_CLK_DISABLE();
    #endif

    #ifdef USE_USB_HS
    __HAL_RCC_USB_OTG_HS_CLK_DISABLE();
    __HAL_RCC_SYSCFG_CLK_DISABLE();
    #endif

    HAL_PCD_DeInit(USBD->Data);
    return USBD_OK;
    }



//-----------------------------------------------------------------------------
//      usbd_core.c ... USBD_Start() ���� ȣ����
//-----------------------------------------------------------------------------
USBD_StatusTypeDef USBD_LL_Start(USBD_HandleTypeDef *USBD)
    {
    HAL_PCD_Start(USBD->Data);
    return USBD_OK;
    }



//-----------------------------------------------------------------------------
//      usbd_core.c ... USBD_DeInit() ���� ȣ����
//-----------------------------------------------------------------------------
USBD_StatusTypeDef USBD_LL_Stop(USBD_HandleTypeDef *USBD)
    {
    HAL_PCD_Stop(USBD->Data);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_OpenEP(USBD_HandleTypeDef *USBD, UINT EpNo, UINT EpType, UINT EpMps)
    {
    PCD_EP_Open(USBD->Data, EpNo, EpMps, EpType);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_CloseEP(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    PCD_EP_Close(USBD->Data, EpNo);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_FlushEP(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    PCD_EP_Flush(USBD->Data, EpNo);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_StallEP(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    PCD_EP_SetStall(USBD->Data, EpNo);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_ClearStallEP(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    PCD_EP_ClrStall(USBD->Data, EpNo);
    return USBD_OK;
    }



UINT USBD_LL_IsStallEP(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    PCD_HandleTypeDef *hPcd=USBD->Data;

    return (EpNo & 0x80) ? hPcd->IN_ep[EpNo&0x7F].is_stall:
                           hPcd->OUT_ep[EpNo].is_stall;
    }



USBD_StatusTypeDef USBD_LL_SetUSBAddress(USBD_HandleTypeDef *USBD, UINT DevAddr)
    {
    PCD_SetAddress(USBD->Data, DevAddr);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_Transmit(USBD_HandleTypeDef *USBD, UINT EpNo, LPBYTE Buff, UINT Size)
    {
    PCD_EP_Transmit(USBD->Data, EpNo, Buff, Size);
    return USBD_OK;
    }



USBD_StatusTypeDef USBD_LL_PrepareReceive(USBD_HandleTypeDef *USBD, UINT EpNo, LPBYTE Buff, UINT Size)
    {
    PCD_EP_Receive(USBD->Data, EpNo, Buff, Size);
    return USBD_OK;
    }



UINT USBD_LL_GetRxDataSize(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    return PCD_EP_GetRxCount(USBD->Data, EpNo);
    }



///////////////////////////////////////////////////////////////////////////////
//              �ݹ��Լ�
///////////////////////////////////////////////////////////////////////////////



//PCD_EP_OutXfrComplete_int(),PCD_EP_OutSetupPacket_int()<-HAL_PCD_IRQHandler()
VOID HAL_PCD_SetupStageCallback(PCD_HandleTypeDef *hPcd)
    {
    USBD_LL_SetupStage(hPcd->pData, (LPBYTE)hPcd->Setup);
    }



//HAL_PCD_IRQHandler()���� ȣ��
VOID HAL_PCD_SOFCallback(PCD_HandleTypeDef *hPcd)
    {
    USBD_LL_SOF(hPcd->pData);
    }



//HAL_PCD_IRQHandler()���� ȣ��
VOID HAL_PCD_ResetCallback(PCD_HandleTypeDef *hPcd)
    {
    USBD_LL_Reset(hPcd->pData);
    USBD_LL_SetSpeed(hPcd->pData, hPcd->Init.speed==PCD_SPEED_HIGH ? USBD_SPEED_HIGH:USBD_SPEED_FULL);
    }


//HAL_PCD_IRQHandler()���� ȣ��
VOID HAL_PCD_ConnectCallback(PCD_HandleTypeDef *hPcd)
    {
    ConnectedUsb=1;
    //USBD_LL_DevConnected(hPcd->pData);
    }


//HAL_PCD_IRQHandler()���� ȣ��
VOID HAL_PCD_DisconnectCallback(PCD_HandleTypeDef *hPcd)
    {
    ConnectedUsb=0;
    USBD_LL_DevDisconnected(hPcd->pData);
    }


//���̸�: HAL_PCD_DataOutStageCallback
//PCD_EP_OutXfrComplete_int()<-HAL_PCD_IRQHandler()
LOCAL(VOID) HAL_PCD_DataOutStageCB(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    USBD_LL_DataOutStage(hPcd->pData, EpNo, hPcd->OUT_ep[EpNo].xfer_buff);
    }


//���̸�: HAL_PCD_DataInStageCallback
//HAL_PCD_IRQHandler()���� ȣ��
LOCAL(VOID) HAL_PCD_DataInStageCB(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    USBD_LL_DataInStage(hPcd->pData, EpNo, hPcd->IN_ep[EpNo].xfer_buff);
    }



//���̸�: HAL_PCD_ISOOUTIncompleteCallback
//HAL_PCD_IRQHandler()���� ȣ��
LOCAL(VOID) HAL_PCD_ISOOUTIncompleteCB(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    //USBD_LL_IsoOUTIncomplete(hPcd->pData, EpNo);
    }


//���̸�:HAL_PCD_ISOINIncompleteCallback
//HAL_PCD_IRQHandler()���� ȣ��
LOCAL(VOID) HAL_PCD_ISOINIncompleteCB(PCD_HandleTypeDef *hPcd, UINT EpNo)
    {
    //USBD_LL_IsoINIncomplete(hPcd->pData, EpNo);
    }




//-----------------------------------------------------------------------------
//      HOST USB�� ����Ǿ� �ִ��� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsConnectedUsb(VOID) {return ConnectedUsb;}


#endif //HAL_PCD_MODULE_ENABLED
