
#ifndef __USBD_CORE_H
#define __USBD_CORE_H

#ifdef __cplusplus
extern"C"{
#endif

#include "usbd_conf.h"



#ifndef NULL
#define NULL                                            0
#endif

#ifndef USBD_MAX_NUM_INTERFACES
#define USBD_MAX_NUM_INTERFACES                         1
#endif

#ifndef USBD_MAX_NUM_CONFIGURATION
#define USBD_MAX_NUM_CONFIGURATION                      1
#endif

#ifndef USBD_LPM_ENABLED
#define USBD_LPM_ENABLED                                0
#endif

#ifndef USBD_SELF_POWERED
#define USBD_SELF_POWERED                               1
#endif

#ifndef USBD_SUPPORT_USER_STRING
#define USBD_SUPPORT_USER_STRING                        0
#endif

#define  USB_LEN_DEV_QUALIFIER_DESC                     0x0A
#define  USB_LEN_DEV_DESC                               0x12
#define  USB_LEN_CFG_DESC                               0x09
#define  USB_LEN_IF_DESC                                0x09
#define  USB_LEN_EP_DESC                                0x07
#define  USB_LEN_OTG_DESC                               0x03
#define  USB_LEN_LANGID_STR_DESC                        0x04
#define  USB_LEN_OTHER_SPEED_DESC_SIZ                   0x09

#define  USBD_IDX_LANGID_STR                            0x00
#define  USBD_IDX_MFC_STR                               0x01
#define  USBD_IDX_PRODUCT_STR                           0x02
#define  USBD_IDX_SERIAL_STR                            0x03
#define  USBD_IDX_CONFIG_STR                            0x04
#define  USBD_IDX_INTERFACE_STR                         0x05

#define  USB_REQ_TYPE_STANDARD                          0x00
#define  USB_REQ_TYPE_CLASS                             0x20
#define  USB_REQ_TYPE_VENDOR                            0x40
#define  USB_REQ_TYPE_MASK                              0x60

#define  USB_REQ_RECIPIENT_DEVICE                       0x00
#define  USB_REQ_RECIPIENT_INTERFACE                    0x01
#define  USB_REQ_RECIPIENT_ENDPOINT                     0x02
#define  USB_REQ_RECIPIENT_MASK                         0x03

#define  USB_REQ_GET_STATUS                             0x00
#define  USB_REQ_CLEAR_FEATURE                          0x01
#define  USB_REQ_SET_FEATURE                            0x03
#define  USB_REQ_SET_ADDRESS                            0x05
#define  USB_REQ_GET_DESCRIPTOR                         0x06
#define  USB_REQ_SET_DESCRIPTOR                         0x07
#define  USB_REQ_GET_CONFIGURATION                      0x08
#define  USB_REQ_SET_CONFIGURATION                      0x09
#define  USB_REQ_GET_INTERFACE                          0x0A
#define  USB_REQ_SET_INTERFACE                          0x0B
#define  USB_REQ_SYNCH_FRAME                            0x0C

#define  USB_DESC_TYPE_DEVICE                           0x01
#define  USB_DESC_TYPE_CONFIGURATION                    0x02
#define  USB_DESC_TYPE_STRING                           0x03
#define  USB_DESC_TYPE_INTERFACE                        0x04
#define  USB_DESC_TYPE_ENDPOINT                         0x05
#define  USB_DESC_TYPE_DEVICE_QUALIFIER                 0x06
#define  USB_DESC_TYPE_OTHER_SPEED_CONFIGURATION        0x07
#define  USB_DESC_TYPE_BOS                              0x0F

#define USB_CONFIG_REMOTE_WAKEUP                        0x02
#define USB_CONFIG_SELF_POWERED                         0x01

#define USB_FEATURE_EP_HALT                             0x00
#define USB_FEATURE_REMOTE_WAKEUP                       0x01
#define USB_FEATURE_TEST_MODE                           0x02

#define USB_DEVICE_CAPABITY_TYPE                        0x10

#define USB_HS_MAX_PACKET_SIZE                          512
#define USB_FS_MAX_PACKET_SIZE                          64
#define USB_MAX_EP0_SIZE                                64

#define USBD_STATE_DEFAULT                              0x01
#define USBD_STATE_ADDRESSED                            0x02
#define USBD_STATE_CONFIGURED                           0x03
#define USBD_STATE_SUSPENDED                            0x04


#define USBD_EP0_IDLE                                   0x00
#define USBD_EP0_SETUP                                  0x01
#define USBD_EP0_DATA_IN                                0x02
#define USBD_EP0_DATA_OUT                               0x03
#define USBD_EP0_STATUS_IN                              0x04
#define USBD_EP0_STATUS_OUT                             0x05
#define USBD_EP0_STALL                                  0x06

#define USBD_EP_TYPE_CTRL                               0x00
#define USBD_EP_TYPE_ISOC                               0x01
#define USBD_EP_TYPE_BULK                               0x02
#define USBD_EP_TYPE_INTR                               0x03




typedef struct usb_setup_req
    {
    BYTE bmRequest;
    BYTE bRequest;
    WORD wValue;
    WORD wIndex;
    WORD wLength;
    } USBD_SetupReq;

struct _USBD_HandleTypeDef;

typedef struct _Device_cb
    {
    UINT (*Init)(struct _USBD_HandleTypeDef*pdev, UINT cfgidx);
    UINT (*DeInit)(struct _USBD_HandleTypeDef*pdev, UINT cfgidx);
    UINT (*Setup)(struct _USBD_HandleTypeDef*pdev, USBD_SetupReq*req);
    UINT (*EP0_TxSent)(struct _USBD_HandleTypeDef*pdev);
    UINT (*EP0_RxReady)(struct _USBD_HandleTypeDef*pdev);
    UINT (*DataIn)(struct _USBD_HandleTypeDef*pdev, UINT EpNo);
    UINT (*DataOut)(struct _USBD_HandleTypeDef*pdev, UINT EpNo);
    UINT (*SOF)(struct _USBD_HandleTypeDef*pdev);
    UINT (*IsoINIncomplete)(struct _USBD_HandleTypeDef*pdev, UINT EpNo);
    UINT (*IsoOUTIncomplete)(struct _USBD_HandleTypeDef*pdev, UINT EpNo);

    LPBYTE (*GetHSConfigDescriptor)(UINT*length);
    LPBYTE (*GetFSConfigDescriptor)(UINT*length);
    LPBYTE (*GetOtherSpeedConfigDescriptor)(UINT*length);
    LPBYTE (*GetDeviceQualifierDescriptor)(UINT*length);
    #if USBD_SUPPORT_USER_STRING
    LPBYTE (*GetUsrStrDescriptor)(struct _USBD_HandleTypeDef*pdev, UINT index, UINT*length);
    #endif
    } USBD_ClassTypeDef;

typedef enum
    {
    USBD_SPEED_HIGH=0,
    USBD_SPEED_FULL=1,
    USBD_SPEED_LOW=2,
    } USBD_SpeedTypeDef;

typedef enum
    {
    USBD_OK=0,
    USBD_BUSY,
    USBD_FAIL,
    } USBD_StatusTypeDef;

typedef struct
    {
    LPBYTE (*GetDeviceDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetLangIDStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetManufacturerStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetProductStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetSerialStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetConfigurationStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    LPBYTE (*GetInterfaceStrDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    #if (USBD_LPM_ENABLED == 1U)
    LPBYTE (*GetBOSDescriptor)(USBD_SpeedTypeDef speed, UINT*length);
    #endif
    } USBD_DescriptorsTypeDef;

typedef struct
    {
    UINT status;
    UINT is_used;
    UINT total_length;
    UINT rem_length;
    UINT maxpacket;
    } USBD_EndpointTypeDef;

typedef struct _USBD_HandleTypeDef
    {
    BYTE Id;
    UINT DevConfig;
    UINT DevDefaultConfig;
    UINT DevConfigStatus;
    USBD_SpeedTypeDef DevSpeed;
    USBD_EndpointTypeDef EpIn[15];
    USBD_EndpointTypeDef EpOut[15];
    UINT Ep0State;
    UINT Ep0DataLen;
    BYTE DevState;
    BYTE DevOldState;
    BYTE DevAddress;
    BYTE DevConnStatus;
    BYTE DevTestMode;
    UINT DevRemoteWakeup;

    USBD_SetupReq Request;
    USBD_DescriptorsTypeDef *Desc;
    USBD_ClassTypeDef *Class;
    LPVOID ClassData;
    LPVOID UserData;
    LPVOID Data;
    } USBD_HandleTypeDef;




#ifndef USBD_DEBUG_LEVEL
#define USBD_DEBUG_LEVEL           0
#endif


#define USBD_SOF          USBD_LL_SOF

VOID USBD_Init(USBD_HandleTypeDef*pdev, USBD_DescriptorsTypeDef*pdesc, UINT id);
VOID USBD_DeInit(USBD_HandleTypeDef*pdev);
VOID USBD_Start(USBD_HandleTypeDef*pdev);
VOID USBD_Stop(USBD_HandleTypeDef*pdev);
VOID USBD_RegisterClass(USBD_HandleTypeDef*pdev, USBD_ClassTypeDef*pclass);

USBD_StatusTypeDef USBD_LL_SetupStage(USBD_HandleTypeDef*pdev, LPBYTE psetup);
USBD_StatusTypeDef USBD_LL_DataOutStage(USBD_HandleTypeDef*pdev, UINT EpNo, LPBYTE pdata);
USBD_StatusTypeDef USBD_LL_DataInStage(USBD_HandleTypeDef*pdev, UINT EpNo, LPBYTE pdata);

VOID USBD_LL_Reset(USBD_HandleTypeDef*pdev);
VOID USBD_LL_SetSpeed(USBD_HandleTypeDef*pdev, USBD_SpeedTypeDef speed);
VOID USBD_LL_Suspend(USBD_HandleTypeDef*pdev);
VOID USBD_LL_Resume(USBD_HandleTypeDef*pdev);
VOID USBD_LL_SOF(USBD_HandleTypeDef*pdev);
VOID USBD_LL_DevDisconnected(USBD_HandleTypeDef*pdev);

USBD_StatusTypeDef USBD_LL_Init(USBD_HandleTypeDef*pdev);
USBD_StatusTypeDef USBD_LL_DeInit(USBD_HandleTypeDef*pdev);
USBD_StatusTypeDef USBD_LL_Start(USBD_HandleTypeDef*pdev);
USBD_StatusTypeDef USBD_LL_Stop(USBD_HandleTypeDef*pdev);
USBD_StatusTypeDef USBD_LL_OpenEP(USBD_HandleTypeDef*pdev, UINT EpNo, UINT ep_type, UINT ep_mps);

USBD_StatusTypeDef USBD_LL_CloseEP(USBD_HandleTypeDef*pdev, UINT EpNo);
USBD_StatusTypeDef USBD_LL_FlushEP(USBD_HandleTypeDef*pdev, UINT EpNo);
USBD_StatusTypeDef USBD_LL_StallEP(USBD_HandleTypeDef*pdev, UINT EpNo);
USBD_StatusTypeDef USBD_LL_ClearStallEP(USBD_HandleTypeDef*pdev, UINT EpNo);
USBD_StatusTypeDef USBD_LL_SetUSBAddress(USBD_HandleTypeDef*pdev, UINT dev_addr);
USBD_StatusTypeDef USBD_LL_Transmit(USBD_HandleTypeDef*pdev, UINT EpNo, LPBYTE pbuf, UINT size);
USBD_StatusTypeDef USBD_LL_PrepareReceive(USBD_HandleTypeDef*pdev, UINT EpNo, LPBYTE pbuf, UINT size);
UINT USBD_LL_IsStallEP(USBD_HandleTypeDef*pdev, UINT EpNo);
UINT USBD_LL_GetRxDataSize(USBD_HandleTypeDef*pdev, UINT EpNo);


//usbd_ctlreq.h
VOID USBD_CtlError(USBD_HandleTypeDef*pdev, USBD_SetupReq*req);
VOID USBD_CtlSendData(USBD_HandleTypeDef*pdev, LPBYTE pbuf, UINT len);
VOID USBD_CtlPrepareRx(USBD_HandleTypeDef*USBD, LPBYTE Buff, UINT Len);



#ifdef __cplusplus
}
#endif

#endif



