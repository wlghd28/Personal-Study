///////////////////////////////////////////////////////////////////////////////
//                  USB ���丮�� Ŭ����
//
// HighSpeed ... SD ���� �д� �ӵ� 1.2M Byte
// FullSpeed ... SD ���� �д� �ӵ� 650K Byte
// SD����    ... SD ���� �д� �ӵ� 14M Byte
///////////////////////////////////////////////////////////////////////////////


#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"
#include "usbd_core.h"
#include "USBD_MSC.h"
#include "MAIN.H"


VOID WINAPI PCDEx_SetTxFiFo(PCD_TypeDef *PcdInst, UINT Fifo, UINT Size);
VOID WINAPI PCDEx_SetRxFiFo(PCD_TypeDef *PcdInst, UINT Size);


#define STANDARD_INQUIRY_DATA_LEN       0x24
#define USB_SIZ_STRING_SERIAL           0x1A
#define DEVICE_ID1                      0x1FFF7A10
#define DEVICE_ID2                      0x1FFF7A14
#define DEVICE_ID3                      0x1FFF7A18


#define USBD_VID                        0x0483
#define USBD_PID                        0x5720
#define USBD_LANGID_STRING              0x409
#define USBD_MANUFACTURER_STRING        "STMicroelectronics"
#define USBD_PRODUCT_HS_STRING          "Mass Storage in HS Mode"
#define USBD_PRODUCT_FS_STRING          "Mass Storage in FS Mode"
#define USBD_CONFIGURATION_HS_STRING    "MSC Config"
#define USBD_INTERFACE_HS_STRING        "MSC Interface"
#define USBD_CONFIGURATION_FS_STRING    "MSC Config"
#define USBD_INTERFACE_FS_STRING        "MSC Interface"



#define USBD_BOT_IDLE                   0
#define USBD_BOT_DATA_OUT               1
#define USBD_BOT_DATA_IN                2
#define USBD_BOT_LAST_DATA_IN           3
#define USBD_BOT_SEND_DATA              4
#define USBD_BOT_NO_DATA                5

#define USBD_BOT_CBW_SIGNATURE          0x43425355
#define USBD_BOT_CSW_SIGNATURE          0x53425355
#define USBD_BOT_CBW_LENGTH             31
#define USBD_BOT_CSW_LENGTH             13
#define USBD_BOT_MAX_DATA               256

#define USBD_CSW_CMD_PASSED             0
#define USBD_CSW_CMD_FAILED             1
#define USBD_CSW_PHASE_ERROR            2

#define USBD_BOT_STATUS_NORMAL          0
#define USBD_BOT_STATUS_RECOVERY        1
#define USBD_BOT_STATUS_ERROR           2

#define SENSE_LIST_DEEPTH               4

#define SCSI_FORMAT_UNIT                0x04
#define SCSI_INQUIRY                    0x12
#define SCSI_MODE_SELECT6               0x15
#define SCSI_MODE_SELECT10              0x55
#define SCSI_MODE_SENSE6                0x1A
#define SCSI_MODE_SENSE10               0x5A
#define SCSI_ALLOW_MEDIUM_REMOVAL       0x1E
#define SCSI_READ6                      0x08
#define SCSI_READ10                     0x28
#define SCSI_READ12                     0xA8
#define SCSI_READ16                     0x88
#define SCSI_READ_CAPACITY10            0x25
#define SCSI_READ_CAPACITY16            0x9E
#define SCSI_REQUEST_SENSE              0x03
#define SCSI_START_STOP_UNIT            0x1B
#define SCSI_TEST_UNIT_READY            0x00
#define SCSI_WRITE6                     0x0A
#define SCSI_WRITE10                    0x2A
#define SCSI_WRITE12                    0xAA
#define SCSI_WRITE16                    0x8A
#define SCSI_VERIFY10                   0x2F
#define SCSI_VERIFY12                   0xAF
#define SCSI_VERIFY16                   0x8F
#define SCSI_SEND_DIAGNOSTIC            0x1D
#define SCSI_READ_FORMAT_CAPACITIES     0x23

#define NO_SENSE                        0
#define RECOVERED_ERROR                 1
#define NOT_READY                       2
#define MEDIUM_ERROR                    3
#define HARDWARE_ERROR                  4
#define ILLEGAL_REQUEST                 5
#define UNIT_ATTENTION                  6
#define DATA_PROTECT                    7
#define BLANK_CHECK                     8
#define VENDOR_SPECIFIC                 9
#define COPY_ABORTED                    10
#define ABORTED_COMMAND                 11
#define VOLUME_OVERFLOW                 13
#define MISCOMPARE                      14


#define INVALID_CDB                     0x20
#define INVALID_FIELED_IN_COMMAND       0x24
#define PARAMETER_LIST_LENGTH_ERROR     0x1A
#define INVALID_FIELD_IN_PARAMETER_LIST 0x26
#define ADDRESS_OUT_OF_RANGE            0x21
#define MEDIUM_NOT_PRESENT              0x3A
#define MEDIUM_HAVE_CHANGED             0x28
#define WRITE_PROTECTED                 0x27
#define UNRECOVERED_READ_ERROR          0x11
#define WRITE_FAULT                     0x03
#define REQUEST_SENSE_DATA_LEN          0x12


#ifndef MSC_MEDIA_PACKET
#define MSC_MEDIA_PACKET                512
#endif

#define MSC_MAX_FS_PACKET               0x40
#define MSC_MAX_HS_PACKET               0x200

#define BOT_GET_MAX_LUN                 0xFE
#define BOT_RESET                       0xFF
#define USB_MSC_CONFIG_DESC_SIZ         32


#define MSC_EPIN_ADDR                   0x81
#define MSC_EPOUT_ADDR                  0x01



typedef struct _SENSE_ITEM
    {
    char Skey;
    union{
        struct _ASCs
            {
            char ASC;
            char ASCQ;
            } b;
        BYTE  ASC;
        LPSTR pData;
        } w;
    } USBD_SCSI_Sense;

typedef struct
    {
    UINT Sign;
    UINT Tag;
    UINT DataLen;
    BYTE Flags;
    BYTE Lun;
    BYTE Length;
    BYTE CB[16];
    BYTE ReservedForAlign;
    } USBD_MSC_BOT_CBW;

typedef struct
    {
    UINT Sign;
    UINT Tag;
    UINT DataResidue;
    BYTE Status;
    BYTE ReservedForAlign[3];
    } USBD_MSC_BOT_CSW;

typedef struct
    {
    UINT MaxLun;
    UINT Interface;
    BYTE BotState;
    BYTE BotStatus;
    WORD BotDataLen;
    BYTE BotData[MSC_MEDIA_PACKET];
    USBD_MSC_BOT_CBW CBW;
    USBD_MSC_BOT_CSW CSW;

    USBD_SCSI_Sense ScsiSense[SENSE_LIST_DEEPTH];
    BYTE ScsiSenseHead;
    BYTE ScsiSenseTail;

    UINT ScsiBlkSize;
    DWORD ScsiBlkQty;

    UINT ScsiBlkAddr;
    UINT ScsiBlkLen;
    } USBD_MSC_BOT;




static __ALIGN_BEGIN BYTE USBD_DeviceDesc[USB_LEN_DEV_DESC]__ALIGN_END=
    {
    0x12,
    USB_DESC_TYPE_DEVICE,
    0x00,
    0x02,
    0x00,
    0x00,
    0x00,
    USB_MAX_EP0_SIZE,
    LoByte(USBD_VID),
    HiByte(USBD_VID),
    LoByte(USBD_PID),
    HiByte(USBD_PID),
    0x00,
    0x02,
    USBD_IDX_MFC_STR,
    USBD_IDX_PRODUCT_STR,
    USBD_IDX_SERIAL_STR,
    USBD_MAX_NUM_CONFIGURATION
    };



static __ALIGN_BEGIN BYTE USBD_LangIDDesc[USB_LEN_LANGID_STR_DESC]__ALIGN_END=
    {
    USB_LEN_LANGID_STR_DESC,
    USB_DESC_TYPE_STRING,
    LoByte(USBD_LANGID_STRING),
    HiByte(USBD_LANGID_STRING),
    };



static __ALIGN_BEGIN BYTE USBD_StringSerial[USB_SIZ_STRING_SERIAL]__ALIGN_END=
    {
    USB_SIZ_STRING_SERIAL,
    USB_DESC_TYPE_STRING,
    };




static __ALIGN_BEGIN BYTE USBD_StrDesc[USBD_MAX_STR_DESC_SIZ]__ALIGN_END;



static INT8 STORAGE_Inquirydata[]=
    {
    0x00,
    0x80,
    0x02,
    0x02,
    STANDARD_INQUIRY_DATA_LEN-5,
    0x00,
    0x00,
    0x00,
    'S', 'T', 'M', ' ', ' ', ' ', ' ', ' ',
    'P', 'r', 'o', 'd', 'u', 'c', 't', ' ',
    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    '0', '.', '0', '1',
    };




LOCAL(LPBYTE) USBD_MSC_DeviceDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    *lpLen=sizeof(USBD_DeviceDesc);
    return USBD_DeviceDesc;
    }



LOCAL(LPBYTE) USBD_MSC_LangIDStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    *lpLen=sizeof(USBD_LangIDDesc);
    return USBD_LangIDDesc;
    }



LOCAL(VOID) SetAsc2Unicode(LPCSTR Desc, LPBYTE Utf16, UINT *lpLen)
    {
    UINT I=0;

    if (Desc!=NULL)
        {
        *lpLen=lstrlen(Desc)*2+2;
        Utf16[I++]=*(LPBYTE)lpLen;
        Utf16[I++]=USB_DESC_TYPE_STRING;

        while (*Desc!=0)
            {
            Utf16[I++]=*Desc++;
            Utf16[I++]=0;
            }
        }
    }



LOCAL(LPBYTE) USBD_MSC_ProductStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    SetAsc2Unicode(Speed==USBD_SPEED_HIGH ? USBD_PRODUCT_HS_STRING:USBD_PRODUCT_FS_STRING, USBD_StrDesc, lpLen);
    return USBD_StrDesc;
    }



LOCAL(LPBYTE) USBD_MSC_ManufacturerStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    SetAsc2Unicode(USBD_MANUFACTURER_STRING, USBD_StrDesc, lpLen);
    return USBD_StrDesc;
    }



LOCAL(VOID) IntToHex(UINT Value, LPBYTE Buff, int Len)  //HEX���ڿ��� UTF16����
    {
    int I, Cha;

    for (I=0; I<Len; I++)
        {
        Cha=Value>>28;
        Buff[2*I]=(Cha<10) ? Cha+'0':Cha+'A'-10;
        Value<<=4;
        Buff[2*I+1]=0;
        }
    }



LOCAL(VOID) Get_SerialNum(VOID)
    {
    UINT DevSn0, DevSn1, DevSn2;

    DevSn0=*(UINT*)DEVICE_ID1;
    DevSn1=*(UINT*)DEVICE_ID2;
    DevSn2=*(UINT*)DEVICE_ID3;

    DevSn0+=DevSn2;

    if (DevSn0!=0)
        {
        IntToHex(DevSn0, &USBD_StringSerial[2], 8);
        IntToHex(DevSn1, &USBD_StringSerial[18], 4);
        }
    }


LOCAL(LPBYTE) USBD_MSC_SerialStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    *lpLen=USB_SIZ_STRING_SERIAL;
    Get_SerialNum();
    return (LPBYTE)USBD_StringSerial;
    }



LOCAL(LPBYTE) USBD_MSC_ConfigStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    SetAsc2Unicode(Speed==USBD_SPEED_HIGH ? USBD_CONFIGURATION_HS_STRING:USBD_CONFIGURATION_FS_STRING, USBD_StrDesc, lpLen);
    return USBD_StrDesc;
    }



LOCAL(LPBYTE) USBD_MSC_InterfaceStrDescriptor(USBD_SpeedTypeDef Speed, UINT *lpLen)
    {
    SetAsc2Unicode(Speed==USBD_SPEED_HIGH ? USBD_INTERFACE_HS_STRING:USBD_INTERFACE_FS_STRING, USBD_StrDesc, lpLen);
    return USBD_StrDesc;
    }



//#define MODE_SENSE6_LEN                   8
//#define MODE_SENSE10_LEN                  8
#define LENGTH_INQUIRY_PAGE00               7
//#define LENGTH_FORMAT_CAPACITIES          20


LOCAL(VOID) SCSI_SenseCode(USBD_HandleTypeDef *USBD, UINT Lun, UINT Key, UINT ASC)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->ScsiSense[MSC->ScsiSenseTail].Skey=Key;
    MSC->ScsiSense[MSC->ScsiSenseTail].w.ASC=ASC<<8;
    MSC->ScsiSenseTail++;
    if (MSC->ScsiSenseTail==SENSE_LIST_DEEPTH) MSC->ScsiSenseTail=0;
    }


LOCAL(int) SCSI_TestUnitReady(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (MSC->CBW.DataLen!=0)
        {
        SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
        return -1;
        }

    if (STORAGE_IsReady(Lun)==FALSE)
        {
        SCSI_SenseCode(USBD, Lun, NOT_READY, MEDIUM_NOT_PRESENT);
        MSC->BotState=USBD_BOT_NO_DATA;
        return -1;
        }
    MSC->BotDataLen=0;
    return 0;
    }



LOCAL(int) SCSI_Inquiry(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    LPBYTE pPage;
    UINT Len;
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    static const BYTE MSC_Page00_Inquiry_Data[]=
        {
        0x00,
        0x00,
        0x00,
        LENGTH_INQUIRY_PAGE00-4,
        0x00,
        0x80,
        0x83
        };


    if (Params[1]&1)
        {
        Len=LENGTH_INQUIRY_PAGE00;
        MSC->BotDataLen=Len;
        while (Len)
            {
            Len--;
            MSC->BotData[Len]=MSC_Page00_Inquiry_Data[Len];
            }
        }
    else{
        pPage=(LPBYTE)&STORAGE_Inquirydata[Lun*STANDARD_INQUIRY_DATA_LEN];
        Len=pPage[4]+5;

        if (Params[4]<=Len) Len=Params[4];
        MSC->BotDataLen=Len;

        while (Len)
            {
            Len--;
            MSC->BotData[Len]=pPage[Len];
            }
        }

    return 0;
    }



LOCAL(int) SCSI_ReadCapacity10(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (STORAGE_GetCapacity(Lun, &MSC->ScsiBlkQty, &MSC->ScsiBlkSize)==FALSE)
        {
        SCSI_SenseCode(USBD, Lun, NOT_READY, MEDIUM_NOT_PRESENT);
        return -1;
        }
    else{
        PokeBI(MSC->BotData+0, MSC->ScsiBlkQty-1);
        PokeBI(MSC->BotData+4, MSC->ScsiBlkSize);
        MSC->BotDataLen=8;
        return 0;
        }
    }


LOCAL(int) SCSI_ReadFormatCapacity(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    UINT  BlkSize;
    DWORD BlkQty;
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    ZeroMem(MSC->BotData, 12);

    if (STORAGE_GetCapacity(Lun, &BlkQty, &BlkSize)==FALSE)
        {
        SCSI_SenseCode(USBD, Lun, NOT_READY, MEDIUM_NOT_PRESENT);
        return -1;
        }
    else{
        MSC->BotData[3]=8;
        PokeBI(MSC->BotData+4, BlkQty-1);

        MSC->BotData[8]=2;
        MSC->BotData[9]=(BYTE)(BlkSize>>16);
        MSC->BotData[10]=(BYTE)(BlkSize>>8);
        MSC->BotData[11]=(BYTE)(BlkSize);

        MSC->BotDataLen=12;
        return 0;
        }
    }


LOCAL(int) SCSI_ModeSense6(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    static const BYTE MSC_Mode_Sense6_data[]=
        {
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00
        };

    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    UINT Len=8;
    MSC->BotDataLen=Len;

    while (Len)
        {
        Len--;
        MSC->BotData[Len]=MSC_Mode_Sense6_data[Len];
        }
    return 0;
    }



LOCAL(int) SCSI_ModeSense10(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    static const BYTE MSC_Mode_Sense10_data[]=
        {
        0x00,
        0x06,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00
        };

    UINT Len=8;
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->BotDataLen=Len;
    while (Len)
        {
        Len--;
        MSC->BotData[Len]=MSC_Mode_Sense10_data[Len];
        }
    return 0;
    }




LOCAL(int) SCSI_RequestSense(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    ZeroMem(MSC->BotData, REQUEST_SENSE_DATA_LEN);

    MSC->BotData[0]=0x70;
    MSC->BotData[7]=REQUEST_SENSE_DATA_LEN-6;

    if ((MSC->ScsiSenseHead!=MSC->ScsiSenseTail))
        {
        MSC->BotData[2]=MSC->ScsiSense[MSC->ScsiSenseHead].Skey;
        MSC->BotData[12]=MSC->ScsiSense[MSC->ScsiSenseHead].w.b.ASCQ;
        MSC->BotData[13]=MSC->ScsiSense[MSC->ScsiSenseHead].w.b.ASC;
        MSC->ScsiSenseHead++;

        if (MSC->ScsiSenseHead==SENSE_LIST_DEEPTH) MSC->ScsiSenseHead=0;
        }
    MSC->BotDataLen=REQUEST_SENSE_DATA_LEN;

    if (Params[4]<=REQUEST_SENSE_DATA_LEN) MSC->BotDataLen=Params[4];
    return 0;
    }



LOCAL(int) SCSI_StartStopUnit(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    ((USBD_MSC_BOT*)USBD->ClassData)->BotDataLen=0;
    return 0;
    }



LOCAL(int) SCSI_CheckAddressRange(USBD_HandleTypeDef *USBD, UINT Lun, UINT BlkOffset, UINT BlkQty)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (BlkOffset+BlkQty > MSC->ScsiBlkQty)
        {
        SCSI_SenseCode(USBD, Lun, ILLEGAL_REQUEST, ADDRESS_OUT_OF_RANGE);
        return -1;
        }
    return 0;
    }



LOCAL(int) SCSI_ProcessRead(USBD_HandleTypeDef *USBD, UINT Lun)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    UINT Len, BlkQty;

    Len=GetMin(MSC->ScsiBlkLen*MSC->ScsiBlkSize, MSC_MEDIA_PACKET);
    BlkQty=Len/MSC->ScsiBlkSize;

    if (STORAGE_Read(Lun, MSC->BotData, MSC->ScsiBlkAddr, BlkQty)==FALSE)
        {
        SCSI_SenseCode(USBD, Lun, HARDWARE_ERROR, UNRECOVERED_READ_ERROR);
        return -1;
        }

    USBD_LL_Transmit(USBD, MSC_EPIN_ADDR, MSC->BotData, Len);

    MSC->ScsiBlkAddr+=BlkQty;
    MSC->ScsiBlkLen-=BlkQty;
    MSC->CSW.DataResidue-=Len;

    if (MSC->ScsiBlkLen==0) MSC->BotState=USBD_BOT_LAST_DATA_IN;
    return 0;
    }




LOCAL(int) SCSI_Read10(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (MSC->BotState==USBD_BOT_IDLE)
        {
        if ((MSC->CBW.Flags&0x80)==0)
            {
            SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
            return -1;
            }

        if (STORAGE_IsReady(Lun)==FALSE)
            {
            SCSI_SenseCode(USBD, Lun, NOT_READY, MEDIUM_NOT_PRESENT);
            return -1;
            }

        MSC->ScsiBlkAddr=PeekBI(Params+2);
        MSC->ScsiBlkLen=PeekBIW(Params+7);
        if (SCSI_CheckAddressRange(USBD, Lun, MSC->ScsiBlkAddr, MSC->ScsiBlkLen)<0) return -1;

        MSC->BotState=USBD_BOT_DATA_IN;

        if (MSC->CBW.DataLen!=MSC->ScsiBlkLen*MSC->ScsiBlkSize)
            {
            SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
            return -1;
            }
        }
    MSC->BotDataLen=MSC_MEDIA_PACKET;
    return SCSI_ProcessRead(USBD, Lun);
    }




LOCAL(VOID) MSC_BOT_SendCSW(USBD_HandleTypeDef *USBD, UINT CSW_Status)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->CSW.Sign=USBD_BOT_CSW_SIGNATURE;
    MSC->CSW.Status=CSW_Status;
    MSC->BotState=USBD_BOT_IDLE;
    USBD_LL_Transmit(USBD, MSC_EPIN_ADDR, (LPBYTE)&MSC->CSW, USBD_BOT_CSW_LENGTH);
    USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, (LPBYTE)&MSC->CBW, USBD_BOT_CBW_LENGTH);
    }




LOCAL(int) SCSI_ProcessWrite(USBD_HandleTypeDef *USBD, UINT Lun)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    UINT Len, BlkQty;

    Len=GetMin(MSC->ScsiBlkLen*MSC->ScsiBlkSize, MSC_MEDIA_PACKET);
    BlkQty=Len/MSC->ScsiBlkSize;

    if (STORAGE_Write(Lun, MSC->BotData, MSC->ScsiBlkAddr, BlkQty)==FALSE)
        {
        SCSI_SenseCode(USBD, Lun, HARDWARE_ERROR, WRITE_FAULT);
        return -1;
        }

    MSC->ScsiBlkAddr+=BlkQty;
    MSC->ScsiBlkLen-=BlkQty;
    MSC->CSW.DataResidue-=Len;

    if (MSC->ScsiBlkLen==0)
        {
        MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_PASSED);
        }
    else{
        Len=GetMin(MSC->ScsiBlkLen*MSC->ScsiBlkSize, MSC_MEDIA_PACKET);
        USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, MSC->BotData, Len);
        }

    return 0;
    }




LOCAL(int) SCSI_Write10(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    UINT Len;

    if (MSC->BotState==USBD_BOT_IDLE)
        {
        if (MSC->CBW.Flags & 0x80)
            {
            SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
            return -1;
            }

        if (STORAGE_IsReady(Lun)==FALSE)
            {
            SCSI_SenseCode(USBD, Lun, NOT_READY, MEDIUM_NOT_PRESENT);
            return -1;
            }

        if (STORAGE_IsWriteProtected(Lun))
            {
            SCSI_SenseCode(USBD, Lun, NOT_READY, WRITE_PROTECTED);
            return -1;
            }

        MSC->ScsiBlkAddr=PeekBI(Params+2);
        MSC->ScsiBlkLen=PeekBIW(Params+7);

        if (SCSI_CheckAddressRange(USBD, Lun, MSC->ScsiBlkAddr, MSC->ScsiBlkLen)<0) return -1;
        Len=MSC->ScsiBlkLen*MSC->ScsiBlkSize;

        if (MSC->CBW.DataLen!=Len)
            {
            SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
            return -1;
            }

        MSC->BotState=USBD_BOT_DATA_OUT;
        USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, MSC->BotData, GetMin(Len, MSC_MEDIA_PACKET));
        }
    else return SCSI_ProcessWrite(USBD, Lun);
    return 0;
    }





LOCAL(int) SCSI_Verify10(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE Params)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (Params[1] & 2)
        {
        SCSI_SenseCode(USBD, Lun, ILLEGAL_REQUEST, INVALID_FIELED_IN_COMMAND);
        return -1;
        }

    if (SCSI_CheckAddressRange(USBD, Lun, MSC->ScsiBlkAddr, MSC->ScsiBlkLen)<0) return -1;
    MSC->BotDataLen=0;
    return 0;
    }



LOCAL(int) SCSI_ProcessCmd(USBD_HandleTypeDef *USBD, UINT Lun, LPBYTE cmd)
    {
    switch (cmd[0])
        {
        case SCSI_TEST_UNIT_READY:  SCSI_TestUnitReady(USBD, Lun, cmd); break;
        case SCSI_REQUEST_SENSE:    SCSI_RequestSense(USBD, Lun, cmd); break;
        case SCSI_INQUIRY:          SCSI_Inquiry(USBD, Lun, cmd); break;
        case SCSI_START_STOP_UNIT:  SCSI_StartStopUnit(USBD, Lun, cmd); break;
        case SCSI_ALLOW_MEDIUM_REMOVAL: SCSI_StartStopUnit(USBD, Lun, cmd); break;
        case SCSI_MODE_SENSE6:      SCSI_ModeSense6(USBD, Lun, cmd); break;
        case SCSI_MODE_SENSE10:     SCSI_ModeSense10(USBD, Lun, cmd); break;
        case SCSI_READ_FORMAT_CAPACITIES: SCSI_ReadFormatCapacity(USBD, Lun, cmd); break;
        case SCSI_READ_CAPACITY10:  SCSI_ReadCapacity10(USBD, Lun, cmd); break;
        case SCSI_READ10:           SCSI_Read10(USBD, Lun, cmd); break;
        case SCSI_WRITE10:          SCSI_Write10(USBD, Lun, cmd); break;
        case SCSI_VERIFY10:         SCSI_Verify10(USBD, Lun, cmd); break;
        default:
            SCSI_SenseCode(USBD, Lun, ILLEGAL_REQUEST, INVALID_CDB);
            return -1;
        }
    return 0;
    }






static __ALIGN_BEGIN BYTE USBD_MSC_CfgHSDesc[USB_MSC_CONFIG_DESC_SIZ]__ALIGN_END=
    {
    0x09,
    USB_DESC_TYPE_CONFIGURATION,
    USB_MSC_CONFIG_DESC_SIZ,

    0x00,
    0x01,
    0x01,
    0x04,
    0xC0,
    0x32,

    0x09,
    0x04,
    0x00,
    0x00,
    0x02,
    0x08,
    0x06,
    0x50,
    0x05,
    0x07,
    0x05,
    MSC_EPIN_ADDR,
    0x02,
    LoByte(MSC_MAX_HS_PACKET),
    HiByte(MSC_MAX_HS_PACKET),
    0x00,

    0x07,
    0x05,
    MSC_EPOUT_ADDR,
    0x02,
    LoByte(MSC_MAX_HS_PACKET),
    HiByte(MSC_MAX_HS_PACKET),
    0x00
    };



static BYTE USBD_MSC_CfgFSDesc[USB_MSC_CONFIG_DESC_SIZ]__ALIGN_END=
    {
    0x09,
    USB_DESC_TYPE_CONFIGURATION,
    USB_MSC_CONFIG_DESC_SIZ,

    0x00,
    0x01,
    0x01,
    0x04,
    0xC0,
    0x32,

    0x09,
    0x04,
    0x00,
    0x00,
    0x02,
    0x08,
    0x06,
    0x50,
    0x05,
    0x07,
    0x05,
    MSC_EPIN_ADDR,
    0x02,
    LoByte(MSC_MAX_FS_PACKET),
    HiByte(MSC_MAX_FS_PACKET),
    0x00,

    0x07,
    0x05,
    MSC_EPOUT_ADDR,
    0x02,
    LoByte(MSC_MAX_FS_PACKET),
    HiByte(MSC_MAX_FS_PACKET),
    0x00
    };



static __ALIGN_BEGIN BYTE USBD_MSC_OtherSpeedCfgDesc[USB_MSC_CONFIG_DESC_SIZ]__ALIGN_END=
    {
    0x09,
    USB_DESC_TYPE_OTHER_SPEED_CONFIGURATION,
    USB_MSC_CONFIG_DESC_SIZ,

    0x00,
    0x01,
    0x01,
    0x04,
    0xC0,
    0x32,

    0x09,
    0x04,
    0x00,
    0x00,
    0x02,
    0x08,
    0x06,
    0x50,
    0x05,
    0x07,
    0x05,
    MSC_EPIN_ADDR,
    0x02,
    0x40,
    0x00,
    0x00,

    0x07,
    0x05,
    MSC_EPOUT_ADDR,
    0x02,
    0x40,
    0x00,
    0x00
    };



static __ALIGN_BEGIN BYTE USBD_MSC_DeviceQualifierDesc[USB_LEN_DEV_QUALIFIER_DESC]__ALIGN_END=
    {
    USB_LEN_DEV_QUALIFIER_DESC,
    USB_DESC_TYPE_DEVICE_QUALIFIER,
    0x00,
    0x02,
    0x00,
    0x00,
    0x00,
    MSC_MAX_FS_PACKET,
    0x01,
    0x00,
    };




LOCAL(VOID) MSC_BOT_Init(USBD_HandleTypeDef *USBD)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->BotState=USBD_BOT_IDLE;
    MSC->BotStatus=USBD_BOT_STATUS_NORMAL;
    MSC->ScsiSenseTail=0;
    MSC->ScsiSenseHead=0;

    STORAGE_Init(0);

    USBD_LL_FlushEP(USBD, MSC_EPOUT_ADDR);
    USBD_LL_FlushEP(USBD, MSC_EPIN_ADDR);

    USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, (LPBYTE)&MSC->CBW, USBD_BOT_CBW_LENGTH);
    }



LOCAL(VOID) MSC_BOT_Reset(USBD_HandleTypeDef *USBD)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->BotState=USBD_BOT_IDLE;
    MSC->BotStatus=USBD_BOT_STATUS_RECOVERY;
    USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, (LPBYTE)&MSC->CBW, USBD_BOT_CBW_LENGTH);
    }



LOCAL(VOID) MSC_BOT_DeInit(USBD_HandleTypeDef *USBD)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    MSC->BotState=USBD_BOT_IDLE;
    }



LOCAL(VOID) MSC_BOT_DataIn(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    switch (MSC->BotState)
        {
        case USBD_BOT_DATA_IN:
            if (SCSI_ProcessCmd(USBD, MSC->CBW.Lun, MSC->CBW.CB)<0)
                MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_FAILED);
            break;

        case USBD_BOT_SEND_DATA:
        case USBD_BOT_LAST_DATA_IN:
            MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_PASSED);
            //break;
        }
    }


LOCAL(VOID) MSC_BOT_Abort(USBD_HandleTypeDef *USBD)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (MSC->CBW.Flags==0 &&
        MSC->CBW.DataLen!=0 &&
        MSC->BotStatus==USBD_BOT_STATUS_NORMAL)
        {
        USBD_LL_StallEP(USBD, MSC_EPOUT_ADDR);
        }

    USBD_LL_StallEP(USBD, MSC_EPIN_ADDR);

    if (MSC->BotStatus==USBD_BOT_STATUS_ERROR)
        {
        USBD_LL_PrepareReceive(USBD, MSC_EPOUT_ADDR, (LPBYTE)&MSC->CBW, USBD_BOT_CBW_LENGTH);
        }
    }




LOCAL(VOID) MSC_BOT_SendData(USBD_HandleTypeDef *USBD, LPBYTE pbuf, UINT Len)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->CSW.DataResidue-=Len;
    MSC->CSW.Status=USBD_CSW_CMD_PASSED;
    MSC->BotState=USBD_BOT_SEND_DATA;
    USBD_LL_Transmit(USBD, MSC_EPIN_ADDR, pbuf, GetMin(MSC->CBW.DataLen, Len));
    }



LOCAL(VOID) MSC_BOT_CBW_Decode(USBD_HandleTypeDef *USBD)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    MSC->CSW.Tag=MSC->CBW.Tag;
    MSC->CSW.DataResidue=MSC->CBW.DataLen;

    if (USBD_LL_GetRxDataSize(USBD, MSC_EPOUT_ADDR)!=USBD_BOT_CBW_LENGTH ||
        MSC->CBW.Sign!=USBD_BOT_CBW_SIGNATURE ||
        MSC->CBW.Lun>1 || MSC->CBW.Length<1 || MSC->CBW.Length>16)
        {
        SCSI_SenseCode(USBD, MSC->CBW.Lun, ILLEGAL_REQUEST, INVALID_CDB);
        MSC->BotStatus=USBD_BOT_STATUS_ERROR;
        MSC_BOT_Abort(USBD);
        }
    else{
        if (SCSI_ProcessCmd(USBD, MSC->CBW.Lun, MSC->CBW.CB)<0)
            {
            if (MSC->BotState==USBD_BOT_NO_DATA)
                MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_FAILED);
            else
                MSC_BOT_Abort(USBD);
            }
        else if (MSC->BotState!=USBD_BOT_DATA_IN &&
                 MSC->BotState!=USBD_BOT_DATA_OUT &&
                 MSC->BotState!=USBD_BOT_LAST_DATA_IN)
            {
            if (MSC->BotDataLen>0)
                MSC_BOT_SendData(USBD, MSC->BotData, MSC->BotDataLen);
            else if (MSC->BotDataLen==0)
                MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_PASSED);
            else
                MSC_BOT_Abort(USBD);
            }
        }
    }



LOCAL(VOID) MSC_BOT_CplClrFeature(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    if (MSC->BotStatus==USBD_BOT_STATUS_ERROR)
        {
        USBD_LL_StallEP(USBD, MSC_EPIN_ADDR);
        MSC->BotStatus=USBD_BOT_STATUS_NORMAL;
        }
    else if ((EpNo&0x80)!=0 && MSC->BotStatus!=USBD_BOT_STATUS_RECOVERY)
        {
        MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_FAILED);
        }
    }




LOCAL(VOID) MSC_BOT_DataOut(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;

    switch (MSC->BotState)
        {
        case USBD_BOT_IDLE:
            MSC_BOT_CBW_Decode(USBD);
            break;

        case USBD_BOT_DATA_OUT:
            if (SCSI_ProcessCmd(USBD, MSC->CBW.Lun, MSC->CBW.CB)<0)
                MSC_BOT_SendCSW(USBD, USBD_CSW_CMD_FAILED);
            //break;
        }
    }





LOCAL(UINT) USBD_MSC_Init(USBD_HandleTypeDef *USBD, UINT CfgIdx)
    {
    if (USBD->DevSpeed==USBD_SPEED_HIGH)
        {
        USBD_LL_OpenEP(USBD, MSC_EPOUT_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_HS_PACKET);
        USBD->EpOut[MSC_EPOUT_ADDR&0x0F].is_used=1;

        USBD_LL_OpenEP(USBD, MSC_EPIN_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_HS_PACKET);
        USBD->EpIn[MSC_EPIN_ADDR&0x0F].is_used=1;
        }
    else{
        USBD_LL_OpenEP(USBD, MSC_EPOUT_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_FS_PACKET);
        USBD->EpOut[MSC_EPOUT_ADDR&0x0F].is_used=1;

        USBD_LL_OpenEP(USBD, MSC_EPIN_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_FS_PACKET);
        USBD->EpIn[MSC_EPIN_ADDR&0x0F].is_used=1;
        }

    if ((USBD->ClassData=AllocMem(sizeof(USBD_MSC_BOT), MEMOWNER_USB_MSC))==NULL) return USBD_FAIL;
    MSC_BOT_Init(USBD);

    return USBD_OK;
    }



LOCAL(UINT) USBD_MSC_DeInit(USBD_HandleTypeDef *USBD, UINT CfgIdx)
    {
    USBD_LL_CloseEP(USBD, MSC_EPOUT_ADDR);
    USBD->EpOut[MSC_EPOUT_ADDR&0x0F].is_used=0;

    USBD_LL_CloseEP(USBD, MSC_EPIN_ADDR);
    USBD->EpIn[MSC_EPIN_ADDR&0x0F].is_used=0;

    MSC_BOT_DeInit(USBD);

    if (USBD->ClassData!=NULL)
        {
        FreeMem(USBD->ClassData);
        USBD->ClassData=NULL;
        }
    return USBD_OK;
    }


LOCAL(UINT) USBD_MSC_Setup(USBD_HandleTypeDef *USBD, USBD_SetupReq*Req)
    {
    USBD_MSC_BOT *MSC=(USBD_MSC_BOT*)USBD->ClassData;
    UINT Rslt=USBD_OK;
    WORD StatusInfo=0;

    switch (Req->bmRequest & USB_REQ_TYPE_MASK)
        {
        case USB_REQ_TYPE_CLASS:
            switch (Req->bRequest)
                {
                case BOT_GET_MAX_LUN:
                    if (Req->wValue==0 && Req->wLength==1 && (Req->bmRequest&0x80)!=0)
                        {
                        MSC->MaxLun=STORAGE_GetMaxLun();
                        USBD_CtlSendData(USBD, (LPBYTE)&MSC->MaxLun, 1);
                        }
                    else{
                        USBD_CtlError(USBD, Req);
                        Rslt=USBD_FAIL;
                        }
                    break;

                case BOT_RESET:
                    if (Req->wValue==0 && Req->wLength==0 && (Req->bmRequest&0x80)==0)
                        MSC_BOT_Reset(USBD);
                    else{
                        USBD_CtlError(USBD, Req);
                        Rslt=USBD_FAIL;
                        }
                    break;

                default:
                    USBD_CtlError(USBD, Req);
                    Rslt=USBD_FAIL;
                    //break;
                }
            break;

        case USB_REQ_TYPE_STANDARD:
            switch (Req->bRequest)
                {
                case USB_REQ_GET_STATUS:
                    if (USBD->DevState==USBD_STATE_CONFIGURED)
                        USBD_CtlSendData(USBD, (LPBYTE)&StatusInfo, 2);
                    else{
                        USBD_CtlError(USBD, Req);
                        Rslt=USBD_FAIL;
                        }
                    break;

                case USB_REQ_GET_INTERFACE:
                    if (USBD->DevState==USBD_STATE_CONFIGURED)
                        USBD_CtlSendData(USBD, (LPBYTE)&MSC->Interface, 1);
                    else{
                        USBD_CtlError(USBD, Req);
                        Rslt=USBD_FAIL;
                        }
                    break;

                case USB_REQ_SET_INTERFACE:
                    if (USBD->DevState==USBD_STATE_CONFIGURED)
                        MSC->Interface=(BYTE)Req->wValue;
                    else{
                        USBD_CtlError(USBD, Req);
                        Rslt=USBD_FAIL;
                        }
                    break;

                case USB_REQ_CLEAR_FEATURE:
                    USBD_LL_FlushEP(USBD, Req->wIndex);
                    USBD_LL_CloseEP(USBD, Req->wIndex);
                    if (Req->wIndex & 0x80)
                        {
                        USBD->EpIn[Req->wIndex&0x0F].is_used=0;
                        if (USBD->DevSpeed==USBD_SPEED_HIGH)
                            USBD_LL_OpenEP(USBD, MSC_EPIN_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_HS_PACKET);
                        else
                            USBD_LL_OpenEP(USBD, MSC_EPIN_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_FS_PACKET);
                        USBD->EpIn[MSC_EPIN_ADDR&0x0F].is_used=1;
                        }
                    else{
                        USBD->EpOut[Req->wIndex&0x0F].is_used=0;
                        if (USBD->DevSpeed==USBD_SPEED_HIGH)
                            USBD_LL_OpenEP(USBD, MSC_EPOUT_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_HS_PACKET);
                        else
                            USBD_LL_OpenEP(USBD, MSC_EPOUT_ADDR, USBD_EP_TYPE_BULK, MSC_MAX_FS_PACKET);
                        USBD->EpOut[MSC_EPOUT_ADDR&0x0F].is_used=1;
                        }

                    MSC_BOT_CplClrFeature(USBD, Req->wIndex);
                    break;

                default:
                    USBD_CtlError(USBD, Req);
                    Rslt=USBD_FAIL;
                    //break;
                }
            break;

        default:
            USBD_CtlError(USBD, Req);
            Rslt=USBD_FAIL;
            //break;
        }

    return Rslt;
    }



LOCAL(UINT) USBD_MSC_DataIn(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    MSC_BOT_DataIn(USBD, EpNo);
    return USBD_OK;
    }



LOCAL(UINT) USBD_MSC_DataOut(USBD_HandleTypeDef *USBD, UINT EpNo)
    {
    MSC_BOT_DataOut(USBD, EpNo);
    return USBD_OK;
    }



LOCAL(LPBYTE) USBD_MSC_GetHSCfgDesc(UINT *lpLen)
    {
    *lpLen=sizeof(USBD_MSC_CfgHSDesc);
    return USBD_MSC_CfgHSDesc;
    }



LOCAL(LPBYTE) USBD_MSC_GetFSCfgDesc(UINT *lpLen)
    {
    *lpLen=sizeof(USBD_MSC_CfgFSDesc);
    return USBD_MSC_CfgFSDesc;
    }



LOCAL(LPBYTE) USBD_MSC_GetOtherSpeedCfgDesc(UINT *lpLen)
    {
    *lpLen=sizeof(USBD_MSC_OtherSpeedCfgDesc);
    return USBD_MSC_OtherSpeedCfgDesc;
    }


LOCAL(LPBYTE) USBD_MSC_GetDeviceQualifierDesc(UINT *lpLen)
    {
    *lpLen=sizeof(USBD_MSC_DeviceQualifierDesc);
    return USBD_MSC_DeviceQualifierDesc;
    }





///////////////////////////////////////////////////////////////////////////////
//          USB ���丮�� Ŭ���� ����
///////////////////////////////////////////////////////////////////////////////


static PCD_HandleTypeDef G_hPcd;



VOID HAL_PCD_SuspendCallback(PCD_HandleTypeDef *hPcd)
    {
    USBD_LL_Suspend(hPcd->pData);
    }



VOID HAL_PCD_ResumeCallback(PCD_HandleTypeDef *hPcd)
    {
    USBD_LL_Resume(hPcd->pData);
    }




//-----------------------------------------------------------------------------
//      usbd_core.c ... USBD_Init() ���� ȣ����
//-----------------------------------------------------------------------------
USBD_StatusTypeDef USBD_LL_Init(USBD_HandleTypeDef *USBD)
    {
    #ifdef USE_USB_FS
    __HAL_RCC_USB_OTG_FS_CLK_ENABLE();

    G_hPcd.Instance=USB_OTG_FS;
    G_hPcd.Init.dev_endpoints=6;
    G_hPcd.Init.use_dedicated_ep1=0;
    G_hPcd.Init.dma_enable=0;
    G_hPcd.Init.low_power_enable=0;
    G_hPcd.Init.phy_itface=PCD_PHY_EMBEDDED;
    G_hPcd.Init.Sof_enable=0;
    G_hPcd.Init.speed=PCD_SPEED_FULL;
    G_hPcd.Init.vbus_sensing_enable=0;
    G_hPcd.Init.lpm_enable=0;
    G_hPcd.pData=USBD;
    USBD->Data=&G_hPcd;
    HAL_PCD_Init(&G_hPcd);

    HAL_NVIC_SetPriority(OTG_FS_IRQn, 7, 0);
    NVIC_EnableIRQ(OTG_FS_IRQn);

    PCDEx_SetRxFiFo(G_hPcd.Instance, 0x80);
    PCDEx_SetTxFiFo(G_hPcd.Instance, 0, 0x40);
    PCDEx_SetTxFiFo(G_hPcd.Instance, 1, 0x80);
    #endif

    #ifdef USE_USB_HS
    __HAL_RCC_USB_OTG_HS_ULPI_CLK_ENABLE();
    __HAL_RCC_USB_OTG_HS_CLK_ENABLE();

    G_hPcd.Instance=USB_OTG_HS;
    G_hPcd.Init.dev_endpoints=9;
    G_hPcd.Init.use_dedicated_ep1=0;
    G_hPcd.Init.dma_enable=0;
    G_hPcd.Init.low_power_enable=0;
    G_hPcd.Init.lpm_enable=0;
    G_hPcd.Init.phy_itface=PCD_PHY_ULPI;
    G_hPcd.Init.Sof_enable=0;
    G_hPcd.Init.speed=PCD_SPEED_HIGH;
    G_hPcd.Init.vbus_sensing_enable=1;
    G_hPcd.pData=USBD;
    USBD->Data=&G_hPcd;
    HAL_PCD_Init(&G_hPcd);

    HAL_NVIC_SetPriority(OTG_HS_IRQn, 7, 0);
    NVIC_EnableIRQ(OTG_HS_IRQn);

    PCDEx_SetRxFiFo(G_hPcd.Instance, 0x200);
    PCDEx_SetTxFiFo(G_hPcd.Instance, 0, 0x80);
    PCDEx_SetTxFiFo(G_hPcd.Instance, 1, 0x174);
    #endif

    return USBD_OK;
    }



//-----------------------------------------------------------------------------
//      USB MSC Class �ʱ�ȭ
//-----------------------------------------------------------------------------
VOID WINAPI USBD_MSC_Start(VOID)
    {
    static USBD_DescriptorsTypeDef MSC_Desc=
        {
        USBD_MSC_DeviceDescriptor,          //GetDeviceDescriptor()
        USBD_MSC_LangIDStrDescriptor,       //GetLangIDStrDescriptor()
        USBD_MSC_ManufacturerStrDescriptor, //GetManufacturerStrDescriptor()
        USBD_MSC_ProductStrDescriptor,      //GetProductStrDescriptor()
        USBD_MSC_SerialStrDescriptor,       //GetSerialStrDescriptor()
        USBD_MSC_ConfigStrDescriptor,       //GetConfigurationStrDescriptor()
        USBD_MSC_InterfaceStrDescriptor,    //GetInterfaceStrDescriptor()
        };

    static USBD_ClassTypeDef USBD_MSC_Class=
        {
        USBD_MSC_Init,                      //Init()
        USBD_MSC_DeInit,                    //DeInit()
        USBD_MSC_Setup,                     //Setup()
        NULL,                               //EP0_TxSent()
        NULL,                               //EP0_RxReady()
        USBD_MSC_DataIn,                    //DataIn() ... Device -> PC
        USBD_MSC_DataOut,                   //DataOut()
        NULL,                               //SOF()
        NULL,                               //IsoINIncomplete()
        NULL,                               //IsoOUTIncomplete()
        USBD_MSC_GetHSCfgDesc,              //GetHSConfigDescriptor()
        USBD_MSC_GetFSCfgDesc,              //GetFSConfigDescriptor()
        USBD_MSC_GetOtherSpeedCfgDesc,      //GetOtherSpeedConfigDescriptor()
        USBD_MSC_GetDeviceQualifierDesc,    //GetDeviceQualifierDescriptor()
        };

    static USBD_HandleTypeDef USBD_Device;

    USBD_Init(&USBD_Device, &MSC_Desc, 0);      //USBD_LL_Init()ȣ����
    USBD_RegisterClass(&USBD_Device, &USBD_MSC_Class);
    USBD_Start(&USBD_Device);
    }



#ifdef USE_USB_FS
VOID OTG_FS_IRQHandler(VOID)
#else
VOID OTG_HS_IRQHandler(VOID)
#endif
    {
    JOSIntEnter();
    HAL_PCD_IRQHandler(&G_hPcd);
    JOSIntExit();
    }




