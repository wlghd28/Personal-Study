
#ifndef __USBD_CONF_H
#define __USBD_CONF_H

#define USBD_MAX_NUM_INTERFACES               1
#define USBD_MAX_NUM_CONFIGURATION            1
#define USBD_MAX_STR_DESC_SIZ                 0x100
#define USBD_SUPPORT_USER_STRING              0
#define USBD_SELF_POWERED                     1
#define USBD_DEBUG_LEVEL                      0

#define MSC_MEDIA_PACKET                      512


#if (USBD_DEBUG_LEVEL>1)
#define USBD_ErrLog(...)   printf("ERROR: "); printf(__VA_ARGS__); printf("\n");
#else
#define USBD_ErrLog(...)
#endif


#if !defined(USE_USB_HS) && !defined(USE_USB_FS)
#error "Either USE_USB_HS or USE_USB_FS must be declared."
#endif



//��������� �ϴ� �Լ�
BOOL WINAPI STORAGE_Init(UINT LogUnitNo);
BOOL WINAPI STORAGE_GetCapacity(UINT LogUnitNo, DWORD *lpBlockQty, UINT *lpBlockSize);
BOOL WINAPI STORAGE_IsReady(UINT LogUnitNo);
BOOL WINAPI STORAGE_IsWriteProtected(UINT LogUnitNo);
BOOL WINAPI STORAGE_Read(UINT LogUnitNo, LPBYTE Buff, DWORD BlockAddr, UINT BlockLen);
BOOL WINAPI STORAGE_Write(UINT LogUnitNo, LPCBYTE Buff, DWORD BlockAddr, UINT BlockLen);
int  WINAPI STORAGE_GetMaxLun(VOID);
VOID WINAPI STORAGE_AutoFlush(UINT LogUnitNo, BOOL NowFlush);


#endif

