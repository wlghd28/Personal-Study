
#include "JLIB.H"
#include "JWSOCK.H"
#include "SHA1.H"
#include "RESOURCE.H"


extern CONST CHAR GetHttpAgentName[]="FindMp3/3.03";


#define RCVBUFFSIZE             10000
#define SCRAMBLE_LENGTH         20
#define WSA_READCLOSECLNT               (WM_USER+100)


#define MEMOWNER_ClientSockTestInitDlg  (MEMOWNER_APP+0)
#define MEMOWNER_RcvBuffer1             (MEMOWNER_APP+1)
#define MEMOWNER_RcvBuffer2             (MEMOWNER_APP+2)
#define MEMOWNER_ClntSockTestConnBTID   (MEMOWNER_APP+3)
#define MEMOWNER_MakeAuthenticationPacket (MEMOWNER_APP+4)
#define MEMOWNER_AutoSendMySquAuthPacket  (MEMOWNER_APP+5)
#define MEMOWNER_UdpSendReceive         (MEMOWNER_APP+6)
#define MEMOWNER_SetHttpHeaderCmdID     (MEMOWNER_APP+7)



//-----------------------------------------------------------------------------
//      ���¹��ڿ��� ���â�� ǥ��
//-----------------------------------------------------------------------------
LOCAL(VOID) DispRecvWindow(HWND hWnd, LPCSTR Msg)
    {
    EB_AddStr(hWnd, ClntSockTestReceivedEBID, Msg);
    }



//-----------------------------------------------------------------------------
//      ���Լ��� MySql�� �α����� �� ��ȣ�� ��ũ���� �ϴ� �Լ���
//      mysql-4.1.12.tar.gz ������ ���̸�:scramble
//      Message�� ���̴� 20Byte��
//      Message�� ������ �������� ���� ���� Authentication ��
//      Offset 14h 8���ڿ� Offset 2Fh�� 12���ڸ� ��ģ ���ڿ���
//-----------------------------------------------------------------------------
VOID WINAPI ScramblePassword(LPBYTE Buff, LPCSTR Password, LPCBYTE Message)
    {
    BYTE H1[SHA1_HASH_SIZE];
    BYTE H2[SCRAMBLE_LENGTH+SHA1_HASH_SIZE];

    CopyMem(H2, Message, SCRAMBLE_LENGTH);
    SHA1_ShortCalc(H1, Password, lstrlen(Password));
    SHA1_ShortCalc(H2+SCRAMBLE_LENGTH, H1, SHA1_HASH_SIZE);
    SHA1_ShortCalc(Buff, H2, SCRAMBLE_LENGTH+SHA1_HASH_SIZE);
    XorMem(Buff, H1, SCRAMBLE_LENGTH);
    }



//-----------------------------------------------------------------------------
//      MySQL Authentication Packet �� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) SendAuthenticationPacket(SOCKET hSocket, LPCSTR UserID, LPCSTR Psw, LPCSTR RandomStr)
    {
    int Size;
    LPSTR lp, lpMem, ScrambledPsw;

    ALLOCMEM2(lpMem, RCVBUFFSIZE,
              ScrambledPsw ,SHA1_HASH_SIZE,
              MEMOWNER_MakeAuthenticationPacket, ProcExit);

    ScramblePassword((LPBYTE)ScrambledPsw, Psw, (LPCBYTE)RandomStr);

    ZeroMem(lpMem, 0x0024);
    PTODWORD(lpMem+4)=0xA285;
    PTODWORD(lpMem+8)=0x40000000;
    lpMem[0x000C]=8;
    lstrcpy(lpMem+0x0024, UserID);
    lp=(LPSTR)GetNextStr(lpMem+0x0024);
    *lp++=SCRAMBLE_LENGTH;
    CopyMem(lp, ScrambledPsw, SHA1_HASH_SIZE);
    lp+=SHA1_HASH_SIZE;
    Size=lp-lpMem;
    PTODWORD(lpMem)=Size-4;
    lpMem[3]=1;
    SendAll(hSocket, lpMem, Size);

    ProcExit:
    FreeMem(lpMem);
    }



//-----------------------------------------------------------------------------
//      MySQL �ڵ� �α��� ��Ŷ ����
//-----------------------------------------------------------------------------
LOCAL(VOID) AutoSendMySquAuthPacket(HWND hWnd, SOCKET hSocket, LPCSTR RcvBuff)
    {
    LPSTR lpMem, UserName, UserPsw;

    ALLOCMEM3(lpMem, MAX_PATH,
              UserName, MAX_PATH,
              UserPsw, MAX_PATH,
              MEMOWNER_AutoSendMySquAuthPacket, ProcExit);

    if (GetIniStr(ConfigStr, "MysqlUserName", UserName, MAX_PATH)==0 ||
        GetIniStr(ConfigStr, "MysqlPsw", UserPsw, MAX_PATH)==0) goto ProcExit;

    lstrcpy(lpMem, RcvBuff+0x0014);
    lstrcat(lpMem, RcvBuff+0x002F);
    SendAuthenticationPacket(hSocket, UserName, UserPsw, lpMem);
    DispRecvWindow(hWnd, "Auto Send MySQL Authentication Packet...\r\n");

    ProcExit:
    FreeMem(lpMem);
    }



//-----------------------------------------------------------------------------
//      �־��� Hex���ڿ��� �Ľ���
//-----------------------------------------------------------------------------
LOCAL(VOID) EB_AddToHex(HWND hWnd, LPCSTR Buff, int BuffLen)
    {
    BYTE B;
    int I,J;
    char szTmp[80], szHex[60], szAsc[20];

    szHex[0]=szAsc[0]=0;
    for (I=0; I<BuffLen; I++)
        {
        J=I&0x0F;
        if (J==0) wsprintf(szHex, "%04X: ", I);
        B=*((BYTE*)Buff+I);
        wsprintf(GetStrLast(szHex), "%02X%c", B, J==7 ? '-':' ');
        AddCha(szAsc, B>' ' && B<0x7F ? B:' ');
        if (J==15)
            {
            wsprintf(szTmp, "%-55s%s\r\n", szHex, szAsc);
            DispRecvWindow(hWnd, szTmp);
            szHex[0]=szAsc[0]=0;
            }
        }
    if (szHex[0]!=0)
        {
        wsprintf(szTmp, "%-55s %s\r\n", szHex, szAsc);
        DispRecvWindow(hWnd, szTmp);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� Hex���ڿ��� �Ľ���
//-----------------------------------------------------------------------------
LOCAL(int) ParsingHexStr(HWND hWnd, LPSTR Buff)
    {
    int I,J,K;
    LPSTR lpD;
    char szTmp[100];

    lpD=Buff;
    for (I=0; ; )
        {
        Buff=(LPSTR)SkipSpace(Buff);
        if (Buff[0]==0) break;
        J=AtoH(Buff, &K);
        if (K==0 || J>255)
            {
            lstrcpy(Buff+10, "...");
            wsprintf(szTmp, "Hex ���ڿ� ����: '%s'", Buff);
            DispMsg(hWnd, szTmp);
            I=0;
            break;
            }
        Buff+=K;
        *lpD++=(BYTE)J;
        I++;
        }

    return I;
    }



//-----------------------------------------------------------------------------
//      UDP Send/Receive
//-----------------------------------------------------------------------------
LOCAL(VOID) UdpSendReceive(HWND hWnd)
    {
    int   I, Port=0;
    DWORD Time;
    LPSTR lpMem, HostAdd;
    SOCKET hSocket=INVALID_SOCKET;

    ALLOCMEM2(lpMem, RCVBUFFSIZE,
              HostAdd, MAX_PATH,
              MEMOWNER_UdpSendReceive, ProcExit);

    MyGetDlgItemText(hWnd, ClntSockTestToSendAddrEBID, lpMem, MAX_PATH);
    SeparateUrlBS(lpMem, HostAdd, MAX_PATH, &Port);
    if (HostAdd[0]==0 || Port==0)
        {
        DispRecvWindow(hWnd, "�����ּҰ� �ùٸ��� �ʽ��ϴ�\r\n");
        goto ProcExit;
        }

    if ((hSocket=SocketUdpOpen(Port))==INVALID_SOCKET)
        {
        DispRecvWindow(hWnd, "UDP Socket Open Error\r\n");
        goto ProcExit;
        }

    GetDlgItemText(hWnd, ClntSockTestToSendEBID, lpMem, RCVBUFFSIZE);
    I=lstrlen(lpMem);
    if (IsDlgButtonChecked(hWnd, ClntSockTestSendHexCKID)!=0)
        I=ParsingHexStr(hWnd, lpMem);

    if (I==0)
        {
        DispRecvWindow(hWnd, "���� ������ ����־ �߸��� Hex Data�Դϴ�.\r\n");
        goto ProcExit;
        }

    SetNonBlockingMode(hSocket, TRUE);

    MySendTo(hSocket, lpMem, I, HostAdd, Port, 0);

    Time=GetTickCount();
    for (;;)
        {
        if ((I=MyRecvFrom(hSocket, lpMem, RCVBUFFSIZE, NULL, NULL, 0))>0) break;
        if (GetTickCount()-Time>=3000)
            {
            DispRecvWindow(hWnd, "UDP������ ������ �����ϴ�.\r\n");
            goto ProcExit;
            }
        }
    EB_AddToHex(hWnd, lpMem, I);

    ProcExit:
    SocketClose(hSocket);
    FreeMem(lpMem);
    }



//-----------------------------------------------------------------------------
//      �ý��۸޴��� �츮�� �޴��� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) SetSysMenu(HWND hWnd)
    {
    HMENU hSysMenu;

    hSysMenu=GetSystemMenu(hWnd, FALSE);        //FALSE:��������
    InsertMenu(hSysMenu, SC_CLOSE, MF_BYCOMMAND, UdpSendReceiveCmdID, "UDP ����");
    InsertMenu(hSysMenu, SC_CLOSE, MF_BYCOMMAND, SetHttpHeaderCmdID, "HTTP ��� ����");
    InsertMenu(hSysMenu, SC_CLOSE, MF_BYCOMMAND|MF_SEPARATOR, 0, NULL);
    }



//-----------------------------------------------------------------------------
//      ������ �����Ͽ� ���ڿ� �ְ��ޱ� ��ȭ���� Proc (���Ͻ���� Ŭ���̾�Ʈ)
//
// Http ����� ������ ���
//=========================
// GET / HTTP/1.1
// Accept: */*                  ... ����ġ�� �����ߴµ� �Ⱥ����� ��
// User-Agent: Mozilla/4.0      ... ����ġ�� �����ߴµ� �Ⱥ����� ��
// Host: www.ojang.pe.kr
//-----------------------------------------------------------------------------
DLGFNC(ClientSockTestDlgProc)
    {
    int I, Port;
    LPSTR lpMem, HostAdd, RcvBuff;
    static SOCKET hSocketClient;
    static char ToConnSvrAddrStr[]="ToConnSvrAddr";
    static char SendHexModeStr[]="SendHexMode";
    static char RcvHexModeStr[]="RcvHexMode";

    DialogPosition(hWnd, Msg, wPrm, TRUE);
    switch (Msg)
        {
        case WM_INITDIALOG:
            hSocketClient=INVALID_SOCKET;
            if ((lpMem=(LPSTR)AllocMem(MAX_PATH, MEMOWNER_ClientSockTestInitDlg))!=NULL)
                {
                GetIniStr(ConfigStr, ToConnSvrAddrStr, lpMem, MAX_PATH);
                SetDlgItemText(hWnd, ClntSockTestToSendAddrEBID, lpMem);

                CheckDlgButton(hWnd, ClntSockTestSendHexCKID, GetIniInt(ConfigStr, SendHexModeStr, 0));
                CheckDlgButton(hWnd, ClntSockTestRcvHexCKID,  GetIniInt(ConfigStr, RcvHexModeStr, 0));

                FreeMem(lpMem);
                }

            EB_LoadFromFile(hWnd, ClntSockTestToSendEBID, "ToSendData.txt");
            SetSysMenu(hWnd);
            return TRUE;

        case WM_GETMINMAXINFO:
            SetDlgMinSize((MINMAXINFO*)lPrm, 220, 140);
            break;

        case WM_SIZE:
            {
            int  Cx;
            RECT R;
            SIZE DeltaSize;

            if (IsChangedWndSize(hWnd, wPrm, lPrm, &DeltaSize))
                {
                GetDlgItemRect(hWnd, ClntSockTestToSendAddrEBID, &R); Cx=R.right-2;
                GetDlgItemRect(hWnd, ClntSockTestReceivedEBID, &R);
                AdjustDlgItemSize(hWnd, Cx, R.bottom-20, DeltaSize.cx, DeltaSize.cy);   //-20 �� Grip Top��ǥ����

                InvalidateRect(hWnd, NULL, TRUE);
                }
            break;
            }

        case WSA_READCLOSECLNT: //wPrm==hSocketClient ��
            if (LOWORD(lPrm)==FD_READ)
                {
                if ((RcvBuff=(LPSTR)AllocMem(RCVBUFFSIZE, MEMOWNER_RcvBuffer1))==NULL) break;
                if ((I=RecvWait((SOCKET)wPrm, RcvBuff, RCVBUFFSIZE, 3000))>0)
                    {
                    if (IsDlgButtonChecked(hWnd, ClntSockTestRcvHexCKID)!=0)
                        {
                        EB_AddToHex(hWnd, RcvBuff, I);
                        }
                    else{
                        RcvBuff[I]=0;
                        DispRecvWindow(hWnd, RcvBuff);
                        }
                    if (I==0x52 && lstrcmp(RcvBuff+0x003C, "mysql_native_password")==0) AutoSendMySquAuthPacket(hWnd, (SOCKET)wPrm, RcvBuff);
                    }
                FreeMem(RcvBuff);
                }
            else if (LOWORD(lPrm)==FD_CLOSE)
                {
                DispRecvWindow(hWnd, "������...\r\n");
                PostMessage(hWnd, WM_COMMAND, ClntSockTestDisconnBTID, 0);
                }
            return 0;

        case WM_SYSCOMMAND:
            if (wPrm>=SC_SIZE) break;
            PostMessage(hWnd, WM_COMMAND, wPrm, 0);
            return 0;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case UdpSendReceiveCmdID:
                    UdpSendReceive(hWnd);
                    break;

                case SetHttpHeaderCmdID:
                    {
                    CHAR Url[80];

                    GetDlgItemText(hWnd, ClntSockTestToSendAddrEBID, Url, sizeof(Url));
                    if ((lpMem=(LPSTR)AllocMem(4096, MEMOWNER_SetHttpHeaderCmdID))==NULL) break;
                    wsprintf(lpMem,
                        "GET / HTTP/1.1\r\n"
                        "Accept: text/html, application/xhtml+xml, image/jxr, */*\r\n"
                        "Accept-Language: ko\r\n"
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Trident/7.0; rv:11.0) like Gecko\r\n"
                        "Accept-Encoding: gzip, deflate\r\n"
                        "Host: %s\r\n"
                        "Connection: close\r\n"
                        "\r\n", Url);
                    SetDlgItemText(hWnd, ClntSockTestToSendEBID, lpMem);
                    FreeMem(lpMem);
                    break;
                    }

                case ClntSockTestSendBTID:      //��Ʈ������
                    if (hSocketClient==INVALID_SOCKET) break;
                    if ((RcvBuff=(LPSTR)AllocMem(RCVBUFFSIZE, MEMOWNER_RcvBuffer2))==NULL) break;
                    GetDlgItemText(hWnd, ClntSockTestToSendEBID, RcvBuff, RCVBUFFSIZE);

                    if (IsDlgButtonChecked(hWnd, ClntSockTestSendHexCKID)!=0)
                        {
                        if ((I=ParsingHexStr(hWnd, RcvBuff))==0) goto CSTS_Exit;        //�м������� �ִ� ���
                        I=SendAll(hSocketClient, RcvBuff, I);
                        }
                    else{
                        I=SendString(hSocketClient, RcvBuff);
                        }
                    DispRecvWindow(hWnd, I>0 ? "���ۼ���\r\n":"�����߿���߻�\r\n");

                    CSTS_Exit:
                    FreeMem(RcvBuff);
                    break;

                case ClntSockTestConnectBTID:
                    if (hSocketClient!=INVALID_SOCKET) break;

                    ALLOCMEM2(lpMem, MAX_PATH,
                              HostAdd, MAX_PATH,
                              MEMOWNER_ClntSockTestConnBTID, SendProcExit);

                    MyGetDlgItemText(hWnd, ClntSockTestToSendAddrEBID, lpMem, MAX_PATH);
                    Port=0;
                    SeparateUrlBS(lpMem, HostAdd, MAX_PATH, &Port);
                    if (HostAdd[0]==0 || Port==0)
                        {
                        DispRecvWindow(hWnd, "�����ּҰ� �ùٸ��� �ʽ��ϴ�\r\n");
                        goto SendProcExit;
                        }
                    if ((hSocketClient=SocketClientOpenII(hWnd, HostAdd, Port, WSA_READCLOSECLNT))==INVALID_SOCKET)
                        {
                        DispRecvWindow(hWnd, "������ �������� �ʽ��ϴ�\r\n");
                        goto SendProcExit;
                        }

                    WriteIniStr(ConfigStr, ToConnSvrAddrStr, lpMem);

                    EnableDlgItem(hWnd, ClntSockTestConnectBTID, FALSE);
                    EnableDlgItem(hWnd, ClntSockTestDisconnBTID, TRUE);
                    EnableDlgItem(hWnd, ClntSockTestSendBTID, TRUE);

                    SendProcExit:
                    FreeMem(lpMem);
                    break;

                case ClntSockTestDisconnBTID:
                    if (hSocketClient!=INVALID_SOCKET)
                        {
                        SocketClose(hSocketClient);
                        hSocketClient=INVALID_SOCKET;
                        EnableDlgItem(hWnd, ClntSockTestConnectBTID, TRUE);
                        EnableDlgItem(hWnd, ClntSockTestDisconnBTID, FALSE);
                        EnableDlgItem(hWnd, ClntSockTestSendBTID, FALSE);
                        }
                    break;

                case ClntSockClearSendDataBTID:         //���� ������ â ����
                    EB_Clear(hWnd, ClntSockTestToSendEBID);
                    break;

                case ClntSockClearRecvDataBTID:         //���� ������ â ����
                    EB_Clear(hWnd, ClntSockTestReceivedEBID);
                    break;

                case IDCANCEL:
                    EB_SaveToFile(hWnd, ClntSockTestToSendEBID, "ToSendData.txt");
                    WriteIniInt(ConfigStr, SendHexModeStr, IsDlgButtonChecked(hWnd, ClntSockTestSendHexCKID));
                    WriteIniInt(ConfigStr, RcvHexModeStr, IsDlgButtonChecked(hWnd, ClntSockTestRcvHexCKID));
                    SocketClose(hSocketClient);
                    EndDialog(hWnd, 0);
                }
            return TRUE;
        }

    return FALSE;
    }



//-----------------------------------------------------------------------------
//      Main Wondow Procedure
//-----------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE /*hInstPrev*/, LPSTR /*szCmdLine*/, int CmdShow)
    {
    InitJLib(hInst, hInst);
    if (SocketInit(NULL)==FALSE)
        {
        DispMsg(NULL, "WinSock�� �ʱ�ȭ�� �� �����ϴ�\n��Ʈ�� ����(TCP/IP)�� �����ϼ���");
        goto ProcExit;
        }
    DialogBox(hInst, (LPSTR)ClientSockTestDialog, NULL, ClientSockTestDlgProc);
    SocketRelease();

    ProcExit:
    ReleaseJLib();
    return 0;
    }


