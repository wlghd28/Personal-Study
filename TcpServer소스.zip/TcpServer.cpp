
#define _WINSOCK_DEPRECATED_NO_WARNINGS //WSAAsyncSelect()��� WSAEventSelect() �̰� ����� ��� ����� ���ƶ�
#include "JLIB.H"
#include "JWSOCK.H"
#include "RESOURCE.H"

extern const char GetHttpAgentName[]="FindMp3/3.03";

#define RCVBUFFSIZE             10000
#define WSA_ACCEPTSVR           (WM_USER+100)
#define WSA_READCLOSESVR        (WM_USER+101)


#define MEMOWNER_RcvBuffer1             (MEMOWNER_APP+1)
#define MEMOWNER_RcvBuffer2             (MEMOWNER_APP+2)


//-----------------------------------------------------------------------------
//      ����Ʈ �ڽ��� Hex�� ǥ��
//-----------------------------------------------------------------------------
LOCAL(VOID) EB_AddToHex(HWND hWnd, int EBID, LPCSTR Buff, int DataLen)
    {
    BYTE B;
    int I,J;
    char Tmp[80], Hex[60], Asc[20];

    Hex[0]=Asc[0]=0;
    for (I=0; I<DataLen; I++)
        {
        J=I&0x0F;
        if (J==0) wsprintf(Hex, "%04X: ", I);
        B=*((BYTE*)Buff+I);
        wsprintf(GetStrLast(Hex), "%02X%c", B, J==7 ? '-':' ');
        AddCha(Asc, B>' ' && B<0x7F ? B:' ');
        if (J==15)
            {
            wsprintf(Tmp, "%-55s%s\r\n", Hex, Asc);
            EB_AddStr(hWnd, EBID, Tmp);
            Hex[0]=Asc[0]=0;
            }
        }
    if (Hex[0]!=0)
        {
        wsprintf(Tmp, "%-55s %s\r\n", Hex, Asc);
        EB_AddStr(hWnd, EBID, Tmp);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� Hex���ڿ��� �Ľ���
//-----------------------------------------------------------------------------
LOCAL(int) ParsingHexStr(HWND hWnd, LPSTR Buff)
    {
    int I,J,K;
    LPSTR lpD;
    char Tmp[100];

    lpD=Buff;
    for (I=0; ; )
        {
        Buff=(LPSTR)SkipSpace(Buff);
        if (Buff[0]==0) break;
        J=AtoH(Buff, &K);
        if (K==0 || J>255)
            {
            lstrcpy(Buff+10, "...");
            wsprintf(Tmp, "Hex ���ڿ� ����: '%s'", Buff);
            DispMsg(hWnd, Tmp);
            I=0;
            break;
            }
        Buff+=K;
        *lpD++=(BYTE)J;
        I++;
        }

    return I;
    }



//-----------------------------------------------------------------------------
//      ���������� �����ϰ� ������ ����� ���ڿ� �ְ��ޱ� ��ȭ���� Proc (���Ͻ���� ����)
//-----------------------------------------------------------------------------
#define PORTCHANGEDTIMER    1
#define ECHOSERVERTIMER     2
DLGFNC(ServerSockTestDlgProc)
    {
    int I, Port, ToSend;
    char   szTmp[20];
    LPSTR  RcvBuff;
    static SOCKET hSocketListen;
    static SOCKET hSocketAccept;
    static char ListenPortStr[]="ListenPort";
    static char SendHexModeStr[]="SendHexMode";
    static char RcvHexModeStr[]="RcvHexMode";

    DialogPosition(hWnd, Msg, wPrm, TRUE);
    switch (Msg)
        {
        case WM_INITDIALOG:
            hSocketListen=hSocketAccept=INVALID_SOCKET;
            SetDlgItemInt(hWnd, SvrSockTestListenPortEBID, GetIniInt(ConfigStr, ListenPortStr), 0);
            CheckDlgButton(hWnd, SvrSockTestSendHexCKID, GetIniInt(ConfigStr, SendHexModeStr, 0));
            CheckDlgButton(hWnd, SvrSockTestRcvHexCKID,  GetIniInt(ConfigStr, RcvHexModeStr, 0));
            EB_LoadFromFile(hWnd, SvrSockTestToSendEBID, "ToSendData.txt");
            return TRUE;

        case WM_GETMINMAXINFO:
            SetDlgMinSize((MINMAXINFO*)lPrm, 220, 140);
            break;

        case WM_SIZE:
            {
            int  Cx;
            RECT R;
            SIZE DeltaSize;

            if (IsChangedWndSize(hWnd, wPrm, lPrm, &DeltaSize))
                {
                GetDlgItemRect(hWnd, SvrSockTestDisconnBTID, &R); Cx=R.left-1;
                GetDlgItemRect(hWnd, SvrSockTestReceivedEBID, &R);
                AdjustDlgItemSize(hWnd, Cx, R.bottom-20, DeltaSize.cx, DeltaSize.cy);   //-20 �� Grip Top��ǥ����

                InvalidateRect(hWnd, NULL, TRUE);
                }
            break;
            }

        case WM_TIMER:
            if (wPrm==PORTCHANGEDTIMER)
                {
                KillTimer(hWnd, PORTCHANGEDTIMER);
                MyGetDlgItemText(hWnd, SvrSockTestListenPortEBID, szTmp, sizeof(szTmp));
                if (szTmp[0]==0) break;
                Port=AtoI(szTmp);
                SendMessage(hWnd, WM_COMMAND, SvrSockTestDisconnBTID, 0);
                SocketClose(hSocketListen);
                hSocketListen=SocketServerOpenWin(hWnd, INADDR_ANY, Port, WSA_ACCEPTSVR);
                EB_AddStr(hWnd, SvrSockTestReceivedEBID, "�����׽���\r\n");
                WriteIniInt(ConfigStr, ListenPortStr, Port);
                }
            else if (wPrm==ECHOSERVERTIMER)
                {
                KillTimer(hWnd, ECHOSERVERTIMER);
                PostMessage(hWnd, WM_COMMAND, SvrSockTestDisconnBTID, 0);
                }
            break;

        case WSA_ACCEPTSVR:     //wPrm==hSocketListen ��
            {
            int Len;
            SOCKET hSocket;
            SOCKADDR_IN SAI;

            if (HIWORD(lPrm)!=0)
                {
                //WSAAsyncSelect((SOCKET)wPrm, hWnd, 0, 0);
                //MessageBox(hWnd, "WSA_ACCEPT ���� �����߻�", AppTitle, MB_OK);
                break;
                }
            Len=sizeof(SOCKADDR_IN);
            if ((hSocket=accept((SOCKET)wPrm, (SOCKADDR*)&SAI, &Len))==INVALID_SOCKET)
                {
                DispSocketErr(hWnd, "accept");
                break;
                }

            if (hSocketAccept==INVALID_SOCKET)
                {
                if (WSAAsyncSelect(hSocket, hWnd, WSA_READCLOSESVR, FD_READ|FD_CLOSE)==SOCKET_ERROR)
                    {
                    EB_AddStr(hWnd, SvrSockTestReceivedEBID, "WSAAsyncSelect()���� �����߻�\r\n");
                    goto CancelAccept;
                    }
                hSocketAccept=hSocket;
                EnableDlgItem(hWnd, SvrSockTestDisconnBTID, TRUE);
                EnableDlgItem(hWnd, SvrSockTestSendBTID, TRUE);
                EB_AddStr(hWnd, SvrSockTestReceivedEBID, "�����û�� ������\r\n");

                if (IsDlgButtonChecked(hWnd, SvrSockEchoServerCKID)!=0)
                    SetTimer(hWnd, ECHOSERVERTIMER, 60000, NULL);
                }
            else{
                EB_AddStr(hWnd, SvrSockTestReceivedEBID, "�߰������� ������\r\n");
                CancelAccept:
                SocketClose(hSocket);
                }
            return 0;
            }

        case WSA_READCLOSESVR:  //wPrm==hSocketAccept ��
            if (LOWORD(lPrm)==FD_READ)
                {
                if ((RcvBuff=(LPSTR)AllocMem(RCVBUFFSIZE, MEMOWNER_RcvBuffer1))==NULL) break;
                if ((I=RecvWait((SOCKET)wPrm, RcvBuff, RCVBUFFSIZE, 3000))>0)
                    {
                    //DebugMemII("OUT.BIN", RcvBuff, I);

                    if (IsDlgButtonChecked(hWnd, SvrSockTestRcvHexCKID)!=0)
                        EB_AddToHex(hWnd, SvrSockTestReceivedEBID, RcvBuff, I);
                    else{
                        RcvBuff[I]=0;
                        EB_AddStr(hWnd, SvrSockTestReceivedEBID, RcvBuff);
                        }

                    if (IsDlgButtonChecked(hWnd, SvrSockEchoServerCKID)!=0)
                        {
                        SendAll((SOCKET)wPrm, RcvBuff, I);
                        SetTimer(hWnd, ECHOSERVERTIMER, 60000, NULL);
                        }

                    if (IsDlgButtonChecked(hWnd, SvrSockAutoReplyCKID)!=0)
                        PostMessage(hWnd, WM_COMMAND, SvrSockTestSendBTID, 0);
                    }
                FreeMem(RcvBuff);
                }
            else if (LOWORD(lPrm)==FD_CLOSE)
                {
                EB_AddStr(hWnd, SvrSockTestReceivedEBID, "������...\r\n");
                PostMessage(hWnd, WM_COMMAND, SvrSockTestDisconnBTID, 0);
                }
            return 0;

        case WM_COMMAND:
            switch (WMCMDID)
                {
                case SvrSockTestListenPortEBID:         //��Ʈ�� �����
                    if (WMCMDNOTIFY==EN_CHANGE) SetTimer(hWnd, PORTCHANGEDTIMER, 3000, NULL);
                    break;

                case SvrSockTestSendBTID:               //���Ʈ ��Ʈ�� ����
                    if (hSocketAccept==INVALID_SOCKET) break;
                    if ((RcvBuff=(LPSTR)AllocMem(RCVBUFFSIZE, MEMOWNER_RcvBuffer2))==NULL) break;
                    GetDlgItemText(hWnd, SvrSockTestToSendEBID, RcvBuff, RCVBUFFSIZE);
                    ToSend=lstrlen(RcvBuff);
                    if (IsDlgButtonChecked(hWnd, SvrSockTestSendHexCKID)!=0)
                        ToSend=ParsingHexStr(hWnd, RcvBuff);        //Hex �м������� �ִ� ���

                    if (ToSend>0)
                        {
                        I=send(hSocketAccept, RcvBuff, ToSend, 0);
                        wsprintf(RcvBuff, "\r\n%d Byte ����\r\n", I);
                        EB_AddStr(hWnd, SvrSockTestReceivedEBID, RcvBuff);
                        }
                    FreeMem(RcvBuff);
                    break;

                case SvrSockTestDisconnBTID:            //����Ʈ��Ʈ�� ����
                    if (hSocketAccept!=INVALID_SOCKET)
                        {
                        SocketClose(hSocketAccept);
                        hSocketAccept=INVALID_SOCKET;
                        EnableDlgItem(hWnd, SvrSockTestDisconnBTID, FALSE);
                        EnableDlgItem(hWnd, SvrSockTestSendBTID, FALSE);
                        }
                    break;

                case SvrSockClearSendDataBTID:          //���� ������ â ����
                    EB_Clear(hWnd, SvrSockTestToSendEBID);
                    break;

                case SvrSockClearRecvDataBTID:          //���� ������ â ����
                    EB_Clear(hWnd, SvrSockTestReceivedEBID);
                    break;

                case IDCANCEL:
                    WriteIniInt(ConfigStr, SendHexModeStr, IsDlgButtonChecked(hWnd, SvrSockTestSendHexCKID));
                    WriteIniInt(ConfigStr, RcvHexModeStr, IsDlgButtonChecked(hWnd, SvrSockTestRcvHexCKID));
                    SocketClose(hSocketAccept);
                    SocketClose(hSocketListen);
                    EB_SaveToFile(hWnd, SvrSockTestToSendEBID, "ToSendData.txt");
                    EndDialog(hWnd, 0);
                }
            return TRUE;
        }

    return FALSE;
    }




//-----------------------------------------------------------------------------
//      Main Wondow Procedure
//-----------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE /*hInstPrev*/, LPSTR /*szCmdLine*/, int CmdShow)
    {
    InitJLib(hInst, hInst);
    if (SocketInit(NULL)==FALSE)
        {
        DispMsg(NULL, "WinSock�� �ʱ�ȭ�� �� �����ϴ�\n��Ʈ�� ����(TCP/IP)�� �����ϼ���");
        goto ProcExit;
        }
    DialogBox(hInst, (LPSTR)ServerSockTestDialog, NULL, ServerSockTestDlgProc);
    SocketRelease();

    ProcExit:
    ReleaseJLib();
    return 0;
    }


