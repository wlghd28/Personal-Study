///////////////////////////////////////////////////////////////////////////////
//                  Cortex-M3/M4/M7 �� JLIB
///////////////////////////////////////////////////////////////////////////////


#include "JLIB.H"
#if INIFILE_EN
#include "INIDATA.H"
#endif



CHAR JLibVersion[]="JL101"; //KEIL �����Ϸ����� JLibVersion�� 0x20000000�� ���εǴµ� �տ� 2����Ʈ�� FE E7�� �и��µ� ������ �𸣰���
                            //������ �����ϸ� 20000000�� ���εǴ� �ٸ� ���������� ����
CONST CHAR NullStr[]="";
CONST CHAR Psnt1s[]="%s";
CONST CHAR Psnt1d[]="%d";
CONST CHAR Psnt1u[]="%u";
CONST CHAR Psnt2d[]="%d %d";
CONST CHAR ConfigStr[]="Config";
CONST CHAR CrLfStr[]=CRLF;
CONST CHAR IniFileName[]="";

#define MAF_NOUSE       0
#define MAF_USE         1
#define MAF_LAST        2

#define MAH_SIGN        0x4D4A  //'MJ' ��������˻�

typedef struct MemAllocHeadStruc    //ũ�⸦ 8 Byte�� ����
    {
    WORD  Sign;
    WORD  OwnerID;
    DWORD Size;
    struct MemAllocHeadStruc  *This;
    BYTE  Flag;
    BYTE  CurrPrio;
    BYTE  Dummy3;
    BYTE  Dummy4;
    } MEMALLOCHEAD;

static UINT RamStartAdd, RamEndAdd, RamUsingSize, RamMaxUsedSize;
static UINT VRamStartAdd, VRamEndAdd, VRamUsingSize, VRamMaxUsedSize;

static CONST CHAR WeekNameList[]="Sun\0Mon\0Tue\0Wed\0Thu\0Fri\0Sat";
static CONST CHAR MonthNameList[]="Jan\0Feb\0Mar\0Apr\0May\0Jun\0Jul\0Aug\0Sep\0Oct\0Nov\0Dec";
VOID Printf(LPCSTR DispStr, ...);


#define MEMOWNER_PutString              1
#define MEMOWNER_ELB_New                2
#define MEMOWNER_FreeStrBuffPrepare1    3
#define MEMOWNER_FreeStrBuffPrepare2    4
#define MEMOWNER_AddStringList          5
#define MEMOWNER_AddRectList            6



//-----------------------------------------------------------------------------
//              �޸� ���� �ʱ�ȭ
//-----------------------------------------------------------------------------
LOCAL(VOID) SetMAH(MEMALLOCHEAD *MAH, int Owner, UINT BlkSize, int Flag)
    {
    MAH->Sign=MAH_SIGN;
    MAH->OwnerID=Owner;
    MAH->Size=BlkSize;
    MAH->This=MAH;
    MAH->Flag=Flag;
    //MAH->CurrPrio=JOSPrioCur;
    }



//-----------------------------------------------------------------------------
//              �޸� ���� �ʱ�ȭ
//-----------------------------------------------------------------------------
LOCAL(BOOL) MemAllocInit_(UINT MemStart, UINT BlkSize)
    {
    SetMAH((MEMALLOCHEAD*)MemStart, 0, BlkSize, MAF_NOUSE);

    MemStart+=BlkSize;
    SetMAH((MEMALLOCHEAD*)MemStart, 0, sizeof(MEMALLOCHEAD), MAF_LAST);

    return ((MEMALLOCHEAD*)MemStart)->Sign==MAH_SIGN &&
           ((MEMALLOCHEAD*)MemStart)->Flag==MAF_LAST;
    }

BOOL WINAPI MemAllocInit(UINT MemStart, UINT BlkSize)
    {
    RamStartAdd=(MemStart+15) & ~0xF;
    BlkSize-=RamStartAdd-MemStart;

    BlkSize&=~0xF;
    BlkSize-=sizeof(MEMALLOCHEAD);          //�ǵ� �޸��� ���� ��
    RamEndAdd=RamStartAdd+BlkSize;
    return MemAllocInit_(RamStartAdd, BlkSize);
    }

BOOL WINAPI VMemAllocInit(UINT MemStart, UINT BlkSize)
    {
    VRamStartAdd=(MemStart+15) & ~0xF;
    BlkSize-=VRamStartAdd-MemStart;

    BlkSize&=~0xF;
    BlkSize-=sizeof(MEMALLOCHEAD);          //�ǵ� �޸��� ���� ��
    VRamEndAdd=VRamStartAdd+BlkSize;
    return MemAllocInit_(VRamStartAdd, BlkSize);
    }



//-----------------------------------------------------------------------------
//              �޸� �Ҵ�
//���ϰ� 0:OK
//       7:�޸� ������� �ı�
//       8:�䱸�ϴ� ũ���� �޸𸮰� ����
//-----------------------------------------------------------------------------
LOCAL(LPVOID) AllocMem_(DWORD ReqSize, UINT OwnerID, BOOL IsVRam)
    {
    int  Rslt;
    UINT Sz;
    MEMALLOCHEAD *MAH;
    LPVOID lpMem=NULL;
    JOS_CRITICAL_VAR;

    MAH=(IsVRam==FALSE) ? (MEMALLOCHEAD*)RamStartAdd:(MEMALLOCHEAD*)VRamStartAdd;

    ReqSize+=7; ReqSize&=~7;        //8�� ���ũ��� �Ҵ��ϰ� �ϴ� ������ Ptr�� ���� 3Bit�� 0�� �ǵ��� �ϱ� ���� (���������� Ȯ�ο� ���)
    ReqSize+=sizeof(MEMALLOCHEAD);

    JOS_ENTER_CRITICAL();

    for (; ;)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || MAH->This!=MAH || Sz==0) {Printf("Mem=%X Broken"CRLF, MAH); Rslt=MA_BROKENMCB; break;}
        if (MAH->Flag==MAF_LAST) {Rslt=MA_INSUFFICIENT; break;}

        if (MAH->Flag==MAF_NOUSE && Sz>=ReqSize)
            {
            SetMAH(MAH, OwnerID, ReqSize, MAF_USE);
            Sz-=ReqSize;
            if (Sz>=sizeof(MEMALLOCHEAD)) SetMAH((MEMALLOCHEAD*)((LPBYTE)MAH+ReqSize), 0, Sz, MAF_NOUSE); //������ ũ�⸦ ��������� ó��
            else MAH->Size=Sz+ReqSize;      //�ڸ� �� ������ ũ�Ⱑ sizeof(MEMALLOCHEAD)�� �ȵǴ� ���

            lpMem=(LPVOID)((LPBYTE)MAH+sizeof(MEMALLOCHEAD));
            Rslt=MA_OK;
            break;
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    JOS_EXIT_CRITICAL();

    if (Rslt!=MA_OK) Printf("AllocMem(Req=%d, Owner=%d) %s"CRLF, ReqSize, OwnerID, Rslt==MA_BROKENMCB ? "Broken MCB":(Rslt==MA_INSUFFICIENT ? "Insufficient Memory":"Error"));
    else{
        //Printf("%d=AllocMem(%d, %d) Ok (Task=%d)"CRLF, Rslt, ReqSize, OwnerID);
        if (IsVRam==FALSE)
            {
            if ((RamUsingSize+=ReqSize)>RamMaxUsedSize) RamMaxUsedSize=RamUsingSize;
            }
        else{
            if ((VRamUsingSize+=ReqSize)>VRamMaxUsedSize) VRamMaxUsedSize=VRamUsingSize;
            }
        }
    return lpMem;
    }

LPVOID WINAPI AllocMem(DWORD ReqSize, UINT OwnerID) {return AllocMem_(ReqSize, OwnerID, FALSE);}
LPVOID WINAPI AllocVMem(DWORD ReqSize, UINT OwnerID) {return AllocMem_(ReqSize, OwnerID, TRUE);}




//-----------------------------------------------------------------------------
//      AllocMem�� �Ҵ�� �޸��� ũ�⸦ �����Ѵ�
//-----------------------------------------------------------------------------
LPVOID WINAPI ReAllocMem(LPVOID *lpMem, UINT NowSize, UINT NewSize, UINT OwnerID)
    {
    LPVOID lp;

    if ((lp=AllocMem(NewSize, OwnerID))!=NULL)
        {
        CopyMem(lp, *lpMem, UGetMin(NowSize, NewSize));
        FreeMem(*lpMem);
        *lpMem=lp;
        }
    return lp;
    }



 //-----------------------------------------------------------------------------
//      ���ӵ� �Ⱦ��� ������ �ϳ��� ��ģ��
//-----------------------------------------------------------------------------
LOCAL(int) MergeScatteredPieces(MEMALLOCHEAD *MAH)
    {
    int Rslt=MA_OK, Sz;
    MEMALLOCHEAD *NoUseStart=NULL;

    for (; ;)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Rslt=MA_BROKENMCB; break;}
        if (MAH->Flag==MAF_LAST) break;

        if (MAH->Flag!=MAF_NOUSE) NoUseStart=NULL;
        else{
            if (NoUseStart==NULL) NoUseStart=MAH;   //ó������ �����ϴ� ����
            else{
                MAH->Sign=0;
                MAH->This=NULL;
                NoUseStart->Size+=Sz;
                }
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Root MAH�� ������
//-----------------------------------------------------------------------------
LOCAL(MEMALLOCHEAD*) GetRootMAH(LPVOID lpMem, BOOL *IsVRam)
    {
    MEMALLOCHEAD *RootMAH=NULL;

    if ((UINT)lpMem>=RamStartAdd && (UINT)lpMem<RamEndAdd)
        {
        RootMAH=(MEMALLOCHEAD*)RamStartAdd;
        *IsVRam=FALSE;
        }
    else if ((UINT)lpMem>=VRamStartAdd && (UINT)lpMem<VRamEndAdd)
        {
        RootMAH=(MEMALLOCHEAD*)VRamStartAdd;
        *IsVRam=TRUE;
        }
    else Printf("FreeMem() Invalid Ptr, %X"CRLF, (UINT)lpMem);

    return RootMAH;
    }




//-----------------------------------------------------------------------------
//              �޸� �ع�
//      7:�޸� ������� �ı�
//      9:�߸��� ������
//-----------------------------------------------------------------------------
int WINAPI FreeMem(LPVOID lpMem)
    {
    int Rslt=MA_INVALIDPTR, IsVram;
    MEMALLOCHEAD *MAH, *RootMAH;
    JOS_CRITICAL_VAR;

    if (lpMem==NULL) goto ProcExit;
    if ((RootMAH=GetRootMAH(lpMem, &IsVram))==NULL) goto ProcExit;

    JOS_ENTER_CRITICAL();
    MAH=(MEMALLOCHEAD*)((LPBYTE)lpMem-sizeof(MEMALLOCHEAD));
    if (MAH->Sign==MAH_SIGN && MAH->Flag==MAF_USE)
        {
        MAH->Flag=MAF_NOUSE;
        if (IsVram==FALSE) RamUsingSize-=MAH->Size; else VRamUsingSize-=MAH->Size;
        Rslt=MergeScatteredPieces(RootMAH);
        }
    JOS_EXIT_CRITICAL();

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//          �޸� ��� (������ ��� NULL ����)
//-----------------------------------------------------------------------------
LPVOID WINAPI ShrinkMem(LPVOID lpMem, int ReqSize)
    {
    BOOL IsVram;
    UINT Sz;
    MEMALLOCHEAD *MAH, *RootMAH;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if (lpMem==NULL) goto ProcExit;
    if ((RootMAH=GetRootMAH(lpMem, &IsVram))==NULL) goto ProcExit;

    MAH=(MEMALLOCHEAD*)((LPBYTE)lpMem-sizeof(MEMALLOCHEAD));
    if (MAH->Sign!=MAH_SIGN || MAH->Flag!=MAF_USE) {ErExit: lpMem=NULL; goto ProcExit;}
    Sz=MAH->Size;

    ReqSize+=7; ReqSize&=~0x7;      //8�� ���ũ��� �Ҵ��ϰ� �ϴ� ������ Ptr�� ���� 3Bit�� 0�� �ǵ��� �ϱ� ���� (���������� Ȯ�ο� ���)
    ReqSize+=sizeof(MEMALLOCHEAD);
    if (ReqSize>Sz) goto ErExit;

    Sz-=ReqSize;    //����ũ��
    if (Sz>=sizeof(MEMALLOCHEAD))
        {
        MAH->Size=ReqSize;
        SetMAH((MEMALLOCHEAD*)((LPBYTE)MAH+ReqSize), 0, Sz, MAF_NOUSE);     //������ ũ�⸦ ��������� ó��
        MergeScatteredPieces(RootMAH);
        }
    ProcExit:
    JOS_EXIT_CRITICAL();
    return (LPVOID)lpMem;
    }



//-----------------------------------------------------------------------------
//              �޸� ���� �뷮 ���
//���ϰ� 0:OK
//       7:�޸� ������� �ı�
//       8:�䱸�ϴ� ũ���� �޸𸮰� ����
//-----------------------------------------------------------------------------
LOCAL(UINT) GetMemFree_(MEMALLOCHEAD *MAH, UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty)
    {
    int  Rslt=MA_OK, Cnt;
    UINT MaxBlkSize, FreeSize, Sz;
    JOS_CRITICAL_VAR;

    MaxBlkSize=FreeSize=Cnt=0;
    if (MAH==NULL) goto ProcExit;       //�ʱ�ȭ ���� ���

    JOS_ENTER_CRITICAL();
    while (MAH->Flag!=MAF_LAST)
        {
        Cnt++;
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Rslt=MA_BROKENMCB; break;}

        if (MAH->Flag==MAF_NOUSE)
            {
            FreeSize+=Sz;
            MaxBlkSize=UGetMax(MaxBlkSize, Sz);
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    JOS_EXIT_CRITICAL();

    ProcExit:
    if (lpRslt!=NULL) *lpRslt=Rslt;
    if (lpLargestBlkSize!=NULL) *lpLargestBlkSize=MaxBlkSize;
    if (BlkQty!=NULL) *BlkQty=Cnt;
    return FreeSize;
    }

UINT WINAPI GetMemFree(UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty) {return GetMemFree_((MEMALLOCHEAD*)RamStartAdd, lpLargestBlkSize, lpRslt, BlkQty);}
UINT WINAPI GetVMemFree(UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty) {return GetMemFree_((MEMALLOCHEAD*)VRamStartAdd, lpLargestBlkSize, lpRslt, BlkQty);}




//-----------------------------------------------------------------------------
//      �޸� ������ Dump��
//-----------------------------------------------------------------------------
LOCAL(VOID) DispMemBlock_(MEMALLOCHEAD *MAH, BOOL DispBlkFg)
    {
    UINT Sz, Cnt, Used, Free;

    if (MAH==NULL) {Printf("No Initialized"CRLF); goto ProcExit;}

    Cnt=Used=Free=0;
    while (MAH->Flag!=MAF_LAST)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Printf("%08X %d Owner=%3d Size=%d Broken\r\n", MAH, MAH->Flag, MAH->OwnerID, Sz); break;}
        if (DispBlkFg) Printf("%08X %d Owner=%3d Size=%d\r\n", MAH, MAH->Flag, MAH->OwnerID, Sz);
        if (MAH->Flag==MAF_NOUSE) Free+=Sz; else Used+=Sz;
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        Cnt++;
        }
    Printf("Total Blocks = %u"CRLF
           "Free Size = %,u"CRLF
           "Use Size  = %,u"CRLF, Cnt, Free, Used);

    ProcExit:;
    }

VOID WINAPI DispMemBlock(BOOL DispBlkFg)
    {
    DispMemBlock_((MEMALLOCHEAD*)RamStartAdd, DispBlkFg);
    Printf("Max Used  = %,u"CRLF, RamMaxUsedSize);  //RamUsingSize
    }

VOID WINAPI DispVMemBlock(BOOL DispBlkFg)
    {
    DispMemBlock_((MEMALLOCHEAD*)VRamStartAdd, DispBlkFg);
    Printf("Max Used  = %,u"CRLF, VRamMaxUsedSize);     //VRamUsingSize
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� ������ (strdup()�� ���� �Լ�)
//-----------------------------------------------------------------------------
LPSTR WINAPI CopyStr(LPCSTR OrgStr, int Owner)
    {
    int Len;
    LPSTR Buff;

    Len=lstrlen(OrgStr)+1;
    if ((Buff=(LPSTR)AllocMem(Len, Owner))!=NULL) CopyMem(Buff, OrgStr, Len);
    return Buff;
    }



//-----------------------------------------------------------------------------
//      ��ġ���� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsNumeric(int Cha)
    {
    return Cha>='0' && Cha<='9';
    }



//-----------------------------------------------------------------------------
//      ASCII�������� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsAscii(int Cha)
    {
    return Cha>=' ' && Cha<=0x7F;
    }



//-----------------------------------------------------------------------------
//      ASCII�������� �˷���
//-----------------------------------------------------------------------------
int WINAPI CatchAscii(int Cha)
    {
    if (IsAscii(Cha)==FALSE) Cha=' ';
    return Cha;
    }



//-----------------------------------------------------------------------------
//      ū�� �Ǵ� �������� ����
//-----------------------------------------------------------------------------
int WINAPI GetMin(int A, int B)     {return A<=B ? A:B;}
UINT WINAPI UGetMin(UINT A, UINT B) {return A<=B ? A:B;}

int WINAPI GetMax(int A, int B)     {return A>=B ? A:B;}
UINT WINAPI UGetMax(UINT A, UINT B) {return A>=B ? A:B;}

int WINAPI GetAbs(int A)
    {
    return A>=0 ? A:-A;
    }

int WINAPI GetDiff(int A, int B)
    {
    if ((A-=B)<0) A=-A;
    return A;
    }

UINT WINAPI UGetDiff(UINT A, UINT B)
    {
    return (A>=B) ? A-B:B-A;
    }


int WINAPI Limit(int Value, int Min, int Max)
    {
    if (Value<Min) Value=Min;
    else if (Value>Max) Value=Max;
    return Value;
    }



//-----------------------------------------------------------------------------
//      ���� �� / ū ���� ����
//-----------------------------------------------------------------------------
VOID WINAPI ChoiceMin(int *lpA, int B) {if (*lpA>B) *lpA=B;}
VOID WINAPI ChoiceMax(int *lpA, int B) {if (*lpA<B) *lpA=B;}




//-----------------------------------------------------------------------------
//      ���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
int WINAPI AtoI(LPCSTR Str, int *NonStrLoc)
    {
    int  Rslt, Sign, HexMode, NoErr, Cha, Cha2;
    LPCSTR lp;

    Rslt=Sign=HexMode=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha=='0')
            {
            Cha2=*lp++;
            if (Cha2=='x' || Cha2=='X') HexMode++; else lp-=2;
            }
        else lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (HexMode==0) break;
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        if (HexMode) Rslt<<=4;
        else{
            Rslt<<=1;
            Rslt+=Rslt<<2;      //*10
            }
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �������ڿ��� ��ġ�� ��ȭ�� (�տ� 0�� ������ ����ó����)
//-----------------------------------------------------------------------------
int WINAPI AtoN(LPCSTR Str, int *NonStrLoc)
    {
    int  Cha, Rslt, Sign, NoErr;
    LPCSTR lp;

    Rslt=Sign=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;        //���� Skip
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0' || Cha>'9') break;
        NoErr=1;
        Rslt<<=1; Rslt+=Rslt<<2;
        Rslt+=Cha-'0';
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
INT64 WINAPI AtoI64(LPCSTR Str, int *NonStrLoc)
    {
    BOOL   Sign, HexMode, NoErr;
    INT64  Rslt;
    CHAR   Cha, Cha2;
    LPCSTR lp;

    Rslt=0;
    Sign=HexMode=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha=='0')
            {
            Cha2=*lp++;
            if (Cha2=='x' || Cha2=='X') HexMode++; else lp-=2;
            }
        else lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (HexMode==0) break;
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        if (HexMode) Rslt<<=4;
        else Rslt*=10;

        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �־��� ���ڿ����� ��� ����� ���ڷ� ����
//-----------------------------------------------------------------------------
int WINAPI AtoIN(LPCSTR NumStr, int StrLen)
    {
    int Rslt=0;
    CHAR Cha;

    while (StrLen--)
        {
        Cha=*NumStr++;
        if (Cha<'0' || Cha>'9') break;

        Rslt<<=1;
        Rslt+=Rslt<<2;  //*10
        Rslt+=Cha-'0';
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿��� ���ڿ� �񱳸� ��
//-----------------------------------------------------------------------------
int WINAPI CompMemStr(LPCSTR Src, LPCSTR Find)
    {
    return CompMem(Src, Find, lstrlen(Find));
    }



//-----------------------------------------------------------------------------
//      Memory������ ���մϴ� (������ 0, ������ -1, ũ�� 1) (��ҹ��ڹ���)
//      memicmp
//-----------------------------------------------------------------------------
int WINAPI CompMemI(LPCVOID Str1, LPCVOID Str2, UINT CompSize)
    {
    UINT Cha1, Cha2;
    BOOL Rslt=0;

    while (CompSize--)
        {
        Cha1=*(LPCBYTE)Str1; Str1=(LPCBYTE)Str1+1;
        Cha2=*(LPCBYTE)Str2; Str2=(LPCBYTE)Str2+1;
        if (Cha1>='a' && Cha1<='z') Cha1-=0x20;
        if (Cha2>='a' && Cha2<='z') Cha2-=0x20;
        if ((Rslt=Cha1-Cha2)!=0) break;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿��� ���ڿ� �񱳸� ��
//-----------------------------------------------------------------------------
int WINAPI CompMemStrI(LPCSTR Src, LPCSTR Find)
    {
    return CompMemI(Src, Find, lstrlen(Find));
    }




//-----------------------------------------------------------------------------
//      ��� ����Ʈ�� 0���� üũ���ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI IsZeroMem(LPCVOID Mem, int ByteSize)
    {
    int I;

    for (I=0; I<ByteSize; I++) if (*((LPCBYTE)Mem+I)!=0) break;
    return I>=ByteSize;
    }




#if 0   //Asm���� �����
//-----------------------------------------------------------------------------
//      64Bit=64Bit/32Bit ... 32Bit
//-----------------------------------------------------------------------------
UINT64 WINAPI UDiv64_32(UINT64 Dividend, UINT Divisor, UINT *lpRemain)
    {
    UINT64 Rslt;
    Rslt=Dividend/Divisor;
    *lpRemain=Dividend%Divisor;
    return Rslt;
    }
#endif




//-----------------------------------------------------------------------------
//      ���ڿ��� ������ Format���� ����� �ݴϴ�
//      %c, %d, %u, %s, %x, %X, %lld, %llu, %I64d, %I64u, %ws, %llX
//      %[-][,][#][0][width][.decimal]type
//
//      Test
//      ====
//      CHAR Buff[80];
//      Jsprintf(Buff, "%,X  %.4d   %.2d  %,d  %,.2d", 0x125679AF, 23, 123456789, 123456789, 123456789);
//      DispMsg(NULL, Buff);
//
// Ver 2.02 2001/01/07 "%.01d" �Ҽ����ڿ� 0�� ������ �Ҽ����ڿ��� 0�̾ ǥ����
// Ver 2.03 2005/10/17 "%.02d" ���� ���� ��ġ�� 0�� ��� ������ 0���� ������� 0.00 ���� ����
// Ver 2.04 2012/01/20 "%.lld %.llu %I64d %I64u"�߰� 64bit���� ǥ��
// Ver 2.05 2012/08/30 "%ws" Utf16���ڿ� ǥ�� �߰�
// Ver 2.06 2015/07/30 "%llX" 64bit���� Hexǥ��
// Ver 2.07 2016/04/11 DestBuff�� ũ�⸦ �ް� ��ġ�� �ʰ� ó����
// Ver 2.08 2017/01/11 .12 -> 0.12
// Ver 2.09 2018/01/12 %U8s �߰�, UTF8���ڿ� ���� �� ����
// Ver 2.10 2018/08/24 BuffSize==0 �̸� �� �ʿ��� ����ũ�⸦ ������
//
// 64��Ʈ������ va_arg()�� �������� �ִ� ũ�Ⱑ 64��Ʈ��. %c,%d �� ��������
//-----------------------------------------------------------------------------
#define JSPRINTF_PUTCHA(Cha)\
    {\
    TotalSize++;\
    if (BuffSize>1) {*DestBuff++=Cha; BuffSize--;}\
    }
#define JSPRINTF_FILLCHA(Cha, Cnt)\
    {\
    TotalSize+=Cnt;\
    if (BuffSize>Cnt) {FillMem(DestBuff, Cnt, Cha); DestBuff+=Cnt; BuffSize-=Cnt;}\
    }
#define JSPRINTF_PUTSTR(Str)\
    {\
    TotalSize+=Len;\
    if (BuffSize>Len) {CopyMem(DestBuff, Str, Len); DestBuff+=Len; BuffSize-=Len;}\
    }

int WINAPI VsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormStr, va_list VL)
    {
    int    I, Width, CommaUnit, FractionUnit, TotalSize=1,
           Cha, ZeroFillCha, TypeCha, Len;
    UINT   ArgValue;
    BOOL   LeftAlignFg, HexPrefixFg, FractionZFillFg, I64;
    LPSTR  lp;
    LPCSTR lpPsntNextPtr;
    CHAR   Buff[32];

    for (;;)
        {
        Cha=*FormStr++;
        if (Cha!='%')
            {
            PassCha:
            if (Cha==0) break;
            JSPRINTF_PUTCHA(Cha)
            }
        else{
            if (FormStr[0]=='%') {FormStr++; goto PassCha;}     //'%%'�� %�� �Ϲ� ���ڷ� ���
            lpPsntNextPtr=FormStr;
            Width=LeftAlignFg=HexPrefixFg=FractionUnit=CommaUnit=FractionZFillFg=I64=0;
            ZeroFillCha=' ';

            for (;;)
                {
                Cha=*FormStr++;
                if (Cha=='-') LeftAlignFg=1;
                else if (Cha==',') CommaUnit=3;
                else if (Cha=='#') HexPrefixFg=1;
                else if (Cha=='0') ZeroFillCha='0';
                else if (Cha>='1' && Cha<='9') {FormStr--; Width=AtoI(FormStr, &I); FormStr+=I;}
                else if (Cha=='.')
                    {
                    if (FormStr[0]=='0') FractionZFillFg=1;
                    FractionUnit=-AtoI(FormStr, &I); FormStr+=I;
                    }
                else if (Cha=='I' && FormStr[0]=='6' && FormStr[1]=='4') {FormStr+=2; I64=1;}
                else if (Cha=='l' && FormStr[0]=='l') {FormStr++; I64=1;}
                else{
                    TypeCha=Cha;
                    ArgValue=va_arg(VL, UINT);

                    if (Cha=='c')               //%c
                        {
                        Buff[0]=(BYTE)ArgValue; Buff[1]=0;
                        lp=Buff;

                        PutStr:
                        Len=lstrlen(lp);
                        if (LeftAlignFg!=0)     //'-'�� ������ ����������
                            {
                            JSPRINTF_PUTSTR(lp)
                            if ((Width-=Len)>0) JSPRINTF_FILLCHA(' ', Width)
                            }
                        else{                   //������ ���� ó��
                            if (Width!=0 && (Width-=Len)>0) JSPRINTF_FILLCHA(ZeroFillCha, Width)
                            JSPRINTF_PUTSTR(lp)
                            }
                        break;
                        }
                    else if (Cha=='s')                  //%s
                        {
                        if ((lp=(LPSTR)ArgValue)==NULL) lp="<null>";
                        goto PutStr;
                        }
                    else if (Cha=='x' || Cha=='X')      //%x, %X
                        {
                        int HexChaOfs;

                        I=0;                            //�ڸ��� ī����
                        HexChaOfs=(TypeCha=='x') ? 'a'-10:'A'-10;
                        lp=Buff+sizeof(Buff)-1; lp[0]=0;
                        if (I64==0)
                            {
                            #define ArgValue32  ArgValue
                            do  {
                                Cha=ArgValue32 & 0x0F; ArgValue32>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue32!=0);
                            #undef ArgValue32
                            }
                        else{
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;

                            do  {
                                Cha=(int)(ArgValue64 & 0x0F); ArgValue64>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue64!=0);
                            }

                        if (HexPrefixFg!=0)
                            {
                            *--lp='x';
                            *--lp='0';
                            }
                        goto PutStr;
                        }
                    else if (Cha=='d' || Cha=='u')      //%d, %u
                        {
                        BOOL FirstFg=1, Sign=0;

                        if (I64==0)
                            {
                            #define ArgValue32  ArgValue
                            if (TypeCha=='d' && (int)ArgValue32<0) {ArgValue32=-(int)ArgValue32; Sign=1;}
                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue32==0) {*--lp='0'; goto PutStr;}

                            do  {
                                Cha=(ArgValue32%10)+'0';
                                ArgValue32/=10;
                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue32==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit+1==0) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue32!=0);
                            #undef ArgValue32
                            }
                        else{
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);

                            //*((DWORD*)&ArgValue64+0)=ArgValue;                //GCC������ �̷� ����� �������� ����
                            //*((DWORD*)&ArgValue64+1)=HighValue;
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;    //�����Ϸ��� �˾Ƽ�ó���ϴ��� __allshl() �θ��� ����
                            if (TypeCha=='d' && (int)HighValue<0) {ArgValue64=-(INT64)ArgValue64; Sign=1;}

                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue64==0) {*--lp='0'; goto PutStr;}

                            do  {
                                //Cha=(UCHAR)(ArgValue64%10)+'0';
                                //ArgValue64/=10;
                                ArgValue64=UDiv64_32(ArgValue64, 10, (UINT*)&I);
                                Cha=I+'0';

                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue64==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit+1==0) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue64!=0);
                            }

                        if (FractionUnit<0)
                            {
                            while (FractionUnit<0) {*--lp='0'; FractionUnit++;}
                            *--lp='.';
                            }
                        if (FractionUnit==0) *--lp='0';
                        if (TypeCha=='d' && Sign!=0) *--lp='-';
                        goto PutStr;
                        }
                    else{
                        FormStr=lpPsntNextPtr;      //ó������ �ʴ� '%' Type�̸� �״�� ǥ��
                        //ArgList--;                //va_list���� �ڷ� ���ư��� ��� ��ã��
                        Cha='%';
                        goto PassCha;
                        }
                    }
                } //while (*FormStr++)
            } //'%' ó��
        } //for (;;)

    if (BuffSize>0) DestBuff[0]=0;
    return TotalSize;
    }


int Jsprintf(LPSTR DestBuff, LPCSTR FormatStr, ...)     //�����Լ��� ȣȯ�� ����, ������ JsprintfN()�� ����� ��
    {
    int Rslt;
    va_list VL;

    va_start(VL, FormatStr);
    Rslt=VsprintfN(DestBuff, 10240, FormatStr, VL);
    va_end(VL);
    return Rslt;
    }

int JsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormatStr, ...)
    {
    int Rslt;
    va_list VL;

    va_start(VL, FormatStr);
    Rslt=VsprintfN(DestBuff, BuffSize, FormatStr, VL);
    va_end(VL);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              ������ Skip��
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR lp)
    {
    int Cha;

    for (;;)
        {
        Cha=*(LPCBYTE)lp;
        if (Cha==0 || Cha>' ') break;
        lp++;
        }
    return lp;
    }



//-----------------------------------------------------------------------------
//      String���� %d, %s, %c, %x�� ó���Ͽ� �̾��ݴϴ�
//      %u=%d, %X=%x ���� ó����
//      %.3d �� �Ҽ������� ���ڸ����� ������ ���� (*1000�� �϶�� ��)
//      �� String�� ��ġ�ϸ� True�� �����մϴ�

//Test:
//    int  I1, I2, I3, I4, H;
//    CHAR Cha, Str[40], Buff[80];
//    I=Jsscanf("TestStr: 5% +1234 -1234 12.3456 123 AF90 \"This Is Str\" J %z EOF",
//            "TestStr: 5%% %u %d %.2d %.3d %X %s %c %z EOF",
//            &I1, &I2, &I3, &I4, &H, Str, &Cha);
//
//    wsprintfA(Buff, "(Rslt=%d) I1=%d I2=%d I3=%d I4=%d H=%X Str=[%s] Cha=[%c]",
//                    I, I1, I2, I3, I4, H, Str, Cha);
//    DebugFile(Buff); //=> (Rslt=1) I1=1234 I2=-1234 I3=1235 I4=123000 H=AF90 Str=[This Is Str] Cha=[J]
//-----------------------------------------------------------------------------
BOOL Jsscanf(LPCSTR SourceStr, LPCSTR FormatStr, ...)
    {
    int  I, DecimalPt;
    BYTE Cha, SCha,FCha;
    LPCSTR FormatStrBkup, SourceStrBkup;
    LPVOID *lpArg;

    lpArg=(LPVOID*)&FormatStr+1;
    for (;;)
        {
        SCha=*SourceStr++;
        FCha=*FormatStr++;
        if (SCha==0 || FCha==0) break;

        if (FCha=='%')
            {
            SourceStrBkup=SourceStr;
            FormatStrBkup=FormatStr;
            FCha=*FormatStr++;
            if (FCha!='%')      //%%�� %���� �ϳ���
                {
                DecimalPt=0;
                if (FCha=='.')
                    {
                    DecimalPt=AtoI(FormatStr, &I);
                    FormatStr+=I;
                    FCha=*FormatStr++;
                    }

                if (FCha=='c')                          //'%c'
                    {
                    *(LPBYTE)(*lpArg++)=SCha;
                    continue;
                    }
                else if (FCha=='d' || FCha=='u')        //'%d', '%u'
                    {
                    int Val=0, NumbSignFg, ExistDcmlPtFg, HalfRiseFg, ValidFg;

                    NumbSignFg=ExistDcmlPtFg=HalfRiseFg=ValidFg=0;

                    if (SCha=='-') NumbSignFg++;
                    else if (SCha!='+') SourceStr--;

                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha=='.')
                            {
                            if (ExistDcmlPtFg) break;   //�ι�°�� �Ҽ����� ������ ��� ���ڹ��ڿ� ����� ó��
                            ExistDcmlPtFg++;
                            continue;
                            }
                        Cha-='0';
                        if (Cha>9) break;               //���ڹ��ڿ� ����
                        ValidFg++;
                        if (ExistDcmlPtFg)
                            {
                            if (DecimalPt==0)           //������ ��ȿ���� ����
                                {
                                if (HalfRiseFg==0)
                                    {
                                    HalfRiseFg++;
                                    if (Cha>=5) Val++;
                                    }
                                continue;
                                }
                            DecimalPt--;
                            }
                        Val<<=1; Val+=Val<<2; Val+=Cha; //Val=Val*10+Cha
                        }

                    if (ValidFg)
                        {
                        SourceStr--;
                        while (DecimalPt!=0) {Val<<=1; Val+=Val<<2; DecimalPt--;}
                        if (NumbSignFg) Val=-Val;
                        *(int*)(*lpArg++)=Val;
                        continue;
                        }

                    //��ȿ�� ���ڹ��ڰ� �ϳ��� ������ �Ϲ� ���ڿ��� ó��
                    SourceStr=SourceStrBkup;
                    FormatStr=FormatStrBkup;
                    }
                else if (FCha=='x' || FCha=='X')        //'%x', '%X'
                    {
                    int Val, ValidFg;

                    Val=ValidFg=0;
                    SourceStr--;
                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha<'0') break;
                        if (Cha<='9') {Cha-='0'; goto AddDigit;}
                        if (Cha<'A') break;
                        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
                        if (Cha<'a' || Cha>'f') break;
                        Cha-='a'-10;
                        AddDigit:
                        ValidFg++;
                        Val<<=4; Val|=Cha;
                        }

                    if (ValidFg)
                        {
                        SourceStr--;
                        *(UINT*)(*lpArg++)=Val;
                        continue;
                        }

                    //��ȿ�� ���ڹ��ڰ� �ϳ��� ������ �ϸ� ���ڿ��� ó��
                    SourceStr=SourceStrBkup;
                    FormatStr=FormatStrBkup;
                    }
                else if (FCha=='s')             //'%s'
                    {
                    LPSTR lpD;

                    lpD=(LPSTR)(*lpArg++);
                    if (SCha!='\'' && SCha!='"')
                        {
                        SourceStr--;
                        SCha=0;         //0:ó������ String, �̶��� ���� Space�� Tab���ڱ��� �д´�
                        }
                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha==0) {SourceStr--; break;}
                        if (SCha!=0)
                            {
                            if (Cha==SCha) break;
                            }
                        else{
                            if (Cha<=' ') {SourceStr--; break;}
                            }
                        *lpD++=Cha;
                        }
                    *lpD=0;
                    continue;
                    }
                else{
                    FormatStr=FormatStrBkup;
                    FCha='%';
                    }
                }
            }

        //1�� �̻��� Space�� Tab�� ��� �ϳ��� Space�� ���Ѵ�
        if (SCha<=' ') {SourceStr=SkipSpace(SourceStr); SCha=' ';}
        if (FCha<=' ') {FormatStr=SkipSpace(FormatStr); FCha=' ';}
        if (SCha!=FCha) break;
        }
    return (SCha|FCha)==0;      //SCha�� FCha��� 0�̸� �� String�� ��ġ���� �ǹ���
    }




//-----------------------------------------------------------------------------
//      Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� Hex�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
DWORD WINAPI AtoH(LPCSTR String, int *NonStrLoc)
    {
    BOOL   NoErr;
    DWORD  Rslt;
    CHAR   Cha;
    LPCSTR lp;

    Rslt=NoErr=0;
    lp=SkipSpace(String);
    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        Rslt<<=4;
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-String)-1:0;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Hex���ڿ��� ��ġ�� ��ȭ��
//-----------------------------------------------------------------------------
DWORD WINAPI AtoHN(LPCSTR Str, int StrLen)
    {
    DWORD  Rslt=0;
    int   Cha;

    while (StrLen--)
        {
        Cha=*Str++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        Rslt<<=4;
        Rslt+=Cha;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Str�� ��(NULL������ġ)�� �ݴϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetStrLast(LPSTR Str)
    {
    return lstrlen(Str)+Str;
    }



//-----------------------------------------------------------------------------
//      String�� Cha�� ���Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI AddCha(LPSTR Str, int Cha)
    {
    int I;
    I=lstrlen(Str);
    Str[I]=Cha;
    Str[I+1]=0;
    }



int WINAPI UpCaseCha(int Cha)
    {
    if (Cha>='a' && Cha<='z') Cha-=0x20;
    return Cha;
    }




//-----------------------------------------------------------------------------
//      �־��� ���ڿ��� �빮�ڷ� �ٲ۴� (���̸� UpcaseStr)
//-----------------------------------------------------------------------------
VOID WINAPI CharUpper(LPSTR Str)
    {
    int Ch;

    while ((Ch=*(LPCBYTE)Str)!=0)
        {
        if (Ch>='a' && Ch<='z') Str[0]=Ch-0x20;
        Str++;
        }
    }




//-----------------------------------------------------------------------------
//      �־��� ���� ���ڿ��� �ҹ��ڷ� ��ȯ
//-----------------------------------------------------------------------------
int WINAPI CharLowerBuff(LPSTR Str, int Len)
    {
    int Cnt=0, Cha;

    while (Len--)
        {
        Cha=*(LPCBYTE)Str;
        if (Cha==0) break;
        if (Cha>='A' && Cha<='Z') Str+=0x20;        //������ �ٸ����� ���ڵ� ó���ؾ� ��
        Str++;
        Cnt++;
        }
    return Cnt;
    }



//-----------------------------------------------------------------------------
//      ����ũ�� ���� ū ���ڿ��� �߶� ����
//-----------------------------------------------------------------------------
LPSTR WINAPI lstrcpyn(LPSTR Dest, LPCSTR Src, UINT BuffSize)
    {
    int CopyLen;

    if ((CopyLen=GetMin(lstrlen(Src), BuffSize-1))>0)
        CopyMem(Dest, Src, CopyLen);

    Dest[CopyLen]=0;
    return Dest;
    }



//-----------------------------------------------------------------------------
//      �־��� String�� �յ��� ������ �������ش� (�����̸�: CleanupStr)
//-----------------------------------------------------------------------------
VOID WINAPI StrTrim(LPSTR String)
    {
    BYTE Byt;
    LPSTR lp;

    //�ǵ��� ���� ����
    for (lp=GetStrLast(String)-1; lp>=String; lp--)
        {
        if (*(LPCBYTE)lp>0x20) break;
        lp[0]=0;
        }

    //���� ���� ����
    for (lp=String; ;lp++)
        {
        Byt=*(LPCBYTE)lp;
        if (Byt==0 || Byt>' ') break;
        }
    if (lp>String) lstrcpy(String, lp);
    }



//-----------------------------------------------------------------------------
//      ���� �ܾ��� ��ġ�� �ݴϴ� (�����̳� TAB����)
//      ����ܾ�� ������ ���� ���� �ܾ��� ��ġ�� �ݴϴ�
//      ������ġ�� �����̸� �ٷ� ���� ������ �ܾ�
//      '�� "�� ���ΰ�� �ϳ��� �ܾ�� �ν��մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextWord(LPCSTR lp, int WordCnt)
    {
    int Cha, FirstCha;

    for (;;)
        {
        lp=SkipSpace(lp);       //���齺ŵ
        FirstCha=lp[0];
        if (FirstCha==0 || WordCnt==0) break;
        WordCnt--;

        if (FirstCha==0x27 || FirstCha==0x22) lp++;     //"'", '"'
        else FirstCha=0;

        for (;;)                        //�ܾŵ
            {
            Cha=*(LPCBYTE)lp++;
            if (Cha==0) {lp--; break;}
            if (FirstCha!=0)
                {
                if (FirstCha==Cha) break;
                }
            else{
                if (Cha<=' ') {lp--; break;}
                }
            }
        }
    return lp;
    }



int WINAPI SearchCha(LPCSTR SourceStr, int SrchCha)
    {
    LPCSTR lp;
    return (lp=strchr(SourceStr, SrchCha))!=NULL ? lp-SourceStr:-1;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿��� Byte�� ã��
//-----------------------------------------------------------------------------
int WINAPI SearchMemByte(LPCVOID Mem, int MemSize, int FindByte)
    {
    int I, Find=-1;

    for (I=0; I<MemSize; I++)
        {
        if (*((LPCBYTE)Mem+I)==FindByte) {Find=I; break;}
        }
    return Find;
    }



//-----------------------------------------------------------------------------
//      ','�� �������� ���ϴ� ��ȣ�� �ܾ� ��ġ�� ����
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextCommaWord(LPCSTR lp, int WordNo)
    {
    int I;

    lp=SkipSpace(lp);   //���齺ŵ
    for (;;)
        {
        if (WordNo==0) break;
        if (lp[0]==0) break;
        if ((I=SearchCha(lp, ','))<0) I=lstrlen(lp)-1;
        lp+=I+1;
        WordNo--;
        }
    return lp;
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����� ������ ���ڿ��� ��)
//-----------------------------------------------------------------------------
LPSTR WINAPI SeparatStr(LPSTR String, int SepCha)
    {
    int I;
    if ((I=SearchCha(String, SepCha))<0) return NULL;
    String[I]=0;
    return String+I+1;
    }



//------------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����ڿ� ������ ���ڿ��� ��)
//------------------------------------------------------------------------------
LPSTR WINAPI SeparatStrStr(LPSTR Str, LPCSTR SepStr)
    {
    int I;

    if ((I=SearchStr(Str, SepStr))<0) return NULL;
    Str[I]=0;
    return lstrlen(SepStr)+Str+I;
    }




//-----------------------------------------------------------------------------
//      �����ڱ����� ���ڿ��� �����ְ� ������ ���� ��ġ�� ������
//      strtok()�� SeparatStr()�� ������ ���������� �� �Լ��� ������ �Ѽ����� ����
//      �����̸� CatchWord()
//      ��뿹: CatchToken("TE;HU;ANALOG", ';', Buff, sizeof(Buff));
//-----------------------------------------------------------------------------
LPCSTR WINAPI CatchToken(LPCSTR Str, int SepCha, LPSTR Buff, int BuffLen)
    {
    int Find;

    if ((Find=SearchCha(Str, SepCha))<0) Find=lstrlen(Str);
    lstrcpyn(Buff, Str, GetMin(Find+1, BuffLen));
    if (Str[Find]!=0) Find++;
    return Str+Find;
    }




//-----------------------------------------------------------------------------
//      �־��� ���ڿ����� ���ϴ� ���̸�ŭ ������
//-----------------------------------------------------------------------------
VOID WINAPI SubStr(LPSTR Buff, int BuffSize, LPCSTR Src, int ReqLen)
    {
    lstrcpyn(Buff, Src, GetMin(ReqLen+1, BuffSize));
    }



//-----------------------------------------------------------------------------
//      �־��� ��Ʈ������ �־��� ���ڸ� ��� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI DelAllCha(LPSTR String, int DelCha)
    {
    int Cha;
    LPSTR lpDest=String;

    if (DelCha!=0)
        for (;;)
            {
            Cha=*(LPCBYTE)String++;
            if (Cha!=DelCha)
                {
                *lpDest++=Cha;
                if (Cha==0) break;
                }
            }
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڸ� �����
//-----------------------------------------------------------------------------
VOID WINAPI DelCha(LPSTR String, int DelLoc)
    {
    if (lstrlen(String)>DelLoc)
        {
        String+=DelLoc;
        lstrcpy(String, String+1);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ��� ������ ���ڸ� ��
//-----------------------------------------------------------------------------
int WINAPI GetLastChar(LPCSTR Str)
    {
    int I;

    if ((I=lstrlen(Str))>0) I=Str[I-1];
    return I;
    }



//-----------------------------------------------------------------------------
//      �ο��ȣ�� ������ (StripQuotationMark)
//-----------------------------------------------------------------------------
VOID WINAPI StripQuoteSign(LPSTR Buff)
    {
    int Cha, Len;

    Cha=Buff[0];
    if (Cha=='\'' || Cha=='\"')
        {
        DelCha(Buff, 0);
        if ((Len=lstrlen(Buff)-1)>=0)
            {
            if (Buff[Len]==Cha) Buff[Len]=0;
            }
        }
    }




int WINAPI SearchStr(LPCSTR SourceStr, LPCSTR SrchStr)
    {
    LPCSTR lp;
    return (lp=strstr(SourceStr, SrchStr))!=NULL ? lp-SourceStr:-1;
    }




//-----------------------------------------------------------------------------
//      �� ����� 8Bit üũ���� ���մϴ�
//-----------------------------------------------------------------------------
int WINAPI GetJ8ChkSum(LPCBYTE lpMem, UINT Size)
    {
    int LfnSum=0;

    while (Size--)
        {
        //ror LfnSum,1
        if (LfnSum & 1)
            {
            LfnSum>>=1;
            LfnSum^=0xA5;
            }
        else LfnSum>>=1;

        LfnSum+=*lpMem++;
        }

    return LfnSum & 0xFF;
    }




//-----------------------------------------------------------------------------
//      ?VAR1=DATA1&VAR2=DATA2, name=������&age=35
//-----------------------------------------------------------------------------
BOOL WINAPI GetUrlVarText(LPCSTR WebArgList, LPCSTR VarName, LPSTR DataBuff, int BuffSize)
    {
    BOOL Rslt=FALSE;
    int   Len, NextPos;

    DataBuff[0]=0;
    Len=lstrlen(VarName);
    while (WebArgList[0]!=0)
        {
        if (lstrlen(WebArgList)<=Len) break;
        NextPos=SearchCha(WebArgList, '&');
        if (WebArgList[Len]=='=' && CompareMem(WebArgList, VarName, Len)==0)
            {
            if (NextPos>=0) BuffSize=GetMin(BuffSize, NextPos-Len);
            lstrcpyn(DataBuff, WebArgList+Len+1, BuffSize);
            Rslt++;
            break;
            }
        if (NextPos<0) break;
        WebArgList+=NextPos+1;
        }
    return Rslt;
    }


int WINAPI GetUrlVarInt(LPCSTR WebArgList, LPCSTR VarName)
    {
    CHAR Buff[16];
    GetUrlVarText(WebArgList, VarName, Buff, sizeof(Buff));
    return AtoI(Buff, NULL);
    }




//-----------------------------------------------------------------------------
//      Null���ڿ�(ȯ�湮�ڿ�ó��)���� �־��� ��ġ�� ���ڿ��� ��
//-----------------------------------------------------------------------------
LPCSTR WINAPI GetToken(LPCSTR TokenList, int TokenNo)
    {
    while (TokenList[0]!=0)
        {
        if (TokenNo==0) break;
        TokenList+=lstrlen(TokenList)+1;
        TokenNo--;
        }
    return TokenList;
    }


//-----------------------------------------------------------------------------
//      Null���ڿ� List(ȯ�湮�ڿ�ó��)���� ������ ���ڿ��� ��
//-----------------------------------------------------------------------------
LPCSTR WINAPI GetNextStr(LPCSTR Str)
    {
    return lstrlen(Str)+Str+1;
    }



//-----------------------------------------------------------------------------
//      A*B/C ���� ������, ���� �� �ݿø�ó����
//-----------------------------------------------------------------------------
UINT WINAPI UMulDiv(UINT A, UINT B, UINT C)
    {
    return (UINT)(((UINT64)A*B+(C>>1))/C);
    }



//-----------------------------------------------------------------------------
//              ���ڿ� �Է� (���̹��ڿ�)
//          Out al= 0:1byte����, 1:2byte���� ù��°, 2:2byte���� �ι�°
//-----------------------------------------------------------------------------
int WINAPI Check2byteCha(LPCSTR Str, int ChkLoc)
    {
    BYTE Cha, HangulFirst=0;
    int I, Rslt;

    for (I=Rslt=0; ;I++)
        {
        if ((Cha=*(LPBYTE)Str++)==0) break;

        if (I>=ChkLoc)
            {
            if (HangulFirst!=0) Rslt=2;             //2byte���� �ι�° Byte
            else                Rslt=(Cha>=0x80);   //1:2byte���� ù��°/ 0:1byte����
            break;
            }

        if (HangulFirst!=0) HangulFirst=0;
        else if (Cha>=0x80) HangulFirst=1;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Utf8���ڿ��� Utf16���� �ٲ� ��� ���� ���� ���� (Null�������Ծ���)
//      �����̸� CalcLenOfU8ToU16, StrLenU8
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//-----------------------------------------------------------------------------
int WINAPI GetChQtyU8(LPCSTR Utf8)
    {
    int  Cha, Cnt;

    for (Cnt=0; ;)
        {
        if ((Cha=*(LPCBYTE)Utf8++)==0) break;
        Cnt++;                                  //����ȵǴ� ������ ��쿣 ��ȯ���Ѵٴ� ���ι��� ���� ��
        if (Cha<0x80) continue;

             if ((Cha & 0xE0)==0xC0) goto Skip1Byte;
        else if ((Cha & 0xF0)==0xE0) goto Skip2Byte;
        else if ((Cha & 0xF8)==0xF0) goto Skip3Byte;        //4Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFC)==0xF8) goto Skip4Byte;        //5Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFE)==0xFC)                        //6Byte, MS UTF16���� ����ȵ�
            {
            if (*Utf8++==0) break;
            Skip4Byte:
            if (*Utf8++==0) break;
            Skip3Byte:
            if (*Utf8++==0) break;
            Skip2Byte:
            if (*Utf8++==0) break;
            Skip1Byte:
            if (*Utf8++==0) break;
            }
        }
    return Cnt;
    }




//-----------------------------------------------------------------------------
//      Utf8���ڿ����� �־��� ���ڹ�ȣ�� �����͸� ����
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//-----------------------------------------------------------------------------
LPCSTR WINAPI GetChPtrU8(LPCSTR Utf8, int ChaPos)
    {
    int  Cha, Cnt;

    for (Cnt=0; ;)
        {
        if ((Cha=*(LPCBYTE)Utf8++)==0) break;
        if (Cnt==ChaPos) break;
        Cnt++;
        if (Cha<0x80) continue;

             if ((Cha & 0xE0)==0xC0) goto Skip1Byte;
        else if ((Cha & 0xF0)==0xE0) goto Skip2Byte;
        else if ((Cha & 0xF8)==0xF0) goto Skip3Byte;        //4Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFC)==0xF8) goto Skip4Byte;        //5Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFE)==0xFC)                        //6Byte, MS UTF16���� ����ȵ�
            {
            if (*Utf8++==0) break;
            Skip4Byte:
            if (*Utf8++==0) break;
            Skip3Byte:
            if (*Utf8++==0) break;
            Skip2Byte:
            if (*Utf8++==0) break;
            Skip1Byte:
            if (*Utf8++==0) break;
            }
        }
    return Utf8-1;
    }




//-----------------------------------------------------------------------------
//      Utf8���ڿ����� ���� ������ ��ġ�� ������
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//-----------------------------------------------------------------------------
LPCSTR WINAPI CharNextU8(LPCSTR Utf8)
    {
    int Cha, Len=1;

    if ((Cha=*(LPCBYTE)Utf8) & 0x80)
        {
             if ((Cha & 0xE0)==0xC0) Len=2;
        else if ((Cha & 0xF0)==0xE0) Len=3;
        else if ((Cha & 0xF8)==0xF0) Len=4;     //4Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFC)==0xF8) Len=5;     //5Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFE)==0xFC) Len=6;     //6Byte, MS UTF16���� ����ȵ�
        }
    return Utf8+Len;
    }



//-----------------------------------------------------------------------------
//      UTF8�����̸� UTF16�ڵ�� ��ȭ����
//-----------------------------------------------------------------------------
int WINAPI GetCharU8(LPCSTR Str, int *lpLen)
    {
    int Cha, Len=1;

    Cha=*(LPCBYTE)Str;
    if (Cha & 0x80)
        {
        if ((Cha & 0xE0)==0xC0)
            {
            Cha=((Cha&0x1F)<<6) | (Str[1]&0x3F);
            Len=2;
            }
        else if ((Cha & 0xF0)==0xE0)
            {
            Cha=((Cha&0x0F)<<12) | ((Str[1]&0x3F)<<6) | (Str[2]&0x3F);
            Len=3;
            }
        else Printf("%X Illegal UTF8 ch!"CRLF, Cha);
        }
    *lpLen=Len;
    return Cha;
    }

LPSTR WINAPI CharNext(LPCSTR Str)
    {
    int Len;
    GetCharU8(Str, &Len);
    return (LPSTR)Str+Len;
    }



//-----------------------------------------------------------------------------
//      UTF16���� 1���� UTF8�� �ٲپ� ���� (���̸� ����)
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//-----------------------------------------------------------------------------
int WINAPI SetUtf8FromU16(LPSTR Buff, UINT U16)
    {
    int Len=0;

    Poke(Buff, 0);
    if (U16<=0x7F)
        {
        Buff[0]=U16;
        Len=1;
        }
    else if (U16<=0x7FF)
        {
        Buff[0]=(U16>>6)|0xC0;
        Buff[1]=(U16&0x3F)|0x80;
        Len=2;
        }
    else if (U16<=0xFFFF)
        {
        Buff[0]=(U16>>12)|0xE0;
        Buff[1]=((U16>>6)&0x3F)|0x80;
        Buff[2]=(U16&0x3F)|0x80;
        Len=3;
        }
    return Len;
    }




//-----------------------------------------------------------------------------
//      Utf8���ڿ����� �־��� ��ġ�� ���� 1���� ������
//-----------------------------------------------------------------------------
BOOL WINAPI DelChaU8(LPSTR Utf8, int DelPos)
    {
    int Cha, Cnt, Rslt=FALSE;

    for (Cnt=0; ;)
        {
        if ((Cha=*(LPCBYTE)Utf8)==0) break;
        if (Cnt==DelPos) {lstrcpy(Utf8, CharNextU8(Utf8)); Rslt++; break;}
        Utf8++;
        Cnt++;                                              //����ȵǴ� ������ ��쿣 ��ȯ���Ѵٴ� ���ι��� ���� ��
        if (Cha<0x80) continue;

             if ((Cha & 0xE0)==0xC0) goto Skip1Byte;
        else if ((Cha & 0xF0)==0xE0) goto Skip2Byte;
        else if ((Cha & 0xF8)==0xF0) goto Skip3Byte;        //4Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFC)==0xF8) goto Skip4Byte;        //5Byte, MS UTF16���� ����ȵ�
        else if ((Cha & 0xFE)==0xFC)                        //6Byte, MS UTF16���� ����ȵ�
            {
            if (*Utf8++==0) break;
            Skip4Byte:
            if (*Utf8++==0) break;
            Skip3Byte:
            if (*Utf8++==0) break;
            Skip2Byte:
            if (*Utf8++==0) break;
            Skip1Byte:
            if (*Utf8++==0) break;
            }
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      2���� ������ ���մϴ�
//-----------------------------------------------------------------------------
int WINAPI GetMonthLastDay(int Year, int Month)
    {
    int LastDay;
    static BYTE LastDays[]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (Month!=2) LastDay=LastDays[Month-1];
    else          LastDay=(Year % 400)==0 || ((Year % 100)!=0 && (Year & 3)==0) ? 29:28;    //&3=%4
    return LastDay;
    }



//-----------------------------------------------------------------------------
//      �־��� ����ϱ����� �� ���ڼ��� ���մϴ� (0000�� 1�� 1�Ϻ���)
//
//      Year * (365*400+100-4+1) / 400 => Year*146097/400
//      �̷��� �����ؼ� ���� 2020-12-31�� ���ϼ��� 2021-1-1�� ���ϼ��� ������ (�ɰ��� ������)
//-----------------------------------------------------------------------------
TDATE WINAPI GetTotalDays(int Year, int Month, int Day)
    {
    int I;

    for (I=1; I<Month; I++) Day+=GetMonthLastDay(Year, I);

    if (Year>0)
        {
        Year--;
        Day+=Year*365 + (Year>>2) - Year/100 + Year/400;
        }
    return Day;
    }



//-----------------------------------------------------------------------------
//      �־��� ���� ������ �˷��ݴϴ�
//      Return 0:����, 1:������ ...
//-----------------------------------------------------------------------------
int WINAPI GetWeek(int Year, int Month, int Day)
    {
    return GetTotalDays(Year, Month, Day) % 7;
    }




//-----------------------------------------------------------------------------
//      ���ϼ��� ����Ϸ� �ٲߴϴ�
//-----------------------------------------------------------------------------
#define YEAR1DAYS       365
#define YEAR4DAYS       1461
#define YEAR100DAYS     36524
#define YEAR400DAYS     146097
VOID WINAPI CnvFromTotalDay(TDATE TotalDays, int *lpYear, int *lpMonth, int *lpDay)
    {
    int Y,M, LDays;

    #if 1
    //A���
    Y=(TotalDays*400/YEAR400DAYS)+1;    //T=Y*365+Y/4-Y/100+Y/400 => Y=T*400/(365*400+100-4+1)
    TotalDays-=GetTotalDays(Y, 0, 0);
    #else
    //B��� - A������ε� �Ʒ�ó�� �����ϸ� 3000����� ������ ��� ������ ������ A��� ������
    Y=DivMod(TotalDays, YEAR400DAYS, (int*)&TotalDays)*400+1;
    D=GetMin(DivMod(TotalDays, YEAR100DAYS, &Remain), 3); Y+=D*100;         //3���� �����ϴ� �ϴ� ������ 400�⿡ 1�� �߰��Ǿ��⿡ 146096�� ��� 4�� ����
    TotalDays-=D*YEAR100DAYS;
    Y+=DivMod(TotalDays, YEAR4DAYS, (int*)&TotalDays)*4;
    Y+=D=GetMin(DivMod(TotalDays, YEAR1DAYS, &Remain), 3);                  //3���� �����ϴ� �ϴ� ������ 4�⿡ 1�� �߰��Ǿ��⿡ 1460�� ��� 4�� ����
    TotalDays-=D*YEAR1DAYS;
    #endif

    if (TotalDays==0) {Y--; M=12; TotalDays=31;}    //2021-06-10 �߰�
    else{
        for (M=1; M<=12; M++)
            {
            LDays=GetMonthLastDay(Y, M);
            if (TotalDays<=LDays) break;
            TotalDays-=LDays;
            }
        if (M>12) {Y++; M=1;}                       //2021-06-10 A������� ���� ��������
        }

    *lpYear=Y;
    *lpMonth=M;
    *lpDay=TotalDays;
    }



#if 0
//-----------------------------------------------------------------------------
//      ���ϼ� �Լ� �׽�Ʈ
//-----------------------------------------------------------------------------
LOCAL(VOID) TestTotalDayFunc()
    {
    int  Y, M, D;
    UINT T;

    for (T=1; T<1095728; T++)
        {
        CnvFromTotalDay(T, &Y, &M, &D);
        if (GetTotalDays(Y,M,D)==T)
            {
            if (M<1 || M>12 || D<1 || D>GetMonthLastDay(Y,M)) goto Fail;
            printf("\r%d-%d-%d", Y,M,D);
            }
        else{
            Fail:
            printf("\nT=%d, %d-%d-%d Fail\n",T, Y,M,D);
            }
        }
    }
#endif



//-----------------------------------------------------------------------------
//      GMT�ð��� Local�ð����� ��ȯ����
//-----------------------------------------------------------------------------
VOID WINAPI SystemTimeToLocalTime(SYSTEMTIME *ST)
    {
    int  Y,M,D;

    ST->wHour+=9;
    if (ST->wHour>=24)
        {
        ST->wHour-=24;
        CnvFromTotalDay(GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)+1, &Y, &M, &D);
        ST->wYear=Y;
        ST->wMonth=M;
        ST->wDay=D;
        }
    }



//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI GetAppCompileDate(SYSTEMTIME *ST)
    {
    int Rslt=FALSE, Y,Month,D, H,M,S;
    CHAR MonthName[80];

    Jsscanf(__DATE__ " " __TIME__, "%s %d %d %d:%d:%d", MonthName, &D, &Y, &H, &M, &S);
    //���̸��м�
    for (Month=0; Month<12; Month++)
        if (lstrcmpi(GetToken(MonthNameList, Month), MonthName)==0) break;
    if (Month>=12) goto ProcExit;

    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)(Month+1);
    ST->wDay=(WORD)D;
    ST->wHour=(WORD)H;
    ST->wMinute=(WORD)M;
    ST->wSecond=(WORD)S;
    Rslt=TRUE;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �ð����ڿ��� ����� �� (2017-11-17 15:19:25)
//-----------------------------------------------------------------------------
LPSTR WINAPI MakeYMDHMS(LPSTR Buff, CONST SYSTEMTIME *ST)
    {
    wsprintf(Buff, "%d-%02d-%02d %02d:%02d:%02d", ST->wYear, ST->wMonth, ST->wDay, ST->wHour, ST->wMinute, ST->wSecond);
    return Buff;
    }



//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI GetAppCompileDateStr(LPSTR Buff)
    {
    BOOL Rslt;
    SYSTEMTIME ST;

    Buff[0]=0;
    if ((Rslt=GetAppCompileDate(&ST))!=FALSE) MakeYMDHMS(Buff, &ST);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ� (JTIME����)
//-----------------------------------------------------------------------------
JTIME WINAPI GetAppCompileDateTime(VOID)
    {
    JTIME Rslt=0;
    SYSTEMTIME ST;

    if (GetAppCompileDate(&ST)!=FALSE) Rslt=PackTotalSecond(&ST);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      HTTP TimeStr�� ����ϴ�
//      "Mon, 31 May 2004 13:55:12 GMT"
//-----------------------------------------------------------------------------
LPSTR WINAPI MakeHttpTimeStr(LPSTR TimeStr, CONST SYSTEMTIME *ST)
    {
    wsprintf(TimeStr, "%s, %d %s %d %02d:%02d:%02d GMT", GetToken(WeekNameList, ST->wDayOfWeek),
                      ST->wDay, ST->wMonth==0 ? "0":GetToken(MonthNameList, ST->wMonth-1), ST->wYear,
                      ST->wHour, ST->wMinute, ST->wSecond);
    return TimeStr;
    }




//-----------------------------------------------------------------------------
//      HTTP TimeStr�� �м��մϴ�
//      "Mon, 31 May 2004 13:55:12 GMT"
//-----------------------------------------------------------------------------
BOOL WINAPI AnalysisHttpTimeStr(LPCSTR TimeStr, SYSTEMTIME *ST)
    {
    int   I, Rslt=FALSE, Day, Year, Hour, Min, Sec;
    CHAR  Buff[40], lpGmt[40];

    ZeroMem(ST, sizeof(SYSTEMTIME));

    //�����̸��м�
    lstrcpyn(Buff, TimeStr, 3+1);
    for (I=0; I<7; I++)
        if (lstrcmpi(GetToken(WeekNameList, I), Buff)==0) break;
    if (I<7)
        {
        ST->wDayOfWeek=I;

        Jsscanf(NextWord(TimeStr,1), "%d %s %d %d:%d:%d %s", &Day, Buff, &Year, &Hour, &Min, &Sec, lpGmt);
        ST->wDay=Day;
        ST->wYear=Year;
        ST->wHour=Hour;
        ST->wMinute=Min;
        ST->wSecond=Sec;

        //���̸��м�
        for (I=0; I<12; I++)
            if (lstrcmpi(GetToken(MonthNameList, I), Buff)==0) break;
        if (I<12)
            {
            ST->wMonth=I+1;
            if (lstrcmpi(lpGmt, "GMT")==0) Rslt++;
            }
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �ð����ڿ��� ����ϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI Make10msTimeStr(LPSTR Buff, DWORD _10msTime, BOOL DetailFg)
    {
    UINT _10ms, M,S;

    _10msTime=UDivMod(_10msTime, 100, &_10ms);
    _10msTime=UDivMod(_10msTime, 60, &S);
    _10msTime=UDivMod(_10msTime, 60, &M);

    if (_10msTime==0) wsprintf(Buff, "%d:%02d", M, S);
    else              wsprintf(Buff, "%d:%02d:%02d", _10msTime, M, S);

    if (DetailFg!=0) wsprintf(GetStrLast(Buff), ".%02d", _10ms);
    return Buff;
    }



//------------------------------------------------------------------------------
//      String���� from�� ã�� to�� �ٲ۴� (�ٲ� ������ �˷���)
//------------------------------------------------------------------------------
int WINAPI ChangeCha(LPSTR String, int from, int to)
    {
    int  Cnt=0;
    int Cha;

    while ((Cha=*String++)!=0)
        {
        if (Cha==from) {String[-1]=to; Cnt++;}
        }
    return Cnt;
    }



//-----------------------------------------------------------------------------
//      ���� ���ڿ��� Cr,Lf ���� �� ������ �ݴϴ�
//      LineLen���� Cr,Lf�������� Bytes��
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextLine(LPCSTR SrcStr, int *LineLen)
    {
    int Len=0, Cha, T;

    for (;;)
        {
        if ((Cha=*SrcStr)==0) goto ProcExit;
        SrcStr++;

        T=10; if (Cha==13) break;
        T=13; if (Cha==10) break;
        Len++;
        }
    if (*SrcStr==T) SrcStr++;

    ProcExit:
    if (LineLen!=NULL) *LineLen=Len;
    return SrcStr;
    }



//-----------------------------------------------------------------------------
//      13,10���� �и��� ���� ���� ���� ���� ���ڼ� ����, Cr,Lf�� ������
//      �������� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI QueryStrOneLine(LPCSTR Str, int *lpLen)
    {
    int Len=0;
    CHAR Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0) {Str--; break;}
        if (Cha==13 || Cha==10)
            {
            if (Str[0]==(Cha==13 ? 10:13)) Str++;
            break;
            }
        else Len++;
        }
    *lpLen=Len;
    return Str;
    }



//-----------------------------------------------------------------------------
//      Cr,Lf�� ������ ���ڿ����� �־��� ���� �ִ���
//      ������ ã�� ���ڵڸ� ��������
//-----------------------------------------------------------------------------
BOOL WINAPI IsExistLineII(LPCSTR Str, LPCSTR FindLine, LPSTR Buff, int BuffSize)
    {
    int Rslt=FALSE, Len;

    Len=lstrlen(FindLine);
    while (Str[0]!=0)
        {
        if (CompMem(Str, FindLine, Len)==0)
            {
            lstrcpyn(Buff, Str+Len, BuffSize);
            ChangeCha(Buff, 13, 0);
            ChangeCha(Buff, 10, 0);
            Rslt=TRUE;
            break;
            }
        Str=NextLine(Str, NULL);
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      1Line�� ���� -  13,10���� �и��� ���� ���� Text���� �Ѷ����� �����ϴ�
//              �������� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI CatchStrOneLine(LPCSTR SrcStr, LPSTR DestBuff, int BuffLen)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*SrcStr++;
        if (Cha==0) {SrcStr--; break;}
        if (Cha==13 || Cha==10)
            {
            if (SrcStr[0]==(Cha==13 ? 10:13)) SrcStr++;
            break;
            }
        else{
            if (BuffLen>1)
                {
                *DestBuff++=Cha;
                BuffLen--;
                }
            }
        }
    if (BuffLen>0) *DestBuff=0;
    return SrcStr;
    }



#if 0
//-----------------------------------------------------------------------------
//      �޸𸮿� �ִ� Ini���ϱ����� ������ ���ڿ����� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniStrInMem(LPCSTR SecName, LPCSTR VarName, LPSTR Buff, int BuffSize, LPCSTR IniMem)
    {
    int  CopyLen=0, SNLen;
    LPSTR lpVal;
    CHAR Tmp[128];

    Buff[0]=0;
    if (IniMem==NULL) goto ProcExit;
    SNLen=lstrlen(SecName);
    while (IniMem[0]!=0)
        {
        IniMem=CatchStrOneLine(IniMem, Tmp, sizeof(Tmp));
        CleanupStr(Tmp);
        if (Tmp[0]=='[' && Tmp[SNLen+1]==']' && CompareMem(Tmp+1, SecName, SNLen)==0)
            {
            while (IniMem[0]!=0)
                {
                IniMem=CatchStrOneLine(IniMem, Tmp, sizeof(Tmp));
                if (Tmp[0]==0) continue;
                if (Tmp[0]=='[') goto ProcExit;       //��������
                lpVal=SeparatStr(Tmp, '=');
                CleanupStr(Tmp);
                if (lstrcmp(Tmp, VarName)==0)
                    {
                    if (lpVal!=NULL)
                        {
                        CleanupStr(lpVal);
                        lstrcpyn(Buff, lpVal, BuffSize);
                        }
                    CopyLen=lstrlen(Buff);
                    goto ProcExit;
                    }
                }
            }
        }

    ProcExit:
    return CopyLen;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿� �ִ� Ini���ϱ����� ������ �������� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniIntInMem(LPCSTR SecName, LPCSTR VarName, int DefValue, LPCSTR IniMem)
    {
    CHAR Buff[16];
    if (GetIniStrInMem(SecName, VarName, Buff, sizeof(Buff), IniMem)>0) DefValue=AtoI(Buff, NULL);
    return DefValue;
    }
#endif




//-----------------------------------------------------------------------------
//      ���ڿ��� ��ü��
//-----------------------------------------------------------------------------
VOID WINAPI PutString(LPSTR *lplpStr, LPCSTR PutStr)
    {
    FreeMem(*lplpStr);
    if ((*lplpStr=(LPSTR)AllocMem(lstrlen(PutStr)+1, MEMOWNER_PutString))!=NULL)
        lstrcpy(*lplpStr, PutStr);
    }



//-----------------------------------------------------------------------------
//      �־��� ����ũ�⸦ �������� �ʰ� ���ڿ��� �߰��մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI lstrcatn(LPSTR DestBuff, LPCSTR SrcBuff, int BuffSize)
    {
    int Len=lstrlen(DestBuff);
    if (Len<BuffSize) lstrcpyn(DestBuff+Len, SrcBuff, BuffSize-Len);
    }


#if INIFILE_EN
//-----------------------------------------------------------------------------
//      Ini������ �а� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniStr(LPCSTR Section, LPCSTR Entry, LPSTR Buff, int BuffSize)
    {return GetPrivateProfileString(Section, Entry, NullStr, Buff, BuffSize, IniFileName);}

int WINAPI GetIniStrEx(LPCSTR Section, LPCSTR Entry, LPSTR Buff, int BuffSize, LPCSTR DefStr)
    {return GetPrivateProfileString(Section, Entry, DefStr, Buff, BuffSize, IniFileName);}

VOID WINAPI WriteIniStrN(LPCSTR Section, int EntryNo, LPCSTR Buff)
    {
    CHAR Entry[16];
    wsprintf(Entry, Psnt1d, EntryNo);
    WriteIniStr(Section, Entry, Buff);
    }

int WINAPI GetIniInt(LPCSTR Section, LPCSTR Entry, int DefValue)
    {return GetPrivateProfileInt(Section, Entry, DefValue, IniFileName);}

int WINAPI GetIniStrN(LPCSTR Section, int EntryNo, LPSTR Buff, int BuffSize)
    {
    CHAR Entry[16];
    wsprintf(Entry, Psnt1d, EntryNo);
    return GetIniStr(Section, Entry, Buff, BuffSize);
    }

VOID WINAPI WriteIniStr(LPCSTR Section, LPCSTR Entry, LPCSTR Data)
    {WritePrivateProfileString(Section, Entry, Data, IniFileName);}

VOID WINAPI WriteIniInt(LPCSTR Section, LPCSTR Entry, int Value)
    {
    CHAR Buff[16];
    wsprintf(Buff, Psnt1d, Value);
    WriteIniStr(Section, Entry, Buff);
    }
#endif //INIFILE_EN



//-----------------------------------------------------------------------------
//      �ú��ʸ� ��Ĩ
//-----------------------------------------------------------------------------
INT32 WINAPI PackSecondExceptDate(CONST SYSTEMTIME *ST)
    {
    return ST->wHour*3600 + ST->wMinute*60 + ST->wSecond;
    }


VOID WINAPI UnpackSecondExceptDate(SYSTEMTIME *ST, INT32 Secs)
    {
    UINT Remain;

    Secs=UDivMod(Secs, 60, &Remain); ST->wSecond=(WORD)Remain;
    ST->wHour=(WORD)UDivMod(Secs, 60, &Remain);
    ST->wMinute=(WORD)Remain;
    }


VOID WINAPI UnpackMilliSecondExceptDate(SYSTEMTIME *ST, INT32 ms)
    {
    UINT Remain;

    ms=UDivMod(ms, 1000, &Remain); ST->wMilliseconds=(WORD)Remain;
    ms=UDivMod(ms, 60, &Remain);   ST->wSecond=(WORD)Remain;
    ST->wHour=(WORD)UDivMod(ms, 60, &Remain);
    ST->wMinute=(WORD)Remain;
    }



//-----------------------------------------------------------------------------
//      GMT UnixTime: 1970 ���ĸ� �ʴ����� ǥ���� (2106���� �ִ�) (WIN32��)
//      1335319508 -> 2012-04-25 11:05:08
//-----------------------------------------------------------------------------
#define ONEDAYSECONDS    86400  //=24*3600
DWORD WINAPI SystemTimeToUnixTime(CONST SYSTEMTIME *ST)
    {
    return (GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)-719163)*86400 + PackSecondExceptDate(ST);
    }



//-----------------------------------------------------------------------------
//      �־��� �ð��� 2000/1/1�� �������� �ؼ� �ʷ� ������� (���� �̸�: GetTotalSecond)
//      �ִ� ǥ�ð��� �ð�: 2136-02-07 06:28:15
//-----------------------------------------------------------------------------
JTIME WINAPI PackTotalSecond(CONST SYSTEMTIME *ST)
    {
    return (GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)-730120)*86400 + PackSecondExceptDate(ST);     //730120=GetTotalDays(2000,1,1) / 86400=24*60*60
    }




//-----------------------------------------------------------------------------
//      JTIME�� JTIME64�� ����
//-----------------------------------------------------------------------------
JTIME64 WINAPI JTimeToJTime64(JTIME JTime)
    {
    return (JTIME64)JTime*1000+63082368000000ULL;                               //2000������� ms = 63082368000000 ms = 730120*86400*1000;
    }



//-----------------------------------------------------------------------------
//      �־��� �ð��� AD�� �������� �ؼ� ms�� �������
//      �ִ� ǥ�ð��� �ð�: ���Ѿ��� (11,767,033 ����� ����)
//-----------------------------------------------------------------------------
JTIME64 WINAPI PackTotalSecond64(CONST SYSTEMTIME *ST)
    {
    JTIME64 T;

    T=(JTIME64)GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)*ONEDAYSECONDS + PackSecondExceptDate(ST);
    return T*1000 + ST->wMilliseconds;
    }




//-----------------------------------------------------------------------------
//      AD�� �������� ms���� ���� ����� �ú���,ms�� �и���
//-----------------------------------------------------------------------------
VOID WINAPI UnpackTotalSecond64(SYSTEMTIME *ST, JTIME64 JTime)
    {
    int  Y,M,D;
    UINT JT;

    JTime=UDiv64_32(JTime, 1000, &JT); ST->wMilliseconds=(WORD)JT;
    JTime=UDiv64_32(JTime, 60, &JT);   ST->wSecond=(WORD)JT;
    JTime=UDiv64_32(JTime, 60, &JT);   ST->wMinute=(WORD)JT;
    JTime=UDiv64_32(JTime, 24, &JT);   ST->wHour=(WORD)JT;

    ST->wDayOfWeek=(TDATE)JTime % 7;
    CnvFromTotalDay((TDATE)JTime, &Y, &M, &D);
    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)M;
    ST->wDay=(WORD)D;
    }




//-----------------------------------------------------------------------------
//      2000/1/1�� �������� �ʴ��� ���� ����Ͻú��ʷ� �и���
//      ST->wDayOfWeek �� ����� ���� ����
//-----------------------------------------------------------------------------
VOID WINAPI UnpackTotalSecond(SYSTEMTIME *ST, JTIME JTime)
    {
    int Y,M,D;
    UINT Remain;

    JTime=UDivMod(JTime, 60, &Remain); ST->wSecond=(WORD)Remain;
    JTime=UDivMod(JTime, 60, &Remain); ST->wMinute=(WORD)Remain;
    JTime=UDivMod(JTime, 24, &Remain); ST->wHour=(WORD)Remain;

    JTime+=730120;  //730120=GetTotalDays(2000,1,1)
    ST->wDayOfWeek=JTime % 7;
    CnvFromTotalDay(JTime, &Y, &M, &D);
    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)M;
    ST->wDay=(WORD)D;
    ST->wMilliseconds=0;
    }



//-----------------------------------------------------------------------------
//      CorTex M0���� �������� �ʴ� �޸� ��� �б�/����
//-----------------------------------------------------------------------------
VOID WINAPI PokeW(LPPKVOID Ptr, UINT W)
    {
    *((LPBYTE)Ptr+0)=(BYTE)W;
    *((LPBYTE)Ptr+1)=(BYTE)(W>>8);
    }


VOID WINAPI Poke(LPPKVOID Ptr, DWORD Dw)
    {
    *((LPBYTE)Ptr+0)=(BYTE)Dw;
    *((LPBYTE)Ptr+1)=(BYTE)(Dw>>8);
    *((LPBYTE)Ptr+2)=(BYTE)(Dw>>16);
    *((LPBYTE)Ptr+3)=(BYTE)(Dw>>24);
    }



VOID WINAPI PokeBIW(LPPKVOID Ptr, UINT W)
    {
    *((LPBYTE)Ptr+0)=(BYTE)(W>>8);
    *((LPBYTE)Ptr+1)=(BYTE)W;
    }


VOID WINAPI PokeBI(LPPKVOID Ptr, DWORD Dw)
    {
    *((LPBYTE)Ptr+0)=(BYTE)(Dw>>24);
    *((LPBYTE)Ptr+1)=(BYTE)(Dw>>16);
    *((LPBYTE)Ptr+2)=(BYTE)(Dw>>8);
    *((LPBYTE)Ptr+3)=(BYTE)Dw;
    }


//-----------------------------------------------------------------------------
//      1����Ʈ�� �е��� �ڵ��ص� Cortax-M7ó�� �ƹ��������� ���� �� �ִ�
//      MCU���� �������ϸ� �ѹ��� �е��� ��������
//-----------------------------------------------------------------------------
DWORD WINAPI Peek(LPCPKVOID Ptr)
    {
    return *(LPCBYTE)Ptr | (*((LPCBYTE)Ptr+1)<<8) | (*((LPCBYTE)Ptr+2)<<16) | (*((LPCBYTE)Ptr+3)<<24);
    }

UINT WINAPI PeekW(LPCPKVOID Ptr)
    {
    return *(LPCBYTE)Ptr | (*((LPCBYTE)Ptr+1)<<8);
    }


DWORD WINAPI PeekBI(LPCPKVOID Ptr)
    {
    return (*(LPCBYTE)Ptr<<24) | (*((LPCBYTE)Ptr+1)<<16) | (*((LPCBYTE)Ptr+2)<<8) | *((LPCBYTE)Ptr+3);
    }

UINT WINAPI PeekBIW(LPCPKVOID Ptr)
    {
    return (*(LPCBYTE)Ptr<<8) | *((LPCBYTE)Ptr+1);
    }

DWORD WINAPI PeekCDAB(LPCPKVOID Ptr)  //9B F8 48 42 -> 48429BF8
    {
    return (*(LPCBYTE)Ptr<<8) | *((LPCBYTE)Ptr+1) | (*((LPCBYTE)Ptr+2)<<24) | (*((LPCBYTE)Ptr+3)<<16);
    }


#if 0 //Startup_STM32F746xx.s ���� ������� ������
UINT WINAPI SwapIndianW(UINT W)
    {
    return (W>>8) | ((W&0xFF)<<8);
    }
#endif


//-----------------------------------------------------------------------------
//      �־��� �޸𸮸� �������� Hex���ڿ��� ����
//-----------------------------------------------------------------------------
VOID WINAPI MakeHexStr(LPSTR Buff, LPCBYTE lpMem, int MemSize)
    {
    BYTE B1, B2;
    while (MemSize--)
        {
        B1=*lpMem++;
        if ((B2=(B1>>4)+'0')>'9') B2+=7;
        *Buff++=B2;
        if ((B2=(B1&0x0F)+'0')>'9') B2+=7;
        *Buff++=B2;
        }
    *Buff=0;
    }



UINT WINAPI htons(UINT W)
    {
    return ((W&0xFF)<<8) | (W>>8);
    }




//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(LPCBYTE)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//-----------------------------------------------------------------------------
//      ���� ���ڸ� ���� �ݴϴ� (sscanf()�� %d���)
//      ���� �ܾ��� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanInt(LPCSTR Str, int *lpValue)
    {
    int I,J;

    Str=SkipSpace(Str);
    J=AtoI(Str, &I);
    if (I>0) *lpValue=J;
    return (BYTE)Str[I]>' ' ? NextWord(Str+I, 1):SkipSpace(Str+I);  //���ڵڿ� ���ڰ� �پ� ���� �� �� �Լ��� ȣ���ϸ� ���� �����͸� �����ϱ� ������ ���ѷ����� ���ư�
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ� 1�� ������ ��Ƹ�
//-----------------------------------------------------------------------------
int WINAPI GetBitCnt(UINT Value)
    {
    int Cnt=0;

    while (Value!=0)
        {
        if (Value&1) Cnt++;
        Value>>=1;
        }
    return Cnt;
    }



//-----------------------------------------------------------------------------
//      CRC�� ����Ѵ�
//-----------------------------------------------------------------------------
DWORD WINAPI CalculateCRC(LPCBYTE Buff, DWORD BuffSize, DWORD PreCRC)
    {
    int I;
    DWORD Dw, Crc;

    Crc=PreCRC;
    while (BuffSize--)
        {
        Dw=(*Buff++) ^ (Crc & 0xFF);
        Crc>>=8;
        for (I=0; I<8; I++)     //CRC Table�� ����ϴ�
            {
            if (Dw & 1) {Dw>>=1; Dw^=0xEDB88320L;}
            else Dw>>=1;
            }
        Crc^=Dw;
        }
    return Crc;
    }




//-----------------------------------------------------------------------------
//      CRC16�� ����Ѵ�
//
//      http://www.zorc.breitbandkatze.de/crc.html
//      Crc�ʱⰪ�� 0xFFFF�� �ָ� CCITT CRC16���� ��µ�
//-----------------------------------------------------------------------------
UINT WINAPI CalculateCrc16(LPCVOID Buff, UINT BuffSize, UINT Crc)
    {
    UINT I;

    while (BuffSize--)
        {
        Crc^=*(LPCBYTE)Buff <<8;
        Buff=(LPCBYTE)Buff+1;

        for (I=0; I<8; I++)
            {
            if (Crc & 0x8000) {Crc<<=1; Crc^=0x1021;} else Crc<<=1;
            }
        }
    return Crc & 0xFFFF;
    }




//-----------------------------------------------------------------------------
//      ��ũ���� / ��ũ����
//-----------------------------------------------------------------------------
VOID WINAPI EncryptDecrypt(LPBYTE Buff, int BuffSize, DWORD Crc, int Mode)
    {
    int I;
    DWORD Dw;

    while (BuffSize--)
        {
        if (Mode==ED_ENCRYPT)
            {
            Dw=Buff[0] ^ (Crc & 0xFF);
            Buff[0]^=(BYTE)Crc;
            }
        else{
            Buff[0]^=(BYTE)Crc;
            Dw=Buff[0] ^ (Crc & 0xFF);
            }
        Buff++;

        Crc>>=8;
        for (I=0; I<8; I++)
            {
            if (Dw & 1) {Dw>>=1; Dw^=0xEDB88320;}
            else Dw>>=1;
            }
        Crc^=Dw;
        }
    }




//-----------------------------------------------------------------------------
//      �־��� float ���� Digit ���� �������� ������
//      float(IEEE-754) ���� ������ ��ȯ��
//      INTPARTBITS==25 �̸� (0.1 ~ 200,0000.0 ����)
//          Fixed 25:7  25��Ʈ ������ 7��Ʈ �Ҽ����ڸ���
//-----------------------------------------------------------------------------
#define INTPARTBITS     25  //�����Ҽ�����Ŀ��� �����η� �Ҵ�� ��Ʈ��
#define FRACPARTBITS    (32-INTPARTBITS)
int WINAPI FloatToInt(UINT Float, UINT Digit, UINT Max)
    {
    int  Exp, Value=Max;
    UINT Frac;

    Frac=(Float|0x800000)<<8;   //������ ��Ʈ�� �����ϰ� �� ������ ����
    Exp=((Float<<1)>>24)-126-INTPARTBITS; //����

    if (Exp>0) goto ProcExit;   //OverFlow

    Exp=-Exp;
    if (Exp<INTPARTBITS)        //�����ΰ� �ִ� ���
        {
        Frac>>=Exp;
        if ((Frac>>FRACPARTBITS)>Max/Digit) goto ProcExit;  //OverFlow
        Value=(Frac>>FRACPARTBITS)*Digit + UMulDiv((Frac<<INTPARTBITS)>>INTPARTBITS, Digit, 1<<FRACPARTBITS);
        }
    else{                           //��ȿ���ڴ� ��� �Ҽ���
        Frac>>=Exp-INTPARTBITS+1;   //+1�� ��� ������ ����� ����
        Value=UMulDiv(Frac, Digit, 0x80000000); //= 1<<31
        }

    ProcExit:
    if ((Float>>31)!=0) Value=-Value;
    return Value;
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڸ� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI InsCha(LPSTR SrcStr, int InsLoc, int Cha)
    {
    int SLen;

    SLen=lstrlen(SrcStr);
    if (InsLoc<=SLen)
        {
        while (InsLoc<=SLen)
            {
            SrcStr[1+SLen]=SrcStr[SLen];                //+1�� Null���ڱ���
            SLen--;
            }
        SrcStr[InsLoc]=Cha;
        }
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڿ��� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI InsStr(LPSTR SrcStr, int InsLoc, LPCSTR ToInsStr)
    {
    int SLen, ILen;

    SLen=lstrlen(SrcStr);
    ILen=lstrlen(ToInsStr);
    if (InsLoc<=SLen && ILen>0)
        {
        while (SLen>=InsLoc)
            {
            SrcStr[ILen+SLen]=SrcStr[SLen];
            SLen--;
            }
        CopyMem(SrcStr+InsLoc, ToInsStr, ILen);
        }
    }



//-----------------------------------------------------------------------------
//              ��ȭ��ȣ ���ڿ��� �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI AdjustDialStr(LPSTR DialStr, int BuffLen)
    {
    int I=0, Len, Remainder;

    if (lstrlen(DialStr)<=5 || IsNumeric(DialStr[0])==FALSE) goto ProcExit;

    BuffLen--;
    if ((Len=lstrlen(DialStr))<BuffLen && DialStr[0]=='0')
        {
        if (DialStr[1]=='2')
            {
            if (Len<2) goto ProcExit;
            InsCha(DialStr, 2, '-'); I=3;
            }
        else{
            if (Len<3) goto ProcExit;
            InsCha(DialStr, 3, '-'); I=4;
            }
        }
    if ((Len=lstrlen(DialStr))<BuffLen)
        {
        Remainder=Len-I;
        if (Remainder>8) DelAllCha(DialStr, '-');
        else if (Remainder==8) InsCha(DialStr, I+4, '-');
        else if (Remainder>=3) InsCha(DialStr, I+3, '-');
        }
    ProcExit:;
    }




//-----------------------------------------------------------------------------
//      Word Array���� �־��� Word�� ã�� (ã�� �ε����� ��, ��ã���� -1)
//      WordArray�� ������������ ���ĵǾ� �־�� ��
//-----------------------------------------------------------------------------
int WINAPI BinSearchWord(CONST WORD *ArrayBase, UINT Elements, UINT SearchWord)
    {
    int Rslt, Find=-1, Half, Low=0, Mid;

    while (Elements>0)
        {
        Half=Elements>>1;
        Mid=Low+Half;
        if ((Rslt=SearchWord-ArrayBase[Mid])==0) {Find=Mid; break;}
        if (Rslt<0)
            {
            Elements=Half;
            }
        else{
            Low=Mid+1;
            Elements=(Elements&1) ? Half:Half-1;
            }
        }
    return Find;
    }



///////////////////////////////////////////////////////////////////////////////
//              �ܺ� �޼��� ��Ʈ��
///////////////////////////////////////////////////////////////////////////////

#define MSGBUFFSIZE     4096
extern LPCSTR MessageStrList[];

//-----------------------------------------------------------------------------
//      �־��� �̸��� �޼����� ������, ������ �޼��� �̸��� ����
//-----------------------------------------------------------------------------
LPCSTR WINAPI GetMsgStr(LPCSTR MsgName)
    {
    int Len;
    LPCSTR Msg, *MsgList, FindMsg=MsgName;

    Len=lstrlen(MsgName);
    for (MsgList=MessageStrList; (Msg=MsgList[0])!=NULL; MsgList++)
        {
        if (CompMem(Msg, MsgName, Len)==0 && Msg[Len]=='=')
            {
            FindMsg=Msg+Len+1;
            break;
            }
        }
    return FindMsg;
    }





//-----------------------------------------------------------------------------
//      ������ ����
//      (���̸�: FreeStrBuff)
//-----------------------------------------------------------------------------
typedef struct _ElasticBuffer
    {
    int BuffSize, BlockSize, DataSize;
    LPSTR Buffer;
    } ElasticBuffer;

HELB WINAPI ELB_New(int BlockSize)
    {
    HELB EB;

    if ((EB=AllocMemS(ElasticBuffer, MEMOWNER_ELB_New))!=NULL)
        {
        ZeroMem(EB, sizeof(ElasticBuffer));
        EB->BlockSize=BlockSize;
        }
    return EB;
    }

LPSTR WINAPI ELB_ReleaseHusk(HELB EB) {LPSTR lp=EB->Buffer; FreeMem(EB); return lp;}
VOID  WINAPI ELB_Delete(HELB EB) {if (EB) {FreeMem(EB->Buffer); FreeMem(EB);}}
VOID  WINAPI ELB_Clear(HELB EB) {if (EB->Buffer!=NULL) EB->Buffer[0]=0; EB->DataSize=0;}
LPCSTR WINAPI ELB_GetBuffer(HELB EB) {return EB->Buffer!=NULL ? EB->Buffer:NullStr;}
int   WINAPI ELB_UpdateSize(HELB EB, int Size) {EB->DataSize+=Size; EB->Buffer[EB->DataSize]=0; return EB->DataSize;}
int WINAPI ELB_GetLength(HELB EB)
    {
    if (EB->Buffer) EB->DataSize+=lstrlen(EB->Buffer+EB->DataSize); //Prepare()�� ���� ���ۿ� ���� ������ ��üũ�⿡ �ݿ�
    return EB->DataSize;
    }
LPSTR WINAPI ELB_Prepare(HELB EB, int ReqSize)
    {
    LPSTR End=NULL, New;

    ReqSize++;          //�ǵڿ� 0�� �ֱ� ����
    if (EB->Buffer==NULL)
        {
        EB->DataSize=0;
        EB->BuffSize=(ReqSize+EB->BlockSize)/EB->BlockSize*EB->BlockSize;
        if ((End=EB->Buffer=(LPSTR)AllocMem(EB->BuffSize, MEMOWNER_FreeStrBuffPrepare1))!=NULL) End[0]=0;
        else EB->BuffSize=0;
        }
    else{
        ELB_GetLength(EB);      //Prepare()�� ���� ���ۿ� ���� ������ ��üũ�⿡ ����
        End=EB->Buffer+EB->DataSize;
        if (EB->BuffSize-EB->DataSize<ReqSize)
            {
            End=NULL;
            EB->BuffSize=(EB->DataSize+ReqSize+EB->BlockSize)/EB->BlockSize*EB->BlockSize;
            if ((New=(LPSTR)AllocMem(EB->BuffSize, MEMOWNER_FreeStrBuffPrepare2))!=NULL)
                {
                if (EB->DataSize>0) {CopyMem(New, EB->Buffer, EB->DataSize); New[EB->DataSize]=0;}  //�ӵ������ ���� lstrcpy()�� �Ⱦ�, ���̰� �乮�ڿ� ���� ��꿡�� �ð��� �ɸ�
                FreeMem(EB->Buffer);
                EB->Buffer=New;
                End=EB->Buffer+EB->DataSize;
                }
            }
        }
    return End;
    }

LPSTR WINAPI ELB_PutBin(HELB EB, LPCVOID Data, int Len)
    {
    LPSTR lp;

    if ((lp=ELB_Prepare(EB, Len))!=NULL)
        {
        CopyMem(lp, Data, Len);
        lp[Len]=0;      //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize+=Len;
        }
    return lp;
    }

LPSTR WINAPI ELB_PutByte(HELB EB, int Byt)
    {
    LPSTR lp;

    if ((lp=ELB_Prepare(EB, 1))!=NULL)
        {
        lp[0]=Byt;
        lp[1]=0;        //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize++;
        }
    return lp;
    }


LPSTR WINAPI ELB_PutWord(HELB EB, int W)
    {
    LPSTR lp;

    if ((lp=ELB_Prepare(EB, 2))!=NULL)
        {
        PokeW(lp, W);
        lp[2]=0;        //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize+=2;
        }
    return lp;
    }


LPSTR WINAPI ELB_PutDword(HELB EB, int Dw)
    {
    LPSTR lp;

    if ((lp=ELB_Prepare(EB, 4))!=NULL)
        {
        Poke(lp, Dw);
        lp[4]=0;        //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize+=4;
        }
    return lp;
    }


LPSTR WINAPI ELB_PutQword(HELB EB, INT64 Qw)
    {
    LPSTR lp;

    if ((lp=ELB_Prepare(EB, 8))!=NULL)
        {
        Poke(lp, (DWORD)Qw);
        Poke(lp+4, (DWORD)(Qw>>32));
        lp[8]=0;        //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize+=8;
        }
    return lp;
    }


LPSTR WINAPI ELB_PutString(HELB EB, LPCSTR Str)
    {
    int Len;
    LPSTR lp;

    Len=lstrlen(Str);
    if ((lp=ELB_Prepare(EB, Len))!=NULL)
        {
        CopyMem(lp, Str, Len+1);
        EB->DataSize+=Len;
        }
    return lp;
    }


VOID WINAPI ELB_TrimEnd(HELB EB)
    {
    int I;

    while ((I=EB->DataSize)>0)
        {
        I--;
        if (*((LPCBYTE)EB->Buffer+I)>' ') break;
        EB->Buffer[I]=0;
        EB->DataSize--;
        }
    }


LPSTR WINAPI ELB_PutLenStr(HELB EB, LPCSTR Str) //ThingWorx���� �����
    {
    int Len;
    LPSTR lp;

    Len=lstrlen(Str);
    if ((lp=ELB_Prepare(EB, Len+1))!=NULL)
        {
        lp[0]=Len;
        CopyMem(lp+1, Str, Len);
        lp[Len+1]=0;    //Prepare() ���ڿ����۷� �ν��ϰ� ���� �ұ������� �� ���� ���� �ϱ� ����
        EB->DataSize+=Len+1;
        }
    return lp;
    }


LPSTR WINAPIV ELB_Printf(HELB EB, LPCSTR FormStr, ...)
    {
    int   BLen;
    LPSTR lp;
    va_list VL;

    va_start(VL, FormStr);
    BLen=VsprintfN(NULL, 0, FormStr, VL);   //�ڿ� 0���� ũ�⸦ ������
    if ((lp=ELB_Prepare(EB, BLen))!=NULL)
        {
        VsprintfN(lp, BLen, FormStr, VL);
        ELB_GetLength(EB);
        }
    va_end(VL);
    return lp;
    }


int WINAPI ELB_GetData(HELB EB, LPVOID Buff, int ReqSize)   //Buff�� NULL�� �ָ� �����͸� ������
    {
    int CopyBytes=0;

    if (EB->Buffer!=NULL &&
        (CopyBytes=GetMin(ELB_GetLength(EB), ReqSize))>0)
        {
        if (Buff) CopyMem(Buff, EB->Buffer, CopyBytes);
        EB->DataSize-=CopyBytes;
        if (EB->DataSize>0) memmove(EB->Buffer, EB->Buffer+CopyBytes, EB->DataSize);  //������ ������ ����
        EB->Buffer[EB->DataSize]=0;
        }
    return CopyBytes;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
LOCAL(int) Base64Dec(int Cha)
    {
    if (Cha=='+') Cha=0x3E;
    else if (Cha=='/') Cha=0x3F;
    else if (Cha>='0' && Cha<='9') Cha-='0'-0x34;
    else if (Cha>='A' && Cha<='Z') Cha-='A';
    else if (Cha>='a' && Cha<='z') Cha-='a'-0x1A;
    else Cha=-1;
    return Cha;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
LOCAL(CHAR) Base64Enc(BYTE Byt)
    {
    Byt&=0x3F;
    if (Byt==0x3E) Byt='+';
    else if (Byt==0x3F) Byt='/';
    else if (Byt<=0x19) Byt+='A';
    else if (Byt<=0x33) Byt+='a'-0x1A;
    else Byt+='0'-0x34;
    return Byt;
    }




//-----------------------------------------------------------------------------
//      '+'�� %2B �������� �ٲߴϴ�
//-----------------------------------------------------------------------------
LOCAL(LPSTR) ChaToPsntHex(LPSTR Buff, int Cha)
    {
    int B;

    *Buff++='%';
    if ((B=((Cha>>4) & 0x0F)+'0')>'9') B+=7;    //7='A'-'0'-10
    *Buff++=B;
    if ((B=(Cha      & 0x0F)+'0')>'9') B+=7;
    *Buff++=B;
    return Buff;
    }




//-----------------------------------------------------------------------------
//      2���� Hex���ڸ� ������ ����
//-----------------------------------------------------------------------------
DWORD WINAPI Hex2Int(LPCSTR StrBuff, int ChaQty)
    {
    int I, Cha;
    DWORD Dw=0;

    for (I=0; I<ChaQty; I++)
        {
        Cha=*StrBuff++;
        if (Cha>='0' && Cha<='9') Cha-='0';
        else if (Cha>='A' && Cha<='F') Cha-='A'-10;
        else if (Cha>='a' && Cha<='f') Cha-='a'-10;
        else break;

        Dw<<=4;
        Dw|=Cha;
        }
    return Dw;
    }



//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
int WINAPI DecodeBase64(LPCSTR InBuff, LPSTR OutBuff, int Inlen)
    {
    int  Cha, Code, DecodeSize, RemainBits, NowBits, NeedBits;
    UINT BufW;

    BufW=DecodeSize=RemainBits=0;
    if (Inlen<0) Inlen=lstrlen(InBuff);
    while (Inlen>0)
        {
        Cha=*InBuff++; Inlen--; if (Cha==0) break;
        if (Cha=='%')
            {
            Cha=*InBuff++; Inlen--; if (Cha==0) break;
            Cha=*InBuff++; Inlen--; if (Cha==0) break;
            Cha=Hex2Int(InBuff-2, 2);
            }
        if (Cha>' ')
            {
            if ((Code=Base64Dec(Cha))<0) break;
            BufW|=Code<<2;
            NowBits=6;

            while (NowBits>0)
                {
                NeedBits=GetMin(8-RemainBits, NowBits);
                BufW<<=NeedBits; RemainBits+=NeedBits; NowBits-=NeedBits;
                if (RemainBits==8) {*OutBuff++=BufW>>8; DecodeSize++; RemainBits=0;}
                }
            }
        }
    /*
    if (RemainBits>0)   //Web������ ���� 4Byte¦�� ���߱� ������ ¥������ ���� ����
        {
        LoByte(BufW)=0;
        BufW<<=8-RemainBits;
        *OutBuff++=HiByte(BufW); DecodeSize++;
        }*/
    return DecodeSize;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ� (���۸� ����� �ٰ�)
//      OutBuff ����.. CnvToWebStr==0 �ΰ��� InDataLen * 1.5 + 4
//                     CnvToWebStr!=0 �ΰ��� InDataLen * 1.5 * 3
//-----------------------------------------------------------------------------
VOID WINAPI EncodeBase64(LPCSTR InBuff, int InDataLen, LPSTR OutBuff, int LineLen, BOOL CnvToWebChaFg)
    {
    WORD BufW;
    CHAR Cha;
    int  EncodeSize, RemainBits, NowBits, LineChaCnt;

    EncodeSize=RemainBits=LineChaCnt=0;
    //_asm int 3;
    BufW=0;
    while (InDataLen>0)
        {
        NowBits=0;
        if (RemainBits<6)
            {
            BufW<<=RemainBits; NowBits=RemainBits;
            LoByteW(BufW)=*InBuff++; InDataLen--; RemainBits+=8;
            }
        if (NowBits<6)
            {
            BufW<<=6-NowBits;
            }

        Cha=Base64Enc(HiByte(BufW)); RemainBits-=6; EncodeSize++;
        if (CnvToWebChaFg!=0 && Cha=='+') OutBuff=ChaToPsntHex(OutBuff, Cha); else *OutBuff++=Cha;

        if (LineLen>0 && ++LineChaCnt>=LineLen)
            {
            *OutBuff++=13;
            *OutBuff++=10;
            LineChaCnt=0;
            }
        }

    if (RemainBits>0)
        {
        BufW<<=6;
        Cha=Base64Enc(HiByte(BufW)); EncodeSize++;
        if (CnvToWebChaFg!=0 && Cha=='+') OutBuff=ChaToPsntHex(OutBuff, Cha); else *OutBuff++=Cha;
        }

    while ((EncodeSize & 3)!=0)
        {
        EncodeSize++;
        /*if (CnvToWebChaFg!=0) OutBuff=ChaToPsntHex(OutBuff, '='); else*/ *OutBuff++='=';
        }

    *OutBuff=0;
    }




//-----------------------------------------------------------------------------
//              Data�� ��ũ������
//-----------------------------------------------------------------------------
VOID WINAPI Scrambling(LPVOID lpMem, UINT MemSize, LPCSTR EncrypKey)
    {
    DWORD XorCode;

    XorCode=CalculateCRC((LPCBYTE)EncrypKey, lstrlen(EncrypKey), 0x75FA98ED);

    while (MemSize>=4)
        {
        *(DWORD*)lpMem^=XorCode;
        XorCode++;
        if (XorCode & 1) {XorCode>>=1; XorCode|=0x80000000;} else XorCode>>=1;  //ror XorCode,1
        lpMem=(LPBYTE)lpMem+4;
        MemSize-=4;
        }

    XorCode&=0xFF;      //Rotate�Ҷ� ������ ���� ������ ������ ��
    while (MemSize--)
        {
        *(LPBYTE)lpMem^=(BYTE)XorCode;
        XorCode++;
        if (XorCode & 1) {XorCode>>=1; XorCode|=0x80;} else XorCode>>=1;        //ror (BYTE)XorCode,1
        lpMem=(LPBYTE)lpMem+1;
        }
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �ڿ��� ���ڿ��� ã��
//-----------------------------------------------------------------------------
int WINAPI SearchBackCha(LPCSTR Str, int Cha)
    {
    int I;

    I=lstrlen(Str);
    while (--I>=0)
        {
        if (Str[I]==Cha) break;
        }
    return I;
    }



//-----------------------------------------------------------------------------
//      Full Path���� ���ϸ�������ġ�� �ش�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetFileNameLocU8(LPSTR FPath)
    {
    return SearchBackCha(FPath, '/')+FPath+1;
    }



//-----------------------------------------------------------------------------
//      Full Path���� ����Ȯ���������ġ�� �ش�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetFileExtNameLoc(LPSTR FPath)
    {
    int I;

    if ((I=SearchBackCha(FPath, '.'))<0) I=lstrlen(FPath)-1;
    return I+1+FPath;
    }




//-----------------------------------------------------------------------------
//      �µ��� ������ ǥ��
//-----------------------------------------------------------------------------
#define COLORMAX    255
LOCAL(int) MulDivS(int A, int B, int C) {return (A*B+(C>>1))/C;}
COLORREF WINAPI GetTempColor(int Temp, int Width)
    {
    int R,G,B, Half, Q1, Q3;

    Q1=MulDivS(183, Width, 512);
    Q3=MulDivS(353, Width, 512);
    Half=Width>>1;

    if (Temp<Half) G=MulDivS(Temp,       COLORMAX-55, Half)+55;
    else      if ((G=MulDivS(Width-Temp, COLORMAX-48, Half)+48)>255) G=255;

    if (Temp<Half) B=COLORMAX;
    else if (Temp<Q3) B=MulDivS(Q3-Temp, COLORMAX, Q3-Half);
    else B=0;

    if (Temp<Q1) R=0;
    else if (Temp<Half) R=MulDivS(Temp-Q1, COLORMAX, Half-Q1);
    else R=COLORMAX;

    return RGB(B,G,R);
    }



//-----------------------------------------------------------------------------
//      BMP���Ͽ��� ������ ���̸� ����
//-----------------------------------------------------------------------------
int WINAPI GetBmp1LineBytes(int Width, int ColBits)
    {
    return ((Width*ColBits+31) & ~31) >>3;
    }



//-----------------------------------------------------------------------------
//      RECT ���� �Լ�
//-----------------------------------------------------------------------------
VOID WINAPI PrintRect(LPCSTR Title, CONST RECT *R)
    {
    Printf("%s %d,%d - %d,%d (%d,%d)"CRLF, Title, R->left, R->top, R->right, R->bottom, R->right-R->left, R->bottom-R->top);
    }


VOID WINAPI SetRectEmpty(LPRECT R)
    {
    ZeroMem(R, sizeof(RECT));
    }


BOOL WINAPI IsRectEmpty(CONST RECT *R)
    {
    return R->left>=R->right || R->top>=R->bottom;
    }


BOOL WINAPI EqualRect(CONST RECT *R1, CONST RECT *R2)
    {
    return CompareMem(R1, R2, sizeof(RECT))==0;
    }


VOID WINAPI SetRect(LPRECT R, int Left, int Top, int Right, int Bottom)
    {
    R->left=Left;
    R->top=Top;
    R->right=Right;
    R->bottom=Bottom;
    }


VOID WINAPI OffsetRect(LPRECT R, int X, int Y)
    {
    R->left+=X;
    R->right+=X;
    R->top+=Y;
    R->bottom+=Y;
    }


VOID WINAPI InflateRect(LPRECT R, int X, int Y)
    {
    R->left-=X;
    R->right+=X;
    R->top-=Y;
    R->bottom+=Y;
    }



//-----------------------------------------------------------------------------
//      �� �簢���� ��ġ�� �κ��� ������ ���簢���� ����
//      �簢���� �������� ������ �� �簢��(��� ��ǥ�� 0���� ���� ��)�� ��� ����
//-----------------------------------------------------------------------------
BOOL WINAPI IntersectRect(RECT *DR, CONST RECT *R1, CONST RECT *R2)
    {
    if (IsRectEmpty(R1) || IsRectEmpty(R2)) goto ErExit;
    DR->left  =GetMax(R1->left, R2->left);
    DR->right =GetMin(R1->right, R2->right);
    DR->top   =GetMax(R1->top, R2->top);
    DR->bottom=GetMin(R1->bottom, R2->bottom);
    if (IsRectEmpty(DR)) {ErExit: SetRectEmpty(DR); return FALSE;}
    return TRUE;
    }

BOOL WINAPI MyIntersectRect(RECT *R1, CONST RECT *R2)
    {
    if (IsRectEmpty(R1) || IsRectEmpty(R2)) goto ErExit;
    R1->left  =GetMax(R1->left, R2->left);
    R1->right =GetMin(R1->right, R2->right);
    R1->top   =GetMax(R1->top, R2->top);
    R1->bottom=GetMin(R1->bottom, R2->bottom);
    if (IsRectEmpty(R1)) {ErExit: SetRectEmpty(R1); return FALSE;}
    return TRUE;
    }




//-----------------------------------------------------------------------------
//      �� �簢���� ��ġ�� �κ��� �ִ��� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsIntersectRect(CONST RECT *R1, CONST RECT *R2)
    {
    RECT T;

    T.left  =GetMax(R1->left, R2->left);
    T.right =GetMin(R1->right, R2->right);
    T.top   =GetMax(R1->top, R2->top);
    T.bottom=GetMin(R1->bottom, R2->bottom);
    return IsRectEmpty(&T)==FALSE;
    }



//-----------------------------------------------------------------------------
//      R1�� R2�� ��� ���ԵǴ��� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsIncludeRect(CONST RECT *R1, CONST RECT *R2)
    {
    //if (R1->left>R1->right) SwapInt(&R1->left, &R1->right);
    //if (R1->top>R1->bottom) SwapInt(&R1->top, &R1->bottom);
    //if (R2->left>R2->right) SwapInt(&R2->left, &R2->right);
    //if (R2->top>R2->bottom) SwapInt(&R2->top, &R2->bottom);
    return R2->left   >= R1->left &&
           R2->right  <= R1->right &&
           R2->top    >= R1->top &&
           R2->bottom <= R1->bottom;
    }



//-----------------------------------------------------------------------------
//      �� �ҽ� �簢���� ��� �����ϴ� ���� ���� �簢���� ����
//-----------------------------------------------------------------------------
BOOL WINAPI UnionRect(RECT *DR, CONST RECT *R1, CONST RECT *R2)
    {
    BOOL Rslt=FALSE;

    if (IsRectEmpty(R1))
        {
        if (IsRectEmpty(R2)) SetRectEmpty(DR);
        else {*DR=*R2; Rslt++;}
        }
    else if (IsRectEmpty(R2)) {*DR=*R1; Rslt++;}
    else{
        DR->left  =GetMin(R1->left, R2->left);
        DR->right =GetMax(R1->right, R2->right);
        DR->top   =GetMin(R1->top, R2->top);
        DR->bottom=GetMax(R1->bottom, R2->bottom);
        Rslt++;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �� �ҽ� �簢���� ��� �����ϴ� ���� ���� �簢���� ����
//-----------------------------------------------------------------------------
VOID WINAPI MyUnionRect(INOUT RECT *R1, CONST RECT *R2)
    {
    if (IsRectEmpty(R1)) *R1=*R2;
    else if (IsRectEmpty(R2)==FALSE)
        {
        R1->left  =GetMin(R1->left, R2->left);
        R1->right =GetMax(R1->right, R2->right);
        R1->top   =GetMin(R1->top, R2->top);
        R1->bottom=GetMax(R1->bottom, R2->bottom);
        }
    }



//-----------------------------------------------------------------------------
//      DR=R1-R2, R2�� ���̳� ���̰� R1���� �� �� ���� ��� DR==R1��
//-----------------------------------------------------------------------------
BOOL WINAPI SubtractRect(RECT *DR, CONST RECT *R1, CONST RECT *R2)
    {
    BOOL Rslt=FALSE;
    RECT T;

    *DR=*R1;
    if (IsRectEmpty(R1)) goto ProcExit;
    if (IsRectEmpty(R2) || IntersectRect(&T, R1, R2)==FALSE) goto ProcExit;

    if (DR->top==T.top && DR->bottom==T.bottom)
        {
        if (DR->left==T.left)          DR->left=T.right;   //DR�� R1�� ��ġ�ϴ� ��� �Ʒ����� Emptyó���� ��
        else if (DR->right==T.right)   DR->right=T.left;
        }
    else if (DR->left==T.left && DR->right==T.right)
        {
        if (DR->top==T.top)            DR->top=T.bottom;
        else if (DR->bottom==T.bottom) DR->bottom=T.top;
        }

    ProcExit:
    if (IsRectEmpty(DR)) SetRectEmpty(DR); else Rslt++;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      R1-=R2, R2�� ���̳� ���̰� R1���� �� �� ���� ��� R1�� ������ ����
//      ��� ������ �������� Empty�� �Ǹ� FALSE�� ����
//-----------------------------------------------------------------------------
BOOL WINAPI SubRect(RECT *R1, CONST RECT *R2)
    {
    BOOL Rslt=FALSE;
    RECT T;

    if (IsRectEmpty(R1)) goto ProcExit;

    if (IsRectEmpty(R2) || IntersectRect(&T, R1, R2)==FALSE) {Rslt++; goto ProcExit;}

    if (R1->top==T.top && R1->bottom==T.bottom)
        {
        if (R1->left==T.left)          R1->left=T.right;
        else if (R1->right==T.right)   R1->right=T.left;
        }
    else if (R1->left==T.left && R1->right==T.right)
        {
        if (R1->top==T.top)            R1->top=T.bottom;
        else if (R1->bottom==T.bottom) R1->bottom=T.top;
        }
    if (IsRectEmpty(R1)) SetRectEmpty(R1); else Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      RECTLIST�� RECT�� �ǵڿ� �߰���
//-----------------------------------------------------------------------------
BOOL WINAPI AddRectList(RECTLIST *RL, CONST RECT *R)
    {
    BOOL Rslt=Rslt;
    RECT *New;

    if (RL->CurrQty>=RL->AllocQty)
        {
        RL->AllocQty+=50;
        if ((New=(LPRECT)AllocMem(RL->AllocQty*sizeof(RECT), MEMOWNER_AddRectList))==NULL) goto ProcExit;
        if (RL->CurrQty>0) CopyMem(New, RL->RectList, RL->CurrQty*sizeof(RECT));
        FreeMem(RL->RectList);
        RL->RectList=New;
        }
    RL->RectList[RL->CurrQty++]=*R;
    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      RECTLIST�� RECT�� �Ǿտ� �߰���
//      ���ھٹ��� ť�� ���� ǥ�ÿ����� ����ϹǷ� ���ɹ����ϰ� ����
//-----------------------------------------------------------------------------
BOOL WINAPI AddRectListFront(RECTLIST *RL, CONST RECT *R)
    {
    int I, Rslt;

    if ((Rslt=AddRectList(RL, R))!=FALSE)   //�ϴ� �ǵڿ� �߰��ϰ�
        {
        if (RL->CurrQty>1)
            {
            for (I=RL->CurrQty-1; I>0; I--) RL->RectList[I]=RL->RectList[I-1];
            RL->RectList[0]=*R;
            }
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �簢���� ����, RectList�� ���ҵ� �� ����
//-----------------------------------------------------------------------------
VOID WINAPI SubRectEx(RECTLIST *RL, CONST RECT *ToSub)
    {
    int  I, OrgCnt, Adds;
    RECT T, *CR, TR[4];

    OrgCnt=RL->CurrQty;
    for (I=0; I<OrgCnt; I++)
        {
        CR=RL->RectList+I;
        if (IntersectRect(&T, CR, ToSub))
            {
            Adds=0;
            if (CR->top<T.top)      {SetRect(TR, CR->left, CR->top, CR->right, T.top); Adds++;}             //��
            if (CR->left<T.left)    {SetRect(TR+Adds, CR->left, T.top, T.left, T.bottom); Adds++;}          //��
            if (CR->right>T.right)  {SetRect(TR+Adds, T.right, T.top, CR->right, T.bottom); Adds++;}        //��
            if (CR->bottom>T.bottom){SetRect(TR+Adds, CR->left, T.bottom, CR->right, CR->bottom); Adds++;}  //�Ʒ�
            SetRectEmpty(CR);
            for (I=0; I<Adds; I++) AddRectList(RL, TR+I);
            }
        }

    //�� RECT ����
    for (I=OrgCnt=0; I<RL->CurrQty; I++)
        {
        CR=RL->RectList+I;
        if (IsRectEmpty(CR)==FALSE)
            {
            if (I!=OrgCnt) RL->RectList[OrgCnt]=*CR;
            OrgCnt++;
            }
        }
    RL->CurrQty=OrgCnt;
    }



BOOL WINAPI PtInRect(CONST RECT *R, POINT P)
    {
    return P.x>=R->left && P.x<R->right && P.y>=R->top && P.y<R->bottom;
    }




///////////////////////////////////////////////////////////////////////////////
//              ���ڿ� ����Ʈ ����
///////////////////////////////////////////////////////////////////////////////


//------------------------------------------------------------------------------
//      �ǵڿ� ���ڿ� �߰�
//------------------------------------------------------------------------------
StringList* WINAPI AddStringList(StringList **Root, LPCSTR ToAddStr)
    {
    StringList *SL, *TailSL;

    if ((SL=(StringList*)AllocMem(lstrlen(ToAddStr)+sizeof(StringList), MEMOWNER_AddStringList))==NULL) goto ProcExit;
    ZeroMem(SL, sizeof(StringList));
    lstrcpy(SL->String, ToAddStr);

    if ((TailSL=*Root)==NULL) *Root=SL;
    else{
        while (TailSL->Next!=NULL) TailSL=TailSL->Next;
        TailSL->Next=SL;
        }

    ProcExit:
    return SL;
    }



//------------------------------------------------------------------------------
//      ���ڿ� ���� (���η�)
//------------------------------------------------------------------------------
BOOL WINAPI DelStringList(StringList **Root, StringList *DelStr)
    {
    BOOL Rslt=FALSE;
    StringList *SL;

    if (*Root==DelStr) {*Root=DelStr->Next; goto DeleteProc;}
    else
        for (SL=*Root; SL!=NULL; SL=SL->Next)
            if (SL->Next==DelStr)
                {
                SL->Next=DelStr->Next;

                DeleteProc:
                FreeMem(DelStr);
                Rslt++;
                break;
                }
    return Rslt;
    }

VOID WINAPI DelAllStringList(StringList **Root)
    {
    StringList *SL;

    while ((SL=*Root)!=NULL) DelStringList(Root, SL);
    }



//-----------------------------------------------------------------------------
//      �־��� ��ȣ�� �ش��ϴ� ���ڿ��� �� (���η�)
//-----------------------------------------------------------------------------
StringList* WINAPI GetStringList(StringList *Root, int No)
    {
    int I;
    StringList *SL;
    for (SL=Root, I=0; SL!=NULL; SL=SL->Next, I++) if (I==No) break;
    return SL;
    }



//-----------------------------------------------------------------------------
//      Red�� Blue�� �ٲ۴�
//-----------------------------------------------------------------------------
COLORREF WINAPI SwapRedBlue(COLORREF Col)
    {
    return ((Col>>16)&0xFF) | (Col&0xFF00) | ((Col&0xFF)<<16);
    }




//-----------------------------------------------------------------------------
//              �����ڵ带 UTF-8�� ��ȯ�մϴ�
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//-----------------------------------------------------------------------------
VOID WINAPI Utf16ToUtf8(LPCWSTR Utf16, LPSTR Utf8)
    {
    UINT WCh;

    for (;;)
        {
        WCh=*Utf16++;
        if (WCh<=0x7F)
            {
            *Utf8++=(BYTE)WCh;
            if (WCh==0) break;
            }
        else if (WCh<=0x7FF)
            {
            *Utf8++=(BYTE)((WCh>>6)|0xC0);
            *Utf8++=(BYTE)((WCh&0x3F)|0x80);
            }
        else{
            *Utf8++=(BYTE)((WCh>>12)|0xE0);
            *Utf8++=(BYTE)(((WCh>>6)&0x3F)|0x80);
            *Utf8++=(BYTE)((WCh&0x3F)|0x80);
            }
        }
    }



//-----------------------------------------------------------------------------
//      ����ũ�⸦ ����� �������� ũ�⹮�ڿ��� ����
//-----------------------------------------------------------------------------
LOCAL(UINT64) HalfRaiseDiv64(UINT64 A, UINT64 B) {return (A+(B>>1))/B;}
VOID WINAPI MakeSizeStrEx(LPSTR Buff, UINT64 TotalBytes)
    {
    DWORD MegaSize;

    MegaSize=(DWORD)HalfRaiseDiv64(TotalBytes, 1000000);
    if (MegaSize<10)
        {
             if ((DWORD)TotalBytes<1000) Jsprintf(Buff, "%dB", (DWORD)TotalBytes);
        else if ((DWORD)TotalBytes<10000) Jsprintf(Buff, "%.1dK", MulDiv((DWORD)TotalBytes, 1, 100));
        else if ((DWORD)TotalBytes<1000000) Jsprintf(Buff, "%dK", MulDiv((DWORD)TotalBytes, 1, 1000));
        else if ((DWORD)TotalBytes<10000000) Jsprintf(Buff, "%.1dM", MulDiv((DWORD)TotalBytes, 1, 100000));
        }
    else if (MegaSize<1000) Jsprintf(Buff, "%dM", (DWORD)MegaSize);
    else if (MegaSize<10000) Jsprintf(Buff, "%.1dG", MulDiv((DWORD)MegaSize, 1, 100));
    else if (MegaSize<1000000) Jsprintf(Buff, "%dG", MulDiv((DWORD)MegaSize, 1, 1000));
    else if (MegaSize<10000000) Jsprintf(Buff, "%.1dT", MulDiv((DWORD)MegaSize, 1, 100000));
    else                         Jsprintf(Buff, "%dT", (DWORD)HalfRaiseDiv64(MegaSize, 1000000));
    }




//-----------------------------------------------------------------------------
//      WELLRNG512 �˰����� ������ġ ���ϱ�
//-----------------------------------------------------------------------------
DWORD WINAPI MyRand(DWORD InitData)
    {
    DWORD A,B,C,D;
    static int Index;
    static DWORD State[16];

    if (State[0]==0) for (A=0; A<countof(State); A++) State[A]=++InitData;
    A=State[Index];
    C=State[(Index+13)&0x0F];
    B=A^C^(A<<16)^(C<<15);
    C=State[(Index+9)&0x0F];
    C^=C>>11;
    State[Index]=A=B^C;
    D=A^((A<<5) & 0xDA442D24);
    Index=(Index+15)&0x0F;
    A=State[Index];
    State[Index]=A^B^D^(A<<2)^(B<<18)^(C<<28);
    return State[Index];
    }




//-----------------------------------------------------------------------------
//      ���̳ʸ��� BCD���� ��ȯ (RTC���� ���)
//-----------------------------------------------------------------------------
int WINAPI Bin2Bcd(int Value)
    {
    return ((Value/10)<<4) | (Value%10);
    }


int WINAPI Bcd2Bin(int Value)
    {
    return ((Value>>4)&0x0F)*10 + (Value & 0x0F);
    }



//-----------------------------------------------------------------------------
//      ���ϵ�ī�忡 �մ��������� üũ�� (UTF8�� �Բ� ó��) (MatchFileName)
//
//      * �Ǵ� *.*      ... �������
//      A*              ... A�ν����ϴ� ��� ���� (Ȯ���ڵ� ����)
//      *.              ... Ȯ���ڰ� ���� ����
//      ���ϵ�ī��� ';' ���ڵ� ������ �ν��� (���ϵ�ī���� ã�� ���ϸ� ���ڿ� ';'�� �� �� ����)
//      ���ϵ�ī���� ? ���� �����ϴ� �ϳ��� ���ڰ� �־�� �� (DOS�� �ٸ�)
//      �ǵڿ�  �ִ� '.'�� Ȯ���� ���й��ڷ� �ν��ϸ� �׿ܴ� �Ϲݹ��ڷ� ó��
//-----------------------------------------------------------------------------
BOOL WINAPI ChkWildcardFileName(LPCSTR FileName, LPCSTR WildCard)
    {
    int I, Rslt, Len, ExtNameMode;
    UINT FNCha, WildCha;
    LPCSTR FNDot, WCDot, FNQ, WCQ;

    Rslt=ExtNameMode=FALSE;
    WildCha=WildCard[0];
    if (WildCha==0 || WildCha==';') goto ProcExit;
    if (WildCha=='*')
        {
        if (WildCard[1]==0 || (WildCard[1]=='.' && WildCard[2]=='*'))
            {
            OkExit:
            Rslt++;
            goto ProcExit;
            }
        }

    FNDot=NULL; FNQ=GetStrLast((LPSTR)FileName);
    if ((I=SearchBackCha(FileName, '.'))>=0) FNDot=FileName+I;

    if ((I=SearchCha(WildCard, ';'))>=0)
        {
        WCDot=WCQ=WildCard+I;
        for (;;)
            {
            if (--WCDot<WildCard) {WCDot=NULL; break;}
            if (*WCDot=='.') break;
            }
        }
    else{
        WCDot=NULL; WCQ=GetStrLast((LPSTR)WildCard);
        if ((I=SearchBackCha(WildCard, '.'))>=0) WCDot=WildCard+I;
        }

    for (;;)
        {
        if (WildCard>=WCQ)
            {
            if (FileName>=FNQ) goto OkExit;     //���� ������ ���
            break;                              //���ϵ�ī��� �����µ� ���ϸ��� �ȳ����� FALSE
            }
        WildCha=WildCard[0];
        if (WildCha=='*')
            {
            if (ExtNameMode!=FALSE) goto OkExit;

            //���ϸ�ó����
            if (WCDot==NULL) goto OkExit;       //WildCard�� Ȯ���ڰ� ������ ���� �񱳾��� TRUE
            if ((WildCard=WCDot+1)==WCQ)        //ABCD*. => ABCD�� �����ϰ� Ȯ���ڰ� ���� ������ ã��
                {
                Rslt=(FNDot==NULL);
                break;
                }
            if (FNDot==NULL) break;             //WildCard�� Ȯ���ڸ� �����ߴµ� ���ϸ��� Ȯ���ڰ� ���� ��� FALSE
            FileName=FNDot+1;
            ExtNameMode++;
            }
        else if (WildCard==WCDot)
            {
            WildCard++;
            if (WildCard==WCQ)                  //ABCD. => ���ϸ��� ABCD�� Ȯ���ڰ� ���� ������ ã��
                {
                Rslt=(FNDot==NULL);
                break;
                }
            if (FileName!=FNDot) break;
            FileName++;
            ExtNameMode++;
            }
        else{
            if (FileName>=FNQ) break;           //���ϵ�ī��� ���Ҵµ� ���ϸ��� ������ ��� FALSE
            if (FileName==FNDot) break;

            #ifdef WIN32
            WildCard=GetCharU8((LPCBYTE)WildCard, &WildCha);
            FileName=GetCharU8((LPCBYTE)FileName, &FNCha);
            #else
            WildCha=GetCharU8(WildCard, &Len); WildCard+=Len;
            FNCha=GetCharU8(FileName, &Len); FileName+=Len;
            #endif
            if (WildCha!='?')
                {
                //CharUpperBuffW(&WildCha, 1);
                //CharUpperBuffW(&FNCha, 1);
                if (WildCha>='a' && WildCha<='z') WildCha-=0x20;
                if (FNCha>='a' && FNCha<='z') FNCha-=0x20;
                if (WildCha!=FNCha) break;
                }
            }
        }

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      BYTE ��̿��� Nibble������ ���� ������
//-----------------------------------------------------------------------------
VOID WINAPI PokeNibble(LPBYTE Buff, int Index, int Value)
    {
    int I;

    I=Index>>1;
    if (Index & 1)
        {
        Buff[I]&=0x0F;
        Buff[I]|=Value<<4;
        }
    else{
        Buff[I]&=0xF0;
        Buff[I]|=Value & 0x0F;
        }
    }




//-----------------------------------------------------------------------------
//      BYTE ��̿��� Nibble������ ���� ������
//-----------------------------------------------------------------------------
int WINAPI PeekNibble(LPCBYTE Buff, int Index)
    {
    int Value;

    Value=Buff[Index>>1];
    return (Index & 1) ? Value>>4 : Value&0x0F;
    }


