///////////////////////////////////////////////////////////////////////////////
//                          JOS 1.1 CORE
//
//      ROM: 2914 Byte, RAM: 292 Byte (������ �� map ����, ����:2022-07-06)
//      RAMũ�⿡�� Ÿ��ũ ���� �� ������Ʈ�� ������� ����
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "JOS.H"


#define MEMOWNER_CreateThread   (MEMOWNER_JOS+0)
#define MEMOWNER_JOSQCreate     (MEMOWNER_JOS+1)
#define MEMOWNER_CreateSemaphore (MEMOWNER_JOS+2)


       Bool JOSRunning;
       BYTE JOSIntNesting;
       BYTE JOSCurrPrio;
       BYTE JOSPrioHighRdy;
       BYTE JOSCpuUsage;

static BYTE LockNesting;
static TASK_LIST TaskReadyTable;
static DWORD G_LastResult;

#ifdef JOS_SAFETY_CRITICAL_IEC61508
static Bool JOSSafetyCriticalStartFlag;
#endif

       JOS_TCB *JOSCurrTCB;
       JOS_TCB *JOSTcbHighRdy;
static JOS_TCB *UsingTcbList;   //������� TCB ����Ʈ
static JOS_TCB *TcbPrioTbl[JOS_LOWEST_PRIO+1];

//Asm �Լ�
VOID WINAPI JOSCtxSw(VOID);
VOID WINAPI JOSIntCtxSw(VOID);
VOID WINAPI JOSStartHighRdy(VOID);


static CONST BYTE JOSUnMapTbl[256]=
    {
    0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0
    };



#if JOS_LOWEST_PRIO>63
LOCAL(UINT) GetBitPos16(UINT Bit16)
    {
    UINT Pos;

    if (Bit16 & 0xFF) Pos=JOSUnMapTbl[Bit16&0xFF];
    else              Pos=JOSUnMapTbl[Bit16>>8]+8;
    return Pos;
    }
#endif



#if JOS_EVENT_EN && JOS_EVENT_NAME_EN>0
LOCAL(BOOL) IsEvent(JOS_EVENT *lpEv)
    {
    BOOL Rslt=FALSE;

    switch (lpEv->EventType)
        {
        case JOS_EVENT_TYPE_SEM:
        case JOS_EVENT_TYPE_MUTEX:
        case JOS_EVENT_TYPE_MBOX:
        case JOS_EVENT_TYPE_Q: Rslt++;
        }
    return Rslt;
    }



JOS_RESULT WINAPI JOSGetEventName(JOS_EVENT *lpEv, LPSTR Buff, int BuffSize)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (Buff==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (JOSIntNesting>0) return JOS_ERR_NAME_GET_ISR;
    if (IsEvent(lpEv)==FALSE) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    lstrcpyn(Buff, lpEv->EventName, BuffSize);
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }



JOS_RESULT WINAPI JOSSetEventName(JOS_EVENT *lpEv, LPCSTR Name)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (Name==NULL) return JOS_ERR_NULL_PARAM;
    #endif

    if (JOSIntNesting>0) return JOS_ERR_NAME_SET_ISR;
    if (IsEvent(lpEv)==FALSE) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    lstrcpyn(lpEv->EventName, Name, JOS_EVENT_NAME_EN);
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif //JOS_EVENT_EN && JOS_EVENT_NAME_EN>0



LOCAL(VOID) SetTaskReadyBit(CONST JOS_TCB *TCB)
    {
    TaskReadyTable.Group|=TCB->TcbBitY;
    TaskReadyTable.Table[TCB->TcbY]|=TCB->TcbBitX;
    }


LOCAL(VOID) ClrTaskReadyBit(CONST JOS_TCB *TCB)
    {
    if ((TaskReadyTable.Table[TCB->TcbY]&=~TCB->TcbBitX)==0)
        TaskReadyTable.Group&=~TCB->TcbBitY;
    }



#if JOS_EVENT_EN
LOCAL(VOID) SetEventWaitTaskBit(JOS_EVENT *lpEv, CONST JOS_TCB*TCB)
    {
    lpEv->EventTaskList.Table[TCB->TcbY]|=TCB->TcbBitX;
    lpEv->EventTaskList.Group|=TCB->TcbBitY;
    }


LOCAL(VOID) ClrEventWaitTaskBit(JOS_EVENT *lpEv, CONST JOS_TCB*TCB)
    {
    if ((lpEv->EventTaskList.Table[TCB->TcbY]&=~TCB->TcbBitX)==0)
        lpEv->EventTaskList.Group&=~TCB->TcbBitY;
    }
#endif




LOCAL(VOID) FindAndSetHighReadyPrio(VOID)
    {
    UINT Y;

    #if JOS_LOWEST_PRIO<=63
    Y=JOSUnMapTbl[TaskReadyTable.Group];
    JOSPrioHighRdy=JOSUnMapTbl[TaskReadyTable.Table[Y]]+(Y<<3);
    #else
    Y=GetBitPos16(TaskReadyTable.Group);
    JOSPrioHighRdy=GetBitPos16(TaskReadyTable.Table[Y])+(Y<<4);
    #endif
    JOSTcbHighRdy=TcbPrioTbl[JOSPrioHighRdy];
    }




#if JOS_EVENT_EN && JOS_EVENT_MULTI_EN>0
LOCAL(VOID) EventTaskWaitMulti(JOS_EVENT** lpPendEvList)
    {
    JOS_EVENT *lpEv;

    JOSCurrTCB->TcbEventPtr=NULL;
    JOSCurrTCB->TcbMultiEventPtr=lpPendEvList;

    for (;;)
        {
        if ((lpEv=*lpPendEvList++)==NULL) break;
        SetEventWaitTaskBit(lpEv, JOSCurrTCB);
        }

    ClrTaskReadyBit(JOSCurrTCB);
    }
#endif




//-----------------------------------------------------------------------------
//      �־��� Prio�� Task�� �����Ǿ� ���� ������ Reserved�����ϰ� TRUE����
//-----------------------------------------------------------------------------
LOCAL(BOOL) IsEmptyTaskAndSetReserved(UINT Prio)
    {
    BOOL Rslt=FALSE;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if (TcbPrioTbl[Prio]==NULL) {TcbPrioTbl[Prio]=JOS_TCB_RESERVED; Rslt++;}
    JOS_EXIT_CRITICAL();
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �־��� Prio�� �ش��ϴ� TCB�� ����
//-----------------------------------------------------------------------------
LOCAL(JOS_TCB*) GetTCB(UINT Prio, JOS_RESULT *lpRslt)
    {
    JOS_TCB *TCB;

    if (Prio==JOS_PRIO_SELF) Prio=JOSCurrTCB->TcbPrio;
    TCB=TcbPrioTbl[Prio];
    if (TCB==NULL) *lpRslt=JOS_ERR_TASK_NOT_EXIST;
    else if (TCB==JOS_TCB_RESERVED) {*lpRslt=JOS_ERR_TASK_NOT_EXIST; TCB=NULL;}
    return TCB;
    }




#if JOS_EVENT_EN && JOS_EVENT_MULTI_EN>0
VOID RemoveMultiEventTask(JOS_TCB*TCB, JOS_EVENT **lpPendEvList)
    {
    JOS_EVENT *lpEv;

    for (;;)
        {
        if ((lpEv=*lpPendEvList++)==NULL) break;
        ClrEventWaitTaskBit(lpEv, TCB);
        }
    }
#endif


LOCAL(VOID) Scheduling(VOID)
    {
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if (JOSIntNesting==0 && LockNesting==0)
        {
        FindAndSetHighReadyPrio();
        if (JOSPrioHighRdy!=JOSCurrPrio)
            {
            JOSCurrTCB->WorkingTime+=FineTickCnt-JOSCurrTCB->WorkStartTime;
            JOSTcbHighRdy->WorkStartTime=FineTickCnt;
            JOSCtxSw();
            }
        }
    JOS_EXIT_CRITICAL();
    }




///////////////////////////////////////////////////////////////////////////////
//                          Kernal
///////////////////////////////////////////////////////////////////////////////


VOID WINAPI JOSIntEnter(VOID)
    {
    if (JOSRunning) JOSIntNesting++;
    }



VOID WINAPI JOSIntExit(VOID)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        if (JOSIntNesting>0) JOSIntNesting--;
        if (JOSIntNesting==0 && LockNesting==0)
            {
            FindAndSetHighReadyPrio();
            if (JOSPrioHighRdy!=JOSCurrPrio)
                {
                JOSCurrTCB->WorkingTime+=FineTickCnt-JOSCurrTCB->WorkStartTime;
                JOSTcbHighRdy->WorkStartTime=FineTickCnt;
                JOSIntCtxSw();
                }
            }
        JOS_EXIT_CRITICAL();
        }
    }




#ifdef JOS_SAFETY_CRITICAL_IEC61508
VOID WINAPI JOSSafetyCriticalStart(VOID)
    {
    JOSSafetyCriticalStartFlag=TRUE;
    }
#endif



#if JOS_SCHED_LOCK_EN>0
VOID WINAPI JOSSchedLock(VOID)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        if (JOSIntNesting==0 && LockNesting<255) LockNesting++;
        JOS_EXIT_CRITICAL();
        }
    }



VOID WINAPI JOSSchedUnlock(VOID)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        JOS_ENTER_CRITICAL();
        if (JOSIntNesting==0 && LockNesting>0 && --LockNesting==0)
            {
            JOS_EXIT_CRITICAL();
            Scheduling();
            goto ProcExit;
            }
        JOS_EXIT_CRITICAL();
        }
    ProcExit:;
    }
#endif



VOID WINAPI JOSTimeTick(VOID)
    {
    JOS_TCB*TCB;
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        for (TCB=UsingTcbList; TCB->TcbPrio!=JOS_TASK_IDLE_PRIO; )
            {
            JOS_ENTER_CRITICAL();
            if (TCB->TcbDelay!=0 && --TCB->TcbDelay==0)
                {
                if (TCB->TcbState & JOS_STAT_PEND_ANY)
                    {
                    TCB->TcbState&=~JOS_STAT_PEND_ANY;
                    TCB->TcbStatPend=JOS_STAT_PEND_TO;
                    }
                else{
                    TCB->TcbStatPend=JOS_STAT_PEND_OK;
                    }

                if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) SetTaskReadyBit(TCB);
                }
            TCB=TCB->TcbNext;
            JOS_EXIT_CRITICAL();
            }
        }
    }




VOID JOS_Dummy(VOID) {}



LOCAL(VOID) CheckTaskStack(UINT Prio)
    {
    UINT StkFree=0;
    JOS_TCB *TCB;
    JOS_STK *lpStk=NULL;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))!=NULL) lpStk=TCB->TcbStkBegin;
    JOS_EXIT_CRITICAL();

    if (lpStk!=NULL)
        {
        while (*lpStk++==0) StkFree++;

        JOS_ENTER_CRITICAL();   //���� �˻��ϴ� �߿� Ÿ��ũ�� �����Ǿ� ���� ���� �����Ƿ�
        if ((TCB=GetTCB(Prio, &Rslt))!=NULL) TCB->TcbStkFree=StkFree;
        JOS_EXIT_CRITICAL();
        }
    }



//-----------------------------------------------------------------------------
//      ���̵� Ÿ��ũ
//
// ����ڰ� ���� Ÿ��ũ�߿� ����Ÿ��ũ(��ȥ�� ���ó���ϴ�)�� ������ CPU������
// �������� ����. �� Ÿ��ũ�� ����� Ÿ��ũ���� �켱������ �������̱� ����
//-----------------------------------------------------------------------------
static VOID CALLBACK IdleThread(LPVOID lpArg)
    {
    UINT  Prio;
    DWORD Time;
    JOS_TCB *TCB;
    JOS_CRITICAL_VAR;

    Time=FineTickCnt;
    for (;;)
        {
        if (FineTickCnt-Time>=1000)
            {
            JOS_ENTER_CRITICAL();
            for (TCB=UsingTcbList; ;TCB=TCB->TcbNext)
                {
                TCB->TcbCpuUsage=TCB->WorkingTime/10;
                TCB->WorkingTime=0;
                if (TCB->TcbPrio==PRIO_IDLETASK) {JOSCpuUsage=100-TCB->TcbCpuUsage; break;}
                }
            JOS_EXIT_CRITICAL();

            for (Prio=0; Prio<=JOS_TASK_IDLE_PRIO; Prio++) CheckTaskStack(Prio);
            Time=FineTickCnt;
            }
        JOSTaskIdleHook();
        }
    }




#if JOS_TASK_CHANGE_PRIO_EN>0
JOS_RESULT WINAPI JOSTaskChangePrio(UINT OldPrio, UINT NewPrio)
    {
    UINT NewY, NewBitX, NewBitY;
    JOS_TCB *TCB;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;
    #if (JOS_EVENT_EN)
    JOS_EVENT *lpEv;
    #if (JOS_EVENT_MULTI_EN>0)
    JOS_EVENT**lpMultiEv;
    #endif
    #endif

    #if JOS_ARG_CHK_EN>0
    if (OldPrio>=JOS_LOWEST_PRIO && OldPrio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    if (NewPrio>=JOS_LOWEST_PRIO) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if (TcbPrioTbl[NewPrio]!=NULL) {JOS_EXIT_CRITICAL(); return JOS_ERR_PRIO_EXIST;}
    if ((TCB=GetTCB(OldPrio, &Rslt))==NULL) {JOS_EXIT_CRITICAL(); return Rslt;}

    #if JOS_LOWEST_PRIO <= 63u
    NewY=NewPrio>>3;
    NewBitX=1<<(NewPrio&7);
    #else
    NewY=NewPrio>>4;
    NewBitX=1<<(NewPrio&0x0F);
    #endif
    NewBitY=1<<NewY;

    TcbPrioTbl[OldPrio]=NULL;
    TcbPrioTbl[NewPrio]=TCB;

    if ((TaskReadyTable.Table[TCB->TcbY] & TCB->TcbBitX)!=0)
        {
        ClrTaskReadyBit(TCB);

        TaskReadyTable.Group|=NewBitY;
        TaskReadyTable.Table[NewY]|=NewBitX;
        }

    #if (JOS_EVENT_EN)
    if ((lpEv=TCB->TcbEventPtr)!=NULL)
        {
        ClrEventWaitTaskBit(lpEv, TCB);

        lpEv->EventTaskList.Group|=NewBitY;
        lpEv->EventTaskList.Table[NewY]|=NewBitX;
        }

    #if (JOS_EVENT_MULTI_EN>0)
    if ((lpMultiEv=TCB->TcbMultiEventPtr)!=NULL)
        {
        for (;;)
            {
            if ((lpEv=*lpMultiEv++)==NULL) break;
            ClrEventWaitTaskBit(lpEv, TCB);

            lpEv->EventTaskList.Group|=NewBitY;
            lpEv->EventTaskList.Table[NewY]|=NewBitX;
            }
        }
    #endif
    #endif

    TCB->TcbPrio=NewPrio;
    TCB->TcbY=NewY;
    TCB->TcbBitY=NewBitY;
    TCB->TcbBitX=NewBitX;
    JOS_EXIT_CRITICAL();

    if (JOSRunning) Scheduling();
    return JOS_ERR_NONE;
    }
#endif



LOCAL(VOID) JOSTaskReturn(VOID)
    {
    JOSTaskDel(JOS_PRIO_SELF);
    for (;;);
    }



JOS_RESULT WINAPI CreateThread(LPCSTR Name, UINT StackSize, TASKPROC TaskProc, LPVOID TaskArg, UINT Prio)
    {
    JOS_TCB *TCB;
    JOS_CRITICAL_VAR;

    #ifdef JOS_SAFETY_CRITICAL_IEC61508
    if (JOSSafetyCriticalStartFlag==TRUE)
        {
        JOS_SAFETY_CRITICAL_EXCEPTION();
        return JOS_ERR_ILLEGAL_CREATE_RUN_TIME;
        }
    #endif

    #if JOS_ARG_CHK_EN>0
    if (Prio>JOS_LOWEST_PRIO) return JOS_ERR_PRIO_INVALID;
    #endif
    if (JOSIntNesting>0) return JOS_ERR_TASK_CREATE_ISR;
    if (IsEmptyTaskAndSetReserved(Prio)==FALSE) return JOS_ERR_PRIO_EXIST;

    if ((TCB=(JOS_TCB*)AllocMem(StackSize*sizeof(JOS_STK)+sizeof(JOS_TCB), MEMOWNER_CreateThread))==NULL)
        {
        JOS_ENTER_CRITICAL();
        TcbPrioTbl[Prio]=NULL;
        JOS_EXIT_CRITICAL();
        return JOS_ERR_TASK_NO_MORE_TCB;
        }
    ZeroMem(TCB, StackSize*sizeof(JOS_STK)+sizeof(JOS_TCB));
    TCB->TcbStkBegin=(JOS_STK*)((LPBYTE)TCB+sizeof(JOS_TCB));
    TCB->TcbStkPtr=JOSTaskStkInit(TaskProc, TaskArg, TCB->TcbStkBegin+StackSize, JOSTaskReturn);
    TCB->TcbStkSize=StackSize;
    TCB->TcbPrio=Prio;
    //TCB->TcbStatPend=JOS_STAT_PEND_OK;  //=0
    //TCB->TcbState=0;
    //TCB->TcbDelay=0;

    TCB->TcbDelReq=JOS_ERR_NONE;

    #if JOS_LOWEST_PRIO<=63
    TCB->TcbY=Prio>>3;    //0~7
    TCB->TcbBitX=1<<(Prio&7);
    #else
    TCB->TcbY=Prio>>4;    //0~15
    TCB->TcbBitX=1<<(Prio&0x0F);
    #endif
    TCB->TcbBitY=1<<TCB->TcbY;


    #if JOS_TASK_NAME_EN>0
    TCB->TcbTaskName[0]='?';
    if (Name) lstrcpyn(TCB->TcbTaskName, Name, JOS_TASK_NAME_EN);
    #endif

    JOSTcbInitHook(TCB);

    JOS_ENTER_CRITICAL();
    TcbPrioTbl[Prio]=TCB;
    JOS_EXIT_CRITICAL();

    JOSTaskCreateHook(TCB);

    JOS_ENTER_CRITICAL();
    TCB->TcbNext=UsingTcbList;
    TCB->TcbPrev=NULL;
    if (UsingTcbList!=NULL) UsingTcbList->TcbPrev=TCB;
    UsingTcbList=TCB;
    SetTaskReadyBit(TCB);
    JOS_EXIT_CRITICAL();

    if (JOSRunning) Scheduling();
    return JOS_ERR_NONE;
    }




JOS_RESULT WINAPI JOSTaskDel(UINT Prio)
    {
    JOS_TCB *TCB, *Prev, *Next;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (JOSIntNesting>0) return JOS_ERR_TASK_DEL_ISR;
    if (Prio==JOS_TASK_IDLE_PRIO) return JOS_ERR_TASK_DEL_IDLE;

    #if JOS_ARG_CHK_EN>0
    if (Prio>=JOS_LOWEST_PRIO && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))==NULL) {JOS_EXIT_CRITICAL(); return Rslt;}

    ClrTaskReadyBit(TCB);

    #if (JOS_EVENT_EN)
    if (TCB->TcbEventPtr!=NULL) {ClrEventWaitTaskBit(TCB->TcbEventPtr, TCB); TCB->TcbEventPtr=NULL;}

    #if (JOS_EVENT_MULTI_EN>0)
    if (TCB->TcbMultiEventPtr!=NULL) RemoveMultiEventTask(TCB, TCB->TcbMultiEventPtr);
    #endif
    #endif

    TCB->TcbDelay=0;
    TCB->TcbState=0;
    TCB->TcbStatPend=JOS_STAT_PEND_OK;
    if (LockNesting<255) LockNesting++;
    JOS_EXIT_CRITICAL();

    JOS_Dummy();

    JOS_ENTER_CRITICAL();
    if (LockNesting>0) LockNesting--;
    JOSTaskDelHook(TCB);

    if (Prio==JOS_PRIO_SELF) Prio=JOSCurrTCB->TcbPrio;
    TcbPrioTbl[Prio]=NULL;

    Next=TCB->TcbNext;
    if ((Prev=TCB->TcbPrev)==NULL)      //�Ǿտ� �ִ� ���� (�ǳ��߿� ���� Ÿ��ũ��)
        {
        Next->TcbPrev=NULL;
        UsingTcbList=Next;
        }
    else{
        Prev->TcbNext=Next;
        Next->TcbPrev=Prev;
        }
    FreeMem(TCB);

    JOS_EXIT_CRITICAL();
    if (JOSRunning) Scheduling();
    return JOS_ERR_NONE;
    }




JOS_RESULT WINAPI OSTaskDelReq(BYTE Prio)
    {
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    if (Prio==JOS_TASK_IDLE_PRIO) return JOS_ERR_TASK_DEL_IDLE;

    #if JOS_ARG_CHK_EN>0
    if (Prio>=JOS_LOWEST_PRIO && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    if (Prio==JOS_PRIO_SELF)
        {
        JOS_ENTER_CRITICAL();
        Rslt=JOSCurrTCB->TcbDelReq;
        JOS_EXIT_CRITICAL();
        return Rslt;
        }

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))!=NULL) TCB->TcbDelReq=JOS_ERR_TASK_DEL_REQ;
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




#if JOS_TASK_SUSPEND_EN>0
JOS_RESULT WINAPI JOSTaskResume(UINT Prio)
    {
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (Prio>=JOS_LOWEST_PRIO) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))==NULL) goto ProcExit;
    if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) {Rslt=JOS_ERR_TASK_NOT_SUSPENDED; goto ProcExit;}

    TCB->TcbState&=~JOS_STAT_SUSPEND;
    if ((TCB->TcbState & JOS_STAT_PEND_ANY)==0 && TCB->TcbDelay==0)
        {
        SetTaskReadyBit(TCB);
        JOS_EXIT_CRITICAL();

        if (JOSRunning) Scheduling();
        return JOS_ERR_NONE;
        }

    ProcExit:
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif



#if JOS_TASK_SUSPEND_EN>0
JOS_RESULT WINAPI JOSTaskSuspend(UINT Prio)
    {
    BOOL Self=FALSE;
    JOS_TCB *TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (Prio==JOS_TASK_IDLE_PRIO) return JOS_ERR_TASK_SUSPEND_IDLE;
    if (Prio>=JOS_LOWEST_PRIO && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    #endif

    JOS_ENTER_CRITICAL();
    if (Prio==JOS_PRIO_SELF) {Prio=JOSCurrTCB->TcbPrio; Self=TRUE;}
    else if (Prio==JOSCurrTCB->TcbPrio) Self=TRUE;

    if ((TCB=GetTCB(Prio, &Rslt))!=NULL)
        {
        ClrTaskReadyBit(TCB);
        TCB->TcbState|=JOS_STAT_SUSPEND;
        }
    JOS_EXIT_CRITICAL();

    if (Rslt==JOS_ERR_NONE && Self==TRUE) Scheduling();
    return Rslt;
    }
#endif



#if JOS_TASK_QUERY_EN>0
JOS_RESULT WINAPI JOSTaskQuery(UINT Prio, JOS_TCB *lpData)
    {
    JOS_TCB*TCB;
    JOS_RESULT Rslt=JOS_ERR_NONE;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (Prio>JOS_LOWEST_PRIO && Prio!=JOS_PRIO_SELF) return JOS_ERR_PRIO_INVALID;
    if (lpData==NULL) return JOS_ERR_NULL_PARAM;
    #endif

    JOS_ENTER_CRITICAL();
    if ((TCB=GetTCB(Prio, &Rslt))!=NULL) CopyMem(lpData, TCB, sizeof(JOS_TCB));
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif




#if JOS_EVENT_EN
LOCAL(UINT) WaitEventTaskToReady(JOS_EVENT *lpEv, DWORD Msg, UINT ClearState, UINT PendStat)
    {
    UINT Y, Prio;
    JOS_TCB*TCB;

    #if JOS_LOWEST_PRIO<=63
    Y=JOSUnMapTbl[lpEv->EventTaskList.Group];
    Prio=JOSUnMapTbl[lpEv->EventTaskList.Table[Y]]+(Y<<3);
    #else
    Y=GetBitPos16(lpEv->EventTaskList.Group);
    Prio=GetBitPos16(lpEv->EventTaskList.Table[Y])+(Y<<4);
    #endif

    TCB=TcbPrioTbl[Prio];
    TCB->TcbDelay=0;
    #if (JOS_Q_EN>0) || (JOS_MBOX_EN>0)
    TCB->TcbMsg=Msg;
    #endif
    TCB->TcbState&=~ClearState;
    TCB->TcbStatPend=PendStat;
    if ((TCB->TcbState & JOS_STAT_SUSPEND)==0) SetTaskReadyBit(TCB);

    ClrEventWaitTaskBit(lpEv, TCB);
    TCB->TcbEventPtr=NULL;

    #if (JOS_EVENT_MULTI_EN>0)
    if (TCB->TcbMultiEventPtr!=NULL)
        {
        RemoveMultiEventTask(TCB, TCB->TcbMultiEventPtr);
        TCB->TcbEventPtr=lpEv;
        }
    #endif
    return Prio;
    }



LOCAL(VOID) CurrTaskToEventWait(JOS_EVENT *lpEv, UINT State, DWORD Timeout)
    {
    JOSCurrTCB->TcbState|=State;
    JOSCurrTCB->TcbStatPend=JOS_STAT_PEND_OK;
    JOSCurrTCB->TcbDelay=(Timeout==INFINITE) ? 0:Timeout;

    JOSCurrTCB->TcbEventPtr=lpEv;
    SetEventWaitTaskBit(lpEv, JOSCurrTCB);
    ClrTaskReadyBit(JOSCurrTCB);
    }


LOCAL(VOID) FinishPend(VOID)
    {
    JOSCurrTCB->TcbState=0;
    JOSCurrTCB->TcbStatPend=JOS_STAT_PEND_OK;
    JOSCurrTCB->TcbEventPtr=NULL;
    #if JOS_EVENT_MULTI_EN>0
    JOSCurrTCB->TcbMultiEventPtr=NULL;
    #endif
    #if JOS_MBOX_EN>0 || JOS_Q_EN
    JOSCurrTCB->TcbMsg=0;
    #endif
    }

#endif //JOS_EVENT_EN




///////////////////////////////////////////////////////////////////////////////
//                          Semaphore
///////////////////////////////////////////////////////////////////////////////
#if JOS_SEM_EN>0

//-----------------------------------------------------------------------------
//      �����̸� JOSSemCreate
//-----------------------------------------------------------------------------
JOS_EVENT* WINAPI CreateSemaphore(int Cnt)
    {
    JOS_EVENT *lpEv=NULL;

    #ifdef JOS_SAFETY_CRITICAL_IEC61508
    if (JOSSafetyCriticalStartFlag)
        {
        JOS_SAFETY_CRITICAL_EXCEPTION();
        goto ProcExit;
        }
    #endif

    if (JOSIntNesting>0) goto ProcExit;
    if ((lpEv=AllocMemS(JOS_EVENT, MEMOWNER_CreateSemaphore))==NULL) goto ProcExit;
    ZeroMem(lpEv, sizeof(JOS_EVENT));
    lpEv->EventType=JOS_EVENT_TYPE_SEM;
    lpEv->EventCnt=Cnt;

    ProcExit:
    return lpEv;
    }




//-----------------------------------------------------------------------------
//      �����̸� JOSSemDel
//-----------------------------------------------------------------------------
#if JOS_SEM_DEL_EN>0
JOS_RESULT WINAPI DeleteSemaphore(JOS_EVENT *lpEv, UINT Opt)
    {
    BOOL TasksWaiting;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;
    if (JOSIntNesting>0) return JOS_ERR_DEL_ISR;

    JOS_ENTER_CRITICAL();
    TasksWaiting=lpEv->EventTaskList.Group;
    switch (Opt)
        {
        case JOS_DEL_NO_PEND:
            if (TasksWaiting==FALSE) goto DelSem;
            Rslt=JOS_ERR_TASK_WAITING;
            break;

        case JOS_DEL_ALWAYS:
            while (lpEv->EventTaskList.Group!=0) WaitEventTaskToReady(lpEv, 0, JOS_STAT_SEM, JOS_STAT_PEND_ABORT);

            DelSem:
            FreeMem(lpEv);
            JOS_EXIT_CRITICAL();

            if (TasksWaiting) Scheduling();
            Rslt=JOS_ERR_NONE;
            goto ProcExit;

        default:
            Rslt=JOS_ERR_INVALID_OPT;
        }
    JOS_EXIT_CRITICAL();

    ProcExit:
    return Rslt;
    }
#endif



//-----------------------------------------------------------------------------
//      �����̸� JOSSemPost
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI ReleaseSemaphore(JOS_EVENT *lpEv)
    {
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    if (lpEv->EventTaskList.Group!=0)
        {
        WaitEventTaskToReady(lpEv, 0, JOS_STAT_SEM, JOS_STAT_PEND_OK);
        JOS_EXIT_CRITICAL();
        Scheduling();
        return JOS_ERR_NONE;
        }

    Rslt=JOS_ERR_SEM_OVF;
    if (lpEv->EventCnt<65535)
        {
        lpEv->EventCnt++;
        Rslt=JOS_ERR_NONE;
        }

    JOS_EXIT_CRITICAL();
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �����̸� JOSSemPend
//
//      �־��� ������� ��ȣ�� �ִ��� ���� ������ �����
//      Timeout==INFINITE(0xFFFFFFFF) �̸� ���� ���
//      Timeout==0 �� �ָ� JOSSemAccept()�� ���� ���ͷ�Ʈ���� ȣ���� �����ϰ�
//      ��ȣ�� ������ JOS_ERR_NONE ������ JOS_ERR_TIMEOUT ����
//-----------------------------------------------------------------------------
JOS_RESULT WINAPI WaitSemaphore(JOS_EVENT *lpEv, DWORD Timeout)
    {
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;
    if (Timeout!=0)
        {
        if (JOSIntNesting>0) return JOS_ERR_PEND_ISR;
        if (LockNesting>0) return JOS_ERR_PEND_LOCKED;
        }

    JOS_ENTER_CRITICAL();
    if (lpEv->EventCnt>0)
        {
        lpEv->EventCnt--;
        JOS_EXIT_CRITICAL();
        return JOS_ERR_NONE;
        }

    if (Timeout==0)
        {
        JOS_EXIT_CRITICAL();
        return JOS_ERR_TIMEOUT;
        }

    CurrTaskToEventWait(lpEv, JOS_STAT_SEM, Timeout);
    JOS_EXIT_CRITICAL();

    Scheduling();

    JOS_ENTER_CRITICAL();
    switch (JOSCurrTCB->TcbStatPend)
        {
        case JOS_STAT_PEND_OK: Rslt=JOS_ERR_NONE; break;
        case JOS_STAT_PEND_ABORT: Rslt=JOS_ERR_PEND_ABORT; break;

        //case JOS_STAT_PEND_TO:
        default:
            ClrEventWaitTaskBit(lpEv, JOSCurrTCB);
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }
    FinishPend();
    JOS_EXIT_CRITICAL();

    return Rslt;
    }





#if JOS_SEM_PEND_ABORT_EN>0
JOS_RESULT WINAPI PendAbortSemaphore(JOS_EVENT *lpEv, UINT Opt)
    {
    int Tasks=0;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (lpEv->EventTaskList.Group!=0)
        {
        WaitEventTaskToReady(lpEv, 0, JOS_STAT_SEM, JOS_STAT_PEND_ABORT);
        Tasks++;
        if (Opt!=JOS_PEND_OPT_BROADCAST) break;
        }
    JOS_EXIT_CRITICAL();
    if (Tasks==0) return JOS_ERR_NONE;

    Scheduling();
    return JOS_ERR_PEND_ABORT;
    }
#endif




#if JOS_SEM_QUERY_EN>0
JOS_RESULT WINAPI QuerySemaphore(JOS_EVENT *lpEv, JOS_EVENT *lpEvDest)
    {
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpEvDest==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    CopyMem(lpEvDest, lpEv, sizeof(JOS_EVENT));
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif




#if JOS_SEM_SET_EN>0
JOS_RESULT WINAPI SetSemaphore(JOS_EVENT *lpEv, int Cnt)
    {
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_SEM) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    Rslt=JOS_ERR_NONE;
    if (lpEv->EventCnt>0 && lpEv->EventTaskList.Group==0) lpEv->EventCnt=Cnt;
    else Rslt=JOS_ERR_TASK_WAITING;
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif


#endif //JOS_SEM_EN










///////////////////////////////////////////////////////////////////////////////
//                          JOS - Q
///////////////////////////////////////////////////////////////////////////////
#if JOS_Q_EN>0


//-----------------------------------------------------------------------------
//      QType: JOSQTYPE_BYTE, JOSQTYPE_WORD, JOSQTYPE_DWORD
//      ���ο��� �Ҵ�޵��� ������
//-----------------------------------------------------------------------------
JOS_EVENT* WINAPI JOSQCreate(UINT EntryQty, UINT QType)
    {
    int QSize;
    JOS_Q *lpQ;
    JOS_EVENT *lpEv=NULL;

    #ifdef JOS_SAFETY_CRITICAL_IEC61508
    if (JOSSafetyCriticalStartFlag==TRUE)
        {
        JOS_SAFETY_CRITICAL_EXCEPTION();
        goto ProcExit;
        }
    #endif
    if (JOSIntNesting>0) goto ProcExit;

    QSize=EntryQty*QType;
    if ((lpEv=(JOS_EVENT*)AllocMem(JOS_EVENT_ALIGNED_SIZE+sizeof(JOS_Q)+QSize, MEMOWNER_JOSQCreate))==NULL) goto ProcExit;
    ZeroMem(lpEv, sizeof(JOS_EVENT));

    lpQ=(JOS_Q*)((LPBYTE)lpEv+JOS_EVENT_ALIGNED_SIZE);
    lpQ->Entry.B.QStart=
    lpQ->Entry.B.QIn=
    lpQ->Entry.B.QOut=
    lpQ->Entry.B.QEnd=(LPBYTE)lpQ+sizeof(JOS_Q);
    lpQ->Entry.B.QEnd+=QSize;

    lpQ->QSize=EntryQty;
    lpQ->QType=QType;
    lpQ->QEntries=0;

    lpEv->EventType=JOS_EVENT_TYPE_Q;
    lpEv->EventPtr=lpQ;
    //lpEv->EventCnt=0;

    ProcExit:
    return lpEv;
    }




#if JOS_Q_DEL_EN>0
JOS_RESULT WINAPI JOSQDel(JOS_EVENT *lpEv, UINT Opt)
    {
    BOOL TasksWaiting;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;
    if (JOSIntNesting>0) return JOS_ERR_DEL_ISR;

    JOS_ENTER_CRITICAL();
    TasksWaiting=lpEv->EventTaskList.Group;
    switch (Opt)
        {
        case JOS_DEL_NO_PEND:
            if (TasksWaiting==0) goto DelQ;
            Rslt=JOS_ERR_TASK_WAITING;
            break;

        case JOS_DEL_ALWAYS:
            while (lpEv->EventTaskList.Group!=0) WaitEventTaskToReady(lpEv, 0, JOS_STAT_Q, JOS_STAT_PEND_ABORT);

            DelQ:
            JOS_EXIT_CRITICAL();
            FreeMem(lpEv);
            if (TasksWaiting!=0) Scheduling();
            return JOS_ERR_NONE;

        default:
            Rslt=JOS_ERR_INVALID_OPT;
            //break;
        }
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif



#if JOS_Q_FLUSH_EN>0
JOS_RESULT WINAPI JOSQFlush(JOS_EVENT *lpEv)
    {
    JOS_Q*lpQ;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;
    #endif

    JOS_ENTER_CRITICAL();
    lpQ=(JOS_Q*)lpEv->EventPtr;
    lpQ->Entry.B.QIn=lpQ->Entry.B.QOut=lpQ->Entry.B.QStart;
    lpQ->QEntries=0;
    JOS_EXIT_CRITICAL();
    return JOS_ERR_NONE;
    }
#endif



//-----------------------------------------------------------------------------
//      Q���� �����͸� ������
//-----------------------------------------------------------------------------
LOCAL(DWORD) GetQData(JOS_Q *lpQ)
    {
    DWORD Msg;

    switch (lpQ->QType)
        {
        case JOSQTYPE_BYTE: Msg=*lpQ->Entry.B.QOut++; break;
        case JOSQTYPE_WORD: Msg=*lpQ->Entry.W.QOut++; break;
        default:            Msg=*lpQ->Entry.D.QOut++; //break;
        }
    if (lpQ->Entry.B.QOut==lpQ->Entry.B.QEnd) lpQ->Entry.B.QOut=lpQ->Entry.B.QStart;
    lpQ->QEntries--;
    return Msg;
    }




//-----------------------------------------------------------------------------
//      Q�� �����Ͱ� ������ �����
//      Timeout==INFINITE(0xFFFFFFFF) �̸� ���� ���
//      Timeout==0 �� �ָ� JOSQAccept()�� ���� ���ͷ�Ʈ���� ȣ���� �����ϰ�
//      ��ȣ�� ������ JOS_ERR_NONE ������ JOS_ERR_TIMEOUT ����
//-----------------------------------------------------------------------------
DWORD WINAPI JOSQPend(JOS_EVENT *lpEv, DWORD Timeout, JOS_RESULT *lpRslt)
    {
    DWORD Msg=0;
    JOS_Q*lpQ;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) {Rslt=JOS_ERR_PEVENT_NULL; goto ProcExit;}
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) {Rslt=JOS_ERR_EVENT_TYPE; goto ProcExit;}
    if (Timeout!=0)
        {
        if (JOSIntNesting>0) {Rslt=JOS_ERR_PEND_ISR; goto ProcExit;}
        if (LockNesting>0) {Rslt=JOS_ERR_PEND_LOCKED; goto ProcExit;}
        }

    JOS_ENTER_CRITICAL();
    lpQ=(JOS_Q*)lpEv->EventPtr;
    if (lpQ->QEntries>0)
        {
        Msg=GetQData(lpQ);
        JOS_EXIT_CRITICAL();
        Rslt=JOS_ERR_NONE;
        goto ProcExit;
        }

    if (Timeout==0)
        {
        JOS_EXIT_CRITICAL();
        Rslt=JOS_ERR_TIMEOUT;
        goto ProcExit;
        }

    CurrTaskToEventWait(lpEv, JOS_STAT_Q, Timeout);
    JOS_EXIT_CRITICAL();

    Scheduling();

    JOS_ENTER_CRITICAL();
    switch (JOSCurrTCB->TcbStatPend)
        {
        case JOS_STAT_PEND_OK:
            Msg=JOSCurrTCB->TcbMsg;
            Rslt=JOS_ERR_NONE;
            break;

        case JOS_STAT_PEND_ABORT:
            Rslt=JOS_ERR_PEND_ABORT;
            break;

        //case JOS_STAT_PEND_TO:
        default:
            ClrEventWaitTaskBit(lpEv, JOSCurrTCB);
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }
    FinishPend();
    JOS_EXIT_CRITICAL();

    ProcExit:
    if (lpRslt!=NULL) *lpRslt=Rslt;
    return Msg;
    }




#if JOS_Q_PEND_ABORT_EN>0
JOS_RESULT WINAPI JOSQPendAbort(JOS_EVENT *lpEv, UINT Opt)
    {
    int Tasks=0;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (lpEv->EventTaskList.Group!=0)
        {
        WaitEventTaskToReady(lpEv, 0, JOS_STAT_Q, JOS_STAT_PEND_ABORT);
        Tasks++;
        if (Opt!=JOS_PEND_OPT_BROADCAST) break;
        }
    JOS_EXIT_CRITICAL();

    if (Tasks>0)
        {
        Scheduling();
        return JOS_ERR_PEND_ABORT;
        }
    return JOS_ERR_NONE;
    }
#endif




//-----------------------------------------------------------------------------
//      �־��� �̺�Ʈ�� ������� Ÿ��ũ�� ������ �����
//      �̺�Ʈ���� ��⸮��Ʈ���� ����� �غ񸮽�Ʈ�� ������ϰ� �����층��
//
//      ������� Ÿ��ũ�� ������ Q�� �ְ� ������
//-----------------------------------------------------------------------------
#if JOS_Q_POST_EN>0
JOS_RESULT WINAPI JOSQPost(JOS_EVENT *lpEv, DWORD Msg, UINT Opt)
    {
    int Tasks=0;
    JOS_Q *lpQ;
    JOS_RESULT Rslt;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    while (lpEv->EventTaskList.Group!=0)
        {
        WaitEventTaskToReady(lpEv, Msg, JOS_STAT_Q, JOS_STAT_PEND_OK);
        Tasks++;
        if ((Opt & JOS_POST_OPT_BROADCAST)==0) break;
        }

    if (Tasks>0)
        {
        JOS_EXIT_CRITICAL();
        if ((Opt & JOS_POST_OPT_NO_SCHED)==0) Scheduling();
        return JOS_ERR_NONE;
        }

    lpQ=(JOS_Q*)lpEv->EventPtr;
    if (lpQ->QEntries>=lpQ->QSize) {Rslt=JOS_ERR_Q_FULL; goto ProcExit;}

    if (Opt & JOS_POST_OPT_FRONT)
        {
        if (lpQ->Entry.B.QOut==lpQ->Entry.B.QStart) lpQ->Entry.B.QOut=lpQ->Entry.B.QEnd;
        switch (lpQ->QType)
            {
            case JOSQTYPE_BYTE:  *--lpQ->Entry.B.QOut=Msg; break;
            case JOSQTYPE_WORD:  *--lpQ->Entry.W.QOut=Msg; break;
            default:             *--lpQ->Entry.D.QOut=Msg; //break;
            }
        }
    else{
        switch (lpQ->QType)
            {
            case JOSQTYPE_BYTE:  *lpQ->Entry.B.QIn++=Msg; break;
            case JOSQTYPE_WORD:  *lpQ->Entry.W.QIn++=Msg; break;
            default:             *lpQ->Entry.D.QIn++=Msg; //break;
            }
        if (lpQ->Entry.B.QIn==lpQ->Entry.B.QEnd) lpQ->Entry.B.QIn=lpQ->Entry.B.QStart;
        }
    lpQ->QEntries++;
    Rslt=JOS_ERR_NONE;

    ProcExit:
    JOS_EXIT_CRITICAL();
    return Rslt;
    }
#endif





#if JOS_Q_QUERY_EN>0
JOS_RESULT WINAPI JOSQQuery(JOS_EVENT *lpEv, JOS_Q_DATA *lpQData)
    {
    DWORD Entry=0;
    JOS_Q *lpQ;
    JOS_CRITICAL_VAR;

    #if JOS_ARG_CHK_EN>0
    if (lpEv==NULL) return JOS_ERR_PEVENT_NULL;
    if (lpQData==NULL) return JOS_ERR_NULL_PARAM;
    #endif
    if (lpEv->EventType!=JOS_EVENT_TYPE_Q) return JOS_ERR_EVENT_TYPE;

    JOS_ENTER_CRITICAL();
    lpQ=(JOS_Q*)lpEv->EventPtr;
    if (lpQ->QEntries>0)
        {
        switch (lpQ->QType)
            {
            case JOSQTYPE_BYTE:  Entry=*lpQ->Entry.B.QOut; break;
            case JOSQTYPE_WORD:  Entry=*lpQ->Entry.W.QOut; break;
            default:             Entry=*lpQ->Entry.D.QOut; //break;
            }
        }
    lpQData->QEntry=Entry;
    lpQData->QEntries=lpQ->QEntries;
    lpQData->QSize=lpQ->QSize;
    JOS_EXIT_CRITICAL();

    return JOS_ERR_NONE;
    }



//-----------------------------------------------------------------------------
//      Q�ȿ� ����Ʈ ũ�⸦ ���� (�������� JOS�� ȣȯ�� ����)
//-----------------------------------------------------------------------------
int WINAPI JOSQEntries(JOS_EVENT *lpEv)
    {
    JOS_Q_DATA QData;

    if (JOSQQuery(lpEv, &QData)!=JOS_ERR_NONE) QData.QEntries=0;
    return QData.QEntries;
    }
#endif

#endif //JOS_Q_EN





#if ((JOS_EVENT_EN) && (JOS_EVENT_MULTI_EN>0))
int WINAPI JOSEventPendMulti(JOS_EVENT **lpPendEvList, JOS_EVENT **lpReadyEvList, DWORD *lpQData, DWORD Timeout, JOS_RESULT *lpRslt)
    {
    int I, ReadyEvQty=0;
    JOS_RESULT Rslt;
    JOS_EVENT *lpEv;
    #if JOS_Q_EN>0
    JOS_Q*lpQ;
    #endif
    BYTE events_stat;
    JOS_CRITICAL_VAR;


    #if (JOS_ARG_CHK_EN>0)
    if (lpPendEvList==NULL || lpPendEvList[0]==NULL || lpReadyEvList==NULL || lpQData==0) {Rslt=JOS_ERR_PEVENT_NULL; goto ProcExit;}
    #endif

    lpReadyEvList[0]=NULL;
    for (I=0; ;I++)
        {
        if ((lpEv=lpPendEvList[I])==NULL) break;

        switch (lpEv->EventType)
            {
            case JOS_EVENT_TYPE_SEM: break;
            case JOS_EVENT_TYPE_MBOX: break;
            case JOS_EVENT_TYPE_Q: break;
            default: Rslt=JOS_ERR_EVENT_TYPE; goto ProcExit;
            }
        }

    if (JOSIntNesting>0) {Rslt=JOS_ERR_PEND_ISR; goto ProcExit;}
    if (LockNesting>0) {Rslt=JOS_ERR_PEND_LOCKED; goto ProcExit;}

    events_stat=0;
    JOS_ENTER_CRITICAL();

    for (I=0; ;I++)
        {
        if ((lpEv=lpPendEvList[I])==NULL) break;
        switch (lpEv->EventType)
            {
            #if (JOS_SEM_EN>0)
            case JOS_EVENT_TYPE_SEM:
                if (lpEv->EventCnt>0)
                    {
                    lpEv->EventCnt--;
                    *lpReadyEvList++=lpEv;
                    *lpQData++=0;
                    ReadyEvQty++;
                    }
                else events_stat|=JOS_STAT_SEM;
                break;
            #endif

            #if (JOS_MBOX_EN>0)
            case JOS_EVENT_TYPE_MBOX:
                if (lpEv->EventPtr!=NULL)
                    {
                    *lpQData++=lpEv->EventPtr;
                    lpEv->EventPtr=NULL;
                    *lpReadyEvList++=lpEv;
                    ReadyEvQty++;
                    }
                else events_stat|=JOS_STAT_MBOX;
                break;
            #endif

            #if JOS_Q_EN
            case JOS_EVENT_TYPE_Q:
                lpQ=(JOS_Q*)lpEv->EventPtr;
                if (lpQ->QEntries>0)
                    {
                    *lpQData++=GetQData(lpQ);
                    *lpReadyEvList++=lpEv;
                    ReadyEvQty++;
                    }
                else events_stat|=JOS_STAT_Q;
                break;
            #endif

            default:
                JOS_EXIT_CRITICAL();
                *lpReadyEvList=NULL;
                Rslt=JOS_ERR_EVENT_TYPE;
                goto ProcExit;
            }
        }

    if (ReadyEvQty>0)
        {
        *lpReadyEvList=NULL;
        JOS_EXIT_CRITICAL();
        Rslt=JOS_ERR_NONE;
        goto ProcExit;
        }

    JOSCurrTCB->TcbState|=events_stat|JOS_STAT_MULTI;
    JOSCurrTCB->TcbStatPend=JOS_STAT_PEND_OK;
    JOSCurrTCB->TcbDelay=Timeout;
    EventTaskWaitMulti(lpPendEvList);

    JOS_EXIT_CRITICAL();
    Scheduling();
    JOS_ENTER_CRITICAL();

    switch (JOSCurrTCB->TcbStatPend)
        {
        case JOS_STAT_PEND_OK:
        case JOS_STAT_PEND_ABORT:
            lpEv=JOSCurrTCB->TcbEventPtr;
            if (lpEv!=NULL)
                {
                *lpReadyEvList++=lpEv;
                *lpReadyEvList=NULL;
                ReadyEvQty=1;
                }
            else{
                JOSCurrTCB->TcbStatPend=JOS_STAT_PEND_TO;
                RemoveMultiEventTask(JOSCurrTCB, lpPendEvList);
                }
            break;

        default:
            RemoveMultiEventTask(JOSCurrTCB, lpPendEvList);
            break;
        }

    switch (JOSCurrTCB->TcbStatPend)
        {
        case JOS_STAT_PEND_OK:
            switch (lpEv->EventType)
                {
                #if (JOS_SEM_EN>0)
                case JOS_EVENT_TYPE_SEM:
                    *lpQData++=0;
                    break;
                #endif

                #if JOS_MBOX_EN>0 || JOS_Q_EN>0
                case JOS_EVENT_TYPE_MBOX:
                case JOS_EVENT_TYPE_Q:
                    *lpQData++=JOSCurrTCB->TcbMsg;
                    break;
                #endif

                case JOS_EVENT_TYPE_MUTEX:
                default:
                    JOS_EXIT_CRITICAL();
                    *lpReadyEvList=NULL;
                    Rslt=JOS_ERR_EVENT_TYPE;
                    goto ProcExit;
                }
            Rslt=JOS_ERR_NONE;
            break;

        case JOS_STAT_PEND_ABORT:
            *lpQData++=0;
            Rslt=JOS_ERR_PEND_ABORT;
            break;

        //case JOS_STAT_PEND_TO:
        default:
            *lpQData++=0;
            Rslt=JOS_ERR_TIMEOUT;
            //break;
        }

    FinishPend();
    JOS_EXIT_CRITICAL();

    ProcExit:
    if (lpRslt!=NULL) *lpRslt=Rslt;
    return ReadyEvQty;
    }
#endif





///////////////////////////////////////////////////////////////////////////////
//                          ��Ÿ
///////////////////////////////////////////////////////////////////////////////



VOID WINAPI Sleep(UINT ms)
    {
    JOS_CRITICAL_VAR;

    if (JOSRunning)
        {
        if (ms!=0 && JOSIntNesting==0 && LockNesting==0)
            {
            DWORD Ticks;

            if ((Ticks=UMulDiv(ms, JOS_TICKS_PER_SEC, 1000))==0) Ticks=1;
            JOS_ENTER_CRITICAL();
            ClrTaskReadyBit(JOSCurrTCB);
            JOSCurrTCB->TcbDelay=Ticks;
            JOS_EXIT_CRITICAL();
            Scheduling();
            }
        }
    else{
        DWORD Tick=FineTickCnt;
        while (FineTickCnt-Tick<ms);
        }
    }




VOID WINAPI JOSInit(VOID)
    {
    JOSInitHookBegin();

    JOSIntNesting=0;
    LockNesting=0;
    JOSRunning=FALSE;

    #ifdef JOS_SAFETY_CRITICAL_IEC61508
    JOSSafetyCriticalStartFlag=FALSE;
    #endif

    ZeroMem(&TaskReadyTable, sizeof(TaskReadyTable));
    JOSCurrPrio=0;
    JOSPrioHighRdy=0;
    JOSTcbHighRdy=NULL;
    JOSCurrTCB=NULL;

    ZeroMem(TcbPrioTbl, sizeof(TcbPrioTbl));
    UsingTcbList=NULL;
    CreateThread("Idle", IDLE_TASK_STK_SIZE, IdleThread, NULL, JOS_TASK_IDLE_PRIO);
    }



VOID WINAPI JOSStart(VOID)
    {
    if (JOSRunning==FALSE)
        {
        FindAndSetHighReadyPrio();

        JOSCurrPrio=JOSPrioHighRdy;
        JOSCurrTCB=JOSTcbHighRdy;
        JOSStartHighRdy();
        }
    }



DWORD WINAPI GetLastError(VOID)
    {
    return (JOSCurrTCB!=NULL) ? JOSCurrTCB->TcbLastRslt:G_LastResult;
    }

VOID WINAPI SetLastError(DWORD ErrCode)
    {
    if (JOSCurrTCB!=NULL) JOSCurrTCB->TcbLastRslt=ErrCode; else G_LastResult=ErrCode;
    }



DWORD WINAPI JOSVersion(VOID) {return JOS_VERSION;}

