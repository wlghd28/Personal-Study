///////////////////////////////////////////////////////////////////////////////
//      STM32F7XX Driver
//
// ������: 2019-02-14
// ���α׷���: ������
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include "DRIVER.H"
#include "JOS.H"


__IO DWORD FineTickCnt; //JOS���� �����
static LPVOID DebugRedirectInArg;
static LPVOID DebugRedirectOutArg;
static DebugRedirectInFt  DebugRedirectInFp;
static DebugRedirectOutFt DebugRedirectOutFp;
static BYTE DebugPort=COM_DEBUG;

#define MEMOWNER_I2S_Init   (MEMOWNER_Driver+0)


#define MODIFYBIT(Reg, Clear, Set) {UINT R=Reg & ~(Clear); R|=Set; Reg=R;}
#define BITSET(Reg, Bit, OnOff)    {UINT R=Reg; R&=~(Bit); if (OnOff) R|=Bit; Reg=R;}



//-----------------------------------------------------------------------------
//      DWT(Data Watchpoint and Trace) ī���͸� �̿��� us����
//      �ͼ��� �ڵ鷯������ ȣ�Ⱑ��
//      Cortex-M3 �̻󿡼� ��밡��
//-----------------------------------------------------------------------------
VOID WINAPI Delay_us(UINT us)
    {
    UINT Dmcr, DwtCtrl, Start, Delay;
    static UINT Cycles1us;

    if (us)
        {
        if (Cycles1us==0) Cycles1us=SystemCoreClock/1000000;

        Dmcr=CoreDebug->DEMCR;
        CoreDebug->DEMCR=Dmcr|CoreDebug_DEMCR_TRCENA_Msk;   //DWT ����� ���� Ȱ��ȭ

        DwtCtrl=DWT->CTRL;
        DWT->CTRL=DwtCtrl|DWT_CTRL_CYCCNTENA_Msk;           //����Ŭ ī���� Ȱ��
        Delay=Cycles1us*us;
        Start=DWT->CYCCNT;
        while (DWT->CYCCNT-Start < Delay);
        DWT->CTRL=DwtCtrl;

        CoreDebug->DEMCR=Dmcr;
        }
    }



//-----------------------------------------------------------------------------
//      DWT(Data Watchpoint and Trace) ī���͸� �̿��� ms����
//      �ͼ��� �ڵ鷯������ ȣ�Ⱑ��
//      Cortex-M3 �̻󿡼� ��밡��
//-----------------------------------------------------------------------------
VOID WINAPI Delay_ms(UINT ms)
    {
    #if 0
    UINT Dmcr, DwtCtrl, Start, Delay;

    if (ms)
        {
        Dmcr=CoreDebug->DEMCR;
        CoreDebug->DEMCR=Dmcr|CoreDebug_DEMCR_TRCENA_Msk;   //���� �� ����� ����(DWT����) Ȱ��ȭ

        DwtCtrl=DWT->CTRL;
        DWT->CTRL=DwtCtrl|DWT_CTRL_CYCCNTENA_Msk;           //����Ŭ ī���� Ȱ��
        Delay=SystemCoreClock/1000*ms;
        Start=DWT->CYCCNT;
        while (DWT->CYCCNT-Start < Delay);
        DWT->CTRL=DwtCtrl;

        CoreDebug->DEMCR=Dmcr;
        }
    #else
    UINT I;
    volatile UINT Cnt;
    for (I=0; I<ms; I++) {Cnt=95939; while (Cnt>0) Cnt--;}
    #endif
    }



//-----------------------------------------------------------------------------
//      Hard Fault exception.
//      �ͼ����� �߻��� �� CPU�� Push�ϴ� ���� xPSR,PC,LR,R12,R3,R2,R1,R0, R11,R10,R9,R8,R7,R6,R5,R4
//-----------------------------------------------------------------------------
VOID WINAPI UndefinedIntHandler_C(UINT IPSR, UINT *MSP, UINT *PrevSP)
    {
    CHAR  Buff[32];
    LPSTR lp;

    switch (IPSR)
        {
        case 2:  lp="NMI"; break;           //NMI_Handler
        case 3:  lp="Hard Fault"; break;    //HardFault_Handler
        case 4:  lp="MemManage Fault"; break; //MemManage_Handler
        case 5:  lp="Bus Fault"; break;     //BusFault_Handler
        case 6:  lp="Usage Fault"; break;   //UsageFault_Handler
        case 11: lp="Called SVC"; break;    //SVC_Handler
        case 12: lp="Debug Mon"; break;     //DebugMon_Handler
        case 14: lp="PendSV"; break;        //PendSV_Handler
        case 15: lp="SysTick"; break;       //SysTick_Handler
        default: wsprintf(lp=Buff, "Undefined Interrupt #%d", IPSR);
        }

    LowPrintf("\r\n%s\r\n", lp);
    LowPrintf("  R0=%08X  R1=%08X  R2=%08X  R3=%08X\r\n", PrevSP[0], PrevSP[1], PrevSP[2], PrevSP[3]);
    LowPrintf("  R4=%08X  R5=%08X  R6=%08X  R7=%08X\r\n", MSP[0], MSP[1], MSP[2], MSP[3]);
    LowPrintf("  R8=%08X  R9=%08X R10=%08X R11=%08X\r\n", MSP[4], MSP[5], MSP[6], MSP[7]);
    LowPrintf(" R12=%08X  LR=%08X  PC=%08X  SR=%08X\r\n", PrevSP[4], PrevSP[5], PrevSP[6], PrevSP[7]);
    #ifdef USE_JOS
    LowPrintf("  SP=%08X Task=%d\r\n", PrevSP+8, JOSCurrPrio);
    #else
    LowPrintf("  SP=%08X\r\n", PrevSP+8);
    #endif

    LowPrintf("Halted...");
    FatalError(FERR_EXCEPTION);
    }




//-----------------------------------------------------------------------------
//      1ms ������ �ý��� ƽ ���ͷ�Ʈ
//-----------------------------------------------------------------------------
VOID SysTick_Handler(VOID)
    {
    JOSIntEnter();
    FineTickCnt++;
    #ifdef USE_JOS
    JOSTimeTick();
    #endif
    _1msProc();
    JOSIntExit();
    }



//-----------------------------------------------------------------------------
//      1ms ������ Tick���� ����, ���� 0�� �����ϸ� �ȵ�
//-----------------------------------------------------------------------------
UINT HAL_GetTick(VOID)
    {
    UINT Tick;
    if ((Tick=FineTickCnt)==0) Tick++;  //�÷��׷� ���� ����
    return Tick;    //�ݵ�� ���������� ����, FineTickCnt�� �ٽ� ������ ������ üũ�� 0�� ���ǹ�����
    }



///////////////////////////////////////////////////////////////////////////////
//                              GPIO
///////////////////////////////////////////////////////////////////////////////



//-----------------------------------------------------------------------------
//      GPIO Port Base�� ����
//-----------------------------------------------------------------------------
LOCAL(GPIO_TypeDef*) GetGpioBase(int PinNo)
    {
    static GPIO_TypeDef* CONST GBList[]={GPIOA,GPIOB,GPIOC,GPIOD,GPIOE,GPIOF,GPIOG,GPIOH,GPIOI,GPIOJ,GPIOK};
    return GBList[PinNo>>4];
    }



//-----------------------------------------------------------------------------
//      GPIO Out
//-----------------------------------------------------------------------------
BOOL WINAPI PortOut(int PinNo, int PinData)
    {
    int PinBit, Rslt=0, BitNo;
    GPIO_TypeDef *GB;
    JOS_CRITICAL_VAR;

    if (PinNo<I2CPORT)
        {
        BitNo=PinNo & 0x0F;
        PinBit=1<<BitNo;
        if ((GB=GetGpioBase(PinNo))!=NULL)
            {
            switch (PinData)
                {
                case LOW: GB->BSRR=PinBit<<16; break;   //HAL_GPIO_WritePin(GB, PinBit, (GPIO_PinState)PinData);
                case HIGH: GB->BSRR=PinBit; break;

                case PO_NOT:    //HAL_GPIO_TogglePin(GB, PinBit);
                    JOS_ENTER_CRITICAL();
                    GB->ODR^=PinBit;
                    JOS_EXIT_CRITICAL();
                    break;

                case PO_GETSTATE: Rslt=(GB->ODR >> BitNo) & 1;
                }
            }
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      GPIO In
//-----------------------------------------------------------------------------
BOOL WINAPI PortIn(int PinNo)
    {
    BOOL Rslt=FALSE;
    GPIO_TypeDef *GB;

    if (PinNo<I2CPORT)
        {
        if ((GB=GetGpioBase(PinNo))!=NULL)
            Rslt=(GB->IDR & (1<<(PinNo & 0x0F)))!=0;
        }

    return Rslt;
    }

DWORD WINAPI PortAIn(VOID) {return GPIOA->IDR;}
DWORD WINAPI PortBIn(VOID) {return GPIOB->IDR;}





#define GPIO_MODE             0x00000003
#define EXTI_MODE             0x10000000
#define GPIO_MODE_IT          0x00010000
#define GPIO_MODE_EVT         0x00020000
#define RISING_EDGE           0x00100000
#define FALLING_EDGE          0x00200000
#define GPIO_OUTPUT_TYPE      0x00000010
VOID HAL_GPIO_Init(GPIO_TypeDef*GPIOx, GPIO_InitTypeDef*GI)
    {
    int Shift, BitPos, CurrBit;

    for (BitPos=0; (GI->Pin>>BitPos)!=0; BitPos++)      //GI->Pin>>BitPos - ���� BitPos ���ʺκ��� ��� 0�̸� ������ ����
        {
        CurrBit=1<<BitPos;
        if (GI->Pin & CurrBit)
            {
            if (GI->Mode==GPIO_MODE_AF_PP || GI->Mode==GPIO_MODE_AF_OD)
                {
                Shift=(BitPos&7)<<2;
                MODIFYBIT(GPIOx->AFR[BitPos>>3], 0x0F<<Shift, GI->Alternate<<Shift);
                }

            MODIFYBIT(GPIOx->MODER, GPIO_MODER_MODER0<<BitPos*2, (GI->Mode&GPIO_MODE)<<BitPos*2);

            if (GI->Mode==GPIO_MODE_OUTPUT_PP || GI->Mode==GPIO_MODE_AF_PP ||
                GI->Mode==GPIO_MODE_OUTPUT_OD || GI->Mode==GPIO_MODE_AF_OD)
                {
                MODIFYBIT(GPIOx->OSPEEDR, GPIO_OSPEEDER_OSPEEDR0<<BitPos*2, GI->Speed<<BitPos*2);
                MODIFYBIT(GPIOx->OTYPER, GPIO_OTYPER_OT_0<<BitPos, ((GI->Mode&GPIO_OUTPUT_TYPE)>>4)<<BitPos);
                }

            MODIFYBIT(GPIOx->PUPDR, GPIO_PUPDR_PUPDR0<<BitPos*2, GI->Pull<<BitPos*2);

            if (GI->Mode & EXTI_MODE)
                {
                __HAL_RCC_SYSCFG_CLK_ENABLE();

                Shift=(BitPos&3)<<2;
                MODIFYBIT(SYSCFG->EXTICR[BitPos>>2], 0x0F<<Shift, GPIO_GET_INDEX(GPIOx)<<Shift);

                BITSET(EXTI->IMR,  CurrBit, GI->Mode&GPIO_MODE_IT);
                BITSET(EXTI->EMR,  CurrBit, GI->Mode&GPIO_MODE_EVT);
                BITSET(EXTI->RTSR, CurrBit, GI->Mode&RISING_EDGE);
                BITSET(EXTI->FTSR, CurrBit, GI->Mode&FALLING_EDGE);
                }
            }
        }
    }


#if 0
LOCAL(VOID) PrintGpioReg(GPIO_TypeDef *GPIOx, UINT BitPos)
    {
    Printf("GPIO->AFR[BitPos>>3]=%X"CRLF, GPIOx->AFR[BitPos>>3]);
    Printf("GPIO->MODER=%X"CRLF, GPIOx->MODER);
    Printf("GPIO->OSPEEDR=%X"CRLF, GPIOx->OSPEEDR);
    Printf("GPIO->OTYPER=%X"CRLF, GPIOx->OTYPER);
    Printf("GPIO->PUPDR=%X"CRLF, GPIOx->PUPDR);
    Printf("EXTI->IMR=%X"CRLF, EXTI->IMR);
    Printf("EXTI->EMR=%X"CRLF, EXTI->EMR);
    Printf("EXTI->RTSR=%X"CRLF, EXTI->RTSR);
    Printf("EXTI->FTSR=%X"CRLF, EXTI->FTSR);
    Printf("SYSCFG->EXTICR[BitPos>>2]=%X"CRLF, SYSCFG->EXTICR[BitPos>>2]);
    }
#endif




//-----------------------------------------------------------------------------
//      Init GPIO
//-----------------------------------------------------------------------------
VOID WINAPI InitPortEx(int PinNo, int PinMode, int PullUpDown, int AltFnc, int Speed)
    {
    int Port, Dummy;
    GPIO_InitTypeDef  GI;
    GPIO_TypeDef     *GB;

    Port=PinNo>>4;
    if ((GB=GetGpioBase(PinNo))!=NULL)
        {
        //�ش� GPIO Clock Enable
        //__HAL_RCC_GPIOA_CLK_ENABLE();
        RCC->AHB1ENR|=RCC_AHB1ENR_GPIOAEN<<Port;
        Dummy=RCC->AHB1ENR & (RCC_AHB1ENR_GPIOAEN<<Port);   //Delay after an RCC peripheral clock enabling
        UNUSED(Dummy);

        ZeroMem(&GI, sizeof(GPIO_InitTypeDef));
        GI.Mode=PinMode;
        GI.Pull=PullUpDown;
        GI.Speed=Speed;
        GI.Pin=1<<(PinNo & 0x0F);
        GI.Alternate=AltFnc;
        HAL_GPIO_Init(GB, &GI);
        }
    }

VOID WINAPI InitPort(int PinNo, int PinMode, int PullUpDown, int AltFnc)
    {
    InitPortEx(PinNo, PinMode, PullUpDown, AltFnc, GPIO_SPEED_HIGH);    //GPIO_SPEED_HIGH:50MHz
    }

VOID WINAPI InitPortOutputPP(int PinNo)
    {
    InitPortEx(PinNo, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0, GPIO_SPEED_HIGH);
    }

VOID WINAPI InitPortOutputOD(int PinNo)
    {
    InitPort(PinNo, GPIO_MODE_OUTPUT_OD, GPIO_NOPULL, 0);
    }

VOID WINAPI InitPortInput(int PinNo, int PullUpDown)
    {
    InitPortEx(PinNo, GPIO_MODE_INPUT, PullUpDown, 0, GPIO_SPEED_HIGH);
    }



///////////////////////////////////////////////////////////////////////////////
//              UART
///////////////////////////////////////////////////////////////////////////////


typedef struct
    {
    USART_TypeDef *Instance;
    JOS_EVENT *hEvGroupTx;
    JOS_EVENT *RxQ;
    JOS_EVENT *TxQ;
    BYTE PO_RTS;
    BYTE PI_CTS;
    BYTE PO_DTR;
    BYTE PI_DSR;
    UINT BaudRate;
    UINT Mode;
    UINT WordLength;
    UINT Parity;
    UINT StopBits;
    UINT OverSampling;
    UINT HwFlowCtl;
    UINT OneBitSampling;
    UINT ErrorCode;
    } UART_HANDLE;


typedef struct
    {
    USART_TypeDef *Instance;
    } UART_INST;




static UART_HANDLE UartHandle[USART_QTY];

LOCAL(BOOL) UART_TxGroupLock(int Port)
    {
    return JOSSemPend((UartHandle+Port)->hEvGroupTx, JOS_TICKS_PER_SEC*3)!=JOS_ERR_TIMEOUT;
    }

LOCAL(VOID) UART_TxGroupUnlock(int Port)
    {
    JOSSemPost((UartHandle+Port)->hEvGroupTx);
    }




//-----------------------------------------------------------------------------
//      UART Ŭ���� ����
//-----------------------------------------------------------------------------
LOCAL(DWORD) UART_GetClock(USART_TypeDef *UB)
    {
    DWORD InClk=0;
    UART_INST UINST={UB};
    UART_ClockSourceTypeDef ClockSrc=UART_CLOCKSOURCE_UNDEFINED;

    UART_GETCLOCKSOURCE(&UINST, ClockSrc);
    switch (ClockSrc)
        {
        case UART_CLOCKSOURCE_PCLK1:  InClk=HAL_RCC_GetPCLK1Freq(); break;
        case UART_CLOCKSOURCE_PCLK2:  InClk=HAL_RCC_GetPCLK2Freq(); break;
        case UART_CLOCKSOURCE_HSI:    InClk=HSI_VALUE; break;
        case UART_CLOCKSOURCE_SYSCLK: InClk=HAL_RCC_GetSysClockFreq(); break;
        case UART_CLOCKSOURCE_LSE:    InClk=LSE_VALUE; break;
        }
    return InClk;
    }



//-----------------------------------------------------------------------------
//      ���� Baudrate�� ������ ���
//-----------------------------------------------------------------------------
DWORD WINAPI UART_GetBaudrate(int Port)
    {
    int UartDiv;
    DWORD BaudRate=0, InClk;
    USART_TypeDef *UB;

    UB=(UartHandle+Port)->Instance;
    if ((InClk=UART_GetClock(UB))>0)
        {
        UartDiv=UB->BRR;
        BaudRate=(InClk+(UartDiv>>1))/UartDiv;
        }
    return BaudRate;
    }




//-----------------------------------------------------------------------------
//      Baudrate ����
//-----------------------------------------------------------------------------
LOCAL(BOOL) SetBaudRate(USART_TypeDef *UB, UINT BaudRate)
    {
    BOOL Rslt=FALSE;
    UINT InClk;

    if ((InClk=UART_GetClock(UB))>0)
        {
        UB->BRR=(WORD)((InClk+(BaudRate>>1)) / BaudRate);
        Rslt++;
        }
    return Rslt;
    }


VOID WINAPI UART_SetBaudrate(int Port, DWORD NewBaud)
    {
    SetBaudRate((UartHandle+Port)->Instance, NewBaud);
    }



//-----------------------------------------------------------------------------
//      CTS�ɻ��¸� �˷���
//-----------------------------------------------------------------------------
int WINAPI UART_InCTS(int Port)
    {
    int CtsPin;

    if ((CtsPin=(UartHandle+Port)->PI_CTS)==0) return 0;
    return PortIn(CtsPin);
    }



//-----------------------------------------------------------------------------
//      RTS ���
//-----------------------------------------------------------------------------
int WINAPI UART_OutRTS(int Port, BOOL EnableFg)
    {
    int RtsPin, Rslt=0;

    if ((RtsPin=(UartHandle+Port)->PO_RTS)!=0)
        {
        Rslt=PortOut(RtsPin, EnableFg);
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      DSR�ɻ��¸� �˷���
//-----------------------------------------------------------------------------
int WINAPI UART_InDSR(int Port)
    {
    int DsrPin;

    if ((DsrPin=(UartHandle+Port)->PI_DSR)==0) return 0;
    return PortIn(DsrPin);
    }



//-----------------------------------------------------------------------------
//      DTR ���
//-----------------------------------------------------------------------------
int WINAPI UART_OutDTR(int Port, BOOL EnableFg)
    {
    int DtrPin, Rslt=0;

    if ((DtrPin=(UartHandle+Port)->PO_DTR)!=0) Rslt=PortOut(DtrPin, EnableFg);
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      RS232 ���� ǥ��
//-----------------------------------------------------------------------------
VOID WINAPI UART_DisplayError(VOID)
    {
    int I, ErrCode, HwErr;
    UART_HANDLE *hUart;

    for (I=COM1; I<USART_QTY; I++)
        {
        if ((hUart=UartHandle+I)!=NULL &&
            (ErrCode=hUart->ErrorCode)!=0)
            {
            HwErr=0;
            if (ErrCode & HAL_UART_ERROR_PE) {Printf("SENSOR: COM%d Parity Err\r\n", I+1); HwErr=1;}
            if (ErrCode & HAL_UART_ERROR_FE) {Printf("SENSOR: COM%d Frame Err\r\n", I+1); HwErr=1;}
            if (ErrCode & HAL_UART_ERROR_NE) {Printf("SENSOR: COM%d Noise Err\r\n", I+1); HwErr=1;}
            if (ErrCode & HAL_UART_ERROR_ORE) Printf("SENSOR: COM%d Over Run\r\n", I+1);
            if (HwErr) UART_ErrUsrHandler(I, ErrCode);
            hUart->ErrorCode=0;
            }
        }
    }




//-----------------------------------------------------------------------------
//      UART �ʱ�ȭ (���̸�:HAL_UART_IRQHandler)
//-----------------------------------------------------------------------------
LOCAL(VOID) UART_IRQHandler_C(int ComNo)
    {
    DWORD ISR;
    USART_TypeDef *UB;
    UART_HANDLE *hUart;

    JOSIntEnter();
    hUart=UartHandle+ComNo;
    UB=hUart->Instance;
    ISR=UB->ISR;

    if (ISR & USART_ISR_PE)
        {
        UB->ICR=UART_CLEAR_PEF;
        hUart->ErrorCode|=HAL_UART_ERROR_PE;
        }

    if (ISR & USART_ISR_FE)
        {
        UB->ICR=UART_CLEAR_FEF;
        hUart->ErrorCode|=HAL_UART_ERROR_FE;
        }

    if (ISR & USART_ISR_NE)
        {
        UB->ICR=UART_CLEAR_NEF;
        hUart->ErrorCode|=HAL_UART_ERROR_NE;
        }

    if (ISR & USART_ISR_ORE)
        {
        UB->ICR=UART_CLEAR_OREF;
        hUart->ErrorCode|=HAL_UART_ERROR_ORE;
        }

    #if 0
    if (ISR & USART_ISR_RTOF)       //Receiver timeout flag
        {
        UB->ICR=UART_CLEAR_RTOF;
        hUart->ErrorCode|=HAL_UART_ERROR_RTO;
        }
    #endif


    if (ISR & USART_ISR_RXNE)
        {
        if (JOSQPost(hUart->RxQ, UB->RDR, 0)!=JOS_ERR_NONE) hUart->ErrorCode|=HAL_UART_ERROR_ORE;
        }

    if (ISR & USART_ISR_TXE)
        {
        DWORD Data;
        JOS_RESULT QRslt;

        Data=JOSQPend(hUart->TxQ, 0, &QRslt);
        if (QRslt==JOS_ERR_NONE) UB->TDR=Data;
        else{
            UB->CR1&=~USART_CR1_TXEIE;                  //Disable the UART Transmit Data Register Empty Interrupt
            //UB->CR1|=USART_CR1_TCIE;                  //Enable the UART Transmit Complete Interrupt
            }
        }
    //if (ISR & USART_ISR_TC) UART_EndTransmit_IT(hUart); //�۽ſϷ�
    JOSIntExit();
    }



VOID USART1_IRQHandler(VOID) {UART_IRQHandler_C(COM1);}
VOID USART2_IRQHandler(VOID) {UART_IRQHandler_C(COM2);}
VOID USART3_IRQHandler(VOID) {UART_IRQHandler_C(COM3);}
VOID UART4_IRQHandler(VOID)  {UART_IRQHandler_C(COM4);}
VOID UART5_IRQHandler(VOID)  {UART_IRQHandler_C(COM5);}
VOID USART6_IRQHandler(VOID) {UART_IRQHandler_C(COM6);}
VOID UART7_IRQHandler(VOID)  {UART_IRQHandler_C(COM7);}
VOID UART8_IRQHandler(VOID)  {UART_IRQHandler_C(COM8);}




//-----------------------------------------------------------------------------
//      UART �ʱ�ȭ
//-----------------------------------------------------------------------------
LOCAL(VOID) UART_Init(UART_HANDLE *hUart)
    {
    DWORD TickStart;
    USART_TypeDef *UB;

    UB=hUart->Instance;
    UB->CR1&=~USART_CR1_UE;     //__HAL_UART_DISABLE(hUart);

    //UART_SetConfig()
    MODIFYBIT(UB->CR1, USART_CR1_M|USART_CR1_PCE|USART_CR1_PS|USART_CR1_TE|USART_CR1_RE|USART_CR1_OVER8,
                       hUart->WordLength|hUart->Parity|hUart->Mode|hUart->OverSampling);
    MODIFYBIT(UB->CR2, USART_CR2_STOP, hUart->StopBits);

    MODIFYBIT(UB->CR3, USART_CR3_RTSE|USART_CR3_CTSE|USART_CR3_ONEBIT, hUart->HwFlowCtl|hUart->OneBitSampling);

    SetBaudRate(UB, hUart->BaudRate);

    //if (hUart->AdvancedInit.AdvFeatureInit!=UART_ADVFEATURE_NO_INIT) UART_AdvFeatureConfig(hUart);

    CLEAR_BIT(UB->CR2, USART_CR2_LINEN|USART_CR2_CLKEN);
    CLEAR_BIT(UB->CR3, USART_CR3_SCEN|USART_CR3_HDSEL|USART_CR3_IREN);

    UB->CR1|=USART_CR1_UE;      //__HAL_UART_ENABLE(hUart);

    TickStart=HAL_GetTick();
    if (UB->CR1 & USART_CR1_TE) //Tx Enable
        while ((UB->ISR & USART_ISR_TEACK)==0)  //Tx Enable Acknowledge Flag
            {
            if (HAL_GetTick()-TickStart>=HAL_UART_TIMEOUT_VALUE)
                {
                CLEAR_BIT(UB->CR1, USART_CR1_RXNEIE|USART_CR1_PEIE|USART_CR1_TXEIE);
                CLEAR_BIT(UB->CR3, USART_CR3_EIE);
                }
            }
    }



//-----------------------------------------------------------------------------
//      ���ͷ�Ʈ ���Ź��� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) UART_PrepareRecvIT(UART_HANDLE *hUart)
    {
    USART_TypeDef *UB;

    hUart->RxQ=JOSQCreate(UART_RECV_BUFF_SIZE, JOSQTYPE_BYTE);
    UB=hUart->Instance;
    UB->CR1|=USART_CR1_PEIE|USART_CR1_RXNEIE;
    UB->CR3|=USART_CR3_EIE;     //Enable the UART Error Interrupt
    }



//-----------------------------------------------------------------------------
//      ���ͷ�Ʈ �۽Ź��� ����
//-----------------------------------------------------------------------------
LOCAL(VOID) UART_PrepareSendIT(UART_HANDLE *hUart)
    {
    USART_TypeDef *UB;

    hUart->TxQ=JOSQCreate(UART_SEND_BUFF_SIZE, JOSQTYPE_BYTE);
    hUart->hEvGroupTx=JOSSemCreate(1);
    UB=hUart->Instance;
    UB->CR3|=USART_CR3_EIE;     //Enable the UART Error Interrupt: (Frame error, noise error, overrun error)
    }



//-----------------------------------------------------------------------------
//      RS232 �ʱ�ȭ
//-----------------------------------------------------------------------------
VOID WINAPI InitUart(int ComNo, DWORD BaudRate, int Parity, int DataLen, int StopBit)
    {
    UART_HANDLE *hUart;

    hUart=UartHandle+ComNo;
    hUart->Mode=UART_MODE_TX_RX;
    hUart->BaudRate=BaudRate;
    hUart->Parity=Parity;
    hUart->WordLength=DataLen;
    hUart->StopBits=StopBit;

    #if 0
    //hUart->OverSampling=UART_OVERSAMPLING_8;
    hUart->AdvancedInit.AdvFeatureInit=UART_ADVFEATURE_NO_INIT;
    if (AutoBaud)
        {
        hUart->AdvancedInit.AdvFeatureInit=UART_ADVFEATURE_AUTOBAUDRATE_INIT; //UART_ADVFEATURE_NO_INIT;
        hUart->AdvancedInit.AutoBaudRateEnable=UART_ADVFEATURE_AUTOBAUDRATE_ENABLE;
        hUart->AdvancedInit.AutoBaudRateMode=UART_ADVFEATURE_AUTOBAUDRATE_ONSTARTBIT;
        }
    #endif

    switch (ComNo)
        {
        #ifdef PO_COM1TX
        case COM1:
            hUart->Instance=USART1;
            __HAL_RCC_USART1_CLK_ENABLE();
            NVIC_SetPriority(USART1_IRQn, 0);
            NVIC_EnableIRQ(USART1_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM2TX
        case COM2:
            hUart->Instance=USART2;
            __HAL_RCC_USART2_CLK_ENABLE();
            HAL_NVIC_SetPriority(USART2_IRQn, 0, 1);
            NVIC_EnableIRQ(USART2_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM3TX
        case COM3:
            hUart->Instance=USART3;
            __HAL_RCC_USART3_CLK_ENABLE();
            HAL_NVIC_SetPriority(USART3_IRQn, 0, 1);
            NVIC_EnableIRQ(USART3_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM4TX
        case COM4:
            hUart->Instance=UART4;
            __HAL_RCC_UART4_CLK_ENABLE();
            HAL_NVIC_SetPriority(UART4_IRQn, 0, 1);
            NVIC_EnableIRQ(UART4_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM5TX
        case COM5:
            hUart->Instance=UART5;
            __HAL_RCC_UART5_CLK_ENABLE();
            HAL_NVIC_SetPriority(UART5_IRQn, 0, 1);
            NVIC_EnableIRQ(UART5_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM6TX
        case COM6:
            hUart->Instance=USART6;
            __HAL_RCC_USART6_CLK_ENABLE();
            HAL_NVIC_SetPriority(USART6_IRQn, 0, 1);
            NVIC_EnableIRQ(USART6_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM7TX
        case COM7:
            hUart->Instance=UART7;
            __HAL_RCC_UART7_CLK_ENABLE();
            HAL_NVIC_SetPriority(UART7_IRQn, 0, 1);
            NVIC_EnableIRQ(UART7_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            break;
        #endif

        #ifdef PO_COM8TX
        case COM8:
            hUart->Instance=UART8;
            __HAL_RCC_UART8_CLK_ENABLE();
            HAL_NVIC_SetPriority(UART8_IRQn, 0, 1);
            NVIC_EnableIRQ(UART8_IRQn);

            UART_PrepareRecvIT(hUart);
            UART_PrepareSendIT(hUart);
            //break;
        #endif
        }

    UART_Init(hUart);
    }




//-----------------------------------------------------------------------------
//      ����������� ���̳ʸ� ������ ���
//-----------------------------------------------------------------------------
VOID WINAPI UART_TxBin(int Port, LPCBYTE Data, int SendBytes)
    {
    DWORD StartTick, TimeOut;
    USART_TypeDef *UB;

    UB=(UartHandle+Port)->Instance;
    TimeOut=SendBytes+1;    //+1�� 1�� ���� �� GetCount()�� 1ms�� �ٷ� �Ѿ ���� ����
    StartTick=GetTickCount();
    while (SendBytes--)
        {
        while ((UB->ISR & USART_ISR_TXE)==0)
            {
            if (GetTickCount()-StartTick>=TimeOut) goto ProcExit;
            }
        UB->TDR=*Data++;
        }
    ProcExit:;
    }

VOID WINAPI UART_TxStr(int Port, LPCSTR Str)
    {
    UART_TxBin(Port, (LPCBYTE)Str, lstrlen(Str));
    }



//-----------------------------------------------------------------------------
//      �۽� Q�� 1Byte�� ����
//-----------------------------------------------------------------------------
BOOL WINAPI UART_TxByteIT(int Port, int Ch)
    {
    JOS_RESULT Rslt;
    USART_TypeDef *UB;
    UART_HANDLE *hUart;

    if (Port==DebugPort && DebugRedirectOutFp!=NULL)
        {
        return DebugRedirectOutFp(DebugRedirectOutArg, Ch);
        }
    else{
        hUart=UartHandle+Port;
        UB=hUart->Instance;
        Rslt=JOSQPost(hUart->TxQ, Ch, 0);
        UB->CR1|=USART_CR1_TXEIE;               //Enable the UART Transmit Data Register Empty Interrupt
        return Rslt==JOS_ERR_NONE;
        }
    }




//-----------------------------------------------------------------------------
//      Serial Port�� ���̳ʸ� ������ ��� (���ͷ�Ʈ�̿�)
//-----------------------------------------------------------------------------
BOOL WINAPI UART_TxBinIT(int Port, LPCBYTE Data, int SendBytes)
    {
    int Ch, Rslt=FALSE;
    DWORD StartTick, TimeOut;

    TimeOut=(SendBytes+1)<<1;       //+1�� 1�� ���� �� GetCount()�� 1ms�� �ٷ� �Ѿ ���� ����
    StartTick=GetTickCount();
    if (UART_TxGroupLock(Port)!=FALSE)
        {
        while (SendBytes--)
            {
            Ch=*Data++;
            while (UART_TxByteIT(Port, Ch)==FALSE)
                {
                if (GetTickCount()-StartTick>=TimeOut)
                    {
                    UART_TxGroupUnlock(Port);
                    goto ProcExit;
                    }
                }
            }
        UART_TxGroupUnlock(Port);
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Serial Port�� ���ڿ� ��� (���ͷ�Ʈ�̿�)
//-----------------------------------------------------------------------------
BOOL WINAPI UART_TxStrIT(int Port, LPCSTR Str)
    {
    return UART_TxBinIT(Port, (LPCBYTE)Str, lstrlen(Str));
    }




//-----------------------------------------------------------------------------
//      ���ͷ�Ʈ ����
//-----------------------------------------------------------------------------
int WINAPI UART_RxByteIT(int Port)
    {
    int RcvByte;
    JOS_RESULT QRslt;
    UART_HANDLE *hUart;

    if (Port==DebugPort && DebugRedirectInFp!=NULL)
        {
        RcvByte=DebugRedirectInFp(DebugRedirectInArg);
        }
    else{
        hUart=UartHandle+Port;
        RcvByte=JOSQPend(hUart->RxQ, 0, &QRslt);
        if (QRslt!=JOS_ERR_NONE) RcvByte=-1;
        }
    return RcvByte;
    }



//-----------------------------------------------------------------------------
//     ����� IN/OUT�� ��Ʈ������ ��� ó���� �� �����
//-----------------------------------------------------------------------------
VOID WINAPI SetDebugRedirect(DebugRedirectInFt InFnc, LPVOID InArg, DebugRedirectOutFt OutFnc, LPVOID OutArg)
    {
    DebugRedirectInFp=InFnc;
    DebugRedirectInArg=InArg;
    DebugRedirectOutFp=OutFnc;
    DebugRedirectOutArg=OutArg;
    }



//-----------------------------------------------------------------------------
//     ���Ĺ��ڿ� ���
//-----------------------------------------------------------------------------
VOID Printf(LPCSTR DispStr, ...)
    {
    va_list VA;
    CHAR Buff[128];

    va_start(VA, DispStr);
    VsprintfN(Buff, sizeof(Buff), DispStr, VA);
    va_end(VA);
    UART_TxStrIT(DebugPort, Buff);
    }

VOID PrintfII(int Port, LPCSTR DispStr, ...)
    {
    va_list VA;
    CHAR Buff[128];

    va_start(VA, DispStr);
    VsprintfN(Buff, sizeof(Buff), DispStr, VA);
    va_end(VA);
    UART_TxStrIT(Port, Buff);
    }

VOID WINAPI PrintLargeStr(LPCSTR DispStr)
    {
    UART_TxStrIT(DebugPort, CRLF "---" CRLF);
    UART_TxStrIT(DebugPort, DispStr);
    UART_TxStrIT(DebugPort, CRLF "---" CRLF);
    }



//-----------------------------------------------------------------------------
//     ���ͷ�Ʈ ��ƾ���� LowLevel���� ���
//-----------------------------------------------------------------------------
VOID LowPrintf(LPCSTR DispStr, ...)
    {
    va_list VA;
    CHAR Buff[128];

    va_start(VA, DispStr);
    VsprintfN(Buff, sizeof(Buff), DispStr, VA);
    va_end(VA);
    UART_TxStr(DebugPort, Buff);
    }


int  WINAPI GetChar(VOID) {return UART_RxByteIT(DebugPort);}
int  WINAPI GetDebugPort(VOID) {return DebugPort;}
VOID WINAPI SetDebugPort(int PortNo) {DebugPort=PortNo;}



//-----------------------------------------------------------------------------
//      ���� ����Ʈ�� ����
//-----------------------------------------------------------------------------
int WINAPI UART_ReceiveCntIT(int Port)
    {
    return JOSQEntries((UartHandle+Port)->RxQ);
    }




//-----------------------------------------------------------------------------
//     ��� �۽��ߴ��� üũ��
//-----------------------------------------------------------------------------
VOID WINAPI UART_WaitAllSendIT(int ComPort)
    {
    UART_HANDLE *hUart;
    DWORD Time;

    hUart=UartHandle+ComPort;
    Time=GetTickCount();
    for (;;)
        {
        if (JOSQEntries(hUart->TxQ)==0 && (hUart->Instance->ISR & USART_ISR_TC)!=0) break;
        if (GetTickCount()-Time>200)    //2400 Baud���� 40�� ���۽ð��� 166ms
            {
            Printf("COM%d: WaitAllSendIT Timeout\r\n", ComPort+1);
            break;
            }
        }
    }




//-----------------------------------------------------------------------------
//      485 ������ ��
//-----------------------------------------------------------------------------
VOID WINAPI UART_485BinOut(int ComPort, LPCBYTE Data, int ToSendBytes, BOOL FirstDelayFg, int RetryQty, int _485DE)
    {
    int I, Retry;
    DWORD Delay, IdleStartTime, FirstTime, CurrTime;
    USART_TypeDef *UB;

    UB=(UartHandle+ComPort)->Instance;

    for (Retry=0; Retry<RetryQty; Retry++)
        {
        if (FirstDelayFg!=FALSE)
            {
            IdleStartTime=FirstTime=GetTickCount();
            Delay=((IdleStartTime % 10)+1)<<2;          //4~40ms Delay, �ٸ� ��ġ�� 485 �浹�� ���ϱ� ����
            for (;;)
                {
                CurrTime=GetTickCount();
                if (UB->ISR & USART_ISR_RXNE) IdleStartTime=CurrTime;   //������ ������ �����ð� �� ����
                if (CurrTime-IdleStartTime>=Delay) break;
                if (CurrTime-FirstTime>=1000)
                    {
                    Printf("SENSOR: 485 Line Busy\r\n");
                    goto Cont;
                    }
                }
            }

        PortOut(_485DE, HIGH);
        UART_TxBin(ComPort, Data, ToSendBytes);
        UART_WaitAllSendIT(ComPort);    //�۽Ź��۵� ��� �ø��������͵� �������� ��ٸ�
        PortOut(_485DE, LOW);

        for (I=0; I<ToSendBytes; I++)
            {
            if (UART_RxByteIT(ComPort)!=Data[I]) break;
            }

        if (I==ToSendBytes) break;//{Printf("SENSOR: Send 485 OK\r\n"); break;}
        Printf("SENSOR: Retry 485 Out\r\n");
        Cont:;
        }
    }

VOID WINAPI UART_485StrOut(int ComPort, LPCSTR Str, int _485DE) {UART_485BinOut(ComPort, (LPCBYTE)Str, lstrlen(Str), TRUE, 3, _485DE);}



///////////////////////////////////////////////////////////////////////////////
//              FLASH
///////////////////////////////////////////////////////////////////////////////


#define FLASH_TIMEOUT_VALUE     2000
#define SECTOR_MASK             0xFFFFFF07


LOCAL(BOOL) FLASH_WaitForLastOp(int Timeout)
    {
    int Rslt=FALSE, Elapse=0;

    while (FLASH->SR & FLASH_FLAG_BSY)
        {
        Delay_ms(1);
        if (++Elapse>=Timeout) goto ProcExit;
        }
    if (FLASH->SR & FLASH_FLAG_ALL_ERRORS) goto ProcExit;
    if (FLASH->SR & FLASH_FLAG_EOP) FLASH->SR=FLASH_FLAG_EOP; //__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP);
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �־��� ��巹���� �ش��ϴ� ���͹�ȣ�� ����
//-----------------------------------------------------------------------------
int WINAPI FLASH_GetSector(UINT Addr)
    {
    int Sector=-1;

    if      (Addr<ADDR_FLASH_SECTOR_0) goto ProcExit;

    if      (Addr<ADDR_FLASH_SECTOR_1) Sector=FLASH_SECTOR_0;
    else if (Addr<ADDR_FLASH_SECTOR_2) Sector=FLASH_SECTOR_1;
    else if (Addr<ADDR_FLASH_SECTOR_3) Sector=FLASH_SECTOR_2;
    else if (Addr<ADDR_FLASH_SECTOR_4) Sector=FLASH_SECTOR_3;
    else if (Addr<ADDR_FLASH_SECTOR_5) Sector=FLASH_SECTOR_4;
    else if (Addr<ADDR_FLASH_SECTOR_6) Sector=FLASH_SECTOR_5;
    else if (Addr<ADDR_FLASH_SECTOR_7) Sector=FLASH_SECTOR_6;
    else if (Addr<FLASH_END+1)         Sector=FLASH_SECTOR_7;

    ProcExit:
    return Sector;
    }



//-----------------------------------------------------------------------------
//      �־��� ���͹�ȣ�� ���� ��巹�� ����
//-----------------------------------------------------------------------------
UINT WINAPI FLASH_GetSectorAddr(int SctNo)
    {
    static CONST UINT SctAddrList[]=
        {
        ADDR_FLASH_SECTOR_0, ADDR_FLASH_SECTOR_1,
        ADDR_FLASH_SECTOR_2, ADDR_FLASH_SECTOR_3,
        ADDR_FLASH_SECTOR_4, ADDR_FLASH_SECTOR_5,
        ADDR_FLASH_SECTOR_6, ADDR_FLASH_SECTOR_7,
        FLASH_END+1
        };
    return SctAddrList[SctNo];
    }



//-----------------------------------------------------------------------------
//      �־��� ��巹���� �ش��ϴ� ���͸� ������
//-----------------------------------------------------------------------------
BOOL WINAPI FLASH_Erase(UINT Addr)
    {
    int SctNo, Rslt=FALSE;

    if (FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE)==FALSE) goto ProcExit;
    if ((SctNo=FLASH_GetSector(Addr))<0) goto ProcExit;

    FLASH->CR&=CR_PSIZE_MASK;
    FLASH->CR|=FLASH_PSIZE_WORD;
    FLASH->CR&=SECTOR_MASK;
    FLASH->CR|=(SctNo<<FLASH_CR_SNB_Pos)|FLASH_CR_SER;
    FLASH->CR|=FLASH_CR_STRT;
    __DSB();

    Rslt=FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE);
    CLEAR_BIT(FLASH->CR, FLASH_CR_SER|FLASH_CR_SNB);

    ProcExit:
    return Rslt;
    }



#if 0
//-----------------------------------------------------------------------------
//      DWORD�� �����
//-----------------------------------------------------------------------------
LOCAL(BOOL) FLASH_ProgramDW(UINT Addr, DWORD Data)
    {
    BOOL Rslt=FALSE;

    if (FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE)==FALSE) goto ProcExit;
    FLASH->CR&=CR_PSIZE_MASK;
    FLASH->CR|=FLASH_PSIZE_WORD|FLASH_CR_PG;
    *(__IO DWORD*)Addr=Data;
    __DSB();
    Rslt=FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE);
    FLASH->CR&=~FLASH_CR_PG;

    ProcExit:
    return Rslt;
    }
#endif



//-----------------------------------------------------------------------------
//      �÷��� �޸𸮿� �־��� ������ �����͸� �����
//      WriteBytes�� DWORD���� ������ �ƴϰ� Bytes ũ����
//-----------------------------------------------------------------------------
BOOL WINAPI FLASH_Program(UINT StartAddr, CONST DWORD *WriteBuff, int WriteBytes)
    {
    int Rslt=FALSE;
    DWORD Addr, EndAddr;
    CONST DWORD*lpDW;

    if (FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE)==FALSE) goto ProcExit;

    EndAddr=StartAddr+WriteBytes;
    lpDW=WriteBuff;

    FLASH->CR&=CR_PSIZE_MASK;
    FLASH->CR|=FLASH_PSIZE_WORD|FLASH_CR_PG;
    for (Addr=StartAddr; Addr<EndAddr; Addr+=4)
        {
        *(__IO DWORD*)Addr=*lpDW++;
        __DSB();
        }
    Rslt=FLASH_WaitForLastOp(FLASH_TIMEOUT_VALUE);
    FLASH->CR&=~FLASH_CR_PG;
    if (Rslt==FALSE) goto ProcExit;
    Rslt=FALSE;

    lpDW=WriteBuff;
    for (Addr=StartAddr; Addr<EndAddr; Addr+=4)
        {
        if (*(__IO DWORD*)Addr!=*lpDW++) goto ProcExit; //Verify
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



BOOL WINAPI FLASH_Unlock(VOID)
    {
    BOOL Rslt=TRUE;

    if (FLASH->CR & FLASH_CR_LOCK)
        {
        FLASH->KEYR=FLASH_KEY1;
        FLASH->KEYR=FLASH_KEY2;
        if (FLASH->CR & FLASH_CR_LOCK) Rslt=FALSE;
        }
    return Rslt;
    }



VOID WINAPI FLASH_Lock(VOID)
    {
    FLASH->CR|=FLASH_CR_LOCK;
    }



//-----------------------------------------------------------------------------
//      INI �����͸� ����� �� �����
//-----------------------------------------------------------------------------
BOOL WINAPI FLASH_WriteIniData(UINT StartAddr, LPCSTR WriteData, int WriteBytes)
    {
    BOOL Rslt;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();
    FLASH_Unlock();
    if ((Rslt=FLASH_Erase(StartAddr))!=FALSE)
        Rslt=FLASH_Program(StartAddr, (CONST DWORD*)WriteData, WriteBytes);
    FLASH_Lock();
    JOS_EXIT_CRITICAL();
    return Rslt;
    }




#ifdef HAL_TIM_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//                          PWM
///////////////////////////////////////////////////////////////////////////////



VOID TIM_OC1_SetConfig(TIM_TypeDef*TIMx, TIM_OC_InitTypeDef*OC_Config)
    {
    UINT CCMR1, CCER, CR2;

    TIMx->CCER&=~TIM_CCER_CC1E;

    CCER=TIMx->CCER;
    CR2=TIMx->CR2;
    CCMR1=TIMx->CCMR1;

    CCMR1&=~TIM_CCMR1_OC1M;
    CCMR1&=~TIM_CCMR1_CC1S;
    CCMR1|=OC_Config->OCMode;

    CCER&=~TIM_CCER_CC1P;
    CCER|=OC_Config->OCPolarity;

    if (IS_TIM_ADVANCED_INSTANCE(TIMx))
        {
        CCER&=~TIM_CCER_CC1NP;
        CCER|=OC_Config->OCNPolarity;
        CCER&=~TIM_CCER_CC1NE;

        CR2&=~TIM_CR2_OIS1;
        CR2&=~TIM_CR2_OIS1N;
        CR2|=OC_Config->OCIdleState;
        CR2|=OC_Config->OCNIdleState;
        }
    TIMx->CR2=CR2;
    TIMx->CCMR1=CCMR1;
    TIMx->CCR1=OC_Config->Pulse;
    TIMx->CCER=CCER;
    }



VOID TIM_OC2_SetConfig(TIM_TypeDef*TIMx, TIM_OC_InitTypeDef*OC_Config)
    {
    UINT CCMR1, CCER, CR2;

    TIMx->CCER&=~TIM_CCER_CC2E;

    CCER=TIMx->CCER;
    CR2=TIMx->CR2;
    CCMR1=TIMx->CCMR1;

    CCMR1&=~TIM_CCMR1_OC2M;
    CCMR1&=~TIM_CCMR1_CC2S;

    CCMR1|=OC_Config->OCMode<<8;

    CCER&=~TIM_CCER_CC2P;
    CCER|=OC_Config->OCPolarity<<4;

    if (IS_TIM_ADVANCED_INSTANCE(TIMx))
        {
        CCER&=~TIM_CCER_CC2NP;
        CCER|=OC_Config->OCNPolarity<<4;
        CCER&=~TIM_CCER_CC2NE;

        CR2&=~TIM_CR2_OIS2;
        CR2&=~TIM_CR2_OIS2N;
        CR2|=OC_Config->OCIdleState<<2;
        CR2|=OC_Config->OCNIdleState<<2;
        }
    TIMx->CR2=CR2;
    TIMx->CCMR1=CCMR1;
    TIMx->CCR2=OC_Config->Pulse;
    TIMx->CCER=CCER;
    }



VOID TIM_OC3_SetConfig(TIM_TypeDef*TIMx, TIM_OC_InitTypeDef*OC_Config)
    {
    UINT CCMR1, CCER, CR2;

    TIMx->CCER&=~TIM_CCER_CC3E;

    CCER=TIMx->CCER;
    CR2=TIMx->CR2;
    CCMR1=TIMx->CCMR2;

    CCMR1&=~TIM_CCMR2_OC3M;
    CCMR1&=~TIM_CCMR2_CC3S;
    CCMR1|=OC_Config->OCMode;

    CCER&=~TIM_CCER_CC3P;
    CCER|=OC_Config->OCPolarity<<8;

    if (IS_TIM_ADVANCED_INSTANCE(TIMx))
        {
        CCER&=~TIM_CCER_CC3NP;
        CCER|=OC_Config->OCNPolarity<<8;
        CCER&=~TIM_CCER_CC3NE;

        CR2&=~TIM_CR2_OIS3;
        CR2&=~TIM_CR2_OIS3N;
        CR2|=OC_Config->OCIdleState<<4;
        CR2|=OC_Config->OCNIdleState<<4;
        }
    TIMx->CR2=CR2;
    TIMx->CCMR2=CCMR1;
    TIMx->CCR3=OC_Config->Pulse;
    TIMx->CCER=CCER;
    }



VOID TIM_OC4_SetConfig(TIM_TypeDef*TIMx, TIM_OC_InitTypeDef*OC_Config)
    {
    UINT CCMR2, CCER, CR2;

    TIMx->CCER&=~TIM_CCER_CC4E;

    CCER=TIMx->CCER;
    CR2=TIMx->CR2;
    CCMR2=TIMx->CCMR2;

    CCMR2&=~TIM_CCMR2_OC4M;
    CCMR2&=~TIM_CCMR2_CC4S;

    CCMR2|=OC_Config->OCMode<<8;

    CCER&=~TIM_CCER_CC4P;
    CCER|=OC_Config->OCPolarity<<12;

    if (IS_TIM_ADVANCED_INSTANCE(TIMx))
        {
        CR2&=~TIM_CR2_OIS4;
        CR2|=OC_Config->OCIdleState<<6;
        }
    TIMx->CR2=CR2;
    TIMx->CCMR2=CCMR2;
    TIMx->CCR4=OC_Config->Pulse;
    TIMx->CCER=CCER;
    }



VOID WINAPI TIM_CCxChannelCmd(TIM_TypeDef*TIMx, UINT Channel, UINT ChannelState)
    {
    TIMx->CCER&=~(TIM_CCER_CC1E<<Channel);
    TIMx->CCER|=ChannelState<<Channel;
    }




VOID WINAPI TIM_PWM_Start(TIM_HandleTypeDef*hTmr, int Channel)
    {
    TIM_TypeDef *TIMx;

    TIMx=hTmr->Instance;
    TIM_CCxChannelCmd(TIMx, Channel, TIM_CCx_ENABLE);
    if (IS_TIM_ADVANCED_INSTANCE(TIMx)) TIMx->BDTR|=TIM_BDTR_MOE;       //__HAL_TIM_MOE_ENABLE(hTmr);
    TIMx->CR1|=TIM_CR1_CEN; //__HAL_TIM_ENABLE(hTmr);
    }



VOID WINAPI TIM_PWM_Stop(TIM_HandleTypeDef*hTmr, int Channel)
    {
    TIM_TypeDef *TIMx;

    TIMx=hTmr->Instance;
    TIM_CCxChannelCmd(TIMx, Channel, TIM_CCx_DISABLE);
    if (IS_TIM_ADVANCED_INSTANCE(TIMx)) TIMx->BDTR|=TIM_BDTR_MOE;       //__HAL_TIM_MOE_DISABLE(hTmr);

    //__HAL_TIM_DISABLE(hTmr);
    if ((TIMx->CCER & TIM_CCER_CCxE_MASK)==0 &&
        (TIMx->CCER & TIM_CCER_CCxNE_MASK)==0) TIMx->CR1&=~TIM_CR1_CEN;
    }




//-----------------------------------------------------------------------------
//      HAL_TIM_PWM_ConfigChannel
//-----------------------------------------------------------------------------
VOID WINAPI TIM_PWM_ConfigChannel(TIM_HandleTypeDef *hTmr, TIM_OC_InitTypeDef *OCI, int Channel)
    {
    TIM_TypeDef *TIMx;

    TIMx=hTmr->Instance;
    switch (Channel)
        {
        case TIM_CHANNEL_1:
            TIM_OC1_SetConfig(TIMx, OCI);
            TIMx->CCMR1|=TIM_CCMR1_OC1PE;
            TIMx->CCMR1&=~TIM_CCMR1_OC1FE;
            TIMx->CCMR1|=OCI->OCFastMode;
            break;

        case TIM_CHANNEL_2:
            TIM_OC2_SetConfig(TIMx, OCI);
            TIMx->CCMR1|=TIM_CCMR1_OC2PE;
            TIMx->CCMR1&=~TIM_CCMR1_OC2FE;
            TIMx->CCMR1|=OCI->OCFastMode<<8;
            break;

        case TIM_CHANNEL_3:
            TIM_OC3_SetConfig(TIMx, OCI);
            TIMx->CCMR2|=TIM_CCMR2_OC3PE;
            TIMx->CCMR2&=~TIM_CCMR2_OC3FE;
            TIMx->CCMR2|=OCI->OCFastMode;
            break;

        case TIM_CHANNEL_4:
            TIM_OC4_SetConfig(TIMx, OCI);
            TIMx->CCMR2|=TIM_CCMR2_OC4PE;
            TIMx->CCMR2&=~TIM_CCMR2_OC4FE;
            TIMx->CCMR2|=OCI->OCFastMode<<8;
            //break;
        }
    }



//-----------------------------------------------------------------------------
//hTmr->Instance ... TIM2~TIM14
//hTmr->Init.CounterMode
//      TIM_COUNTERMODE_UP
//      TIM_COUNTERMODE_DOWN
//      TIM_COUNTERMODE_CENTERALIGNED1
//      TIM_COUNTERMODE_CENTERALIGNED2
//      TIM_COUNTERMODE_CENTERALIGNED3
//hTmr->Init.ClockDivision
//      TIM_CLOCKDIVISION_DIV1
//      TIM_CLOCKDIVISION_DIV2
//      TIM_CLOCKDIVISION_DIV4
//-----------------------------------------------------------------------------
VOID WINAPI TIM_PWM_Init(TIM_HandleTypeDef *hTmr)
    {
    UINT CR1;
    TIM_TypeDef *TIMx;
    TIM_Base_InitTypeDef *Init;

    TIMx=hTmr->Instance;
    Init=&hTmr->Init;

    CR1=TIMx->CR1;
    if (IS_TIM_CC3_INSTANCE(TIMx))
        {
        CR1&=~(TIM_CR1_DIR|TIM_CR1_CMS);
        CR1|=Init->CounterMode;
        }

    if (IS_TIM_CC1_INSTANCE(TIMx))
        {
        CR1&=~TIM_CR1_CKD;
        CR1|=Init->ClockDivision;
        }

    MODIFY_REG(CR1, TIM_CR1_ARPE, Init->AutoReloadPreload);

    TIMx->CR1=CR1;
    TIMx->ARR=Init->Period;
    TIMx->PSC=Init->Prescaler;

    if (IS_TIM_ADVANCED_INSTANCE(TIMx)) TIMx->RCR=Init->RepetitionCounter;
    TIMx->EGR=TIM_EGR_UG;
    }




//-----------------------------------------------------------------------------
//          STMF7 ���� �Ϸ�
//-----------------------------------------------------------------------------
VOID WINAPI TIM_Base_SetConfig(TIM_TypeDef *TIMx, TIM_Base_InitTypeDef *TBI)
    {
    UINT CR1=0;
    CR1=TIMx->CR1;

    if (IS_TIM_CC3_INSTANCE(TIMx))
        {
        CR1&=~(TIM_CR1_DIR|TIM_CR1_CMS);
        CR1|=TBI->CounterMode;
        }

    if (IS_TIM_CC1_INSTANCE(TIMx))
        {
        CR1&=~TIM_CR1_CKD;
        CR1|=TBI->ClockDivision;
        }

    MODIFY_REG(CR1, TIM_CR1_ARPE, TBI->AutoReloadPreload);
    TIMx->CR1=CR1;
    TIMx->ARR=TBI->Period;
    TIMx->PSC=TBI->Prescaler;
    if (IS_TIM_ADVANCED_INSTANCE(TIMx)) TIMx->RCR=TBI->RepetitionCounter;
    TIMx->EGR=TIM_EGR_UG;
    }



VOID WINAPI TIM_Base_Start(TIM_TypeDef *TIMx)
    {
    UINT Smcr;

    Smcr=TIMx->SMCR & TIM_SMCR_SMS;
    if (Smcr!=TIM_SLAVEMODE_TRIGGER && Smcr!=TIM_SLAVEMODE_COMBINED_RESETTRIGGER)
        TIMx->CR1|=TIM_CR1_CEN;     //__HAL_TIM_ENABLE(htim);
    }



//-----------------------------------------------------------------------------
//      �־��� Ÿ�̸Ӹ� ��ī���� ���, ���ͷ�Ʈ�� ������
//-----------------------------------------------------------------------------
VOID WINAPI TIM_UpCounterSetup(TIM_TypeDef *TIMx, UINT Freq, UINT Divisor)
    {
    IRQn_Type Irq;
    TIM_HandleTypeDef THT;

    if (TIMx==TIM2)
        {
        __HAL_RCC_TIM2_CLK_ENABLE();
        Irq=TIM2_IRQn;
        }
    else if (TIMx==TIM6)
        {
        __HAL_RCC_TIM6_CLK_ENABLE();
        Irq=TIM6_DAC_IRQn;
        }
    else goto ProcExit;

    ZeroMem(&THT, sizeof(THT));
    THT.Instance=TIMx;
    THT.Init.AutoReloadPreload=TIM_AUTORELOAD_PRELOAD_ENABLE;
    THT.Init.ClockDivision=TIM_CLOCKDIVISION_DIV1;
    THT.Init.CounterMode=TIM_COUNTERMODE_UP;
    THT.Init.Prescaler=DIV_ROUNDUP(SystemCoreClock, Freq)-1;
    THT.Init.Period=Divisor;
    TIM_Base_SetConfig(TIMx, &THT.Init);

    HAL_NVIC_SetPriority(Irq, 3, 0);
    HAL_NVIC_EnableIRQ(Irq);

    //TIM_Base_Start_IT(TIMx);
    TIMx->DIER=TIM_IT_UPDATE;       //__HAL_TIM_ENABLE_IT()
    TIMx->CR1|=TIM_CR1_CEN;         //__HAL_TIM_ENABLE()

    ProcExit:;
    }
#endif //HAL_TIM_MODULE_ENABLED



#ifdef HAL_SPI_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//              SPI
///////////////////////////////////////////////////////////////////////////////


typedef struct _SPI_HANDLE
    {
    SPI_TypeDef *Instance;
    JOS_EVENT *RxQ;
    JOS_EVENT *TxQ;
    SPI_InitTypeDef Init;
    UINT ErrorCode;
    } SPI_HANDLE;


static SPI_HANDLE SpiHandle[SPI_QTY];


LOCAL(VOID) DisableSpiWhen1LineMode(SPI_HANDLE *hSpi, SPI_TypeDef *SPIx)
    {
    if (hSpi->Init.Mode==SPI_MODE_MASTER &&
        (hSpi->Init.Direction==SPI_DIRECTION_1LINE ||
         hSpi->Init.Direction==SPI_DIRECTION_2LINES_RXONLY))
        SPIx->CR1&=~SPI_CR1_SPE;   //__HAL_SPI_DISABLE(hspi);
    }




LOCAL(BOOL) SPI_EndRxTxTransaction(SPI_HANDLE *hSpi, SPI_TypeDef *SPIx, UINT Timeout, UINT StartTick)
    {
    BOOL Rslt=FALSE;

    while ((SPIx->SR & SPI_SR_FTLVL)!=SPI_FTLVL_EMPTY)
        {
        if (HAL_GetTick()-StartTick>=Timeout) goto ErExit;
        }

    while (SPIx->SR & SPI_SR_BSY)
        {
        if (HAL_GetTick()-StartTick>=Timeout) goto ErExit;
        }

    while ((SPIx->SR & SPI_SR_FRLVL)!=SPI_FRLVL_EMPTY)
        {
        *(__IO BYTE*)&SPIx->DR;

        if (HAL_GetTick()-StartTick>=Timeout)
            {
            ErExit:
            SPIx->CR2&=~(SPI_IT_TXE|SPI_IT_RXNE|SPI_IT_ERR);    //__HAL_SPI_DISABLE_IT()
            DisableSpiWhen1LineMode(hSpi, SPIx);
            goto ProcExit;
            }
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      8Bit SPI �ۼ��� (HAL_SPI_TransmitReceive() ���� 8��Ʈ ó���� ���)
//-----------------------------------------------------------------------------
BOOL WINAPI SPI_TransmitReceive8(int SPI_Ch, LPCBYTE TxData, int TxSize, LPBYTE RxData, int RxSize, int RecvSkip, UINT Timeout)
    {
    int Rslt=FALSE, TxAllowed=1, Data;
    DWORD StartTick;
    SPI_TypeDef *SPIx;
    SPI_HANDLE  *hSpi;

    hSpi=SpiHandle+SPI_Ch;
    SPIx=hSpi->Instance;
    StartTick=HAL_GetTick();

    SPIx->CR2|=SPI_RXFIFO_THRESHOLD;
    SPIx->CR1|=SPI_CR1_SPE;     //__HAL_SPI_ENABLE(hSpi);

    while (TxSize>0 || RxSize>0)
        {
        if (TxAllowed!=0 && (SPIx->SR & SPI_SR_TXE)!=0)
            {
            Data=0;     //�����͸� �����ϱ� ���� ����, �����ؾ� Ŭ���� �߻���
            if (TxSize>0) {Data=*TxData++; TxSize--;}
            *(__IO BYTE*)&SPIx->DR=Data;
            TxAllowed=0;
            }

        if (SPIx->SR & SPI_SR_RXNE)
            {
            Data=SPIx->DR;
            if (RecvSkip>0) RecvSkip--;
            else if (RxSize>0) {*RxData++=Data; RxSize--;}
            TxAllowed=1;
            }

        if (HAL_GetTick()-StartTick>=Timeout) goto ProcExit;
        }

    Rslt=SPI_EndRxTxTransaction(hSpi, SPIx, Timeout, StartTick);

    ProcExit:
    return Rslt;
    }



//���̸� HAL_SPI_Receive
BOOL WINAPI SPI_Receive8(int SPI_Ch, LPBYTE RxBuff, UINT Size, UINT Timeout)
    {
    int  Rslt=FALSE;
    UINT StartTick;
    SPI_TypeDef *SPIx;
    SPI_HANDLE  *hSpi;

    hSpi=SpiHandle+SPI_Ch;
    SPIx=hSpi->Instance;
    if (hSpi->Init.Mode==SPI_MODE_MASTER && hSpi->Init.Direction==SPI_DIRECTION_2LINES)
        {
        return SPI_TransmitReceive8(SPI_Ch, NULL, 0, RxBuff, Size, 0, Timeout);
        }

    StartTick=HAL_GetTick();
    SPIx->CR2|=SPI_RXFIFO_THRESHOLD;

    if (hSpi->Init.Direction==SPI_DIRECTION_1LINE) SPIx->CR1&=~SPI_CR1_BIDIOE;  //SPI_1LINE_RX(hSpi);
    SPIx->CR1|=SPI_CR1_SPE;                                                     //__HAL_SPI_ENABLE(hSpi);

    while (Size>0)
        {
        if (SPIx->SR & SPI_FLAG_RXNE)
            {
            *RxBuff++=*(__IO BYTE*)&SPIx->DR;
            Size--;
            }
        else if (HAL_GetTick()-StartTick>=Timeout) goto ProcExit;
        }

    //SPI_EndRxTransaction()
    DisableSpiWhen1LineMode(hSpi, SPIx);

    while (SPIx->SR & SPI_SR_BSY)
        {
        if (HAL_GetTick()-StartTick>=Timeout) goto ErExit;
        }

    if (hSpi->Init.Mode==SPI_MODE_MASTER &&
        (hSpi->Init.Direction==SPI_DIRECTION_1LINE ||
         hSpi->Init.Direction==SPI_DIRECTION_2LINES_RXONLY))
        {
        while ((SPIx->SR & SPI_SR_FRLVL)!=SPI_FRLVL_EMPTY)
            {
            *(__IO BYTE*)&SPIx->DR;

            if (HAL_GetTick()-StartTick>=Timeout)
                {
                ErExit:
                SPIx->CR2&=~(SPI_IT_TXE|SPI_IT_RXNE|SPI_IT_ERR);
                DisableSpiWhen1LineMode(hSpi, SPIx);
                goto ProcExit;
                }
            }
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }




//���̸�: HAL_SPI_Transmit
BOOL WINAPI SPI_Transmit8(int SPI_Ch, LPCBYTE TxBuff, UINT Size, UINT Timeout)
    {
    int  Rslt=FALSE;
    UINT StartTick;
    SPI_TypeDef *SPIx;
    SPI_HANDLE  *hSpi;

    hSpi=SpiHandle+SPI_Ch;
    SPIx=hSpi->Instance;
    StartTick=HAL_GetTick();

    if (hSpi->Init.Direction==SPI_DIRECTION_1LINE) SPIx->CR1|=SPI_CR1_BIDIOE;    //SPI_1LINE_TX(hSpi);
    SPIx->CR1|=SPI_CR1_SPE;         //__HAL_SPI_ENABLE(hSpi);

    while (Size>0)
        {
        if (SPIx->SR & SPI_FLAG_TXE)
            {
            *((__IO BYTE*)&SPIx->DR)=*TxBuff++;
            Size--;
            }
        else if (HAL_GetTick()-StartTick>=Timeout) goto ProcExit;
        }

    if (SPI_EndRxTxTransaction(hSpi, SPIx, Timeout, StartTick)==FALSE) goto ProcExit;

    if (hSpi->Init.Direction==SPI_DIRECTION_2LINES)
        {
        __IO UINT T; T=SPIx->DR; T=SPIx->SR; UNUSED(T); //__HAL_SPI_CLEAR_OVRFLAG
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      SPI �ʱ�ȭ
//-----------------------------------------------------------------------------
VOID WINAPI SPI_InitMaster(int SPI_Ch, int BaudPrescaler)
    {
    SPI_TypeDef *SPIx;
    SPI_HANDLE *hSpi;

    hSpi=SpiHandle+SPI_Ch;
    switch (SPI_Ch)
        {
        #ifdef PO_SPI1SCK
        case SPI_CH1:
            __HAL_RCC_SPI1_CLK_ENABLE();
            SPIx=SPI1;
            break;
        #endif

        #ifdef PO_SPI2SCK
        case SPI_CH2:
            __HAL_RCC_SPI2_CLK_ENABLE();
            SPIx=SPI2;
            break;
        #endif

        #ifdef PO_SPI3SCK
        case SPI_CH3:
            __HAL_RCC_SPI3_CLK_ENABLE();
            SPIx=SPI3;
            break;
        #endif

        #ifdef PO_SPI4SCK
        case SPI_CH4:
            __HAL_RCC_SPI4_CLK_ENABLE();
            SPIx=SPI4;
            break;
        #endif

        #ifdef PO_SPI5SCK
        case SPI_CH5:
            __HAL_RCC_SPI5_CLK_ENABLE();
            SPIx=SPI5;
            break;
        #endif

        #ifdef PO_SPI6SCK
        case SPI_CH6:
            __HAL_RCC_SPI6_CLK_ENABLE();
            SPIx=SPI6;
            break;
        #endif
        }

    hSpi->Instance=SPIx;
    hSpi->Init.BaudRatePrescaler=BaudPrescaler; //SPI_BAUDRATEPRESCALER_256;
    hSpi->Init.Direction=SPI_DIRECTION_2LINES;
    hSpi->Init.CLKPhase=SPI_PHASE_1EDGE;
    hSpi->Init.CLKPolarity=SPI_POLARITY_LOW;
    hSpi->Init.CRCCalculation=SPI_CRCCALCULATION_DISABLE;
    hSpi->Init.CRCPolynomial=7;
    hSpi->Init.DataSize=SPI_DATASIZE_8BIT;
    hSpi->Init.FirstBit=SPI_FIRSTBIT_MSB;
    hSpi->Init.NSS=SPI_NSS_SOFT;
    hSpi->Init.TIMode=SPI_TIMODE_DISABLE;
    hSpi->Init.NSSPMode=SPI_NSS_PULSE_DISABLE;
    hSpi->Init.CRCLength=SPI_CRC_LENGTH_8BIT;
    hSpi->Init.Mode=SPI_MODE_MASTER;

    SPIx->CR1&=~SPI_CR1_SPE;  //__HAL_SPI_DISABLE()

    SPIx->CR1=hSpi->Init.Mode|hSpi->Init.Direction|
        hSpi->Init.CLKPolarity|hSpi->Init.CLKPhase|(hSpi->Init.NSS&SPI_CR1_SSM)|
        hSpi->Init.BaudRatePrescaler|hSpi->Init.FirstBit|hSpi->Init.CRCCalculation;

    SPIx->CR2=(((hSpi->Init.NSS>>16)&SPI_CR2_SSOE)|hSpi->Init.TIMode|hSpi->Init.NSSPMode|hSpi->Init.DataSize)|SPI_RXFIFO_THRESHOLD_QF;

    #if defined(SPI_I2SCFGR_I2SMOD)
    SPIx->I2SCFGR&=~SPI_I2SCFGR_I2SMOD;
    #endif
    }


#endif //HAL_SPI_MODULE_ENABLED





#ifdef HAL_I2C_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//                              I2C
///////////////////////////////////////////////////////////////////////////////


#define I2C_TIMEOUT_BUSY    25
#define MAX_NBYTE_SIZE      255
#define TIMING_CLEAR_MASK   0xF0FFFFFF

#define I2C_RESET_CR2_(I2CA)    (I2CA)->CR2&=~(I2C_CR2_SADD|I2C_CR2_HEAD10R|I2C_CR2_NBYTES|I2C_CR2_RELOAD|I2C_CR2_RD_WRN)



static I2C_HandleTypeDef    I2C_Handle[IIC_QTY];


//���̸�: I2C_WaitOnFlagUntilTimeout
LOCAL(HAL_StatusTypeDef) I2C_WaitOnFlag(I2C_TypeDef *I2CA, UINT Flag, BOOL Status, UINT Timeout, UINT StartTick)
    {
    UINT T;

    for (;;)
        {
        T=I2CA->ISR & Flag;
        if (Status) {if (T==0) break;}
        else        {if (T!=0) break;}

        if (HAL_GetTick()-StartTick>Timeout) return HAL_TIMEOUT;
        }
    return HAL_OK;
    }



LOCAL(VOID) I2C_TransferConfig(I2C_TypeDef *I2CA, UINT DevAddr, UINT Size, UINT Mode, UINT Request)
    {
    MODIFY_REG(I2CA->CR2,
        I2C_CR2_SADD|I2C_CR2_NBYTES|I2C_CR2_RELOAD|I2C_CR2_AUTOEND|(I2C_CR2_RD_WRN&(Request>>(31-I2C_CR2_RD_WRN_Pos)))|I2C_CR2_START|I2C_CR2_STOP,
        (DevAddr&I2C_CR2_SADD) | ((Size<<I2C_CR2_NBYTES_Pos)&I2C_CR2_NBYTES) | Mode | Request);
    }



LOCAL(UINT) I2C_TransferConfigEx(I2C_TypeDef *I2CA, UINT DevAddr, UINT Size, UINT Request)
    {
    UINT Mode;

    Mode=I2C_AUTOEND_MODE;
    if (Size>MAX_NBYTE_SIZE) {Mode=I2C_RELOAD_MODE; Size=MAX_NBYTE_SIZE;}
    I2C_TransferConfig(I2CA, DevAddr, Size, Mode, Request);
    return Size;
    }




LOCAL(VOID) I2C_Flush_TXDR(I2C_TypeDef *I2CA)
    {
    if ((I2CA->ISR & I2C_FLAG_TXIS)!=0) I2CA->TXDR=0;
    I2CA->ISR|=I2C_FLAG_TXE;
    }



//-----------------------------------------------------------------------------
//      HAL_TIMEOUT ���� �����ϴ� ��� I2C�� ��� BUSY�� �Ǵ� ���׸� ������ (2020-11-16)
//      ���̸�: I2C_IsAcknowledgeFailed
//-----------------------------------------------------------------------------
LOCAL(HAL_StatusTypeDef) I2C_IsAckFailed(I2C_TypeDef *I2CA, UINT Timeout, UINT StartTick)
    {
    HAL_StatusTypeDef Rslt=HAL_OK;

    if (I2CA->ISR & I2C_FLAG_AF)
        {
        Rslt=HAL_ERROR;
        while ((I2CA->ISR & I2C_FLAG_STOPF)==0)
            {
            if (HAL_GetTick()-StartTick>Timeout) {Rslt=HAL_TIMEOUT; break;}
            }
        I2CA->ICR=I2C_FLAG_AF;
        I2CA->ICR=I2C_FLAG_STOPF;

        I2C_Flush_TXDR(I2CA);
        I2C_RESET_CR2_(I2CA);
        }
    return Rslt;
    }




//Tx���ͷ�Ʈ�� ���ִ��� üũ, ���̸�:I2C_WaitOnTXISFlagUntilTimeout
LOCAL(HAL_StatusTypeDef) I2C_WaitOnTXIS(I2C_TypeDef *I2CA, UINT Timeout, UINT StartTick)
    {
    HAL_StatusTypeDef Rslt=HAL_OK;

    while ((I2CA->ISR & I2C_FLAG_TXIS)==0)
        {
        if ((Rslt=I2C_IsAckFailed(I2CA, Timeout, StartTick))!=HAL_OK) break;
        if (HAL_GetTick()-StartTick>Timeout) {Rslt=HAL_TIMEOUT; break;}
        }
    return Rslt;
    }


//���̸� I2C_WaitOnSTOPFlagUntilTimeout()
LOCAL(HAL_StatusTypeDef) I2C_WaitOnStop(I2C_TypeDef *I2CA, UINT Timeout, UINT StartTick)
    {
    HAL_StatusTypeDef Rslt=HAL_OK;

    while ((I2CA->ISR & I2C_FLAG_STOPF)==0)
        {
        if ((Rslt=I2C_IsAckFailed(I2CA, Timeout, StartTick))!=HAL_OK) break;
        if (HAL_GetTick()-StartTick>Timeout) {Rslt=HAL_TIMEOUT; break;}
        }
    return Rslt;
    }



LOCAL(HAL_StatusTypeDef) I2C_RequestMemoryRead(I2C_TypeDef *I2CA, UINT DevAddr, UINT MemAddress, UINT MemAddSize, UINT Timeout, UINT StartTick)
    {
    HAL_StatusTypeDef Rslt;

    I2C_TransferConfig(I2CA, DevAddr, MemAddSize, I2C_SOFTEND_MODE, I2C_GENERATE_START_WRITE);
    if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;

    if (MemAddSize!=I2C_MEMADD_SIZE_8BIT)
        {
        I2CA->TXDR=I2C_MEM_ADD_MSB(MemAddress);
        if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;
        }
    I2CA->TXDR=I2C_MEM_ADD_LSB(MemAddress);
    Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TC, 0, Timeout, StartTick);

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���̸�: HAL_I2C_Mem_Read
//-----------------------------------------------------------------------------
HAL_StatusTypeDef WINAPI I2C_MemRead(int I2C_No, UINT DevAddr, UINT MemAddress, UINT MemAddSize, LPBYTE Buffer, UINT ReadSize, UINT Timeout)
    {
    UINT StartTick, BlkSize;
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    I2C_TypeDef *I2CA;

    if (ReadSize==0) goto ProcExit;

    I2CA=I2C_Handle[I2C_No].Instance;
    StartTick=HAL_GetTick();

    if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_BUSY, 1, I2C_TIMEOUT_BUSY, StartTick))!=HAL_OK) goto ProcExit;
    if ((Rslt=I2C_RequestMemoryRead(I2CA, DevAddr, MemAddress, MemAddSize, Timeout, StartTick))!=HAL_OK) goto ProcExit;

    BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, ReadSize, I2C_GENERATE_START_READ);
    ReadSize-=BlkSize;
    for (;;)
        {
        if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_RXNE, 0, Timeout, StartTick))!=HAL_OK) goto ProcExit;

        *Buffer++=I2CA->RXDR;

        if (--BlkSize==0)
            {
            if (ReadSize==0) break;
            if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TCR, 0, Timeout, StartTick))!=HAL_OK) goto ProcExit;
            BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, ReadSize, I2C_NO_STARTSTOP);
            ReadSize-=BlkSize;
            }
        }

    Rslt=I2C_WaitOnStop(I2CA, Timeout, StartTick);
    I2CA->ICR=I2C_FLAG_STOPF;
    I2C_RESET_CR2_(I2CA);

    ProcExit:
    return Rslt;
    }




LOCAL(HAL_StatusTypeDef) I2C_RequestMemoryWrite(I2C_TypeDef *I2CA, UINT DevAddr, UINT MemAddress, UINT MemAddSize, UINT Timeout, UINT StartTick)
    {
    HAL_StatusTypeDef Rslt;

    I2C_TransferConfig(I2CA, DevAddr, MemAddSize, I2C_RELOAD_MODE, I2C_GENERATE_START_WRITE);

    if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;

    if (MemAddSize!=I2C_MEMADD_SIZE_8BIT)
        {
        I2CA->TXDR=I2C_MEM_ADD_MSB(MemAddress);
        if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;
        }
    I2CA->TXDR=I2C_MEM_ADD_LSB(MemAddress);

    Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TCR, 0, Timeout, StartTick);

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ���̸�: HAL_I2C_Mem_Write
//-----------------------------------------------------------------------------
HAL_StatusTypeDef WINAPI I2C_MemWrite(int I2C_No, UINT DevAddr, UINT MemAddress, UINT MemAddSize, LPCBYTE Buffer, UINT WriteSize, UINT Timeout)
    {
    UINT StartTick, BlkSize;
    HAL_StatusTypeDef Rslt=HAL_ERROR;
    I2C_TypeDef *I2CA;

    if (WriteSize==0) goto ProcExit;

    I2CA=I2C_Handle[I2C_No].Instance;
    StartTick=HAL_GetTick();

    if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_BUSY, 1, I2C_TIMEOUT_BUSY, StartTick))!=HAL_OK) goto ProcExit;
    if ((Rslt=I2C_RequestMemoryWrite(I2CA, DevAddr, MemAddress, MemAddSize, Timeout, StartTick))!=HAL_OK) goto ProcExit;

    BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, WriteSize, I2C_NO_STARTSTOP);
    WriteSize-=BlkSize;
    for (;;)
        {
        if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;

        I2CA->TXDR=*Buffer++;

        if (--BlkSize==0)
            {
            if (WriteSize==0) break;
            if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TCR, 0, Timeout, StartTick))!=HAL_OK) goto ProcExit;
            BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, WriteSize, I2C_NO_STARTSTOP);
            WriteSize-=BlkSize;
            }
        }

    Rslt=I2C_WaitOnStop(I2CA, Timeout, StartTick);
    I2CA->ICR=I2C_FLAG_STOPF;
    I2C_RESET_CR2_(I2CA);

    ProcExit:
    return Rslt;
    }



//���̸�: I2C_WaitOnRXNEFlagUntilTimeout
LOCAL(HAL_StatusTypeDef) I2C_WaitOnRXNE(I2C_TypeDef *I2CA, UINT Timeout, UINT Tickstart, UINT RxSize)
    {
    while ((I2CA->ISR & I2C_FLAG_RXNE)==0)
        {
        if (I2C_IsAckFailed(I2CA, Timeout, Tickstart)!=HAL_OK) return HAL_ERROR;

        if (I2CA->ISR & I2C_FLAG_STOPF)
            {
            if ((I2CA->ISR & I2C_FLAG_RXNE)!=0 && RxSize>0) return HAL_OK;
            I2CA->ICR=I2C_FLAG_STOPF;
            I2C_RESET_CR2_(I2CA);
            return HAL_ERROR;
            }

        if (HAL_GetTick()-Tickstart>Timeout || Timeout==0) return HAL_ERROR;
        }
    return HAL_OK;
    }



//���̸�: HAL_I2C_Master_Receive
HAL_StatusTypeDef WINAPI I2C_MasterRx(int I2C_No, UINT DevAddr, LPBYTE Buffer, UINT ReadSize, UINT Timeout)
    {
    UINT StartTick, BlkSize;
    HAL_StatusTypeDef Rslt;
    I2C_TypeDef *I2CA;

    I2CA=I2C_Handle[I2C_No].Instance;
    StartTick=HAL_GetTick();
    if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_BUSY, 1, I2C_TIMEOUT_BUSY, StartTick))!=HAL_OK) goto ProcExit;

    BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, ReadSize, I2C_GENERATE_START_READ);
    ReadSize-=BlkSize;
    for (;;)
        {
        if ((Rslt=I2C_WaitOnRXNE(I2CA, Timeout, StartTick, BlkSize))!=HAL_OK) goto ProcExit;

        *Buffer++=I2CA->RXDR;

        if (--BlkSize==0)
            {
            if (ReadSize==0) break;
            if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TCR, 0, Timeout, StartTick))!=HAL_OK) goto ProcExit;
            BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, ReadSize, I2C_NO_STARTSTOP);
            ReadSize-=BlkSize;
            }
        }

    Rslt=I2C_WaitOnStop(I2CA, Timeout, StartTick);
    I2CA->ICR=I2C_FLAG_STOPF;
    I2C_RESET_CR2_(I2CA);

    ProcExit:
    return Rslt;
    }



//���̸�: HAL_I2C_Master_Transmit
HAL_StatusTypeDef WINAPI I2C_MasterTx(int I2C_No, UINT DevAddr, LPCBYTE Buffer, UINT WriteSize, UINT Timeout)
    {
    UINT StartTick, BlkSize;
    HAL_StatusTypeDef Rslt;
    I2C_TypeDef *I2CA;

    I2CA=I2C_Handle[I2C_No].Instance;
    StartTick=HAL_GetTick();
    if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_BUSY, 1, I2C_TIMEOUT_BUSY, StartTick))!=HAL_OK) goto ProcExit;

    BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, WriteSize, I2C_GENERATE_START_WRITE);
    WriteSize-=BlkSize;
    for (;;)
        {
        if ((Rslt=I2C_WaitOnTXIS(I2CA, Timeout, StartTick))!=HAL_OK) goto ProcExit;

        I2CA->TXDR=*Buffer++;

        if (--BlkSize==0)
            {
            if (WriteSize==0) break;
            if ((Rslt=I2C_WaitOnFlag(I2CA, I2C_FLAG_TCR, 0, Timeout, StartTick))!=HAL_OK) goto ProcExit;
            BlkSize=I2C_TransferConfigEx(I2CA, DevAddr, WriteSize, I2C_NO_STARTSTOP);
            WriteSize-=BlkSize;
            }
        }

    Rslt=I2C_WaitOnStop(I2CA, Timeout, StartTick);
    I2CA->ICR=I2C_FLAG_STOPF;
    I2C_RESET_CR2_(I2CA);

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���̸�:HAL_I2C_Init
//-----------------------------------------------------------------------------
VOID WINAPI I2C_Init(int I2C_No, UINT Timing)
    {
    IRQn_Type    ErIrq, EvIrq;
    I2C_TypeDef *I2CA=NULL;
    I2C_HandleTypeDef *hI2C;

    hI2C=I2C_Handle+I2C_No;
    switch (I2C_No)
        {
        #ifdef PO_I2C1SCL
        case IIC1:
            I2CA=I2C1;
            EvIrq=I2C1_EV_IRQn;
            ErIrq=I2C1_ER_IRQn;
            __HAL_RCC_I2C1_CLK_ENABLE();
            __HAL_RCC_I2C1_FORCE_RESET();
            __HAL_RCC_I2C1_RELEASE_RESET();
            break;
        #endif

        #ifdef PO_I2C2SCL
        case IIC2:
            I2CA=I2C2;
            EvIrq=I2C2_EV_IRQn;
            ErIrq=I2C2_ER_IRQn;
            __HAL_RCC_I2C2_CLK_ENABLE();
            __HAL_RCC_I2C2_FORCE_RESET();
            __HAL_RCC_I2C2_RELEASE_RESET();
            break;
        #endif

        #ifdef PO_I2C3SCL
        case IIC3:
            I2CA=I2C3;
            EvIrq=I2C3_EV_IRQn;
            ErIrq=I2C3_ER_IRQn;
            __HAL_RCC_I2C3_CLK_ENABLE();
            __HAL_RCC_I2C3_FORCE_RESET();
            __HAL_RCC_I2C3_RELEASE_RESET();
            break;
        #endif

        #ifdef PO_I2C4SCL
        case IIC4:
            I2CA=I2C4;
            EvIrq=I2C4_EV_IRQn;
            ErIrq=I2C4_ER_IRQn;
            __HAL_RCC_I2C4_CLK_ENABLE();
            __HAL_RCC_I2C4_FORCE_RESET();
            __HAL_RCC_I2C4_RELEASE_RESET();
            //break;
        #endif
        }

    hI2C->Instance=I2CA;
    hI2C->Init.Timing=Timing;
    hI2C->Init.OwnAddress1=0;
    hI2C->Init.AddressingMode=I2C_ADDRESSINGMODE_7BIT;
    hI2C->Init.DualAddressMode=I2C_DUALADDRESS_DISABLE;
    hI2C->Init.OwnAddress2=0;
    hI2C->Init.GeneralCallMode=I2C_GENERALCALL_DISABLE;
    hI2C->Init.NoStretchMode=I2C_NOSTRETCH_DISABLE;


    I2CA->CR1&=~I2C_CR1_PE;   //__HAL_I2C_DISABLE(hI2C)
    I2CA->TIMINGR=hI2C->Init.Timing & TIMING_CLEAR_MASK;

    I2CA->OAR1=I2C_OAR1_OA1EN|hI2C->Init.OwnAddress1;
    if (hI2C->Init.AddressingMode!=I2C_ADDRESSINGMODE_7BIT)  I2CA->OAR1|=I2C_OAR1_OA1MODE;
    if (hI2C->Init.AddressingMode==I2C_ADDRESSINGMODE_10BIT) I2CA->CR2=I2C_CR2_ADD10;

    I2CA->CR2|=I2C_CR2_AUTOEND|I2C_CR2_NACK;
    I2CA->OAR2&=~I2C_DUALADDRESS_ENABLE;
    I2CA->OAR2=hI2C->Init.DualAddressMode|hI2C->Init.OwnAddress2|(hI2C->Init.OwnAddress2Masks<<8);
    I2CA->CR1=hI2C->Init.GeneralCallMode|hI2C->Init.NoStretchMode;

    HAL_NVIC_SetPriority(EvIrq, 0x0F, 0);
    HAL_NVIC_EnableIRQ(EvIrq);

    HAL_NVIC_SetPriority(ErIrq, 0x0F, 0);
    HAL_NVIC_EnableIRQ(ErIrq);

    I2CA->CR1|=I2C_CR1_PE;    //__HAL_I2C_ENABLE(hI2C)
    }
#endif //HAL_I2C_MODULE_ENABLED




#ifdef HAL_RTC_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//              RTC
///////////////////////////////////////////////////////////////////////////////


//#define RTC_CLOCK_SOURCE_LSI  //����RC����
#define RTC_CLOCK_SOURCE_LSE    //�ܺ�32768


#ifdef RTC_CLOCK_SOURCE_LSI
#define RTC_ASYNCH_PREDIV       0x7F
#define RTC_SYNCH_PREDIV        0x0130
#endif

#ifdef RTC_CLOCK_SOURCE_LSE
#define RTC_ASYNCH_PREDIV       0x7F    //0~0x7F
#define RTC_SYNCH_PREDIV        0x00FF  //0~0x7FFF
#endif



#define RTC_WRITEPROTECTION_DISABLE(Inst) (Inst)->WPR=0xCA; (Inst)->WPR=0x53
#define RTC_WRITEPROTECTION_ENABLE(Inst)  (Inst)->WPR=0xFF

static RTC_HandleTypeDef RtcHandle;
static SYSTEMTIME TempST;



LOCAL(BOOL) RTC__EnterInitMode(RTC_TypeDef *RTCB)
    {
    DWORD Time;

    if ((RTCB->ISR & RTC_ISR_INITF)==0)
        {
        RTCB->ISR=RTC_INIT_MASK;

        Time=HAL_GetTick();
        while ((RTCB->ISR & RTC_ISR_INITF)==0)
            {
            if (HAL_GetTick()-Time > RTC_TIMEOUT_VALUE) return FALSE;
            }
        }
    return TRUE;
    }




LOCAL(BOOL) RTC_WaitForSynchro(RTC_TypeDef *RTCB)   //HAL_RTC_WaitForSynchro
    {
    DWORD Time;

    RTCB->ISR&=RTC_RSF_MASK;

    Time=HAL_GetTick();
    while ((RTCB->ISR & RTC_ISR_RSF)==0)
        {
        if (HAL_GetTick()-Time>RTC_TIMEOUT_VALUE) return FALSE;
        }
    return TRUE;
    }




//-----------------------------------------------------------------------------
//      RTC�� �ð��� ������ HAL_RTC_SetTime() + HAL_RTC_SetDate()
//-----------------------------------------------------------------------------
BOOL WINAPI SetLocalTime(CONST SYSTEMTIME *ST)
    {
    int Rslt=FALSE, Week;
    RTC_TypeDef *RTCB;

    if ((RTCB=RtcHandle.Instance)!=NULL)
        {
        //if ((RTCB->Instance->CR&RTC_CR_FMT)==0) ST->TimeFormat=0;
        RTC_WRITEPROTECTION_DISABLE(RTCB);

        if (RTC__EnterInitMode(RTCB)==FALSE) goto ProcExit;

        RTCB->TR=((Bin2Bcd(ST->wHour)<<16)|
                  (Bin2Bcd(ST->wMinute)<<8)|
                   Bin2Bcd(ST->wSecond)) & RTC_TR_RESERVED_MASK;    //| ((ST->TimeFormat)<<16);

        if ((Week=GetWeek(ST->wYear, ST->wMonth, ST->wDay))==0) Week=7; //����
        RTCB->DR=((Bin2Bcd(ST->wYear-2000)<<16) |
                  (Bin2Bcd(ST->wMonth)<<8) |
                   Bin2Bcd(ST->wDay) |
                  (Week<<13)) & RTC_DR_RESERVED_MASK;


        RTCB->CR&=~RTC_CR_BKP;
        //RTCB->CR|=STime->DayLightSaving|STime->StoreOperation;
        RTCB->ISR&=~RTC_ISR_INIT;
        if ((RTCB->CR & RTC_CR_BYPSHAD)==0)
            {
            if (RTC_WaitForSynchro(RTCB)==FALSE) goto ProcExit;
            }

        Rslt=TRUE;
        }
    else TempST=*ST;

    ProcExit:
    if (RTCB) RTC_WRITEPROTECTION_ENABLE(RTCB);
    return Rslt;
    }


BOOL WINAPI SetSystemTime(CONST SYSTEMTIME *ST)
    {
    SYSTEMTIME LocalST;

    UnpackTotalSecond(&LocalST, PackTotalSecond(ST)+9*3600);
    return SetLocalTime(&LocalST);
    }




//-----------------------------------------------------------------------------
//      RTC�� �ð��� ����
//-----------------------------------------------------------------------------
VOID WINAPI GetLocalTime(SYSTEMTIME *ST)
    {
    UINT DR, TR;
    RTC_TypeDef *RTCB;

    if ((RTCB=RtcHandle.Instance)!=NULL)
        {
        //Time->SubSeconds=(UINT)(RTCB->SSR);
        TR=RTCB->TR & RTC_TR_RESERVED_MASK;
        ST->wHour=Bcd2Bin((TR&(RTC_TR_HT|RTC_TR_HU))>>16);
        ST->wMinute=Bcd2Bin((TR&(RTC_TR_MNT|RTC_TR_MNU))>>8);
        ST->wSecond=Bcd2Bin(TR&(RTC_TR_ST|RTC_TR_SU));
        //ST->TimeFormat=(BYTE)((TR&(RTC_TR_PM))>>16);

        DR=RTCB->DR & RTC_DR_RESERVED_MASK;
        ST->wYear=Bcd2Bin((DR&(RTC_DR_YT|RTC_DR_YU))>>16)+2000;
        ST->wMonth=Bcd2Bin((DR&(RTC_DR_MT|RTC_DR_MU))>>8);
        ST->wDay=Bcd2Bin(DR&(RTC_DR_DT|RTC_DR_DU));
        //ST->WeekDay=((DR&(RTC_DR_WDU))>>13);
        }
    else *ST=TempST;
    }


JTIME WINAPI GetTodayToSecond(VOID)
    {
    SYSTEMTIME ST;
    GetLocalTime(&ST);
    return PackTotalSecond(&ST);
    }



VOID WINAPI InitRTC(VOID)
    {
    RTC_TypeDef *RTCB;
    RCC_OscInitTypeDef       RCC_OI;
    RCC_PeriphCLKInitTypeDef RCC_PCI;

    ZeroMem(&RCC_OI, sizeof(RCC_OI));
    ZeroMem(&RCC_PCI, sizeof(RCC_PCI));

    __HAL_RCC_PWR_CLK_ENABLE();

    #ifdef STM32L051xx
    __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_HIGH); //L�ø���� ��� �ش�
    #endif

    PWR->CR1|=PWR_CR1_DBP;      //HAL_PWR_EnableBkUpAccess();   //Enable access to RTC and backup registers

    RCC_OI.PLL.PLLState=RCC_PLL_NONE;
    #ifdef RTC_CLOCK_SOURCE_LSE
    RCC_OI.OscillatorType=RCC_OSCILLATORTYPE_LSE;
    RCC_OI.LSEState=RCC_LSE_ON;
    #endif
    #ifdef RTC_CLOCK_SOURCE_LSI
    RCC_OI.OscillatorType=RCC_OSCILLATORTYPE_LSI;
    RCC_OI.LSIState=RCC_LSI_ON;
    #endif
    if (HAL_RCC_OscConfig(&RCC_OI)!=HAL_OK) Printf("RTC: OSC Config Error\r\n");

    RCC_PCI.PeriphClockSelection=RCC_PERIPHCLK_RTC;
    #ifdef RTC_CLOCK_SOURCE_LSE
    RCC_PCI.RTCClockSelection=RCC_RTCCLKSOURCE_LSE;
    #endif
    #ifdef RTC_CLOCK_SOURCE_LSI
    RCC_PCI.RTCClockSelection=RCC_RTCCLKSOURCE_LSI;
    #endif
    if (HAL_RCCEx_PeriphCLKConfig(&RCC_PCI)!=HAL_OK) Printf("RTC: Select Clock Error\r\n");

    __HAL_RCC_RTC_ENABLE();

    RtcHandle.Init.HourFormat=RTC_HOURFORMAT_24;
    RtcHandle.Init.AsynchPrediv=RTC_ASYNCH_PREDIV;
    RtcHandle.Init.SynchPrediv=RTC_SYNCH_PREDIV;
    RtcHandle.Init.OutPut=RTC_OUTPUT_DISABLE;                   //RTC_OUTPUT_ALARMA, RTC_OUTPUT_WAKEUP
    RtcHandle.Init.OutPutPolarity=RTC_OUTPUT_POLARITY_HIGH;     //RTC_OUTPUT_POLARITY_LOW
    RtcHandle.Init.OutPutType=RTC_OUTPUT_TYPE_OPENDRAIN;        //RTC_OUTPUT_TYPE_PUSHPULL
    RtcHandle.Instance=RTCB=RTC;

    RTC_WRITEPROTECTION_DISABLE(RTCB);
    if (RTC__EnterInitMode(RTCB)!=FALSE)
        {
        RTCB->CR&=~(RTC_CR_FMT|RTC_CR_OSEL|RTC_CR_POL);
        RTCB->CR|=RtcHandle.Init.HourFormat|RtcHandle.Init.OutPut|RtcHandle.Init.OutPutPolarity;
        RTCB->PRER=RtcHandle.Init.SynchPrediv;
        RTCB->PRER|=RtcHandle.Init.AsynchPrediv<<16;
        RTCB->ISR&=~RTC_ISR_INIT;
        RTCB->OR&=~RTC_OR_ALARMTYPE;
        RTCB->OR|=RtcHandle.Init.OutPutType;
        }
    RTC_WRITEPROTECTION_ENABLE(RTCB);
    }


#endif //HAL_RTC_MODULE_ENABLED


#ifdef HAL_IWDG_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//                      WatchDog
///////////////////////////////////////////////////////////////////////////////


#define HAL_IWDG_DEFAULT_TIMEOUT    48


VOID WINAPI IWDG_Refresh(VOID)
    {
    IWDG->KR=IWDG_KEY_RELOAD;   //__HAL_IWDG_RELOAD_COUNTER(hiwdg);
    }


BOOL WINAPI IWDG_Init(int Prescaler, int Reload, int Window)
    {
    BOOL Rslt=FALSE;
    DWORD Tick;
    IWDG_TypeDef *IWdg;

    IWdg=IWDG;
    IWdg->KR=IWDG_KEY_ENABLE;               //__HAL_IWDG_START();
    IWdg->KR=IWDG_KEY_WRITE_ACCESS_ENABLE;  //IWDG_ENABLE_WRITE_ACCESS();
    IWdg->PR=Prescaler;
    IWdg->RLR=Reload;

    Tick=HAL_GetTick();
    while (IWdg->SR!=0)
        {
        if (HAL_GetTick()-Tick>HAL_IWDG_DEFAULT_TIMEOUT) goto ProcExit;
        }

    if (IWdg->WINR!=Window) IWdg->WINR=Window;
    else IWDG_Refresh();    //__HAL_IWDG_RELOAD_COUNTER();
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//          32��Ʈ ���� ��ġ�� ��
//-----------------------------------------------------------------------------
VOID WINAPI TM_RNG_Init(VOID)
    {
    __HAL_RCC_RNG_CLK_ENABLE();
    RNG->CR |= RNG_CR_RNGEN;    //__HAL_RNG_ENABLE()
    }


UINT WINAPI TM_RNG_Get(VOID)
    {
    while ((RNG->SR & RNG_SR_DRDY)==0); //Wait until one RNG number is ready
    return RNG->DR; //Get a 32-bit Random number
    }




VOID WINAPI SystemReset(LPCSTR BootReason)
    {
    Printf(BootReason);
    Printf("SENSOR: Shutdown...\r\n");
    UART_WaitAllSendIT(DebugPort);          //���ڿ� ���� �ð�

    IWDG_Init(IWDG_PRESCALER_32, 10, 0);
    for (;;);
    //NVIC_SystemReset();
    }
#endif //HAL_IWDG_MODULE_ENABLED




#ifdef HAL_I2S_MODULE_ENABLED
///////////////////////////////////////////////////////////////////////////////
//              I2S
///////////////////////////////////////////////////////////////////////////////


typedef struct
    {
    SPI_TypeDef *Instance;
    JOS_EVENT *Q;
    I2S_InitTypeDef Init;
    HAL_I2S_StateTypeDef State;
    UINT ErrorCode;
    } I2S_HANDLE;


static I2S_HANDLE I2S_Handle[I2S_QTY];



LOCAL(VOID) I2S_IRQHandler(I2S_HANDLE *hI2s)
    {
    UINT SR;
    SPI_TypeDef *I2SA;

    JOSIntEnter();
    I2SA=hI2s->Instance;
    SR=I2SA->SR;

    if (SR & I2S_FLAG_RXNE)
        {
        if (JOSQPost(hI2s->Q, (WORD)I2SA->DR, 0)!=JOS_ERR_NONE)
            {
            I2SA->CR2&=~(I2S_IT_RXNE|I2S_IT_ERR);
            hI2s->ErrorCode|=HAL_I2S_ERROR_OVR;
            //HAL_I2S_RxCpltCallback(hI2s);
            }
        goto ProcExit;
        }

    if (SR & I2S_FLAG_TXE)
        {
        UINT Data;
        JOS_RESULT QRslt;

        Data=JOSQPend(hI2s->Q, 0, &QRslt);
        if (QRslt==JOS_ERR_NONE) I2SA->DR=Data;
        else{
            I2SA->CR2&=~(I2S_IT_TXE|I2S_IT_ERR);
            //HAL_I2S_TxCpltCallback(hI2s);
            }
        goto ProcExit;
        }

    if (SR & I2S_FLAG_OVR)
        {
        I2SA->CR2&=~(I2S_IT_RXNE|I2S_IT_ERR);
        hI2s->ErrorCode|=HAL_I2S_ERROR_OVR;
        //HAL_I2S_ErrorCallback(hI2s);
        }

    if (SR & I2S_FLAG_UDR)
        {
        I2SA->CR2&=~(I2S_IT_TXE|I2S_IT_ERR);
        hI2s->ErrorCode|=HAL_I2S_ERROR_UDR;
        //HAL_I2S_ErrorCallback(hI2s);
        }

    ProcExit:
    JOSIntExit();
    }




VOID SPI2_IRQHandler(VOID)
    {
    I2S_IRQHandler(I2S_Handle+I2S2);
    }




int WINAPI I2S_TransmitIT(int I2SNo, CONST WORD *lpData, UINT DataSize)
    {
    UINT WrtedSize=0;
    I2S_HANDLE  *hI2s;
    SPI_TypeDef *I2SA;

    hI2s=I2S_Handle+I2SNo;
    I2SA=hI2s->Instance;

    while (DataSize--)
        {
        JOSQPost(hI2s->Q, *lpData++, 0);
        WrtedSize++;
        }

    I2SA->CR2|=I2S_IT_TXE|I2S_IT_ERR;
    //I2SA->I2SCFGR|=SPI_I2SCFGR_I2SE;
    return WrtedSize;
    }




int WINAPI I2S_ReceiveIT(int I2SNo, WORD *lpData, UINT DataBuffSize)
    {
    UINT Data, ReadedSize=0;
    JOS_RESULT  QRslt;
    I2S_HANDLE  *hI2s;
    SPI_TypeDef *I2SA;

    hI2s=I2S_Handle+I2SNo;
    I2SA=hI2s->Instance;

    I2SA->CR2|=I2S_IT_RXNE|I2S_IT_ERR;
    //I2SA->I2SCFGR|=SPI_I2SCFGR_I2SE;

    while (DataBuffSize--)
        {
        Data=JOSQPend(hI2s->Q, 0, &QRslt);
        if (QRslt!=JOS_ERR_NONE) break;
        *lpData++=Data;
        ReadedSize++;
        }
    return ReadedSize;
    }





LOCAL(UINT) I2S_GetClockFreq(I2S_HANDLE *hI2s)
    {
    UINT T, VcoInput, I2sClkSrc=0;

    switch (hI2s->Init.ClockSource)
        {
        case I2S_CLOCK_PLL:
            if ((RCC->PLLCFGR&RCC_PLLCFGR_PLLSRC)==RCC_PLLSOURCE_HSI)
                T=HSI_VALUE;
            else
                T=HSE_VALUE;

            VcoInput=T/(RCC->PLLCFGR&RCC_PLLCFGR_PLLM);
            T=(RCC->PLLI2SCFGR&RCC_PLLI2SCFGR_PLLI2SR)>>28;
            I2sClkSrc=VcoInput*((RCC->PLLI2SCFGR&RCC_PLLI2SCFGR_PLLI2SN)>>6)/T;
            break;

        case I2S_CLOCK_EXTERNAL:
            I2sClkSrc=EXTERNAL_CLOCK_VALUE;
            //break;
        }

    return I2sClkSrc;
    }




//-----------------------------------------------------------------------------
//      I2S �ʱ�ȭ (I2S_DATAFORMAT_16B�� ����)
//-----------------------------------------------------------------------------
BOOL WINAPI I2S_Init(int I2S_No, I2S_InitTypeDef *Init, int BuffSize)
    {
    BOOL Rslt=FALSE;
    UINT I2sDiv, I2sOdd, PktLen, T, I2sClk;
    LPVOID Buff;
    IRQn_Type    IRQn;
    SPI_TypeDef *I2SA;
    I2S_HANDLE  *hI2S;
    RCC_PeriphCLKInitTypeDef CI;

    if ((Buff=AllocMem(BuffSize, MEMOWNER_I2S_Init))==NULL) goto ProcExit;
    hI2S->ErrorCode=HAL_I2S_ERROR_NONE;
    hI2S=I2S_Handle+I2S_No;
    hI2S->Init=*Init;
    switch (I2S_No)
        {
        #ifdef PIO_I2S1SD
        case I2S1:
            __HAL_RCC_SPI1_CLK_ENABLE();
            I2SA=SPI1;
            IRQn=SPI1_IRQn;
            hI2S->Q=JOSQCreate(Buff, BuffSize/sizeof(WORD), JOSQTYPE_WORD);
            break;
        #endif

        #ifdef PIO_I2S2SD
        case I2S2:
            __HAL_RCC_SPI2_CLK_ENABLE();
            I2SA=SPI2;
            IRQn=SPI2_IRQn;
            hI2S->Q=JOSQCreate(Buff, BuffSize/sizeof(WORD), JOSQTYPE_WORD);
            break;
        #endif
        }

    hI2S->Instance=I2SA;

    //I2SCLK = (HSE_VALUE/PLLM) * PLLI2SN / PLLI2SR;
    //           25000000/25    *   50    /   2     = 25,000,000Hz (=PLLI2SR)
    CI.PeriphClockSelection=RCC_PERIPHCLK_I2S;
    CI.I2sClockSelection=RCC_I2SCLKSOURCE_PLLI2S;
    CI.PLLI2S.PLLI2SN=50;
    CI.PLLI2S.PLLI2SR=2;
    HAL_RCCEx_PeriphCLKConfig(&CI);

    HAL_NVIC_SetPriority(IRQn, 0xF, 0);
    HAL_NVIC_EnableIRQ(IRQn);

    CLEAR_BIT(I2SA->I2SCFGR, (SPI_I2SCFGR_CHLEN|SPI_I2SCFGR_DATLEN|SPI_I2SCFGR_CKPOL|
                              SPI_I2SCFGR_I2SSTD|SPI_I2SCFGR_PCMSYNC|SPI_I2SCFGR_I2SCFG|
                              SPI_I2SCFGR_I2SE|SPI_I2SCFGR_I2SMOD));

    I2SA->I2SPR=2;

    if (hI2S->Init.AudioFreq!=I2S_AUDIOFREQ_DEFAULT)
        {
        PktLen=(hI2S->Init.DataFormat==I2S_DATAFORMAT_16B) ? 16:32;
        if (hI2S->Init.Standard<=I2S_STANDARD_LSB) PktLen<<=1;

        I2sClk=EXTERNAL_CLOCK_VALUE;
        if (hI2S->Init.ClockSource==I2S_CLOCK_PLL) I2sClk=I2S_GetClockFreq(hI2S);

        if (hI2S->Init.MCLKOutput==I2S_MCLKOUTPUT_ENABLE)
            {
            if (hI2S->Init.DataFormat!=I2S_DATAFORMAT_16B)
                PktLen<<=2;
            else
                PktLen<<=3;
            }
        T=(I2sClk/PktLen*10/hI2S->Init.AudioFreq+5)/10;
        I2sOdd=T&1;
        I2sDiv=(T-I2sOdd)>>1;
        I2sOdd<<=8;
        }
    else{
        I2sDiv=2;
        I2sOdd=0;
        }

    if (I2sDiv<2 || I2sDiv>0xFF)
        {
        SET_BIT(hI2S->ErrorCode, HAL_I2S_ERROR_PRESCALER);
        goto ProcExit;
        }

    I2SA->I2SPR=I2sDiv|I2sOdd|hI2S->Init.MCLKOutput;

    MODIFY_REG(I2SA->I2SCFGR,
        SPI_I2SCFGR_CHLEN|SPI_I2SCFGR_DATLEN|SPI_I2SCFGR_CKPOL|SPI_I2SCFGR_I2SSTD|SPI_I2SCFGR_PCMSYNC|SPI_I2SCFGR_I2SCFG|SPI_I2SCFGR_I2SE|SPI_I2SCFGR_I2SMOD,
        SPI_I2SCFGR_I2SMOD|hI2S->Init.Mode|hI2S->Init.Standard|hI2S->Init.DataFormat|hI2S->Init.CPOL);

    #if defined(SPI_I2SCFGR_ASTRTEN)
    if (hI2S->Init.Standard==I2S_STANDARD_PCM_SHORT || hI2S->Init.Standard==I2S_STANDARD_PCM_LONG)
        {
        SET_BIT(I2SA->I2SCFGR, SPI_I2SCFGR_ASTRTEN);
        }
    #endif

    I2SA->I2SCFGR|=SPI_I2SCFGR_I2SE;
    Rslt++;

    ProcExit:
    return Rslt;
    }


#endif //HAL_I2S_MODULE_ENABLED


