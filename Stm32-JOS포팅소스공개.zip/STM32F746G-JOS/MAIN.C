﻿///////////////////////////////////////////////////////////////////////////////
//                      STM32F7 JOS Test Main
//
// 시작일: 2016-06-23 ~
// 프로그래머: 정오장
///////////////////////////////////////////////////////////////////////////////


#include "JLIB.H"
#include "JOS.H"
#include "DRIVER.H"
#include "MONITOR.H"
#include "KEY.H"
#include "MAIN.H"



static CONST CHAR FirstBootMsg[]="\r\nJOS Test (Build %s)\r\n\r\n";

const char* const MessageStrList[]=
    {
    "Name=String:"
    };



//-----------------------------------------------------------------------------
//      치명적인 오류가 생겼을 때 LED 번쩍거림
//-----------------------------------------------------------------------------
VOID WINAPI FatalError(int Err)
    {
    switch (Err)
        {
        case FERR_SYSCLKCFG:    //1초에 두번 짧게 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(10);
                PortOut(PO_STATUSLED, OFF); Delay_ms(490);
                }

        case FERR_EXCEPTION:    //1초에 10번 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, PO_NOT);
                Delay_ms(50);
                }

        case FERR_MEMORY:       //빠르게 두번을 깜빡이는데 1초마다 반복함
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(150);
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(750);
                }
        }
    }

VOID WINAPI UART_ErrUsrHandler(int Port, int ErrCode) {}




//-----------------------------------------------------------------------------
//      키상태 수집
//-----------------------------------------------------------------------------
static KEYCODETABLE KeyCodeTable[]=
    {//DownCode,    DblClickCode,       LongDown1Code,  LongDown2Code,  KeyUpCode
    {KC_TestDown,   KC_TestDblClk,      KC_TestLong1,    KC_TestLong2,  KC_TestUp},
    };

LOCAL(UINT) CollectKeyState(VOID)
    {
    UINT Key=0;

    if (PortIn(PI_TESTKEY)!=0) Key|=1;
    return Key;
    }



//-----------------------------------------------------------------------------
//      전원 켜기전에 이미 눌려있는 키를 어떻게 할지를 결정해줌
//      ScanKey() 에서 호출함
//-----------------------------------------------------------------------------
UINT WINAPI IgnoreFirstPushedKey(int Key)
    {
    return 0;
    }



//-----------------------------------------------------------------------------
//      키클릭음 처리, ScanKey()에서 호출함
//-----------------------------------------------------------------------------
VOID WINAPI PlayKeyClickSound(int KeyCode)
    {
    }



//-----------------------------------------------------------------------------
//      1ms 마다 처리 (틱 인터럽트에서 호출함)
//-----------------------------------------------------------------------------
VOID WINAPI _1msProc(VOID)
    {
    static BYTE _10ms;

    if (++_10ms>=10)
        {
        _10ms=0;
        ScanKey(CollectKeyState(), KeyCodeTable, countof(KeyCodeTable));
        K_TimerProc();
        }
    }




LOCAL(VOID) SystemClock_Config(VOID)
    {
    RCC_ClkInitTypeDef CI;
    RCC_OscInitTypeDef OI;

    OI.OscillatorType=RCC_OSCILLATORTYPE_HSE;
    OI.HSEState=RCC_HSE_ON;
    OI.HSIState=RCC_HSI_OFF;
    OI.PLL.PLLState=RCC_PLL_ON;
    OI.PLL.PLLSource=RCC_PLLSOURCE_HSE;
    OI.PLL.PLLM=25;                     //2~63
    OI.PLL.PLLN=384;                    //40~432
    OI.PLL.PLLP=RCC_PLLP_DIV2;          //HSE_VALUE(25000000)/25*384/RCC_PLLP_DIV2 = 192M (SDRAM은 200M를 초과하면 동작안함)
    OI.PLL.PLLQ=8;                      //HSE_VALUE(25000000)/25*384/8 = 48M (USB를 위해 48M를 맞추어야 함)
    if (HAL_RCC_OscConfig(&OI)!=HAL_OK) FatalError(FERR_SYSCLKCFG);
    if (HAL_PWREx_EnableOverDrive()!=HAL_OK) FatalError(FERR_SYSCLKCFG);

    CI.ClockType=(RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2);
    CI.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;
    CI.AHBCLKDivider=RCC_SYSCLK_DIV1;   //HCLK = SYSCLK / 1
    CI.APB1CLKDivider=RCC_HCLK_DIV4;    //PCLK1 = HCLK / 4
    CI.APB2CLKDivider=RCC_HCLK_DIV2;    //PCLK2 = HCLK / 2
    if (HAL_RCC_ClockConfig(&CI, FLASH_LATENCY_7)!=HAL_OK) FatalError(FERR_SYSCLKCFG);
    }





LOCAL(VOID) MPU_Config(VOID)
    {
    MPU_Region_InitTypeDef MRI;

    HAL_MPU_Disable();

    ZeroMem(&MRI, sizeof(MRI));
    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=SRAM1_BASE;
    MRI.Size=MPU_REGION_SIZE_256KB;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_NOT_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER0;
    MRI.TypeExtField=MPU_TEX_LEVEL0;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=0x2004C000;
    MRI.Size=MPU_REGION_SIZE_16KB;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_NOT_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER1;
    MRI.TypeExtField=MPU_TEX_LEVEL1;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    MRI.Enable=MPU_REGION_ENABLE;
    MRI.BaseAddress=0x2004C000;
    MRI.Size=MPU_REGION_SIZE_256B;
    MRI.AccessPermission=MPU_REGION_FULL_ACCESS;
    MRI.IsBufferable=MPU_ACCESS_BUFFERABLE;
    MRI.IsCacheable=MPU_ACCESS_NOT_CACHEABLE;
    MRI.IsShareable=MPU_ACCESS_SHAREABLE;
    MRI.Number=MPU_REGION_NUMBER2;
    MRI.TypeExtField=MPU_TEX_LEVEL0;
    MRI.SubRegionDisable=0;
    MRI.DisableExec=MPU_INSTRUCTION_ACCESS_ENABLE;
    HAL_MPU_ConfigRegion(&MRI);

    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
    }



//-----------------------------------------------------------------------------
//      루프딜레이 캘리브레이션
//-----------------------------------------------------------------------------
VOID CalLoopDelay(VOID)
    {
    DWORD Tick;

    Tick=GetTickCount();
    Delay_ms(1000);
    Printf("Delay_ms=%d\r\n", GetTickCount()-Tick);
    }




//-----------------------------------------------------------------------------
//      MAIN TASK
//-----------------------------------------------------------------------------
static VOID MainTask(LPVOID lpData)
    {
    int Key;
    DWORD StartTick;

    Printf("SENSOR: JOS Ver=%s\r\n", lpData);
    //Delay_ms(100);

    CreateMonitorTask();

    StartTick=GetTickCount();
    for (;;)
        {
        if ((Key=GetKey())>=0)
            {
            Printf("Key=%d\r\n", Key);

            if (Key==KC_TestDown)
                {
                Printf("Main Task Register Changing Test Start..."CRLF);
                Printf("Main Task Register Changed... (%s)"CRLF, TestChangeReg(90000000)==0 ? "OK":"FAIL");
                }
            }

        if (GetTickCount()-StartTick>=500)
            {
            PortOut(PO_STATUSLED, PO_NOT);
            StartTick=GetTickCount();
            }
        Sleep(1);
        }
    }




//-----------------------------------------------------------------------------
//          Main
//-----------------------------------------------------------------------------
int main(void)
    {
    //CHAR  Buff[40];
    static BYTE AllocMemory[8192];

    __disable_irq();
    InitPortOutputPP(PO_STATUSLED);     //치명적 오류를 표시해야 하므로 맨위에 초기화 필요
    MPU_Config();
    SCB_EnableICache();
    SCB_EnableDCache();
    HAL_Init();
    SystemClock_Config();

    if (MemAllocInit((UINT)AllocMemory, sizeof(AllocMemory))==FALSE) FatalError(FERR_MEMORY);

    //디버깅
    InitPort(PO_COM1TX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF7_USART1);
    InitPort(PI_COM1RX, GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF7_USART1);
    InitPortInput(PI_TESTKEY, GPIO_NOPULL);
    InitPortOutputPP(PO_LCD_BL_CTRL);   //PortOut(PO_LCD_BL_CTRL, OFF);

    InitUart(COM_DEBUG,  115200, UART_PARITY_NONE, UART_WORDLENGTH_8B, UART_STOPBITS_1);
    __enable_irq();

    InitRTC();
    //GetAppCompileDateStr(Buff);
    Printf(FirstBootMsg, "CompileDateTime"); //Buff);
    Printf("SENSOR: SystemCoreClock=%uHz\r\n", SystemCoreClock);

    //CalLoopDelay();

    JOSInit();      //JOS 초기화
    CreateThread("Main", MAIN_TASK_STK_SIZE, MainTask, "v101", PRIO_MAINTASK);  //최초 태스크 생성
    JOSStart();     //JOS 기동
    }




int WINAPI Mon_FuncTest(int PortNo, LPCSTR MonCmd, LPCSTR lpArg, LPCSTR CmdLine)
    {
    if (lpArg[0]=='?') return MONRSLT_EXIT;

    Printf("MON Task Register Changing Test Start..."CRLF);
    Printf("MON Task Register Changed... (%s)"CRLF, TestChangeReg(90000000)==0 ? "OK":"FAIL");

    return MONRSLT_OK;
    }





