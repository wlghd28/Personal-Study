///////////////////////////////////////////////////////////////////////////////
//          Cortex-M0 ���� JLIB
//
// Cortex-M7����� ����
//  �� �޸� �Ҵ��� �� 64K�� �ʰ��ϴ� ���� �Ҵ� �Ұ� (��� ���� ������尡 ����)
//
//2022-03-21 Jsprintf()����, F7���� ����ϴ� JsprintfN()���� ��ü
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#if INIFILE_EN
#include "INIDATA.H"
#endif


CHAR NullStr[]="";
CHAR Psnt1s[]="%s";
CHAR Psnt1d[]="%d";
CHAR Psnt2d[]="%d %d";
CHAR ConfigStr[]="Config";
CHAR CrLfStr[]=CRLF;
CHAR IniFileName[]="";

#define MAF_NOUSE       0
#define MAF_USE         1
#define MAF_LAST        2

#define MAH_SIGN        0x4D4A      //'MJ' ��������˻�

typedef struct MemAllocHeadStruc    //ũ�⸦ 8Byte�� ����
    {
    WORD  Sign;
    WORD  Size;
    BYTE  Flag;
    BYTE  Dummy;
    WORD  OwnerID;                  //Buffer Overflow �� �� �� ����ü���� ���� ������ �ڸ�
    } MEMALLOCHEAD;

static UINT RamStartAdd;
static UINT RamUsingSize;
static UINT RamMaxUsedSize;

static CHAR WeekNameList[]="Sun\0Mon\0Tue\0Wed\0Thu\0Fri\0Sat";
static CHAR MonthNameList[]="Jan\0Feb\0Mar\0Apr\0May\0Jun\0Jul\0Aug\0Sep\0Oct\0Nov\0Dec";
VOID Printf(LPCSTR DispStr, ...);


#define MEMOWNER_PutString              1



//-----------------------------------------------------------------------------
//              �޸� ���� �ʱ�ȭ
//-----------------------------------------------------------------------------
LOCAL(VOID) SetMAH(MEMALLOCHEAD *MAH, int Owner, UINT BlkSize, BYTE Flag)
    {
    MAH->Sign=MAH_SIGN;
    MAH->OwnerID=Owner;
    MAH->Size=BlkSize;
    MAH->Flag=Flag;
    }



//-----------------------------------------------------------------------------
//              �޸� ���� �ʱ�ȭ
//-----------------------------------------------------------------------------
BOOL WINAPI MemAllocInit(UINT MemStart, UINT BlkSize)
    {
    RamStartAdd=(MemStart+15) & ~0xF;
    BlkSize-=RamStartAdd-MemStart;

    BlkSize&=~0xF;
    BlkSize-=sizeof(MEMALLOCHEAD);      //�ǵ� �޸��� ���� ��

    SetMAH((MEMALLOCHEAD*)RamStartAdd, 0, BlkSize, MAF_NOUSE);

    MemStart=RamStartAdd+BlkSize;
    SetMAH((MEMALLOCHEAD*)MemStart, 0, sizeof(MEMALLOCHEAD), MAF_LAST);

    return ((MEMALLOCHEAD*)MemStart)->Sign==MAH_SIGN &&
           ((MEMALLOCHEAD*)MemStart)->Flag==MAF_LAST;
    }




//-----------------------------------------------------------------------------
//              �޸� �Ҵ�
//���ϰ� 0:OK
//       7:�޸� ������� �ı�
//       8:�䱸�ϴ� ũ���� �޸𸮰� ����
//-----------------------------------------------------------------------------
LPVOID WINAPI AllocMem(DWORD ReqSize, UINT OwnerID)
    {
    int  Rslt;
    UINT Sz;
    LPVOID lpMem=NULL;
    MEMALLOCHEAD *MAH;
    JOS_CRITICAL_VAR;

    ReqSize+=7; ReqSize&=~7;        //8�� ���ũ��� �Ҵ��ϰ� �ϴ� ������ Ptr�� ���� 3Bit�� 0�� �ǵ��� �ϱ� ���� (���������� Ȯ�ο� ���)
    ReqSize+=sizeof(MEMALLOCHEAD);

    JOS_ENTER_CRITICAL();

    for (MAH=(MEMALLOCHEAD*)RamStartAdd; ;)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Printf("Mem=%X Broken"CRLF, MAH); Rslt=MA_BROKENMCB; break;}
        if (MAH->Flag==MAF_LAST) {Rslt=MA_INSUFFICIENT; break;}

        if (MAH->Flag==MAF_NOUSE && Sz>=ReqSize)
            {
            SetMAH(MAH, OwnerID, ReqSize, MAF_USE);
            //MAH->CurrPrio=OSPrioCur;
            Sz-=ReqSize;
            if (Sz>=sizeof(MEMALLOCHEAD)) SetMAH((MEMALLOCHEAD*)((LPBYTE)MAH+ReqSize), 0, Sz, MAF_NOUSE); //������ ũ�⸦ ��������� ó��
            else MAH->Size=Sz+ReqSize;      //�ڸ� �� ������ ũ�Ⱑ sizeof(MEMALLOCHEAD)�� �ȵǴ� ���

            lpMem=(LPVOID)((LPBYTE)MAH+sizeof(MEMALLOCHEAD));
            Rslt=MA_OK;
            break;
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    JOS_EXIT_CRITICAL();

    if (Rslt!=MA_OK) Printf("AllocMem(Req=%d, Owner=%d) %s"CRLF, ReqSize, OwnerID, Rslt==MA_BROKENMCB ? "Broken MCB":(Rslt==MA_INSUFFICIENT ? "Insufficient Memory":"Error"));
    else{
        //Printf("%d=AllocMem(%d, %d) Ok (Task=%d)"CRLF, Rslt, ReqSize, OwnerID);
        if ((RamUsingSize+=ReqSize)>RamMaxUsedSize) RamMaxUsedSize=RamUsingSize;
        }
    return lpMem;
    }



//-----------------------------------------------------------------------------
//              �޸� ����
//              cf<-1�϶� ax=1:�޸� ������� �ı�
//                           2:�־��� �޸������� ����
//-----------------------------------------------------------------------------
int WINAPI FreeMem(LPCVOID lpMem)
    {
    int Rslt=MA_INVALIDPTR;
    UINT Sz;
    MEMALLOCHEAD *MAH, *MAH_NoUseStart;
    JOS_CRITICAL_VAR;

    if (lpMem==NULL) goto ProcExit;

    //��������˻�
    MAH=(MEMALLOCHEAD*)((LPBYTE)lpMem-sizeof(MEMALLOCHEAD));
    if (MAH->Sign!=MAH_SIGN || MAH->Flag!=MAF_USE) goto ProcExit;
    MAH->Flag=MAF_NOUSE;
    RamUsingSize-=MAH->Size;
    Rslt=MA_OK;

    //���ӵ� �Ⱦ��� ������ �ϳ��� ��ģ��
    MAH_NoUseStart=NULL;

    JOS_ENTER_CRITICAL();
    for (MAH=(MEMALLOCHEAD*)RamStartAdd; ;)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Rslt=MA_BROKENMCB; break;}
        if (MAH->Flag==MAF_LAST) break;

        if (MAH->Flag!=MAF_NOUSE) MAH_NoUseStart=NULL;
        else{
            if (MAH_NoUseStart==NULL) MAH_NoUseStart=MAH;       //ó������ �����ϴ� ����
            else{
                MAH->Sign=0;
                MAH_NoUseStart->Size+=Sz;
                }
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    JOS_EXIT_CRITICAL();

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              �޸� ���� �뷮 ���
//���ϰ� 0:OK
//       7:�޸� ������� �ı�
//       8:�䱸�ϴ� ũ���� �޸𸮰� ����
//-----------------------------------------------------------------------------
UINT WINAPI GetMemFree(UINT *lpLargestBlkSize, int *lpRslt, int *BlkQty)
    {
    int  Rslt=MA_OK, Cnt=0;
    UINT MaxBlkSize, FreeSize, Sz;
    MEMALLOCHEAD *MAH;
    JOS_CRITICAL_VAR;

    JOS_ENTER_CRITICAL();

    MaxBlkSize=FreeSize=0;
    for (MAH=(MEMALLOCHEAD*)RamStartAdd; MAH->Flag!=MAF_LAST;)
        {
        Cnt++;
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Rslt=MA_BROKENMCB; break;}

        if (MAH->Flag==MAF_NOUSE)
            {
            FreeSize+=Sz;
            MaxBlkSize=UGetMax(MaxBlkSize, Sz);
            }
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        }
    JOS_EXIT_CRITICAL();

    if (lpRslt!=NULL) *lpRslt=Rslt;
    if (lpLargestBlkSize!=NULL) *lpLargestBlkSize=MaxBlkSize;
    if (BlkQty!=NULL) *BlkQty=Cnt;
    return FreeSize;
    }




//-----------------------------------------------------------------------------
//      �޸� ������ Dump��
//-----------------------------------------------------------------------------
VOID WINAPI DispMemBlock(BOOL DispBlkFg)
    {
    UINT Sz, Cnt, Used, Free;
    MEMALLOCHEAD *MAH;

    Cnt=Used=Free=0;
    for (MAH=(MEMALLOCHEAD*)RamStartAdd; MAH->Flag!=MAF_LAST;)
        {
        Sz=MAH->Size;
        if (MAH->Sign!=MAH_SIGN || Sz==0) {Printf("%08X %d Owner=%3d Size=%d Broken"CRLF, MAH, MAH->Flag, Sz, MAH->OwnerID); break;}
        if (DispBlkFg) Printf("%08X %d Owner=%3d Size=%d"CRLF, MAH, MAH->Flag, MAH->OwnerID, Sz);
        if (MAH->Flag==MAF_NOUSE) Free+=Sz; else Used+=Sz;
        MAH=(MEMALLOCHEAD*)((LPBYTE)MAH+Sz);
        Cnt++;
        }
    Printf("Total Blocks = %u"CRLF
           "Free Size = %,u"CRLF
           "Use Size  = %,u"CRLF
           "Max Used  = %,u"CRLF, Cnt, Free, Used, RamMaxUsedSize); //RamUsingSize
    }



//-----------------------------------------------------------------------------
//      ��ġ���� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsNumeric(int Cha)
    {
    return Cha>='0' && Cha<='9';
    }



//-----------------------------------------------------------------------------
//      ASCII�������� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsAscii(int Cha)
    {
    return Cha>=' ' && Cha<=0x7F;
    }



//-----------------------------------------------------------------------------
//      ASCII�������� �˷���
//-----------------------------------------------------------------------------
int WINAPI CatchAscii(int Cha)
    {
    if (IsAscii(Cha)==FALSE) Cha=' ';
    return Cha;
    }



//-----------------------------------------------------------------------------
//      ū�� �Ǵ� �������� ����
//-----------------------------------------------------------------------------
int WINAPI GetMin(int A, int B)
    {
    return A<=B ? A:B;
    }

UINT WINAPI UGetMin(UINT A, UINT B)
    {
    return A<=B ? A:B;
    }

int WINAPI GetMax(int A, int B)
    {
    return A>=B ? A:B;
    }

int WINAPI GetAbs(int A)
    {
    return A>=0 ? A:-A;
    }

int WINAPI GetDiff(int A, int B)
    {
    if ((A-=B)<0) A=-A;
    return A;
    }

UINT WINAPI UGetDiff(UINT A, UINT B)
    {
    return (A>=B) ? A-B:B-A;
    }

UINT WINAPI UGetMax(UINT A, UINT B)
    {
    return A>=B ? A:B;
    }

int WINAPI Limit(int Value, int Min, int Max)
    {
    if (Value<Min) Value=Min;
    else if (Value>Max) Value=Max;
    return Value;
    }

int WINAPI DivRoundUp(int A, int B)
    {
    int Half;

    if ((Half=B>>1)<0) Half=-Half;
    if (A<0) Half=-Half;
    return (A+Half)/B;
    }




//-----------------------------------------------------------------------------
//      ���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
int WINAPI AtoI(LPCSTR Str, int *NonStrLoc)
    {
    int  Rslt, Sign, HexMode, NoErr, Cha, Cha2;
    LPCSTR lp;

    Rslt=Sign=HexMode=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha=='0')
            {
            Cha2=*lp++;
            if (Cha2=='x' || Cha2=='X') HexMode++; else lp-=2;
            }
        else lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (HexMode==0) break;
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        if (HexMode) Rslt<<=4;
        else{
            Rslt<<=1;
            Rslt+=Rslt<<2;      //*10
            }
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ����� ��� ����� ���ڷ� ����
//-----------------------------------------------------------------------------
int WINAPI AtoIN(LPCSTR NumStr, int StrLen)
    {
    int Rslt=0;
    CHAR Cha;

    while (StrLen--)
        {
        Cha=*NumStr++;
        if (Cha<'0' || Cha>'9') break;

        Rslt<<=1;
        Rslt+=Rslt<<2;  //*10
        Rslt+=Cha-'0';
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿��� ���ڿ� �񱳸� ��
//-----------------------------------------------------------------------------
int WINAPI CompMemStr(LPCSTR Src, LPCSTR Find)
    {
    return CompMem(Src, Find, lstrlen(Find));
    }



//-----------------------------------------------------------------------------
//      Memory������ ���մϴ� (������ 0, ������ -1, ũ�� 1) (��ҹ��ڹ���)
//      memicmp
//-----------------------------------------------------------------------------
int WINAPI CompMemI(LPCVOID Str1, LPCVOID Str2, UINT CompSize)
    {
    UINT Cha1, Cha2;
    BOOL Rslt=0;

    while (CompSize--)
        {
        Cha1=*(LPCBYTE)Str1; Str1=(LPCBYTE)Str1+1;
        Cha2=*(LPCBYTE)Str2; Str2=(LPCBYTE)Str2+1;
        if (Cha1>='a' && Cha1<='z') Cha1-=0x20;
        if (Cha2>='a' && Cha2<='z') Cha2-=0x20;
        if ((Rslt=Cha1-Cha2)!=0) break;
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �޸𸮿��� ���ڿ� �񱳸� ��
//-----------------------------------------------------------------------------
int WINAPI CompMemStrI(LPCSTR Src, LPCSTR Find)
    {
    return CompMemI(Src, Find, lstrlen(Find));
    }




//-----------------------------------------------------------------------------
//      ��� ����Ʈ�� 0���� üũ���ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI IsZeroMem(LPCVOID Mem, int ByteSize)
    {
    int I;

    for (I=0; I<ByteSize; I++) if (*((LPCBYTE)Mem+I)!=0) break;
    return I>=ByteSize;
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� ������ Format���� ����� �ݴϴ�
//      %c, %d, %u, %s, %x, %X, %lld, %llu, %I64d, %I64u, %ws, %llX
//      %[-][,][#][0][width][.decimal]type
//
//      Test
//      ====
//      CHAR Buff[80];
//      Jsprintf(Buff, "%,X  %.4d   %.2d  %,d  %,.2d", 0x125679AF, 23, 123456789, 123456789, 123456789);
//      DispMsg(NULL, Buff);
//
// Ver 2.02 2001/01/07 "%.01d" �Ҽ����ڿ� 0�� ������ �Ҽ����ڿ��� 0�̾ ǥ����
// Ver 2.03 2005/10/17 "%.02d" ���� ���� ��ġ�� 0�� ��� ������ 0���� ������� 0.00 ���� ����
// Ver 2.04 2012/01/20 "%.lld %.llu %I64d %I64u"�߰� 64bit���� ǥ��
// Ver 2.05 2012/08/30 "%ws" Utf16���ڿ� ǥ�� �߰�
// Ver 2.06 2015/07/30 "%llX" 64bit���� Hexǥ��
// Ver 2.07 2016/04/11 DestBuff�� ũ�⸦ �ް� ��ġ�� �ʰ� ó����
// Ver 2.08 2017/01/11 .12 -> 0.12
// Ver 2.09 2018/01/12 %U8s �߰�, UTF8���ڿ� ���� �� ����
// Ver 2.10 2018/08/24 BuffSize==0 �̸� �� �ʿ��� ����ũ�⸦ ������
//
// 64��Ʈ������ va_arg()�� �������� �ִ� ũ�Ⱑ 64��Ʈ��. %c,%d �� ��������
// 2022-03-21 ������ ����ũ�⸦ �Է¹��� �ʴ� �Լ� ��� M0�ڵ尡 376Byte ������
//-----------------------------------------------------------------------------
#define JSPRINTF_PUTCHA(Cha)\
    {\
    TotalSize++;\
    if (BuffSize>1) {*DestBuff++=Cha; BuffSize--;}\
    }
#define JSPRINTF_FILLCHA(Cha, Cnt)\
    {\
    TotalSize+=Cnt;\
    if (BuffSize>Cnt) {FillMem(DestBuff, Cnt, Cha); DestBuff+=Cnt; BuffSize-=Cnt;}\
    }
#define JSPRINTF_PUTSTR(Str)\
    {\
    TotalSize+=Len;\
    if (BuffSize>Len) {CopyMem(DestBuff, Str, Len); DestBuff+=Len; BuffSize-=Len;}\
    }

int WINAPI VsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormStr, va_list VL)
    {
    int    I, Width, CommaUnit, FractionUnit, TotalSize=1,
           Cha, ZeroFillCha, TypeCha, Len;
    UINT   ArgValue;
    BOOL   LeftAlignFg, HexPrefixFg, FractionZFillFg, I64;
    LPSTR  lp;
    LPCSTR lpPsntNextPtr;
    CHAR   Buff[32];

    for (;;)
        {
        Cha=*FormStr++;
        if (Cha!='%')
            {
            PassCha:
            if (Cha==0) break;
            JSPRINTF_PUTCHA(Cha)
            }
        else{
            if (FormStr[0]=='%') {FormStr++; goto PassCha;}     //'%%'�� %�� �Ϲ� ���ڷ� ���
            lpPsntNextPtr=FormStr;
            Width=LeftAlignFg=HexPrefixFg=FractionUnit=CommaUnit=FractionZFillFg=I64=0;
            ZeroFillCha=' ';

            for (;;)
                {
                Cha=*FormStr++;
                if (Cha=='-') LeftAlignFg=1;
                else if (Cha==',') CommaUnit=3;
                else if (Cha=='#') HexPrefixFg=1;
                else if (Cha=='0') ZeroFillCha='0';
                else if (Cha>='1' && Cha<='9') {FormStr--; Width=AtoI(FormStr, &I); FormStr+=I;}
                else if (Cha=='.')
                    {
                    if (FormStr[0]=='0') FractionZFillFg=1;
                    FractionUnit=-AtoI(FormStr, &I); FormStr+=I;
                    }
                else if (Cha=='I' && FormStr[0]=='6' && FormStr[1]=='4') {FormStr+=2; I64=1;}
                else if (Cha=='l' && FormStr[0]=='l') {FormStr++; I64=1;}
                else{
                    TypeCha=Cha;
                    ArgValue=va_arg(VL, UINT);

                    if (Cha=='c')               //%c
                        {
                        Buff[0]=(BYTE)ArgValue; Buff[1]=0;
                        lp=Buff;

                        PutStr:
                        Len=lstrlen(lp);
                        if (LeftAlignFg!=0)     //'-'�� ������ ����������
                            {
                            JSPRINTF_PUTSTR(lp)
                            if ((Width-=Len)>0) JSPRINTF_FILLCHA(' ', Width)
                            }
                        else{                   //������ ���� ó��
                            if (Width!=0 && (Width-=Len)>0) JSPRINTF_FILLCHA(ZeroFillCha, Width)
                            JSPRINTF_PUTSTR(lp)
                            }
                        break;
                        }
                    else if (Cha=='s')                  //%s
                        {
                        if ((lp=(LPSTR)ArgValue)==NULL) lp="<null>";
                        goto PutStr;
                        }
                    else if (Cha=='x' || Cha=='X')      //%x, %X
                        {
                        int HexChaOfs;

                        I=0;                            //�ڸ��� ī����
                        HexChaOfs=(TypeCha=='x') ? 'a'-10:'A'-10;
                        lp=Buff+sizeof(Buff)-1; lp[0]=0;
                        if (I64==0)
                            {
                            #define ArgValue32  ArgValue
                            do  {
                                Cha=ArgValue32 & 0x0F; ArgValue32>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue32!=0);
                            #undef ArgValue32
                            }
                        else{
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;

                            do  {
                                Cha=(int)(ArgValue64 & 0x0F); ArgValue64>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue64!=0);
                            }

                        if (HexPrefixFg!=0)
                            {
                            *--lp='x';
                            *--lp='0';
                            }
                        goto PutStr;
                        }
                    else if (Cha=='d' || Cha=='u')      //%d, %u
                        {
                        BOOL FirstFg=1, Sign=0;

                        if (I64==0)
                            {
                            #define ArgValue32  ArgValue
                            if (TypeCha=='d' && (int)ArgValue32<0) {ArgValue32=-(int)ArgValue32; Sign=1;}
                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue32==0) {*--lp='0'; goto PutStr;}

                            do  {
                                Cha=(ArgValue32%10)+'0';
                                ArgValue32/=10;
                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue32==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit+1==0) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue32!=0);
                            #undef ArgValue32
                            }
                        else{
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);

                            //*((DWORD*)&ArgValue64+0)=ArgValue;                //GCC������ �̷� ����� �������� ����
                            //*((DWORD*)&ArgValue64+1)=HighValue;
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;    //�����Ϸ��� �˾Ƽ�ó���ϴ��� __allshl() �θ��� ����
                            if (TypeCha=='d' && (int)HighValue<0) {ArgValue64=-(INT64)ArgValue64; Sign=1;}

                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue64==0) {*--lp='0'; goto PutStr;}

                            do  {
                                //Cha=(UCHAR)(ArgValue64%10)+'0';
                                //ArgValue64/=10;
                                ArgValue64=UDiv64_32(ArgValue64, 10, (UINT*)&I);
                                Cha=I+'0';

                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue64==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit+1==0) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue64!=0);
                            }

                        if (FractionUnit<0)
                            {
                            while (FractionUnit<0) {*--lp='0'; FractionUnit++;}
                            *--lp='.';
                            }
                        if (FractionUnit==0) *--lp='0';
                        if (TypeCha=='d' && Sign!=0) *--lp='-';
                        goto PutStr;
                        }
                    else{
                        FormStr=lpPsntNextPtr;      //ó������ �ʴ� '%' Type�̸� �״�� ǥ��
                        //ArgList--;                //va_list���� �ڷ� ���ư��� ��� ��ã��
                        Cha='%';
                        goto PassCha;
                        }
                    }
                } //while (*FormStr++)
            } //'%' ó��
        } //for (;;)

    if (BuffSize>0) DestBuff[0]=0;
    return TotalSize;
    }


int Jsprintf(LPSTR DestBuff, LPCSTR FormatStr, ...)     //�����Լ��� ȣȯ�� ����, ������ JsprintfN()�� ����� ��
    {
    int Rslt;
    va_list VL;

    va_start(VL, FormatStr);
    Rslt=VsprintfN(DestBuff, 128, FormatStr, VL);
    va_end(VL);
    return Rslt;
    }

int JsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormatStr, ...)
    {
    int Rslt;
    va_list VL;

    va_start(VL, FormatStr);
    Rslt=VsprintfN(DestBuff, BuffSize, FormatStr, VL);
    va_end(VL);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//              ������ Skip��
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR lp)
    {
    int Cha;

    for (;;)
        {
        Cha=*(LPCBYTE)lp;
        if (Cha==0 || Cha>' ') break;
        lp++;
        }
    return lp;
    }



//-----------------------------------------------------------------------------
//      String���� %d, %s, %c, %x�� ó���Ͽ� �̾��ݴϴ�
//      %u=%d, %X=%x ���� ó����
//      %.3d �� �Ҽ������� ���ڸ����� ������ ���� (*1000�� �϶�� ��)
//      �� String�� ��ġ�ϸ� True�� �����մϴ�

//Test:
//    int  I1, I2, I3, I4, H;
//    CHAR Cha, Str[40], Buff[80];
//    I=Jsscanf("TestStr: 5% +1234 -1234 12.3456 123 AF90 \"This Is Str\" J %z EOF",
//            "TestStr: 5%% %u %d %.2d %.3d %X %s %c %z EOF",
//            &I1, &I2, &I3, &I4, &H, Str, &Cha);
//
//    wsprintfA(Buff, "(Rslt=%d) I1=%d I2=%d I3=%d I4=%d H=%X Str=[%s] Cha=[%c]",
//                    I, I1, I2, I3, I4, H, Str, Cha);
//    DebugFile(Buff); //=> (Rslt=1) I1=1234 I2=-1234 I3=1235 I4=123000 H=AF90 Str=[This Is Str] Cha=[J]
//-----------------------------------------------------------------------------
BOOL Jsscanf(LPCSTR SourceStr, LPCSTR FormatStr, ...)
    {
    int  I, DecimalPt;
    BYTE Cha, SCha,FCha;
    LPCSTR FormatStrBkup, SourceStrBkup;
    LPVOID *lpArg;

    lpArg=(LPVOID*)&FormatStr+1;
    for (;;)
        {
        SCha=*SourceStr++;
        FCha=*FormatStr++;
        if (SCha==0 || FCha==0) break;

        if (FCha=='%')
            {
            SourceStrBkup=SourceStr;
            FormatStrBkup=FormatStr;
            FCha=*FormatStr++;
            if (FCha!='%')      //%%�� %���� �ϳ���
                {
                DecimalPt=0;
                if (FCha=='.')
                    {
                    DecimalPt=AtoI(FormatStr, &I);
                    FormatStr+=I;
                    FCha=*FormatStr++;
                    }

                if (FCha=='c')                          //'%c'
                    {
                    *(LPBYTE)(*lpArg++)=SCha;
                    continue;
                    }
                else if (FCha=='d' || FCha=='u')        //'%d', '%u'
                    {
                    int Val=0, NumbSignFg, ExistDcmlPtFg, HalfRiseFg, ValidFg;

                    NumbSignFg=ExistDcmlPtFg=HalfRiseFg=ValidFg=0;

                    if (SCha=='-') NumbSignFg++;
                    else if (SCha!='+') SourceStr--;

                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha=='.')
                            {
                            if (ExistDcmlPtFg) break;   //�ι�°�� �Ҽ����� ������ ��� ���ڹ��ڿ� ����� ó��
                            ExistDcmlPtFg++;
                            continue;
                            }
                        Cha-='0';
                        if (Cha>9) break;               //���ڹ��ڿ� ����
                        ValidFg++;
                        if (ExistDcmlPtFg)
                            {
                            if (DecimalPt==0)           //������ ��ȿ���� ����
                                {
                                if (HalfRiseFg==0)
                                    {
                                    HalfRiseFg++;
                                    if (Cha>=5) Val++;
                                    }
                                continue;
                                }
                            DecimalPt--;
                            }
                        Val<<=1; Val+=Val<<2; Val+=Cha; //Val=Val*10+Cha
                        }

                    if (ValidFg)
                        {
                        SourceStr--;
                        while (DecimalPt!=0) {Val<<=1; Val+=Val<<2; DecimalPt--;}
                        if (NumbSignFg) Val=-Val;
                        *(int*)(*lpArg++)=Val;
                        continue;
                        }

                    //��ȿ�� ���ڹ��ڰ� �ϳ��� ������ �Ϲ� ���ڿ��� ó��
                    SourceStr=SourceStrBkup;
                    FormatStr=FormatStrBkup;
                    }
                else if (FCha=='x' || FCha=='X')        //'%x', '%X'
                    {
                    int Val, ValidFg;

                    Val=ValidFg=0;
                    SourceStr--;
                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha<'0') break;
                        if (Cha<='9') {Cha-='0'; goto AddDigit;}
                        if (Cha<'A') break;
                        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
                        if (Cha<'a' || Cha>'f') break;
                        Cha-='a'-10;
                        AddDigit:
                        ValidFg++;
                        Val<<=4; Val|=Cha;
                        }

                    if (ValidFg)
                        {
                        SourceStr--;
                        *(UINT*)(*lpArg++)=Val;
                        continue;
                        }

                    //��ȿ�� ���ڹ��ڰ� �ϳ��� ������ �ϸ� ���ڿ��� ó��
                    SourceStr=SourceStrBkup;
                    FormatStr=FormatStrBkup;
                    }
                else if (FCha=='s')             //'%s'
                    {
                    LPSTR lpD;

                    lpD=(LPSTR)(*lpArg++);
                    if (SCha!='\'' && SCha!='"')
                        {
                        SourceStr--;
                        SCha=0;         //0:ó������ String, �̶��� ���� Space�� Tab���ڱ��� �д´�
                        }
                    for (;;)
                        {
                        Cha=*SourceStr++;
                        if (Cha==0) {SourceStr--; break;}
                        if (SCha!=0)
                            {
                            if (Cha==SCha) break;
                            }
                        else{
                            if (Cha<=' ') {SourceStr--; break;}
                            }
                        *lpD++=Cha;
                        }
                    *lpD=0;
                    continue;
                    }
                else{
                    FormatStr=FormatStrBkup;
                    FCha='%';
                    }
                }
            }

        //1�� �̻��� Space�� Tab�� ��� �ϳ��� Space�� ���Ѵ�
        if (SCha<=' ') {SourceStr=SkipSpace(SourceStr); SCha=' ';}
        if (FCha<=' ') {FormatStr=SkipSpace(FormatStr); FCha=' ';}
        if (SCha!=FCha) break;
        }
    return (SCha|FCha)==0;      //SCha�� FCha��� 0�̸� �� String�� ��ġ���� �ǹ���
    }




//-----------------------------------------------------------------------------
//      Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� Hex�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
DWORD WINAPI AtoH(LPCSTR String, int *NonStrLoc)
    {
    BOOL   NoErr;
    DWORD  Rslt;
    CHAR   Cha;
    LPCSTR lp;

    Rslt=NoErr=0;
    lp=SkipSpace(String);
    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        Rslt<<=4;
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-String)-1:0;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Hex���ڿ��� ��ġ�� ��ȭ��
//-----------------------------------------------------------------------------
DWORD WINAPI AtoHN(LPCSTR Str, int StrLen)
    {
    DWORD  Rslt=0;
    int   Cha;

    while (StrLen--)
        {
        Cha=*Str++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        Rslt<<=4;
        Rslt+=Cha;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Str�� ��(NULL������ġ)�� �ݴϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetStrLast(LPSTR Str)
    {
    return lstrlen(Str)+Str;
    }



//-----------------------------------------------------------------------------
//      String�� Cha�� ���Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI AddCha(LPSTR Str, int Cha)
    {
    int I;

    I=lstrlen(Str);
    Str[I]=Cha;
    Str[I+1]=0;
    }



int WINAPI UpCaseCha(int Cha)
    {
    if (Cha>='a' && Cha<='z') Cha-=0x20;
    return Cha;
    }



#ifdef SECURE_CODE
//-----------------------------------------------------------------------------
//      �����ڵ� ������ ���ذ��� ���� �Լ�
//-----------------------------------------------------------------------------
int WINAPI strlen_r(LPCSTR Src)
    {
    int Len=0;
    while (*Src++!=0) Len++;
    return Len;
    }


VOID WINAPI strcat_r(LPSTR Dest, LPCSTR Src)
    {
    lstrcpy(GetStrLast(Dest), Src);
    }

VOID WINAPI strcpy_r(LPSTR Dest, LPCSTR Src)
    {
    int Cha;

    for (;;)
        {
        *Dest++=Cha=*Src++;
        if (Cha==0) break;
        }
    }

VOID WINAPI memcpy_r(LPCVOID Dest, LPCVOID Src, UINT Len)
    {
    while (Len--)
        {
        *(LPBYTE)Dest=*(LPCBYTE)Src;
        Dest=(LPCBYTE)Dest+1;
        Src=(LPCBYTE)Src+1;
        }
    }
#endif




//-----------------------------------------------------------------------------
//      �־��� ���ڿ��� �빮�ڷ� �ٲ۴� (���̸� UpcaseStr)
//-----------------------------------------------------------------------------
VOID WINAPI CharUpper(LPSTR Str)
    {
    int Ch;

    while ((Ch=*(LPCBYTE)Str)!=0)
        {
        if (Ch>='a' && Ch<='z') Str[0]=Ch-0x20;
        Str++;
        }
    }




//-----------------------------------------------------------------------------
//      �־��� ���� ���ڿ��� �ҹ��ڷ� ��ȯ
//-----------------------------------------------------------------------------
int WINAPI CharLowerBuff(LPSTR Str, int Len)
    {
    int Cnt=0, Cha;

    while (Len--)
        {
        Cha=*(LPCBYTE)Str;
        if (Cha==0) break;
        if (Cha>='A' && Cha<='Z') Str+=0x20;        //������ �ٸ����� ���ڵ� ó���ؾ� ��
        Str++;
        Cnt++;
        }
    return Cnt;
    }



//-----------------------------------------------------------------------------
//      ����ũ�� ���� ū ���ڿ��� �߶� ����
//-----------------------------------------------------------------------------
LPSTR WINAPI lstrcpyn(LPSTR Dest, LPCSTR Src, UINT BuffSize)
    {
    int CopyLen;

    if ((CopyLen=GetMin(lstrlen(Src), BuffSize-1))>0)
        CopyMem(Dest, Src, CopyLen);

    Dest[CopyLen]=0;
    return Dest;
    }



//-----------------------------------------------------------------------------
//      �־��� String�� �յ��� ������ �������ش� (�����̸�: CleanupStr)
//-----------------------------------------------------------------------------
VOID WINAPI StrTrim(LPSTR String)
    {
    BYTE Byt;
    LPSTR lp;

    //�ǵ��� ���� ����
    for (lp=GetStrLast(String)-1; lp>=String; lp--)
        {
        if (*(LPCBYTE)lp>0x20) break;
        lp[0]=0;
        }

    //���� ���� ����
    for (lp=String; ;lp++)
        {
        Byt=*(LPCBYTE)lp;
        if (Byt==0 || Byt>' ') break;
        }
    if (lp>String) lstrcpy(String, lp);
    }



//-----------------------------------------------------------------------------
//      ���� �ܾ��� ��ġ�� �ݴϴ� (�����̳� TAB����)
//      ����ܾ�� ������ ���� ���� �ܾ��� ��ġ�� �ݴϴ�
//      ������ġ�� �����̸� �ٷ� ���� ������ �ܾ�
//      '�� "�� ���ΰ�� �ϳ��� �ܾ�� �ν��մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextWord(LPCSTR lp, int WordCnt)
    {
    int Cha, FirstCha;

    for (;;)
        {
        lp=SkipSpace(lp);       //���齺ŵ
        FirstCha=lp[0];
        if (FirstCha==0 || WordCnt==0) break;
        WordCnt--;

        if (FirstCha==0x27 || FirstCha==0x22) lp++;     //"'", '"'
        else FirstCha=0;

        for (;;)                        //�ܾŵ
            {
            Cha=*(LPCBYTE)lp++;
            if (Cha==0) {lp--; break;}
            if (FirstCha!=0)
                {
                if (FirstCha==Cha) break;
                }
            else{
                if (Cha<=' ') {lp--; break;}
                }
            }
        }
    return lp;
    }



int WINAPI SearchCha(LPCSTR SourceStr, int SrchCha)
    {
    LPCSTR lp;
    return (lp=strchr(SourceStr, SrchCha))!=NULL ? lp-SourceStr:-1;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿��� Byte�� ã��
//-----------------------------------------------------------------------------
int WINAPI SearchMemByte(LPCVOID Mem, int MemSize, int FindByte)
    {
    int I, Find=-1;

    for (I=0; I<MemSize; I++)
        {
        if (*((LPCBYTE)Mem+I)==FindByte) {Find=I; break;}
        }
    return Find;
    }



//-----------------------------------------------------------------------------
//      ','�� �������� ���ϴ� ��ȣ�� �ܾ� ��ġ�� ����
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextCommaWord(LPCSTR lp, int WordNo)
    {
    int I;

    lp=SkipSpace(lp);   //���齺ŵ
    for (;;)
        {
        if (WordNo==0) break;
        if (lp[0]==0) break;
        if ((I=SearchCha(lp, ','))<0) I=lstrlen(lp)-1;
        lp+=I+1;
        WordNo--;
        }
    return lp;
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����� ������ ���ڿ��� ��)
//-----------------------------------------------------------------------------
LPSTR WINAPI SeparatStr(LPSTR String, int SepCha)
    {
    int I;
    if ((I=SearchCha(String, SepCha))<0) return NULL;
    String[I]=0;
    return String+I+1;
    }



//------------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����ڿ� ������ ���ڿ��� ��)
//------------------------------------------------------------------------------
LPSTR WINAPI SeparatStrStr(LPSTR Str, LPCSTR SepStr)
    {
    int I;

    if ((I=SearchStr(Str, SepStr))<0) return NULL;
    Str[I]=0;
    return lstrlen(SepStr)+Str+I;
    }



//-----------------------------------------------------------------------------
//      �����ڱ����� ���ڿ��� �����ְ� ������ ���� ��ġ�� ������
//      strtok()�� SeparatStr()�� ������ ���������� �� �Լ��� ������ �Ѽ����� ����
//      �����̸� CatchWord()
//      ��뿹: CatchToken("TE;HU;ANALOG", ';', Buff, sizeof(Buff));
//-----------------------------------------------------------------------------
LPCSTR WINAPI CatchToken(LPCSTR Str, int SepCha, LPSTR Buff, int BuffLen)
    {
    int Find;

    if ((Find=SearchCha(Str, SepCha))<0) Find=lstrlen(Str);
    lstrcpyn(Buff, Str, GetMin(Find+1, BuffLen));
    if (Str[Find]!=0) Find++;
    return Str+Find;
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ����� ���ϴ� ���̸�ŭ ������
//-----------------------------------------------------------------------------
VOID WINAPI SubStr(LPSTR Buff, int BuffSize, LPCSTR Src, int ReqLen)
    {
    lstrcpyn(Buff, Src, GetMin(ReqLen+1, BuffSize));
    }



//-----------------------------------------------------------------------------
//      �־��� ��Ʈ������ �־��� ���ڸ� ��� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI DelAllCha(LPSTR String, int DelCha)
    {
    int Cha;
    LPSTR lpDest=String;

    if (DelCha!=0)
        for (;;)
            {
            Cha=*(LPCBYTE)String++;
            if (Cha!=DelCha)
                {
                *lpDest++=Cha;
                if (Cha==0) break;
                }
            }
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڸ� �����
//-----------------------------------------------------------------------------
VOID WINAPI DelCha(LPSTR String, int DelLoc)
    {
    if (lstrlen(String)>DelLoc)
        {
        String+=DelLoc;
        lstrcpy(String, String+1);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ��� ������ ���ڸ� ��
//-----------------------------------------------------------------------------
int WINAPI GetLastChar(LPCSTR Str)
    {
    int I;

    if ((I=lstrlen(Str))>0) I=Str[I-1];
    return I;
    }



//-----------------------------------------------------------------------------
//      �ο��ȣ�� ������ (StripQuotationMark)
//-----------------------------------------------------------------------------
VOID WINAPI StripQuoteSign(LPSTR Buff)
    {
    int Cha, Len;

    Cha=Buff[0];
    if (Cha=='\'' || Cha=='\"')
        {
        DelCha(Buff, 0);
        if ((Len=lstrlen(Buff)-1)>=0)
            {
            if (Buff[Len]==Cha) Buff[Len]=0;
            }
        }
    }




int WINAPI SearchStr(LPCSTR SourceStr, LPCSTR SrchStr)
    {
    LPCSTR lp;
    return (lp=strstr(SourceStr, SrchStr))!=NULL ? lp-SourceStr:-1;
    }




//-----------------------------------------------------------------------------
//      �� ����� 8Bit üũ���� ���մϴ�
//-----------------------------------------------------------------------------
int WINAPI GetJ8ChkSum(LPCBYTE lpMem, UINT Size)
    {
    int LfnSum=0;

    while (Size--)
        {
        //ror LfnSum,1
        if (LfnSum & 1)
            {
            LfnSum>>=1;
            LfnSum^=0xA5;
            }
        else LfnSum>>=1;

        LfnSum+=*lpMem++;
        }

    return LfnSum & 0xFF;
    }




//-----------------------------------------------------------------------------
//      ?VAR1=DATA1&VAR2=DATA2, name=������&age=35
//-----------------------------------------------------------------------------
BOOL WINAPI GetUrlVarText(LPCSTR WebArgList, LPCSTR VarName, LPSTR DataBuff, int BuffSize)
    {
    BOOL Rslt=FALSE;
    int   Len, NextPos;

    DataBuff[0]=0;
    Len=lstrlen(VarName);
    while (WebArgList[0]!=0)
        {
        if (lstrlen(WebArgList)<=Len) break;
        NextPos=SearchCha(WebArgList, '&');
        if (WebArgList[Len]=='=' && CompareMem(WebArgList, VarName, Len)==0)
            {
            if (NextPos>=0) BuffSize=GetMin(BuffSize, NextPos-Len);
            lstrcpyn(DataBuff, WebArgList+Len+1, BuffSize);
            Rslt++;
            break;
            }
        if (NextPos<0) break;
        WebArgList+=NextPos+1;
        }
    return Rslt;
    }


int WINAPI GetUrlVarInt(LPCSTR WebArgList, LPCSTR VarName)
    {
    CHAR Buff[16];
    GetUrlVarText(WebArgList, VarName, Buff, sizeof(Buff));
    return AtoI(Buff, NULL);
    }




//-----------------------------------------------------------------------------
//      Null���ڿ�(ȯ�湮�ڿ�ó��)���� �־��� ��ġ�� ���ڿ��� ��
//-----------------------------------------------------------------------------
LPCSTR WINAPI GetToken(LPCSTR TokenList, int TokenNo)
    {
    while (TokenList[0]!=0)
        {
        if (TokenNo==0) break;
        TokenList+=lstrlen(TokenList)+1;
        TokenNo--;
        }
    return TokenList;
    }




//-----------------------------------------------------------------------------
//      ȣ��Ʈ�ּ��� �⺻��Ʈ�� �ٸ��� �ڿ� ����
//-----------------------------------------------------------------------------
VOID WINAPI AddPortIfNoDef(LPSTR HostAdd, int ToAddPortNo, int DefPortNo)
    {
    if (ToAddPortNo!=DefPortNo) wsprintf(GetStrLast(HostAdd), ":%d", ToAddPortNo);
    }




//-----------------------------------------------------------------------------
//      Url�� HostAddr�� Host���Ϸ� �и��մϴ�
//      ���ϰ��� HostAdd���� ȣ��Ʈ ���� Path�� Ptr�� (ȣ��Ʈ ������ ������ NULL����)
//
//��)   http://www.abcd.com:120/root/abcd.htm
//    =>HostAddr<=www.abcd.com
//      PortNo<=120
//      RetValue=root/abcd.htm
//
// 2022-02-10 ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI SeparateUrl(LPCSTR SrcUrl, LPSTR HostAddr, int HostAddBS, int *lpPortNo)
    {
    int    I;
    LPSTR  lp;
    LPCSTR lpHA, lpHostFName;

    if ((I=SearchStr(lpHA=SrcUrl, "://"))>=0) lpHA+=I+3;

    if ((I=SearchCha(lpHA, '/'))>=0)
        {
        lstrcpyn(HostAddr, lpHA, GetMin(I+1, HostAddBS));
        lpHostFName=lpHA+I+1;
        }
    else{
        lstrcpyn(HostAddr, lpHA, HostAddBS);
        lpHostFName=NULL;
        }

    if ((lp=SeparatStr(HostAddr, ':'))!=NULL) *lpPortNo=AtoI(lp, NULL);

    return lpHostFName;
    }




//-----------------------------------------------------------------------------
//      Url�� HostAddr�� Host���Ϸ� �и��մϴ�
//      ���ϰ��� HostAddr���� ȣ��Ʈ ���� Path�� Ptr�� (ȣ��Ʈ ������ ������ "/"����)
//
//��)   http://www.abcd.com:120/root/abcd.htm
//    =>HostAddr<=www.abcd.com
//      PortNo<=120
//      RetValue=/root/abcd.htm
//
// 2022-02-10 ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI SeparateUrlEx(LPCSTR SrcUrl, LPSTR HostAddr, int HostAddBS, int *lpPortNo)
    {
    LPCSTR lp;

    if ((lp=SeparateUrl(SrcUrl, HostAddr, HostAddBS, lpPortNo))!=NULL)
        lp--;
    else
        lp="/";
    return lp;
    }




//-----------------------------------------------------------------------------
//      A*B/C ���� ������, ���� �� �ݿø�ó����
//-----------------------------------------------------------------------------
UINT WINAPI UMulDiv(UINT A, UINT B, UINT C)
    {
    return (UINT)(((UINT64)A*B+(C>>1))/C);
    }



//-----------------------------------------------------------------------------
//      2���� Hex���ڸ� ������ ����
//-----------------------------------------------------------------------------
DWORD WINAPI Hex2Int(LPCSTR StrBuff, int ChaQty)
    {
    int I, Cha;
    DWORD Dw=0;

    for (I=0; I<ChaQty; I++)
        {
        Cha=*StrBuff++;
        if (Cha>='0' && Cha<='9') Cha-='0';
        else if (Cha>='A' && Cha<='F') Cha-='A'-10;
        else if (Cha>='a' && Cha<='f') Cha-='a'-10;
        else break;

        Dw<<=4;
        Dw|=Cha;
        }
    return Dw;
    }



//-----------------------------------------------------------------------------
//              ���ڿ� �Է� (���̹��ڿ�)
//          Out al= 0:1byte����, 1:2byte���� ù��°, 2:2byte���� �ι�°
//-----------------------------------------------------------------------------
int WINAPI Check2byteCha(LPCSTR Str, int ChkLoc)
    {
    BYTE Cha, HangulFirst=0;
    int I, Rslt;

    for (I=Rslt=0; ;I++)
        {
        if ((Cha=*(LPCBYTE)Str++)==0) break;

        if (I>=ChkLoc)
            {
            if (HangulFirst!=0) Rslt=2;             //2byte���� �ι�° Byte
            else                Rslt=(Cha>=0x80);   //1:2byte���� ù��°/ 0:1byte����
            break;
            }

        if (HangulFirst!=0) HangulFirst=0;
        else if (Cha>=0x80) HangulFirst=1;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      UTF8�����̸� UTF16�ڵ�� ��ȭ����
//-----------------------------------------------------------------------------
int WINAPI GetCharU8(LPCSTR Str, int *lpLen)
    {
    int Cha, Len=1;

    Cha=*(LPCBYTE)Str;
    if (Cha & 0x80)
        {
        if ((Cha & 0xE0)==0xC0)
            {
            Cha=((Cha&0x1F)<<6) | (Str[1]&0x3F);
            Len=2;
            }
        else if ((Cha & 0xF0)==0xE0)
            {
            Cha=((Cha&0x0F)<<12) | ((Str[1]&0x3F)<<6) | (Str[2]&0x3F);
            Len=3;
            }
        else Printf("%X Illegal UTF8 ch!"CRLF, Cha);
        }
    *lpLen=Len;
    return Cha;
    }

LPSTR WINAPI CharNext(LPCSTR Str)
    {
    int Len;
    GetCharU8(Str, &Len);
    return (LPSTR)Str+Len;
    }




//-----------------------------------------------------------------------------
//      2���� ������ ���մϴ�
//-----------------------------------------------------------------------------
int WINAPI GetMonthLastDay(int Year, int Month)
    {
    int LastDay;
    static BYTE LastDays[]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (Month!=2) LastDay=LastDays[Month-1];
    else          LastDay=(Year % 400)==0 || ((Year % 100)!=0 && (Year & 3)==0) ? 29:28;
    return LastDay;
    }




//-----------------------------------------------------------------------------
//      �־��� ����ϱ����� �� ���ڼ��� ���մϴ� (0000�� 1�� 1�Ϻ���)
//
//      Year * (365*400+100-4+1) / 400 => Year*146097/400
//      �̷��� �����ؼ� ���� 2020-12-31�� ���ϼ��� 2021-1-1�� ���ϼ��� ������ (�ɰ��� ������)
//-----------------------------------------------------------------------------
TDATE WINAPI GetTotalDays(int Year, int Month, int Day)
    {
    int I;

    for (I=1; I<Month; I++) Day+=GetMonthLastDay(Year, I);

    if (Year>0)
        {
        Year--;
        Day+=Year*365 + (Year>>2) - Year/100 + Year/400;
        }
    return Day;
    }



int WINAPI GetWeek(int Year, int Month, int Day)
    {
    return GetTotalDays(Year, Month, Day) % 7;
    }




//-----------------------------------------------------------------------------
//      ���ϼ��� ����Ϸ� �ٲߴϴ�
//-----------------------------------------------------------------------------
#define YEAR1DAYS       365
#define YEAR4DAYS       1461
#define YEAR100DAYS     36524
#define YEAR400DAYS     146097
VOID WINAPI CnvFromTotalDay(TDATE TotalDays, int *lpYear, int *lpMonth, int *lpDay)
    {
    int Y,M, LDays;

    #if 1
    //A���
    Y=(TotalDays*400/YEAR400DAYS)+1;    //T=Y*365+Y/4-Y/100+Y/400 => Y=T*400/(365*400+100-4+1)
    TotalDays-=GetTotalDays(Y, 0, 0);
    #else
    //B��� - A������ε� �Ʒ�ó�� �����ϸ� 3000����� ������ ��� ������ ������ A��� ������
    Y=DivMod(TotalDays, YEAR400DAYS, (int*)&TotalDays)*400+1;
    D=GetMin(DivMod(TotalDays, YEAR100DAYS, &Remain), 3); Y+=D*100;         //3���� �����ϴ� �ϴ� ������ 400�⿡ 1�� �߰��Ǿ��⿡ 146096�� ��� 4�� ����
    TotalDays-=D*YEAR100DAYS;
    Y+=DivMod(TotalDays, YEAR4DAYS, (int*)&TotalDays)*4;
    Y+=D=GetMin(DivMod(TotalDays, YEAR1DAYS, &Remain), 3);                  //3���� �����ϴ� �ϴ� ������ 4�⿡ 1�� �߰��Ǿ��⿡ 1460�� ��� 4�� ����
    TotalDays-=D*YEAR1DAYS;
    #endif

    if (TotalDays==0) {Y--; M=12; TotalDays=31;}    //2021-06-10 �߰�
    else{
        for (M=1; M<=12; M++)
            {
            LDays=GetMonthLastDay(Y, M);
            if (TotalDays<=LDays) break;
            TotalDays-=LDays;
            }
        if (M>12) {Y++; M=1;}                       //2021-06-10 A������� ���� ��������
        }

    *lpYear=Y;
    *lpMonth=M;
    *lpDay=TotalDays;
    }




//-----------------------------------------------------------------------------
//      GMT�ð��� Local�ð����� ��ȯ����
//-----------------------------------------------------------------------------
VOID WINAPI SystemTimeToLocalTime(SYSTEMTIME *ST)
    {
    int  Y,M,D;

    ST->wHour+=9;
    if (ST->wHour>=24)
        {
        ST->wHour-=24;
        CnvFromTotalDay(GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)+1, &Y, &M, &D);
        ST->wYear=Y;
        ST->wMonth=M;
        ST->wDay=D;
        }
    }



//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI GetAppCompileDate(SYSTEMTIME *ST)
    {
    int Rslt=FALSE, Y,Month,D, H,M,S;
    CHAR MonthName[80];

    Jsscanf(__DATE__ " " __TIME__, "%s %d %d %d:%d:%d", MonthName, &D, &Y, &H, &M, &S);
    //���̸��м�
    for (Month=0; Month<12; Month++)
        if (lstrcmpi(GetToken(MonthNameList, Month), MonthName)==0) break;
    if (Month>=12) goto ProcExit;

    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)(Month+1);
    ST->wDay=(WORD)D;
    ST->wHour=(WORD)H;
    ST->wMinute=(WORD)M;
    ST->wSecond=(WORD)S;
    Rslt=TRUE;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �ð����ڿ��� ����� �� (2017-11-17 15:19:25)
//-----------------------------------------------------------------------------
LPSTR WINAPI MakeYMDHMS(LPSTR Buff, CONST SYSTEMTIME *ST)
    {
    wsprintf(Buff, "%d-%02d-%02d %02d:%02d:%02d", ST->wYear, ST->wMonth, ST->wDay, ST->wHour, ST->wMinute, ST->wSecond);
    return Buff;
    }



//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ�
//-----------------------------------------------------------------------------
BOOL WINAPI GetAppCompileDateStr(LPSTR Buff)
    {
    BOOL Rslt;
    SYSTEMTIME ST;

    Buff[0]=0;
    if ((Rslt=GetAppCompileDate(&ST))!=FALSE) MakeYMDHMS(Buff, &ST);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �� ���α׷� ������ ��¥�� �ݴϴ� (JTIME����)
//-----------------------------------------------------------------------------
JTIME WINAPI GetAppCompileDateTime(VOID)
    {
    JTIME Rslt=0;
    SYSTEMTIME ST;

    if (GetAppCompileDate(&ST)!=FALSE) Rslt=PackTotalSecond(&ST);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      HTTP TimeStr�� ����ϴ�
//      "Mon, 31 May 2004 13:55:12 GMT"
//-----------------------------------------------------------------------------
LPSTR WINAPI MakeHttpTimeStr(LPSTR TimeStr, CONST SYSTEMTIME *ST)
    {
    wsprintf(TimeStr, "%s, %d %s %d %02d:%02d:%02d GMT", GetToken(WeekNameList, ST->wDayOfWeek),
                      ST->wDay, ST->wMonth==0 ? "0":GetToken(MonthNameList, ST->wMonth-1), ST->wYear,
                      ST->wHour, ST->wMinute, ST->wSecond);
    return TimeStr;
    }




//-----------------------------------------------------------------------------
//      HTTP TimeStr�� �м��մϴ�
//      "Mon, 31 May 2004 13:55:12 GMT"
//-----------------------------------------------------------------------------
BOOL WINAPI AnalysisHttpTimeStr(LPCSTR TimeStr, SYSTEMTIME *ST)
    {
    int   I, Rslt=FALSE, Day, Year, Hour, Min, Sec;
    CHAR  Buff[40], lpGmt[40];

    ZeroMem(ST, sizeof(SYSTEMTIME));

    //�����̸��м�
    lstrcpyn(Buff, TimeStr, 3+1);
    for (I=0; I<7; I++)
        if (lstrcmpi(GetToken(WeekNameList, I), Buff)==0) break;
    if (I<7)
        {
        ST->wDayOfWeek=I;

        Jsscanf(NextWord(TimeStr,1), "%d %s %d %d:%d:%d %s", &Day, Buff, &Year, &Hour, &Min, &Sec, lpGmt);
        ST->wDay=Day;
        ST->wYear=Year;
        ST->wHour=Hour;
        ST->wMinute=Min;
        ST->wSecond=Sec;

        //���̸��м�
        for (I=0; I<12; I++)
            if (lstrcmpi(GetToken(MonthNameList, I), Buff)==0) break;
        if (I<12)
            {
            ST->wMonth=I+1;
            if (lstrcmpi(lpGmt, "GMT")==0) Rslt++;
            }
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �ð����ڿ��� ����ϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI Make10msTimeStr(LPSTR Buff, DWORD _10msTime, BOOL DetailFg)
    {
    UINT _10ms, M,S;

    _10msTime=UDivMod(_10msTime, 100, &_10ms);
    _10msTime=UDivMod(_10msTime, 60, &S);
    _10msTime=UDivMod(_10msTime, 60, &M);

    if (_10msTime==0) wsprintf(Buff, "%d:%02d", M, S);
    else              wsprintf(Buff, "%d:%02d:%02d", _10msTime, M, S);

    if (DetailFg!=0) wsprintf(GetStrLast(Buff), ".%02d", _10ms);
    return Buff;
    }




//-----------------------------------------------------------------------------
//      ST ����ü�� ms������ ���� ������ ��
//-----------------------------------------------------------------------------
VOID WINAPI AddSystemTime(SYSTEMTIME *ST, int Add_ms)
    {
    int AddSec=0, AddMin, AddHour;

    ST->wMilliseconds+=Add_ms;
    while (ST->wMilliseconds>=1000) {ST->wMilliseconds-=1000; AddSec++;}
    if (AddSec>0)
        {
        AddMin=0;
        ST->wSecond+=AddSec;
        while (ST->wSecond>=60) {ST->wSecond-=60; AddMin++;}
        if (AddMin>0)
            {
            AddHour=0;
            ST->wMinute+=AddMin;
            while (ST->wMinute>=60) {ST->wMinute-=60; AddHour++;}
            if (AddHour>0)
                {
                if (++ST->wHour>=24)
                    {
                    ST->wHour=0;
                    if (++ST->wDay>GetMonthLastDay(ST->wYear, ST->wMonth))
                        {
                        ST->wDay=1;
                        if (++ST->wMonth>12)
                            {
                            ST->wMonth=1;
                            ST->wYear++;
                            }
                        }
                    }
                }
            }
        }
    }




//------------------------------------------------------------------------------
//      String���� from�� ã�� to�� �ٲ۴� (�ٲ� ������ �˷���)
//------------------------------------------------------------------------------
int WINAPI ChangeCha(LPSTR String, int from, int to)
    {
    int  Cnt=0;
    int Cha;

    while ((Cha=*String++)!=0)
        {
        if (Cha==from) {String[-1]=to; Cnt++;}
        }
    return Cnt;
    }




//-----------------------------------------------------------------------------
//      ���� ���ڿ��� Cr,Lf ���� �� ������ �ݴϴ�
//      LineLen���� Cr,Lf�������� Bytes��
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextLine(LPCSTR SrcStr, int *LineLen)
    {
    int Len=0, Cha, T;

    for (;;)
        {
        if ((Cha=*SrcStr)==0) goto ProcExit;
        SrcStr++;

        T=10; if (Cha==13) break;
        T=13; if (Cha==10) break;
        Len++;
        }
    if (*SrcStr==T) SrcStr++;

    ProcExit:
    if (LineLen!=NULL) *LineLen=Len;
    return SrcStr;
    }



//-----------------------------------------------------------------------------
//      13,10���� �и��� ���� ���� ���� ���� ���ڼ� ����, Cr,Lf�� ������
//      �������� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI QueryStrOneLine(LPCSTR Str, int *lpLen)
    {
    int Len=0;
    CHAR Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0) {Str--; break;}
        if (Cha==13 || Cha==10)
            {
            if (Str[0]==(Cha==13 ? 10:13)) Str++;
            break;
            }
        else Len++;
        }
    *lpLen=Len;
    return Str;
    }



//-----------------------------------------------------------------------------
//      Cr,Lf�� ������ ���ڿ����� �־��� ���� �ִ���
//      ������ ã�� ���ڵڸ� ��������
//-----------------------------------------------------------------------------
BOOL WINAPI IsExistLineII(LPCSTR Str, LPCSTR FindLine, LPSTR Buff, int BuffSize)
    {
    int Rslt=FALSE, Len;

    Len=lstrlen(FindLine);
    while (Str[0]!=0)
        {
        if (CompMem(Str, FindLine, Len)==0)
            {
            lstrcpyn(Buff, Str+Len, BuffSize);
            ChangeCha(Buff, 13, 0);
            ChangeCha(Buff, 10, 0);
            Rslt=TRUE;
            break;
            }
        Str=NextLine(Str, NULL);
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      1Line�� ���� -  13,10���� �и��� ���� ���� Text���� �Ѷ����� �����ϴ�
//              �������� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI CatchStrOneLine(LPCSTR SrcStr, LPSTR DestBuff, int BuffLen)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*SrcStr++;
        if (Cha==0) {SrcStr--; break;}
        if (Cha==13 || Cha==10)
            {
            if (SrcStr[0]==(Cha==13 ? 10:13)) SrcStr++;
            break;
            }
        else{
            if (BuffLen>1)
                {
                *DestBuff++=Cha;
                BuffLen--;
                }
            }
        }
    if (BuffLen>0) *DestBuff=0;
    return SrcStr;
    }



#if 0
//-----------------------------------------------------------------------------
//      �޸𸮿� �ִ� Ini���ϱ����� ������ ���ڿ����� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniStrInMem(LPCSTR SecName, LPCSTR VarName, LPSTR Buff, int BuffSize, LPCSTR IniMem)
    {
    int  CopyLen=0, SNLen;
    LPSTR lpVal;
    CHAR Tmp[128];

    Buff[0]=0;
    if (IniMem==NULL) goto ProcExit;
    SNLen=lstrlen(SecName);
    while (IniMem[0]!=0)
        {
        IniMem=CatchStrOneLine(IniMem, Tmp, sizeof(Tmp));
        CleanupStr(Tmp);
        if (Tmp[0]=='[' && Tmp[SNLen+1]==']' && CompareMem(Tmp+1, SecName, SNLen)==0)
            {
            while (IniMem[0]!=0)
                {
                IniMem=CatchStrOneLine(IniMem, Tmp, sizeof(Tmp));
                if (Tmp[0]==0) continue;
                if (Tmp[0]=='[') goto ProcExit;       //��������
                lpVal=SeparatStr(Tmp, '=');
                CleanupStr(Tmp);
                if (lstrcmp(Tmp, VarName)==0)
                    {
                    if (lpVal!=NULL)
                        {
                        CleanupStr(lpVal);
                        lstrcpyn(Buff, lpVal, BuffSize);
                        }
                    CopyLen=lstrlen(Buff);
                    goto ProcExit;
                    }
                }
            }
        }

    ProcExit:
    return CopyLen;
    }



//-----------------------------------------------------------------------------
//      �޸𸮿� �ִ� Ini���ϱ����� ������ �������� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniIntInMem(LPCSTR SecName, LPCSTR VarName, int DefValue, LPCSTR IniMem)
    {
    CHAR Buff[16];
    if (GetIniStrInMem(SecName, VarName, Buff, sizeof(Buff), IniMem)>0) DefValue=AtoI(Buff, NULL);
    return DefValue;
    }
#endif




//-----------------------------------------------------------------------------
//      ���ڿ��� ��ü��
//-----------------------------------------------------------------------------
VOID WINAPI PutString(LPSTR *lplpStr, LPCSTR PutStr)
    {
    FreeMem(*lplpStr);
    if ((*lplpStr=(LPSTR)AllocMem(lstrlen(PutStr)+1, MEMOWNER_PutString))!=NULL)
        lstrcpy(*lplpStr, PutStr);
    }



//-----------------------------------------------------------------------------
//      �־��� ����ũ�⸦ �������� �ʰ� ���ڿ��� �߰��մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI lstrcatn(LPSTR DestBuff, LPCSTR SrcBuff, int BuffSize)
    {
    int Len=lstrlen(DestBuff);
    if (Len<BuffSize) lstrcpyn(DestBuff+Len, SrcBuff, BuffSize-Len);
    }


#if INIFILE_EN
//-----------------------------------------------------------------------------
//      Ini������ �а� ����
//-----------------------------------------------------------------------------
int WINAPI GetIniStr(LPCSTR Section, LPCSTR Entry, LPSTR Buff, int BuffSize)
    {return GetPrivateProfileString(Section, Entry, NullStr, Buff, BuffSize, IniFileName);}

int WINAPI GetIniStrEx(LPCSTR Section, LPCSTR Entry, LPSTR Buff, int BuffSize, LPCSTR DefStr)
    {return GetPrivateProfileString(Section, Entry, DefStr, Buff, BuffSize, IniFileName);}

VOID WINAPI WriteIniStrN(LPCSTR Section, int EntryNo, LPCSTR Buff)
    {
    CHAR Entry[16];
    wsprintf(Entry, Psnt1d, EntryNo);
    WriteIniStr(Section, Entry, Buff);
    }

int WINAPI GetIniInt(LPCSTR Section, LPCSTR Entry, int DefValue)
    {return GetPrivateProfileInt(Section, Entry, DefValue, IniFileName);}

int WINAPI GetIniStrN(LPCSTR Section, int EntryNo, LPSTR Buff, int BuffSize)
    {
    CHAR Entry[16];
    wsprintf(Entry, Psnt1d, EntryNo);
    return GetIniStr(Section, Entry, Buff, BuffSize);
    }

VOID WINAPI WriteIniStr(LPCSTR Section, LPCSTR Entry, LPCSTR Data)
    {WritePrivateProfileString(Section, Entry, Data, IniFileName);}

VOID WINAPI WriteIniInt(LPCSTR Section, LPCSTR Entry, int Value)
    {
    CHAR Buff[16];
    wsprintf(Buff, Psnt1d, Value);
    WriteIniStr(Section, Entry, Buff);
    }
#endif //INIFILE_EN



//-----------------------------------------------------------------------------
//      �ú��ʸ� ��Ĩ
//-----------------------------------------------------------------------------
INT32 WINAPI PackSecondExceptDate(CONST SYSTEMTIME *ST)
    {
    return ST->wHour*3600 + ST->wMinute*60 + ST->wSecond;
    }

INT32 WINAPI PackMilliSecondExceptDate(CONST SYSTEMTIME *ST)
    {
    return PackSecondExceptDate(ST)*1000+ST->wMilliseconds;
    }




//-----------------------------------------------------------------------------
//      GMT UnixTime: 1970 ���ĸ� �ʴ����� ǥ���� (2106���� �ִ�) (WIN32��)
//      1335319508 -> 2012-04-25 11:05:08
//-----------------------------------------------------------------------------
#define ONEDAYSECONDS    86400  //=24*3600
DWORD WINAPI SystemTimeToUnixTime(CONST SYSTEMTIME *ST)
    {
    return (GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)-719163)*ONEDAYSECONDS + PackSecondExceptDate(ST);
    }



//-----------------------------------------------------------------------------
//      �־��� �ð��� 2000/1/1�� �������� �ؼ� �ʷ� ������� (���� �̸�: GetTotalSecond)
//      �ִ� ǥ�ð��� �ð�: 2136-02-07 06:28:15
//-----------------------------------------------------------------------------
JTIME WINAPI PackTotalSecond(CONST SYSTEMTIME *ST)
    {
    return (GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)-730120)*ONEDAYSECONDS + PackSecondExceptDate(ST); //730120=GetTotalDays(2000,1,1) / 86400=24*60*60
    }



//-----------------------------------------------------------------------------
//      JTIME�� JTIME64�� ����
//-----------------------------------------------------------------------------
JTIME64 WINAPI JTimeToJTime64(JTIME JTime)
    {
    return (JTIME64)JTime*1000+63082368000000ULL;                               //2000������� ms = 63082368000000 ms = 730120*86400*1000;
    }



//-----------------------------------------------------------------------------
//      �־��� �ð��� AD�� �������� �ؼ� ms�� �������
//      �ִ� ǥ�ð��� �ð�: ���Ѿ��� (11,767,033 ����� ����)
//-----------------------------------------------------------------------------
JTIME64 WINAPI PackTotalSecond64(CONST SYSTEMTIME *ST)
    {
    JTIME64 T;

    T=(JTIME64)GetTotalDays(ST->wYear, ST->wMonth, ST->wDay)*ONEDAYSECONDS + PackSecondExceptDate(ST);
    return T*1000 + ST->wMilliseconds;
    }




//-----------------------------------------------------------------------------
//      2000/1/1�� �������� �ʴ��� ���� ����Ͻú��ʷ� �и���
//-----------------------------------------------------------------------------
VOID WINAPI UnpackTotalSecond(SYSTEMTIME *ST, JTIME JTime)
    {
    int  Y,M,D;
    UINT Remain;

    JTime=UDivMod(JTime, 60, &Remain); ST->wSecond=(WORD)Remain;
    JTime=UDivMod(JTime, 60, &Remain); ST->wMinute=(WORD)Remain;
    JTime=UDivMod(JTime, 24, &Remain); ST->wHour=(WORD)Remain;

    JTime+=730120;  //730120=GetTotalDays(2000,1,1)
    ST->wDayOfWeek=JTime % 7;
    CnvFromTotalDay(JTime, &Y, &M, &D);
    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)M;
    ST->wDay=(WORD)D;
    ST->wMilliseconds=0;
    }




//-----------------------------------------------------------------------------
//      AD�� �������� ms���� ���� ����� �ú���,ms�� �и���
//-----------------------------------------------------------------------------
VOID WINAPI UnpackTotalSecond64(SYSTEMTIME *ST, JTIME64 JTime)
    {
    int  Y,M,D;
    UINT JT;

    JTime=UDiv64_32(JTime, 1000, &JT); ST->wMilliseconds=(WORD)JT;
    JTime=UDiv64_32(JTime, 60, &JT);   ST->wSecond=(WORD)JT;
    JTime=UDiv64_32(JTime, 60, &JT);   ST->wMinute=(WORD)JT;
    JTime=UDiv64_32(JTime, 24, &JT);   ST->wHour=(WORD)JT;

    ST->wDayOfWeek=(TDATE)JTime % 7;
    CnvFromTotalDay((TDATE)JTime, &Y, &M, &D);
    ST->wYear=(WORD)Y;
    ST->wMonth=(WORD)M;
    ST->wDay=(WORD)D;
    }




//-----------------------------------------------------------------------------
//      CorTex M0���� �������� �ʴ� �޸� ��� �б�/����
//-----------------------------------------------------------------------------
VOID WINAPI PokeW(LPPKVOID Ptr, UINT W)
    {
    *((LPBYTE)Ptr+0)=(BYTE)W;
    *((LPBYTE)Ptr+1)=(BYTE)(W>>8);
    }


VOID WINAPI Poke(LPPKVOID Ptr, DWORD Dw)
    {
    *((LPBYTE)Ptr+0)=(BYTE)Dw;
    *((LPBYTE)Ptr+1)=(BYTE)(Dw>>8);
    *((LPBYTE)Ptr+2)=(BYTE)(Dw>>16);
    *((LPBYTE)Ptr+3)=(BYTE)(Dw>>24);
    }



VOID WINAPI PokeBIW(LPPKVOID Ptr, UINT W)
    {
    *((LPBYTE)Ptr+0)=(BYTE)(W>>8);
    *((LPBYTE)Ptr+1)=(BYTE)W;
    }


VOID WINAPI PokeBI(LPPKVOID Ptr, DWORD Dw)
    {
    *((LPBYTE)Ptr+0)=(BYTE)(Dw>>24);
    *((LPBYTE)Ptr+1)=(BYTE)(Dw>>16);
    *((LPBYTE)Ptr+2)=(BYTE)(Dw>>8);
    *((LPBYTE)Ptr+3)=(BYTE)Dw;
    }



DWORD WINAPI Peek(LPCPKVOID Ptr)
    {
    return *(LPCBYTE)Ptr | (*((LPCBYTE)Ptr+1)<<8) | (*((LPCBYTE)Ptr+2)<<16) | (*((LPCBYTE)Ptr+3)<<24);
    }

UINT WINAPI PeekW(LPCPKVOID Ptr)
    {
    return *(LPCBYTE)Ptr | (*((LPCBYTE)Ptr+1)<<8);
    }


DWORD WINAPI PeekBI(LPCPKVOID Ptr)
    {
    return (*(LPCBYTE)Ptr<<24) | (*((LPCBYTE)Ptr+1)<<16) | (*((LPCBYTE)Ptr+2)<<8) | *((LPCBYTE)Ptr+3);
    }

UINT WINAPI PeekBIW(LPCPKVOID Ptr)
    {
    return (*(LPCBYTE)Ptr<<8) | *((LPCBYTE)Ptr+1);
    }

DWORD WINAPI PeekCDAB(LPCPKVOID Ptr)  //9B F8 48 42 -> 48429BF8
    {
    return (*(LPCBYTE)Ptr<<8) | *((LPCBYTE)Ptr+1) | (*((LPCBYTE)Ptr+2)<<24) | (*((LPCBYTE)Ptr+3)<<16);
    }


UINT WINAPI SwapIndianW(UINT W)
    {
    return (W>>8) | ((W&0xFF)<<8);
    }



//-----------------------------------------------------------------------------
//      �־��� �޸𸮸� �������� Hex���ڿ��� ����
//-----------------------------------------------------------------------------
VOID WINAPI MakeHexStr(LPSTR Buff, LPCBYTE lpMem, int MemSize)
    {
    BYTE B1, B2;
    while (MemSize--)
        {
        B1=*lpMem++;
        if ((B2=(B1>>4)+'0')>'9') B2+=7;
        *Buff++=B2;
        if ((B2=(B1&0x0F)+'0')>'9') B2+=7;
        *Buff++=B2;
        }
    *Buff=0;
    }



UINT WINAPI htons(UINT W)
    {
    return ((W&0xFF)<<8) | (W>>8);
    }




//-----------------------------------------------------------------------------
//      ������ ����� �������� �Ѳ����� ��� �Լ�
//      KEIL ������ __aeabi_uidiv()�� �ѹ� �ҷ��� ��� �������� ó����
//-----------------------------------------------------------------------------
UINT WINAPI UDiv(UINT Dividend, UINT Divisor, UINT *lpRemainder)
    {
    if (lpRemainder) *lpRemainder=Dividend % Divisor;
    return Dividend / Divisor;
    }



//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(LPCBYTE)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//-----------------------------------------------------------------------------
//      ���� ���ڸ� ���� �ݴϴ� (sscanf()�� %d���)
//      ���� �ܾ��� ������ġ�� ������
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanInt(LPCSTR Str, int *lpValue)
    {
    int I,J;

    Str=SkipSpace(Str);
    J=AtoI(Str, &I);
    if (I>0) *lpValue=J;
    return (BYTE)Str[I]>' ' ? NextWord(Str+I, 1):SkipSpace(Str+I);  //���ڵڿ� ���ڰ� �پ� ���� �� �� �Լ��� ȣ���ϸ� ���� �����͸� �����ϱ� ������ ���ѷ����� ���ư�
    }



//-----------------------------------------------------------------------------
//      �־��� ���ڿ� 1�� ������ ��Ƹ�
//-----------------------------------------------------------------------------
int WINAPI GetBitCnt(UINT Value)
    {
    int Cnt=0;

    while (Value!=0)
        {
        if (Value&1) Cnt++;
        Value>>=1;
        }
    return Cnt;
    }



//-----------------------------------------------------------------------------
//      CRC�� ����Ѵ�
//-----------------------------------------------------------------------------
DWORD WINAPI CalculateCRC(LPCBYTE Buff, DWORD BuffSize, DWORD PreCRC)
    {
    int   I;
    DWORD Dw, Crc;

    Crc=PreCRC;
    while (BuffSize--)
        {
        Dw=(*Buff++) ^ (Crc & 0xFF);
        Crc>>=8;
        for (I=0; I<8; I++)     //CRC Table�� ����ϴ�
            {
            if (Dw & 1) {Dw>>=1; Dw^=0xEDB88320L;}
            else Dw>>=1;
            }
        Crc^=Dw;
        }
    return Crc;
    }



//-----------------------------------------------------------------------------
//      ��ũ���� / ��ũ���� (��� Ű�� 5��° ����Ʈ���ʹ� ��� Ǯ����)
//-----------------------------------------------------------------------------
VOID WINAPI EncryptDecrypt(LPBYTE Buff, int BuffSize, DWORD Crc, int Mode)
    {
    int   I;
    DWORD Dw;

    while (BuffSize--)
        {
        if (Mode==ED_ENCRYPT)
            {
            Dw=Buff[0] ^ (Crc & 0xFF);
            Buff[0]^=(BYTE)Crc;
            }
        else{
            Buff[0]^=(BYTE)Crc;
            Dw=Buff[0] ^ (Crc & 0xFF);
            }
        Buff++;

        for (I=0; I<8; I++)
            {
            if (Dw & 1) {Dw>>=1; Dw^=0xEDB88320;}
            else Dw>>=1;
            }
        Crc>>=8;
        Crc^=Dw;
        }
    }




//-----------------------------------------------------------------------------
//      ��ũ���� / ��ũ���� (���� ���� ����)
//-----------------------------------------------------------------------------
VOID WINAPI EncryptDecryptII(LPBYTE Buff, int BuffSize, DWORD Crc, int Mode)
    {
    int   I;
    DWORD Dw;

    while (BuffSize--)
        {
        if (Mode==ED_ENCRYPT)
            {
            Dw=Buff[0] ^ (Crc & 0xFF);
            Buff[0]^=(BYTE)Crc;
            }
        else{
            Buff[0]^=(BYTE)Crc;
            Dw=Buff[0] ^ (Crc & 0xFF);
            }
        Buff++;

        Crc^=Dw;
        for (I=0; I<8; I++)
            {
            if (Crc&1) {Crc>>=1; Crc^=0xED0B8832;}
            else Crc>>=1;
            }
        }
    }




//-----------------------------------------------------------------------------
//      �־��� float ���� Digit ���� �������� ������
//      float(IEEE-754) ���� ������ ��ȯ��
//      INTPARTBITS==25 �̸� (0.1 ~ 200,0000.0 ����)
//          Fixed 25:7  25��Ʈ ������ 7��Ʈ �Ҽ����ڸ���
//-----------------------------------------------------------------------------
#define INTPARTBITS     25  //�����Ҽ�����Ŀ��� �����η� �Ҵ�� ��Ʈ��
#define FRACPARTBITS    (32-INTPARTBITS)
int WINAPI FloatToInt(UINT Float, UINT Digit, UINT Max)
    {
    int  Exp, Value=Max;
    UINT Frac;

    Frac=(Float|0x800000)<<8;   //������ ��Ʈ�� �����ϰ� �� ������ ����
    Exp=((Float<<1)>>24)-126-INTPARTBITS; //����

    if (Exp>0) goto ProcExit;   //OverFlow

    Exp=-Exp;
    if (Exp<INTPARTBITS)        //�����ΰ� �ִ� ���
        {
        Frac>>=Exp;
        if ((Frac>>FRACPARTBITS)>Max/Digit) goto ProcExit;  //OverFlow
        Value=(Frac>>FRACPARTBITS)*Digit + UMulDiv((Frac<<INTPARTBITS)>>INTPARTBITS, Digit, 1<<FRACPARTBITS);
        }
    else{                           //��ȿ���ڴ� ��� �Ҽ���
        Frac>>=Exp-INTPARTBITS+1;   //+1�� ��� ������ ����� ����
        Value=UMulDiv(Frac, Digit, 0x80000000); //= 1<<31
        }

    ProcExit:
    if ((Float>>31)!=0) Value=-Value;
    return Value;
    }



//-----------------------------------------------------------------------------
//      CRC16�� ����Ѵ�
//
//      http://www.zorc.breitbandkatze.de/crc.html
//      Crc�ʱⰪ�� 0xFFFF�� �ָ� CCITT CRC16���� ��µ�
//-----------------------------------------------------------------------------
UINT WINAPI CalculateCrc16(LPCVOID Buff, UINT BuffSize, UINT Crc)
    {
    UINT I;

    while (BuffSize--)
        {
        Crc^=*(LPCBYTE)Buff <<8;
        Buff=(LPCBYTE)Buff+1;

        for (I=0; I<8; I++)
            {
            if (Crc & 0x8000) {Crc<<=1; Crc^=0x1021;} else Crc<<=1;
            }
        }
    return Crc & 0xFFFF;
    }




//-----------------------------------------------------------------------------
//      CRC16�� ����Ѵ� (POLYNOMIAL=0x8005)
//-----------------------------------------------------------------------------
UINT WINAPI CalculateCrc16_8005(LPCVOID Buff, UINT BuffSize, UINT Crc)
    {
    UINT I;

    while (BuffSize--)
        {
        Crc^=*(LPCBYTE)Buff <<8;
        Buff=(LPCBYTE)Buff+1;

        for (I=0; I<8; I++)
            {
            if (Crc & 0x8000) {Crc<<=1; Crc^=0x8005;} else Crc<<=1;
            }
        }
    return Crc & 0xFFFF;
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڸ� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI InsCha(LPSTR SrcStr, int InsLoc, int Cha)
    {
    int SLen;

    SLen=lstrlen(SrcStr);
    if (InsLoc<=SLen)
        {
        while (InsLoc<=SLen)
            {
            SrcStr[1+SLen]=SrcStr[SLen];                //+1�� Null���ڱ���
            SLen--;
            }
        SrcStr[InsLoc]=Cha;
        }
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �־��� ��ġ�� ���ڿ��� �����Ѵ�
//-----------------------------------------------------------------------------
VOID WINAPI InsStr(LPSTR SrcStr, int InsLoc, LPCSTR ToInsStr)
    {
    int SLen, ILen;

    SLen=lstrlen(SrcStr);
    ILen=lstrlen(ToInsStr);
    if (InsLoc<=SLen && ILen>0)
        {
        while (SLen>=InsLoc)
            {
            SrcStr[ILen+SLen]=SrcStr[SLen];
            SLen--;
            }
        CopyMem(SrcStr+InsLoc, ToInsStr, ILen);
        }
    }




//-----------------------------------------------------------------------------
//      Word Array���� �־��� Word�� ã�� (ã�� �ε����� ��, ��ã���� -1)
//      WordArray�� ������������ ���ĵǾ� �־�� ��
//-----------------------------------------------------------------------------
int WINAPI BinSearchWord(CONST WORD *ArrayBase, UINT Elements, UINT SearchWord)
    {
    int Rslt, Find=-1, Half, Low=0, Mid;

    while (Elements>0)
        {
        Half=Elements>>1;
        Mid=Low+Half;
        if ((Rslt=SearchWord-ArrayBase[Mid])==0) {Find=Mid; break;}
        if (Rslt<0)
            {
            Elements=Half;
            }
        else{
            Low=Mid+1;
            Elements=(Elements&1) ? Half:Half-1;
            }
        }
    return Find;
    }



//-----------------------------------------------------------------------------
//      �����׸��ý��� �̿��� ���� (��鸮�� ���� �� �� �Լ��� �̿���)
//      ������°� <0�ΰ�� Target+Tolerance �̻��� �Ǹ� 0���� ū���� �����ϰ�
//                 >0�ΰ�� Target-Tolerance ���ϰ� �Ǹ� 0���� �������� ������
//-----------------------------------------------------------------------------
int WINAPI CompareUsingHysteresis(int State, int Value, int Target, int Tolerance)
    {
    if (State==0) State=(Value>=Target) ? 1:-1;
    else if (State>0)
        {
        if (Value<=Target-Tolerance) State=-1;
        }
    else{ //if (State<0)
        if (Value>=Target+Tolerance) State=1;
        }
    return State;
    }



//-------------------------------------------------------------------------
//      ä�͸� ���� (���ŵ� ��ȣ�� �ٲ��� TRUE����)
//-------------------------------------------------------------------------
BOOL WINAPI RemoveChattering(REMOVECHATTERING *RC, UINT CurrState, int KeepTime)
    {
    BOOL Rslt=FALSE;

    if (RC->OldState!=CurrState)
        {
        RC->KeepTime=0;
        RC->OldState=CurrState;
        }
    else{
        if (RC->KeepTime<KeepTime) RC->KeepTime++;
        if (RC->KeepTime==KeepTime)         //'H'�̵� 'L'�̵� �־��� �ð����� �����Ǵ��� Ȯ��
            {
            if (RC->RegularState!=(BYTE)-1 && RC->RegularState!=CurrState) Rslt++;
            RC->RegularState=CurrState;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      WELLRNG512 �˰����� ������ġ ���ϱ�
//-----------------------------------------------------------------------------
DWORD WINAPI MyRand(DWORD InitData)
    {
    DWORD A,B,C,D;
    static int Index;
    static DWORD State[16];

    if (State[0]==0) for (A=0; A<countof(State); A++) State[A]=++InitData;
    A=State[Index];
    C=State[(Index+13)&0x0F];
    B=A^C^(A<<16)^(C<<15);
    C=State[(Index+9)&0x0F];
    C^=C>>11;
    State[Index]=A=B^C;
    D=A^((A<<5) & 0xDA442D24);
    Index=(Index+15)&0x0F;
    A=State[Index];
    State[Index]=A^B^D^(A<<2)^(B<<18)^(C<<28);
    return State[Index];
    }




//-----------------------------------------------------------------------------
//      ����ũ�⸦ ����� �������� ũ�⹮�ڿ��� ����
//-----------------------------------------------------------------------------
LOCAL(UINT64) HalfRaiseDiv64(UINT64 A, UINT64 B) {return (A+(B>>1))/B;}
VOID WINAPI MakeSizeStrEx(LPSTR Buff, UINT64 TotalBytes)
    {
    DWORD MegaSize;

    MegaSize=(DWORD)HalfRaiseDiv64(TotalBytes, 1000000);
    if (MegaSize<10)
        {
             if ((DWORD)TotalBytes<1000) Jsprintf(Buff, "%dB", (DWORD)TotalBytes);
        else if ((DWORD)TotalBytes<10000) Jsprintf(Buff, "%.1dK", MulDiv((DWORD)TotalBytes, 1, 100));
        else if ((DWORD)TotalBytes<1000000) Jsprintf(Buff, "%dK", MulDiv((DWORD)TotalBytes, 1, 1000));
        else if ((DWORD)TotalBytes<10000000) Jsprintf(Buff, "%.1dM", MulDiv((DWORD)TotalBytes, 1, 100000));
        }
    else if (MegaSize<1000) Jsprintf(Buff, "%dM", (DWORD)MegaSize);
    else if (MegaSize<10000) Jsprintf(Buff, "%.1dG", MulDiv((DWORD)MegaSize, 1, 100));
    else if (MegaSize<1000000) Jsprintf(Buff, "%dG", MulDiv((DWORD)MegaSize, 1, 1000));
    else if (MegaSize<10000000) Jsprintf(Buff, "%.1dT", MulDiv((DWORD)MegaSize, 1, 100000));
    else                         Jsprintf(Buff, "%dT", (DWORD)HalfRaiseDiv64(MegaSize, 1000000));
    }




//-----------------------------------------------------------------------------
//      �����͸� Shift�ϸ鼭 ����� ���� (���۸� �ʰ��� ���� �����ʹ� ����)
//      ������ ù��° �����ʹ� ���� ������ �����̾�� �� (MaxQty�� ������ ������ ����)
//-----------------------------------------------------------------------------
int WINAPI CalcAverageI16(INT16 *Buff, int MaxQty, int CurrValue)
    {
    int I,T, ItemQty;

    ItemQty=*Buff++; MaxQty--;

    if (ItemQty<MaxQty) Buff[ItemQty++]=CurrValue;
    else{
        MoveMem(Buff, Buff+1, (MaxQty-1)<<1);
        Buff[MaxQty-1]=CurrValue;
        }
    for (I=T=0; I<ItemQty; I++) T+=Buff[I];

    Buff[-1]=ItemQty;
    return (T+(ItemQty>>1))/ItemQty;
    }




//-----------------------------------------------------------------------------
//      ST �Ÿ��������� ��ƾ���� ������
//      32��Ʈ sqrt()
//-----------------------------------------------------------------------------
DWORD WINAPI SqrtDw(DWORD Numb)
    {
    UINT Rslt=0, Bit=1<<30;

    while (Bit>Numb) Bit>>=2;

    while (Bit!=0)
        {
        if (Numb>=Rslt+Bit)
            {
            Numb-=Rslt+Bit;
            Rslt>>=1;
            Rslt+=Bit;
            }
        else Rslt>>=1;
        Bit>>=2;
        }

    return Rslt;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ� (���۸� ����� �ٰ�)
//      OutBuff ����.. CnvToWebStr==0 �ΰ��� InDataLen * 1.5 + 4
//                     CnvToWebStr!=0 �ΰ��� InDataLen * 1.5 * 3
//-----------------------------------------------------------------------------
VOID WINAPI EncodeBase64(LPCSTR InBuff, int InDataLen, LPSTR OutBuff, int LineLen)
    {
    int  EncodeSize, RemainBits, NowBits, LineChaCnt, BufW;
    static CONST CHAR Base64Chars[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    EncodeSize=RemainBits=LineChaCnt=BufW=0;

    while (InDataLen>0)
        {
        NowBits=0;
        if (RemainBits<6)
            {
            BufW<<=RemainBits; NowBits=RemainBits;
            BufW|=*(LPCBYTE)InBuff++; InDataLen--; RemainBits+=8;
            }
        if (NowBits<6)
            {
            BufW<<=6-NowBits;
            }

        *OutBuff++=Base64Chars[(BufW>>8)&0x3F]; RemainBits-=6; EncodeSize++;

        if (LineLen>0 && ++LineChaCnt>=LineLen)
            {
            *OutBuff++=13;
            *OutBuff++=10;
            LineChaCnt=0;
            }
        }

    if (RemainBits>0)
        {
        BufW<<=6;
        *OutBuff++=Base64Chars[(BufW>>8)&0x3F]; EncodeSize++;
        }

    while ((EncodeSize & 3)!=0)
        {
        EncodeSize++;
        *OutBuff++='=';
        }

    *OutBuff=0;
    }




//-----------------------------------------------------------------------------
//      Hex���ڸ� ������ ����
//-----------------------------------------------------------------------------
int WINAPI GetHexValue(int Cha)
    {
    if (Cha>='0' && Cha<='9') Cha-='0';
    else if (Cha>='A' && Cha<='F') Cha-='A'-10;
    else if (Cha>='a' && Cha<='f') Cha-='a'-10;
    else Cha=0;
    return Cha;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
LOCAL(int) Base64Dec(int Cha)
    {
    if (Cha=='+') Cha=0x3E;
    else if (Cha=='/') Cha=0x3F;
    else if (Cha>='0' && Cha<='9') Cha-='0'-0x34;
    else if (Cha>='A' && Cha<='Z') Cha-='A';
    else if (Cha>='a' && Cha<='z') Cha-='a'-0x1A;
    else Cha=-1;
    return Cha;
    }




//-----------------------------------------------------------------------------
//      Base64�� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
int WINAPI DecodeBase64(LPCSTR InBuff, LPSTR OutBuff, int Inlen)
    {
    int Cha, Ch2, BufW=0, Code, DecodeSize, RemainBits, NowBits, NeedBits;

    DecodeSize=RemainBits=0;
    if (Inlen<0) Inlen=lstrlen(InBuff);
    while (Inlen>0)
        {
        Cha=*InBuff++; Inlen--; if (Cha==0) break;
        if (Cha=='%')
            {
            Cha=*InBuff++; Inlen--; if (Cha==0) break;
            Ch2=*InBuff++; Inlen--; if (Ch2==0) break;
            //Cha=Hex2Cha(Cha, Ch2);
            Cha=(GetHexValue(Cha)<<4) | GetHexValue(Ch2);
            }
        if (Cha>' ')
            {
            if ((Code=Base64Dec(Cha))<0) break;
            BufW&=~0xFF; BufW|=(BYTE)(Code<<2); NowBits=6;

            while (NowBits>0)
                {
                if ((NeedBits=8-RemainBits)>NowBits) NeedBits=NowBits;
                BufW<<=NeedBits; RemainBits+=NeedBits; NowBits-=NeedBits;
                if (RemainBits==8) {*OutBuff++=(BYTE)(BufW>>8); DecodeSize++; RemainBits=0;}
                }
            }
        }
    return DecodeSize;
    }




//-----------------------------------------------------------------------------
//      HEX���ڿ��� ���̳ʸ��� ���ڵ��մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI DecodeHexStr(LPBYTE OutBuff, LPCSTR InBuff, int Inlen)
    {
    int I;

    for (I=0; I<Inlen; I+=2)
        *OutBuff++=(GetHexValue(InBuff[I])<<4) | GetHexValue(InBuff[I+1]);
    }




//-----------------------------------------------------------------------------
//      ���̳ʸ��� HEX���ڿ��� ���ڵ��մϴ� (OutBuff �ǵ� 0���� ä���� ����)
//-----------------------------------------------------------------------------
VOID WINAPI EncodeHexStr(LPSTR OutBuff, LPCBYTE InBuff, int Inlen)
    {
    int I,B, Cha;

    for (I=0; I<Inlen; I++)
        {
        Cha=InBuff[I];
        if ((B=((Cha>>4) & 0x0F)+'0')>'9') B+=7;    //7='A'-'0'-10
        *OutBuff++=B;
        if ((B=(Cha      & 0x0F)+'0')>'9') B+=7;
        *OutBuff++=B;
        }
    }




//-----------------------------------------------------------------------------
//      Dos�ð��� SYSTEMTIME���� ��ȯ
//-----------------------------------------------------------------------------
VOID WINAPI DosFileTimeToSystemTime(UINT FatDate, UINT FatTime, SYSTEMTIME *ST)
    {
    ST->wYear=((FatDate>>9)&0x7F)+1980;
    ST->wMonth=(FatDate>>5)&0x0F;
    ST->wDay=FatDate&0x1F;
    ST->wHour=(FatTime>>11)&0x1F;
    ST->wMinute=(FatTime>>5)&0x3F;
    ST->wSecond=(FatTime<<1)&0x3E;
    }




//-----------------------------------------------------------------------------
//      ���̳ʸ��� BCD���� ��ȯ (RTC���� ���)
//-----------------------------------------------------------------------------
int WINAPI Bin2Bcd(int Value)
    {
    return ((Value/10)<<4) | (Value%10);
    }


int WINAPI Bcd2Bin(int Value)
    {
    return ((Value>>4)&0x0F)*10 + (Value & 0x0F);
    }




//-----------------------------------------------------------------------------
//      �־��� ���ڿ��� �����丮�� �ִ��� Ȯ��
//-----------------------------------------------------------------------------
LOCAL(BOOL) IsInStringHistory(CHKDUPLICATEDSTRING *CDS, LPCSTR Str, DWORD NowTime)
    {
    int I, Rslt=FALSE;
    DWORD Crc;
    STRING_HISTORY *SH;

    Crc=CalculateCRC((LPCBYTE)Str, lstrlen(Str), ~0);
    for (I=0, SH=CDS->SH; I<CDS->HistoryQty; I++, SH++)
        {
        if (SH->EnteredTime!=0 && NowTime-SH->EnteredTime<CDS->LifeTime && SH->Crc==Crc)
            {
            Rslt++;
            break;
            }
        }
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �����丮�� �����
//-----------------------------------------------------------------------------
LOCAL(VOID) PutStringHistory(CHKDUPLICATEDSTRING *CDS, LPCSTR Str, DWORD NowTime)
    {
    int   I;
    DWORD Crc, LongTime=0, ElapseTime;
    STRING_HISTORY *SH, *PutSH=NULL;

    Crc=CalculateCRC((LPCBYTE)Str, lstrlen(Str), ~0);
    for (I=0,SH=CDS->SH; I<CDS->HistoryQty; I++, SH++)
        {
        if (SH->Crc==Crc) {PutSH=SH; break;}
        if ((ElapseTime=NowTime-SH->EnteredTime)>LongTime)                      //���� ������ ��Ŷ �����丮 ���
            {
            PutSH=SH;
            LongTime=ElapseTime;
            }
        }
    PutSH->EnteredTime=NowTime;
    PutSH->Crc=Crc;
    }




//-----------------------------------------------------------------------------
//      �־��� �ð� �������� �ߺ��ؼ� ���� ��� TRUE ����
//      485 ���ſ��� �ߺ� ���ڿ��� �����ϴµ� �����
//-----------------------------------------------------------------------------
BOOL WINAPI IsDuplicatedString(CHKDUPLICATEDSTRING *CDS, LPCSTR Str, DWORD NowTime)
    {
    BOOL Rslt=FALSE;

    if ((Rslt=IsInStringHistory(CDS, Str, NowTime))==FALSE)                     //�۽ŵ���̽��� �ڽ��� �ǵ���� ������ ������ߴµ� �� ���ź��忡���� �Ѵ� �������� ���ŵǾ� ���� ��Ŷ�� ������ ó���� �ؾ� ��
        PutStringHistory(CDS, Str, NowTime);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      ���ڿ��� �ڿ��� ���ڿ��� ã��
//-----------------------------------------------------------------------------
int WINAPI SearchBackCha(LPCSTR Str, int Cha)
    {
    int I;

    I=lstrlen(Str);
    while (--I>=0)
        {
        if (Str[I]==Cha) break;
        }
    return I;
    }



//-----------------------------------------------------------------------------
//      Full Path���� ���ϸ�������ġ�� �ش�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetFileNameLocU8(LPSTR FPath)
    {
    return SearchBackCha(FPath, '/')+FPath+1;
    }



//-----------------------------------------------------------------------------
//      Full Path���� ����Ȯ���������ġ�� �ش�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetFileExtNameLoc(LPSTR FPath)
    {
    int I;

    if ((I=SearchBackCha(FPath, '.'))<0) I=lstrlen(FPath)-1;
    return I+1+FPath;
    }



//-----------------------------------------------------------------------------
//      ���ϵ�ī�忡 �մ��������� üũ�� (UTF8�� �Բ� ó��) (MatchFileName)
//
//      * �Ǵ� *.*      ... �������
//      A*              ... A�ν����ϴ� ��� ���� (Ȯ���ڵ� ����)
//      *.              ... Ȯ���ڰ� ���� ����
//      ���ϵ�ī��� ';' ���ڵ� ������ �ν��� (���ϵ�ī���� ã�� ���ϸ� ���ڿ� ';'�� �� �� ����)
//      ���ϵ�ī���� ? ���� �����ϴ� �ϳ��� ���ڰ� �־�� �� (DOS�� �ٸ�)
//      �ǵڿ�  �ִ� '.'�� Ȯ���� ���й��ڷ� �ν��ϸ� �׿ܴ� �Ϲݹ��ڷ� ó��
//-----------------------------------------------------------------------------
BOOL WINAPI ChkWildcardFileName(LPCSTR FileName, LPCSTR WildCard)
    {
    int I, Rslt, Len, ExtNameMode;
    UINT FNCha, WildCha;
    LPCSTR FNDot, WCDot, FNQ, WCQ;

    Rslt=ExtNameMode=FALSE;
    WildCha=WildCard[0];
    if (WildCha==0 || WildCha==';') goto ProcExit;
    if (WildCha=='*')
        {
        if (WildCard[1]==0 || (WildCard[1]=='.' && WildCard[2]=='*'))
            {
            OkExit:
            Rslt++;
            goto ProcExit;
            }
        }

    FNDot=NULL; FNQ=GetStrLast((LPSTR)FileName);
    if ((I=SearchBackCha(FileName, '.'))>=0) FNDot=FileName+I;

    if ((I=SearchCha(WildCard, ';'))>=0)
        {
        WCDot=WCQ=WildCard+I;
        for (;;)
            {
            if (--WCDot<WildCard) {WCDot=NULL; break;}
            if (*WCDot=='.') break;
            }
        }
    else{
        WCDot=NULL; WCQ=GetStrLast((LPSTR)WildCard);
        if ((I=SearchBackCha(WildCard, '.'))>=0) WCDot=WildCard+I;
        }

    for (;;)
        {
        if (WildCard>=WCQ)
            {
            if (FileName>=FNQ) goto OkExit;     //���� ������ ���
            break;                              //���ϵ�ī��� �����µ� ���ϸ��� �ȳ����� FALSE
            }
        WildCha=WildCard[0];
        if (WildCha=='*')
            {
            if (ExtNameMode!=FALSE) goto OkExit;

            //���ϸ�ó����
            if (WCDot==NULL) goto OkExit;       //WildCard�� Ȯ���ڰ� ������ ���� �񱳾��� TRUE
            if ((WildCard=WCDot+1)==WCQ)        //ABCD*. => ABCD�� �����ϰ� Ȯ���ڰ� ���� ������ ã��
                {
                Rslt=(FNDot==NULL);
                break;
                }
            if (FNDot==NULL) break;             //WildCard�� Ȯ���ڸ� �����ߴµ� ���ϸ��� Ȯ���ڰ� ���� ��� FALSE
            FileName=FNDot+1;
            ExtNameMode++;
            }
        else if (WildCard==WCDot)
            {
            WildCard++;
            if (WildCard==WCQ)                  //ABCD. => ���ϸ��� ABCD�� Ȯ���ڰ� ���� ������ ã��
                {
                Rslt=(FNDot==NULL);
                break;
                }
            if (FileName!=FNDot) break;
            FileName++;
            ExtNameMode++;
            }
        else{
            if (FileName>=FNQ) break;           //���ϵ�ī��� ���Ҵµ� ���ϸ��� ������ ��� FALSE
            if (FileName==FNDot) break;

            #ifdef WIN32
            WildCard=GetCharU8((LPCBYTE)WildCard, &WildCha);
            FileName=GetCharU8((LPCBYTE)FileName, &FNCha);
            #else
            WildCha=GetCharU8(WildCard, &Len); WildCard+=Len;
            FNCha=GetCharU8(FileName, &Len); FileName+=Len;
            #endif
            if (WildCha!='?')
                {
                //CharUpperBuffW(&WildCha, 1);
                //CharUpperBuffW(&FNCha, 1);
                if (WildCha>='a' && WildCha<='z') WildCha-=0x20;
                if (FNCha>='a' && FNCha<='z') FNCha-=0x20;
                if (WildCha!=FNCha) break;
                }
            }
        }

    ProcExit:
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      BYTE ��̿��� Nibble������ ���� ������
//-----------------------------------------------------------------------------
VOID WINAPI PokeNibble(LPBYTE Buff, int Index, int Value)
    {
    int I;

    I=Index>>1;
    if (Index & 1)
        {
        Buff[I]&=0x0F;
        Buff[I]|=Value<<4;
        }
    else{
        Buff[I]&=0xF0;
        Buff[I]|=Value & 0x0F;
        }
    }




//-----------------------------------------------------------------------------
//      BYTE ��̿��� Nibble������ ���� ������
//-----------------------------------------------------------------------------
int WINAPI PeekNibble(LPCBYTE Buff, int Index)
    {
    int Value;

    Value=Buff[Index>>1];
    return (Index & 1) ? Value>>4 : Value&0x0F;
    }


