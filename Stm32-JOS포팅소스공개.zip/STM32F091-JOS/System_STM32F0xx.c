



#include "stm32f0xx.h"




#if !defined  (HSE_VALUE)
#define HSE_VALUE       8000000
#endif

#if !defined  (HSI_VALUE)
#define HSI_VALUE       8000000
#endif

#if !defined (HSI48_VALUE)
#define HSI48_VALUE     48000000
#endif



uint32_t SystemCoreClock=8000000;

const uint8_t AHBPrescTable[16]={0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};
const uint8_t APBPrescTable[8]={0, 0, 0, 0, 1, 2, 3, 4};



void SystemInit(void)
    {
    RCC->CR|=1;                 //Set HSION bit

    #if defined (STM32F051x8) || defined (STM32F058x8)
    RCC->CFGR&=~0x070047F3;     //Reset SW[1:0], HPRE[3:0], PPRE[2:0], ADCPRE and MCOSEL[2:0] bits
    #else
    RCC->CFGR&=//0x08FFB80C;    //Reset SW[1:0], HPRE[3:0], PPRE[2:0], ADCPRE, MCOSEL[2:0], MCOPRE[2:0] and PLLNODIV bits
               ~(0x4000|RCC_CFGR_PLLNODIV|RCC_CFGR_MCOPRE|RCC_CFGR_MCO_2|RCC_CFGR_MCO_1|RCC_CFGR_MCO_0|RCC_CFGR_PPRE|RCC_CFGR_HPRE|RCC_CFGR_SW);
    #endif

    RCC->CR&=~(RCC_CR_PLLON|RCC_CR_HSEON|RCC_CR_CSSON);                         //Reset HSEON, CSSON and PLLON bits
    RCC->CR&=~RCC_CR_HSEBYP;                                                    //Reset HSEBYP bit
    RCC->CFGR&=~(RCC_CFGR_PLLMUL|RCC_CFGR_PLLXTPRE|RCC_CFGR_PLLSRC_HSE_PREDIV); //Reset PLLSRC, PLLXTPRE and PLLMUL[3:0] bits
    RCC->CFGR2&=~(RCC_CFGR2_PREDIV_0|RCC_CFGR2_PREDIV_1|RCC_CFGR2_PREDIV_2|RCC_CFGR2_PREDIV_3);     //Reset PREDIV[3:0] bits

    #if defined (STM32F072xB) || defined (STM32F078xx)
    RCC->CFGR3&=~0x301D3;       //Reset USART2SW[1:0], USART1SW[1:0], I2C1SW, CECSW, USBSW and ADCSW bits
    #elif defined (STM32F071xB)
    RCC->CFGR3&=~0x3153;        //Reset USART2SW[1:0], USART1SW[1:0], I2C1SW, CECSW and ADCSW bits
    #elif defined (STM32F091xC) || defined (STM32F098xx)
    RCC->CFGR3&=~(0x100 | RCC_CFGR3_USART3SW_HSI | RCC_CFGR3_USART2SW | RCC_CFGR3_CECSW | RCC_CFGR3_I2C1SW | RCC_CFGR3_USART1SW);   //Reset USART3SW[1:0], USART2SW[1:0], USART1SW[1:0], I2C1SW, CECSW and ADCSW bits
    #elif defined (STM32F030x6) || defined (STM32F030x8) || defined (STM32F031x6) || defined (STM32F038xx) || defined (STM32F030xC)
    RCC->CFGR3&=~0x113;         //Reset USART1SW[1:0], I2C1SW and ADCSW bits
    #elif defined (STM32F051x8) || defined (STM32F058xx)
    RCC->CFGR3&=~0x153;         //Reset USART1SW[1:0], I2C1SW, CECSW and ADCSW bits
    #elif defined (STM32F042x6) || defined (STM32F048xx)
    RCC->CFGR3&=~0x1D3;         //Reset USART1SW[1:0], I2C1SW, CECSW, USBSW and ADCSW bits
    #elif defined (STM32F070x6) || defined (STM32F070xB)
    RCC->CFGR3&=~0x193;         //Reset USART1SW[1:0], I2C1SW, USBSW and ADCSW bits
    RCC->CFGR3|=0x80;           //Set default USB clock to PLLCLK, since there is no HSI48
    #else
    #warning "No target selected"
    #endif

    RCC->CR2&=~RCC_CR2_HSI14ON; //Reset HSI14 bit
    RCC->CIR=0;                 //Disable all interrupts
    }




