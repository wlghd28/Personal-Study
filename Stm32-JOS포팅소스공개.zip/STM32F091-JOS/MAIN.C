﻿///////////////////////////////////////////////////////////////////////////////
//                          STM32F0 JOS Test Main
// 작성일 2022-07-05
// 작성자 죠우저프
///////////////////////////////////////////////////////////////////////////////


#include "JLIB.H"
#include "JOS.H"
#include "DRIVER.H"
#include "MONITOR.H"
#include "KEY.H"
#include "MAIN.H"



static CONST CHAR FirstBootMsg[]="\r\nJOS Test (Build %s)\r\n\r\n";

const char* const MessageStrList[]=
    {
    "Name=String:"
    };




//-----------------------------------------------------------------------------
//      치명적인 오류가 생겼을 때 LED 번쩍거림
//-----------------------------------------------------------------------------
VOID WINAPI FatalError(int Err)
    {
    switch (Err)
        {
        case FERR_SYSCLKCFG:    //1초에 두번 짧게 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(10);
                PortOut(PO_STATUSLED, OFF); Delay_ms(490);
                }

        case FERR_EXCEPTION:    //1초에 10번 깜빡임
            for (;;)
                {
                PortOut(PO_STATUSLED, PO_NOT);
                Delay_ms(50);
                }

        case FERR_MEMORY:       //빠르게 두번을 깜빡이는데 1초마다 반복함
            for (;;)
                {
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(150);
                PortOut(PO_STATUSLED, ON);  Delay_ms(50);
                PortOut(PO_STATUSLED, OFF); Delay_ms(750);
                }
        }
    }

VOID WINAPI UART_ErrUsrHandler(int Port, int ErrCode) {}




//-----------------------------------------------------------------------------
//      키상태 수집
//-----------------------------------------------------------------------------
static KEYCODETABLE KeyCodeTable[]=
    {//DownCode,    DblClickCode,       LongDown1Code,  LongDown2Code,  KeyUpCode
    {KC_TestDown,   KC_TestDblClk,      KC_TestLong1,    KC_TestLong2,  KC_TestUp},
    };

LOCAL(UINT) CollectKeyState(VOID)
    {
    UINT Key=0;

    if (PortIn(PI_TESTKEY)==0) Key|=1;
    return Key;
    }



//-----------------------------------------------------------------------------
//      전원 켜기전에 이미 눌려있는 키를 어떻게 할지를 결정해줌
//      ScanKey() 에서 호출함
//-----------------------------------------------------------------------------
UINT WINAPI IgnoreFirstPushedKey(int Key)
    {
    return 0;
    }



//-----------------------------------------------------------------------------
//      키클릭음 처리, ScanKey()에서 호출함
//-----------------------------------------------------------------------------
VOID WINAPI PlayKeyClickSound(int KeyCode)
    {
    }



//-----------------------------------------------------------------------------
//      1ms 마다 처리 (틱 인터럽트에서 호출함)
//-----------------------------------------------------------------------------
VOID WINAPI _1msProc(VOID)
    {
    static BYTE _10ms;

    if (++_10ms>=10)
        {
        _10ms=0;
        ScanKey(CollectKeyState(), KeyCodeTable, countof(KeyCodeTable));
        K_TimerProc();

        JOSTimeTick();
        }
    }




//-----------------------------------------------------------------------------
//         The system Clock is configured as follow :
//
//            System Clock source            = PLL (HSE)
//            SYSCLK(Hz)                     = 48000000
//            HCLK(Hz)                       = 48000000
//            AHB Prescaler                  = 1
//            APB1 Prescaler                 = 1
//            HSE Frequency(Hz)              = 8000000
//            PREDIV                         = 1
//            PLLMUL                         = 6
//            Flash Latency(WS)              = 1
//-----------------------------------------------------------------------------
VOID WINAPI InitSystemClockI(VOID)
    {
    RCC_ClkInitTypeDef CLKI;
    RCC_OscInitTypeDef OSCI;

    //Enable HSE Oscillator and Activate PLL with HSE as source
    OSCI.OscillatorType=RCC_OSCILLATORTYPE_HSI;
    OSCI.HSIState=RCC_HSI_ON;
    OSCI.PLL.PLLState=RCC_PLL_ON;
    OSCI.PLL.PLLSource=RCC_PLLSOURCE_HSI;
    OSCI.PLL.PREDIV=RCC_PREDIV_DIV1;
    OSCI.PLL.PLLMUL=RCC_PLL_MUL6;
    if (HAL_RCC_OscConfig(&OSCI)!=HAL_OK) {ClkErr: FatalError(FERR_SYSCLKCFG);}

    //Select HSI48 Oscillator as PLL source
    OSCI.OscillatorType=RCC_OSCILLATORTYPE_HSI48;
    OSCI.HSI48State=RCC_HSI48_ON;
    OSCI.PLL.PLLState=RCC_PLL_ON;
    OSCI.PLL.PLLSource=RCC_PLLSOURCE_HSI48;
    OSCI.PLL.PREDIV=RCC_PREDIV_DIV2;
    OSCI.PLL.PLLMUL=RCC_PLL_MUL2;
    if (HAL_RCC_OscConfig(&OSCI)!=HAL_OK) goto ClkErr;

    //Select PLL as system clock source and configure the HCLK, PCLK1 clocks dividers
    CLKI.ClockType=RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_PCLK1;
    CLKI.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;
    CLKI.AHBCLKDivider=RCC_SYSCLK_DIV1;
    CLKI.APB1CLKDivider=RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&CLKI, FLASH_LATENCY_1)!=HAL_OK) goto ClkErr;
    }




//-----------------------------------------------------------------------------
//      루프딜레이 캘리브레이션
//-----------------------------------------------------------------------------
VOID CalLoopDelay(VOID)
    {
    DWORD Tick;

    Tick=GetTickCount();
    Delay_ms(1000);
    Printf("Delay_ms=%d\r\n", GetTickCount()-Tick);
    }




//-----------------------------------------------------------------------------
//      MAIN TASK
//-----------------------------------------------------------------------------
static VOID MainTask(LPVOID lpData)
    {
    int Key;
    DWORD StartTick;

    Printf("SENSOR: JOS Ver=%s\r\n", lpData);
    //Delay_ms(100);

    CreateMonitorTask();

    StartTick=GetTickCount();
    for (;;)
        {
        if ((Key=GetKey())>=0)
            {
            Printf("Key=%d\r\n", Key);

            if (Key==KC_TestDown)
                {
                Printf("Main Task Register Changing Test Start..."CRLF);
                Printf("Main Task Register Changed... (%s)"CRLF, TestChangeReg(9000000)==0 ? "OK":"FAIL");
                }
            }

        if (GetTickCount()-StartTick>=500)
            {
            PortOut(PO_STATUSLED, PO_NOT);
            StartTick=GetTickCount();
            }
        Sleep(1);
        }
    }





//-----------------------------------------------------------------------------
//          Main
//-----------------------------------------------------------------------------
int main(void)
    {
    static BYTE AllocMemory[8192];

    __disable_irq();
    HAL_Init();

    InitPortOutputPP(PO_STATUSLED); PortOut(PO_STATUSLED, ON);                  //치명적 오류를 표시해야 하므로 맨위에 초기화 필요
    //InitSystemClockI();   //내부클럭사용
    InitSystemClock();      //외부클럭사용 (8MHz)

    if (MemAllocInit((UINT)AllocMemory, sizeof(AllocMemory))==FALSE) FatalError(FERR_MEMORY);
    InitDriver();

    //디버깅
    InitPort(PO_COM3TX,  GPIO_MODE_AF_PP, GPIO_NOPULL, GPIO_AF1_USART3);
    InitPort(PI_COM3RX,  GPIO_MODE_AF_PP, GPIO_PULLUP, GPIO_AF1_USART3);
    InitPortInput(PI_TESTKEY, GPIO_NOPULL);

    InitUart(COM_DEBUG, 115200, UART_PARITY_NONE, UART_WORDLENGTH_8B, UART_STOPBITS_1, UART_HWCONTROL_NONE, FALSE);      //Debug
    __enable_irq();

    InitRTC(RTC_CLOCK_LSI);
    //GetAppCompileDateStr(Buff);
    Printf(FirstBootMsg, "CompileDateTime"); //Buff);
    Printf("SENSOR: SystemCoreClock=%uHz\r\n", SystemCoreClock);

    CalLoopDelay();

    JOSInit();      //JOS 초기화
    CreateThread("Main", MAIN_TASK_STK_SIZE, MainTask, "v101", PRIO_MAINTASK);  //최초 태스크 생성
    JOSStart();     //JOS 기동
    }




int WINAPI Mon_FuncTest(int PortNo, LPCSTR MonCmd, LPCSTR lpArg, LPCSTR CmdLine)
    {
    if (lpArg[0]=='?') return MONRSLT_EXIT;

    Printf("MON Task Register Changing Test Start..."CRLF);
    Printf("MON Task Register Changed... (%s)"CRLF, TestChangeReg(9000000)==0 ? "OK":"FAIL");

    return MONRSLT_OK;
    }





