///////////////////////////////////////////////////////////////////////////////
//              JLIB
//
// #pragma comment(lib, *.LIB) ����� /NODEFAULTLIB �� �ָ� �������� ����
//
// 2016/03/02 ������ ���� ����ð� ���ϴ� �Լ� �߰�
// 2016/03/03 ���� ���� ���̺귯�� ����, �·�ŷ���� �߰�
///////////////////////////////////////////////////////////////////////////////

#include "JLIB.H"
#include <SHLOBJ.H>     //SHBrowseForFolder, SHGetPathFromIDList


HINSTANCE  HInst, HInstRes;



#define MEMOWNER_GetModuleFileNameU8    1
#define MEMOWNER_GetFileAttributesU8    2
#define MEMOWNER_MyCreateFontU8         3
#define MEMOWNER_MyCreateDIBitmap       4
#define MEMOWNER_VsprintfN_U8s          5
#define MEMOWNER_VsprintfN_U16s         6
#define MEMOWNER_Utf8ToEucKrEx          7




//-----------------------------------------------------------------------------
//      ���� ���� �ݴϴ�
//-----------------------------------------------------------------------------
int   WINAPI GetMin(int A, int B)       {return A<=B ? A:B;}
UINT  WINAPI UGetMin(UINT A, UINT B)    {return A<=B ? A:B;}
INT64 WINAPI GetMin64(INT64 A, INT64 B) {return A<=B ? A:B;}




//-----------------------------------------------------------------------------
//      ū ���� �ݴϴ�
//-----------------------------------------------------------------------------
int   WINAPI GetMax(int A, int B)       {return A>=B ? A:B;}
UINT  WINAPI UGetMax(UINT A, UINT B)    {return A>=B ? A:B;}
INT64 WINAPI GetMax64(INT64 A, INT64 B) {return A>=B ? A:B;}




//-----------------------------------------------------------------------------
//      �־��� ������ ��ũ���� ������ ǥ���մϴ�
//-----------------------------------------------------------------------------
VOID Printf(LPCSTR FormStr, ...)
    {
    HDC  hDC;
    CHAR Buff[MAX_PATH];
    va_list VL;
    static int DebugPosY=0;

    hDC=GetDC(NULL);
    va_start(VL, FormStr);
    //wvnsprintf(lpMem, sizeof(Buff), FormStr, VL);
    VsprintfN(Buff, sizeof(Buff), FormStr, VL);
    va_end(VL);
    TextOut(hDC, 0,DebugPosY, Buff, lstrlen(Buff));
    ReleaseDC(NULL, hDC);

    DebugPosY+=16;
    if (DebugPosY>=GetSystemMetrics(SM_CYSCREEN)) DebugPosY=0;
    }




//------------------------------------------------------------------------------
//      SrcStr���� from�� ã�� to�� �ٲ۴� (�ٲ� ������ �˷���)
//------------------------------------------------------------------------------
int WINAPI ChangeChaA(LPSTR Str, int From, int To)
    {
    int Cha, Cnt=0;

    while ((Cha=*(LPCBYTE)Str++)!=0)
        {
        if (Cha==From) {Str[-1]=To; Cnt++;}
        }
    return Cnt;
    }


int WINAPI ChangeChaW(LPWSTR Str, int From, int To)
    {
    int Cha, Cnt=0;

    while ((Cha=*Str++)!=0)
        {
        if (Cha==From) {Str[-1]=To; Cnt++;}
        }
    return Cnt;
    }




//-----------------------------------------------------------------------------
//      ���ҽ��� �ε��մϴ�
//      ��뿹)
//          hRes=MyLoadResource(MAKEINTRESOURCE(RtfResID), "MYTEXT", &Size);
//          CopyMem(&Dest, LockResource(hRes), Size);
//          FreeResource(hRes);
//-----------------------------------------------------------------------------
HGLOBAL WINAPI MyLoadResource(LPCSTR ResName, LPCSTR ResType, int *lpResSize)
    {
    HRSRC   hRsrc;
    HGLOBAL hRes=NULL;

    if ((hRsrc=FindResource(HInstRes, ResName, ResType))!=NULL)
        {
        hRes=LoadResource(HInstRes, hRsrc);
        if (lpResSize!=NULL) *lpResSize=SizeofResource(HInstRes, hRsrc);
        }
    return hRes;
    }




//-----------------------------------------------------------------------------
//      �޸� �Ҵ��� �մϴ�
//-----------------------------------------------------------------------------
static int MemCnt;
LPVOID WINAPI AllocMem(DWORD Size, int Owner)
    {
    LPVOID lpMem;

    if ((lpMem=LocalAlloc(LMEM_FIXED, Size))!=NULL) MemCnt++;
    else
        Printf("Mem Alloc Error. Owner=%d, ReqSize=%d", Owner, Size);

    return lpMem;
    }

VOID WINAPI FreeMem(LPVOID MPtr)
    {
    if (MPtr!=NULL)
        {
        if (LocalFree(MPtr)==NULL) MemCnt--;
        }
    }

int WINAPI GetMemAllocQty() {return MemCnt;}




//-----------------------------------------------------------------------------
//      WELLRNG512 �˰����� ������ġ ���ϱ�
//-----------------------------------------------------------------------------
DWORD WINAPI MyRand(DWORD InitData)
    {
    DWORD A,B,C,D;
    static int Index;
    static DWORD State[16];

    if (State[0]==0) for (A=0; A<countof(State); A++) State[A]=++InitData;
    A=State[Index];
    C=State[(Index+13)&0x0F];
    B=A^C^(A<<16)^(C<<15);
    C=State[(Index+9)&0x0F];
    C^=C>>11;
    State[Index]=A=B^C;
    D=A^((A<<5) & 0xDA442D24);
    Index=(Index+15)&0x0F;
    A=State[Index];
    State[Index]=A^B^D^(A<<2)^(B<<18)^(C<<28);
    return State[Index];
    }




//-----------------------------------------------------------------------------
//      �����ڵ� ���ڿ��� euc-kr�� ��ȯ (�����Ϸ�)
//-----------------------------------------------------------------------------
int WINAPI Utf16ToEucKrBS(LPCWSTR Utf16, LPSTR Buff, int BuffSize)
    {
    int Rslt;
    if ((Rslt=WideCharToMultiByte(CP_ACP, 0, Utf16, -1, Buff, BuffSize, NULL, NULL))==0)
        Buff[BuffSize-1]=0;     //���۰� ������� �ǵڱ��� ���ڰ� ��, �ǵ� 0�� �ƴ϶� ���
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      UniCode�� euc-kr�� �ٲߴϴ� (����� FreeMem()���� �ع��ų��)
//-----------------------------------------------------------------------------
LPSTR WINAPI Utf16ToEucKrEx(LPCWSTR Utf16, int MemOwner)
    {
    int   Size;
    LPSTR EucKr;

    Size=WideCharToMultiByte(CP_ACP, 0, Utf16, -1, NULL, 0, NULL, NULL);        //�ǵڿ� 0���� ����� ����ũ�⸦ ������
    if ((EucKr=(LPSTR)AllocMem(Size, MemOwner))!=NULL)
        WideCharToMultiByte(CP_ACP, 0, Utf16, -1, EucKr, Size, NULL, NULL);
    return EucKr;
    }




//-----------------------------------------------------------------------------
//      Utf8�� euc-kr�� �ٲ� �޸𸮸� ����
//-----------------------------------------------------------------------------
LPSTR WINAPI Utf8ToEucKrEx(LPCSTR Utf8, int MemOwner)
    {
    int Len;
    LPSTR  EucKr=NULL;
    LPWSTR Utf16Str;

    if (Utf8!=NULL)
        {
        Len=lstrlen(Utf8);
        if ((Utf16Str=(LPWSTR)AllocMem(Len*2+2, MEMOWNER_Utf8ToEucKrEx))!=NULL)
            {
            Utf8ToUtf16(Utf8, Utf16Str);

            Len=lstrlenW(Utf16Str)*3+1;
            if ((EucKr=(LPSTR)AllocMem(Len, MemOwner))!=NULL)
                Utf16ToEucKrBS(Utf16Str, EucKr, Len);
            FreeMem(Utf16Str);
            }
        }
    return EucKr;
    }




//-----------------------------------------------------------------------------
//              �����ڵ带 UTF-8�� ��ȯ�մϴ�
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//-----------------------------------------------------------------------------
VOID WINAPI Utf16ToUtf8(LPCWSTR Utf16, LPSTR Utf8)
    {
    UINT WCh;

    for (;;)
        {
        WCh=*Utf16++;
        if (WCh<=0x7F)
            {
            *Utf8++=(BYTE)WCh;
            if (WCh==0) break;
            }
        else if (WCh<=0x7FF)
            {
            *Utf8++=(BYTE)((WCh>>6)|0xC0);
            *Utf8++=(BYTE)((WCh&0x3F)|0x80);
            }
        else{
            *Utf8++=(BYTE)((WCh>>12)|0xE0);
            *Utf8++=(BYTE)(((WCh>>6)&0x3F)|0x80);
            *Utf8++=(BYTE)((WCh&0x3F)|0x80);
            }
        }
    }




//-----------------------------------------------------------------------------
//              UTF-8�� �����ڵ�� ��ȯ�մϴ�
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//
//  MultiByteToWideChar(CP_UTF8, 0, Utf8, lstrlen(Utf8), Utf16, Utf16ChLen);
//-----------------------------------------------------------------------------
LPWSTR WINAPI Utf8ToUtf16(LPCSTR Utf8, LPWSTR Utf16)
    {
    int  Cha;       //WCHAR�� ����ϴ� �ͺ��� �ڵ差�� ����
    BYTE Byt;
    LPWSTR RetBuff=Utf16;

    for (;;)
        {
        if ((Byt=*Utf8++)==0) break;
        if ((Byt & 0x80)==0) *Utf16++=Byt;
        else if ((Byt & 0xE0)==0xC0)
            {
            Cha=Byt & 0x1F;    //5Bit
            goto LastByte;
            }
        else if ((Byt & 0xF0)==0xE0)
            {
            Cha=Byt & 0x0F;    //4Bit
            if ((Byt=*Utf8++)==0) break;
            Cha<<=6; Cha|=Byt & 0x3F;
            LastByte:
            if ((Byt=*Utf8++)==0) break;
            *Utf16++=(Cha<<6) | (Byt & 0x3F);
            }
        else if ((Byt & 0xF8)==0xF0) goto Skip3Byte;    //4Byte, MS UTF16���� ����ȵ�
        else if ((Byt & 0xFC)==0xF8) goto Skip4Byte;    //5Byte, MS UTF16���� ����ȵ�
        else if ((Byt & 0xFE)==0xFC)                    //6Byte, MS UTF16���� ����ȵ�
            {
            if ((Byt=*Utf8++)==0) break;
            Skip4Byte:
            if ((Byt=*Utf8++)==0) break;
            Skip3Byte:
            if ((Byt=*Utf8++)==0) break;
            if ((Byt=*Utf8++)==0) break;
            if ((Byt=*Utf8++)==0) break;
            *Utf16++=0xFFFF;                            //��ȯ�Ұ� �ǹ��� ����
            }
        }
    *Utf16=0;
    return RetBuff;
    }





//-----------------------------------------------------------------------------
//      Utf8���ڿ��� Utf16�� �ٲܰ�� ���ڼ��� ���� (Null�������Ծ���)
//      �����̸� CalcLenOfU8ToU16, StrLenU8
//
//      U-00000000 - U-0000007F:  0xxxxxxx (1����Ʈ : ��κ��� ������)
//      U-00000080 - U-000007FF:  110xxxxx 10xxxxxx
//      U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx (3����Ʈ : �ѱ�)
//      U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//      U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
//-----------------------------------------------------------------------------
int WINAPI GetChQtyU8(LPCSTR Utf8)
    {
    int  Cnt=0;
    BYTE Byt;

    for (;;)
        {
        if ((Byt=*Utf8++)==0) break;
        Cnt++;                                  //����ȵǴ� ������ ��쿣 ��ȯ���Ѵٴ� ���ι��� ���� ��
        if (Byt & 0x80)
            {
                 if ((Byt & 0xE0)==0xC0) goto Skip1Byte;
            else if ((Byt & 0xF0)==0xE0) goto Skip2Byte;
            else if ((Byt & 0xF8)==0xF0) goto Skip3Byte;        //4Byte, MS UTF16���� ����ȵ�
            else if ((Byt & 0xFC)==0xF8) goto Skip4Byte;        //5Byte, MS UTF16���� ����ȵ�
            else if ((Byt & 0xFE)==0xFC)                        //6Byte, MS UTF16���� ����ȵ�
                {
                if (*Utf8++==0) break;
                Skip4Byte:
                if (*Utf8++==0) break;
                Skip3Byte:
                if (*Utf8++==0) break;
                Skip2Byte:
                if (*Utf8++==0) break;
                Skip1Byte:
                if (*Utf8++==0) break;
                }
            }
        }
    return Cnt;
    }




//-----------------------------------------------------------------------------
//      ���Լ��� UTF16���� ��ȯ�� ũ�⸦ ��Ȯ�� ����ؼ� �Ҵ��Ͽ� �� �ȿ� ����ݴϴ�.
//      ��� �Ŀ��� �ݵ�� FreeMem()���� �޸𸮸� �ݳ��ؾ� �մϴ�.
//-----------------------------------------------------------------------------
LPWSTR WINAPI Utf8ToUtf16Ex(LPCSTR Utf8, int MemOwner)
    {
    LPWSTR lpW;

    if ((lpW=(LPWSTR)AllocMem((GetChQtyU8(Utf8)+1)<<1, MemOwner))!=NULL)
        Utf8ToUtf16(Utf8, lpW);
    return lpW;
    }




//-----------------------------------------------------------------------------
//      ������ FullPath�� ���� (UTF8 ����)
//-----------------------------------------------------------------------------
DWORD WINAPI GetModuleFileNameU8(HMODULE hModule, LPSTR Buff, DWORD BuffSize)
    {
    LPSTR lpMem, lpUtf8;
    DWORD Ret=0;

    ALLOCMEM2(lpMem, MAXPATH_U16,
              lpUtf8, MAXPATH_U8,
              MEMOWNER_GetModuleFileNameU8, ProcExit);

    if ((Ret=GetModuleFileNameW(hModule, (LPWSTR)lpMem, MAX_PATH))!=0)
        {
        Utf16ToUtf8((LPWSTR)lpMem, lpUtf8);
        ChangeChaA(lpUtf8, '\\', '/');
        lstrcpynA(Buff, lpUtf8, BuffSize);
        }

    ProcExit:
    FreeMem(lpMem);
    return Ret;
    }




//-----------------------------------------------------------------------------
//      ���� �Ӽ��� �����ɴϴ� (UTF8)
//-----------------------------------------------------------------------------
DWORD WINAPI GetFileAttributesU8(LPCSTR FileName)
    {
    DWORD  Attr=(DWORD)-1;
    LPWSTR lpW;

    if ((lpW=Utf8ToUtf16Ex(FileName, MEMOWNER_GetFileAttributesU8))==NULL) goto ProcExit;
    ChangeChaW(lpW, '/', '\\');
    Attr=GetFileAttributesW(lpW);

    ProcExit:
    FreeMem(lpW);
    return Attr;
    }




//-----------------------------------------------------------------------------
//      BMP���Ͽ��� ������ ���̸� ����
//-----------------------------------------------------------------------------
int WINAPI GetBmp1LineBytes(int Width, int ColBits)
    {
    return ((Width*ColBits+31) & ~31) >>3;
    }




//-----------------------------------------------------------------------------
//      Bitmap �� ũ�⸦ ����ϴ�
//-----------------------------------------------------------------------------
int WINAPI GetBitmapSize(HBITMAP hBtm, int *lpHeight)
    {
    BITMAP BI;
    GetObject(hBtm, sizeof(BITMAP), &BI);
    if (lpHeight!=NULL) *lpHeight=BI.bmHeight;
    return BI.bmWidth;
    }




//-----------------------------------------------------------------------------
//      hBitmap�� hDC�� ǥ��
//      Width�� 0�� ��� �̹��� ���� ���, Height�� 0�� ��� �̹��� ���� ���
//-----------------------------------------------------------------------------
VOID WINAPI DrawBitmap(HDC hDC, int DestX, int DestY, int Width, int Height, HBITMAP hBtm, int SrcX, int SrcY)
    {
    int Sx, Sy;
    HDC hMemDC;
    HBITMAP hBtmOld;

    if (Width==0 || Height==0)
        {
        Sx=GetBitmapSize(hBtm, &Sy);
        if (Width==0) Width=Sx;
        if (Height==0) Height=Sy;
        }

    hMemDC=CreateCompatibleDC(hDC);
    hBtmOld=(HBITMAP)SelectObject(hMemDC, hBtm);
    BitBlt(hDC, DestX, DestY, Width, Height, hMemDC, SrcX, SrcY, SRCCOPY);
    SelectObject(hMemDC, hBtmOld);
    DeleteDC(hMemDC);
    }




//-----------------------------------------------------------------------------
//      ���� �귣��ó���Ͽ� ������ (Stretch ��ɵ� ��)
//
//      AlphaFormat �� 0�̸� ������ �ȼ����� ���ĸ� �����ϰ�
//      AC_SRC_ALPHA�̸� �ҽ� �ȼ����� ���ĸ� �����Ͽ� �귻����
//
//      AlphaBlend()�� TransparentBlt()�� Windows 98�� Windows 2000 �̻� ���������� �۵��ϰ�
//      WindowsNT�� Windows 95 ���������� �۵����� ����
//-----------------------------------------------------------------------------
BOOL WINAPI BitBltAlphaBlend(HDC hDCDest, int DestX, int DestY, int DestWidth, int DestHeight,
                             HDC hDCSrc, int SrcX, int SrcY, int SrcWidth, int SrcHeight, int Alpha, int AlphaFormat)
    {
    BLENDFUNCTION BF;

    ZeroMemory(&BF, sizeof(BF));
    BF.BlendOp=AC_SRC_OVER;
    //BF.BlendFlags=0;
    BF.SourceConstantAlpha=Alpha;   //0(����) ~ 255(������)
    BF.AlphaFormat=AlphaFormat;     //0 or AC_SRC_ALPHA (32��Ʈ�� ���� �����)
    return GdiAlphaBlend(hDCDest, DestX, DestY, DestWidth, DestHeight,
                         hDCSrc, SrcX, SrcY, SrcWidth, SrcHeight, BF);
    }




//-----------------------------------------------------------------------------
//      ���ĺ귣�� �̹����� ǥ��
//      Width�� 0�� ��� �̹��� ���� ���, Height�� 0�� ��� �̹��� ���� ���
//-----------------------------------------------------------------------------
VOID WINAPI DrawBitmapAlphaBlend(HDC hDC, int DestX, int DestY, int Width, int Height, HBITMAP hBtm, int SrcX, int SrcY)
    {
    int  Sx,Sy;
    HDC  hMemDC;
    HBITMAP hBtmOld;

    if (Width==0 || Height==0)
        {
        Sx=GetBitmapSize(hBtm, &Sy);
        if (Width==0) Width=Sx;
        if (Height==0) Height=Sy;
        }

    hMemDC=CreateCompatibleDC(hDC);
    hBtmOld=(HBITMAP)SelectObject(hMemDC, hBtm);
    BitBltAlphaBlend(hDC, DestX, DestY, Width, Height,
                     hMemDC, SrcX, SrcY, Width, Height, 255, AC_SRC_ALPHA);
    SelectObject(hMemDC, hBtmOld);
    DeleteDC(hMemDC);
    }




//-----------------------------------------------------------------------------
//      �־��� ImageData�� HBITMAP���� ����� �ݴϴ�
//      ȭ���� 16BPP�� ���� CreateDIBitmap()�� �̿��ϴ� �ͺ��� ���� ���� (4266:4171) 1000���ݺ��ð� ms
//      ȭ���� 32BPP�� ���� CreateDIBitmap()�� �̿��ϴ� �ͺ��� �ξ� ���� (4438:6812) 1000���ݺ��ð� ms
//-----------------------------------------------------------------------------
HBITMAP WINAPI MyCreateDIBitmap(HDC hDC, int Width, int Height, int Bpp, LPCVOID BitData, CONST RGBQUAD *lpPal)
    {
    int PalSize=0;
    HBITMAP hBtm=NULL;
    LPVOID  DCImgData;
    BITMAPINFO *BI, LBI;

    if (Bpp<=8)
        {
        PalSize=(int)(1<<Bpp)*sizeof(RGBQUAD);
        if ((BI=(BITMAPINFO*)AllocMem(PalSize+sizeof(BITMAPINFO), MEMOWNER_MyCreateDIBitmap))==NULL) goto ProcExit;
        }
    else BI=&LBI;

    ZeroMem(BI, sizeof(BITMAPINFO));
    if (PalSize>0) CopyMem(BI->bmiColors, lpPal, PalSize);
    BI->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    BI->bmiHeader.biWidth=Width;
    BI->bmiHeader.biHeight=-Height;
    BI->bmiHeader.biPlanes=1;
    BI->bmiHeader.biSizeImage=GetBmp1LineBytes(Width, Bpp)*Height;
    BI->bmiHeader.biBitCount=Bpp;
    //BI->bmiHeader.biCompression=BI_RGB;   //BI_RGB:0
    if ((hBtm=CreateDIBSection(hDC, BI, DIB_RGB_COLORS, &DCImgData, NULL, 0))!=NULL)
        CopyMem(DCImgData, BitData, BI->bmiHeader.biSizeImage);

    ProcExit:
    if (PalSize>0) FreeMem(BI);
    return hBtm;
    }





//-----------------------------------------------------------------------------
//      �־��� Path�� �������� �˷���
//-----------------------------------------------------------------------------
BOOL WINAPI IsExistFileU8(LPCSTR Path)
    {
    BOOL  Rslt=FALSE;
    DWORD Attr;

    if ((Attr=GetFileAttributesU8(Path))!=(DWORD)-1)
        {
        if ((Attr & (FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))==0) Rslt++;
        }

    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �־��� �̸��� �۲� ������ ����ϴ�
//-----------------------------------------------------------------------------
static int CALLBACK GetFontInfoEnumProc(CONST LOGFONTW *LF, CONST TEXTMETRICW *TM, DWORD Type, LPARAM lPrm)
    {
    *(LOGFONTW*)lPrm=*LF;
    return TRUE;
    }

BOOL WINAPI GetFontInfoW(LPCWSTR FontFace, LOGFONTW *LF)
    {
    int Rslt;
    HDC hDC;

    hDC=GetDC(NULL);
    Rslt=EnumFontsW(hDC, FontFace, GetFontInfoEnumProc, (LPARAM)LF);
    ReleaseDC(NULL, hDC);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      �۲��� ����ϴ�
//-----------------------------------------------------------------------------
HFONT WINAPI MyCreateFontU8(int Height, BOOL BoldFg, BOOL ItalicFg, LPCSTR FontName)
    {
    HFONT hFont=NULL;
    LOGFONTW LF;
    LPWSTR FontNameW;

    if ((FontNameW=Utf8ToUtf16Ex(FontName, MEMOWNER_MyCreateFontU8))==NULL) goto ProcExit;

    GetFontInfoW(FontNameW, &LF);
    hFont=CreateFontW(Height,           //����
                           0,           //MulDiv(Size, WidthRate, 200); //��
                           0,           //0.1�� ������ ���� ����
                           0,           //�������� �����Ǿ� ������ ������
                           BoldFg==0 ? FW_DONTCARE:FW_BOLD, //���� ����
                           ItalicFg,    //1:���Ÿ�
                           0,           //1:���ٹ���
                           0,           //1:�߾������
                           LF.lfCharSet,
                           OUT_DEFAULT_PRECIS,
                           CLIP_DEFAULT_PRECIS,
                           DEFAULT_QUALITY,
                           FF_DONTCARE|DEFAULT_PITCH,
                           FontNameW);
    ProcExit:
    FreeMem(FontNameW);
    return hFont;
    }




//-----------------------------------------------------------------------------
//      ������ ��ŵ�մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR Str)
    {
    int Cha;

    for (;;)
        {
        Cha=*(LPCBYTE)Str++;
        if (Cha==0 || Cha>' ') break;
        }
    return Str-1;
    }




//-----------------------------------------------------------------------------
//      ���� �ܾ��� ��ġ�� �ݴϴ� (�����̳� TAB����)
//      ����ܾ�� ������ ���� ���� �ܾ��� ��ġ�� �ݴϴ�
//      ������ġ�� �����̸� �ٷ� ���� ������ �ܾ�
//      '�� "�� ���ΰ�� �ϳ��� �ܾ�� �ν��մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI NextWord(LPCSTR lp, int WordCnt)
    {
    int Cha, FirstCha;

    for (;;)
        {
        lp=SkipSpace(lp);       //���齺ŵ
        FirstCha=lp[0];
        if (FirstCha==0 || WordCnt==0) break;
        WordCnt--;

        if (FirstCha==0x27 || FirstCha==0x22) lp++;     //"'", '"'
        else FirstCha=0;

        for (;;)                        //�ܾŵ
            {
            Cha=*(LPCBYTE)lp++;
            if (Cha==0) {lp--; break;}
            if (FirstCha!=0)
                {
                if (FirstCha==Cha) break;
                }
            else{
                if (Cha<=' ') {lp--; break;}
                }
            }
        }
    return lp;
    }




//-----------------------------------------------------------------------------
//      String���� �ڿ��� ���� Cha�� ã�� ��ġ�� �ش�(������ -1)
//-----------------------------------------------------------------------------
int WINAPI SearchBackChaA(LPCSTR SrcStr, int Cha)
    {
    LPCSTR lp;
    return (lp=strrchr(SrcStr, Cha))!=NULL ? (int)(lp-SrcStr):-1;
    }




//-----------------------------------------------------------------------------
//      Full Path���� ���ϸ�������ġ�� �ش�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetFileNameLocU8(LPSTR FPath)
    {
    return SearchBackChaA(FPath, '/')+FPath+1;
    }




//-----------------------------------------------------------------------------
//      Command Parameter�� ��ġ�� ���մϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI GetCmdPrmPtr()
    {
    return (LPSTR)NextWord(GetCommandLine(), 1);
    }




//-----------------------------------------------------------------------------
//      ���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
//      2019-07-11 8���� ���ڿ� ó��
//-----------------------------------------------------------------------------
#define NUMTYPE_DECIMAL 0
#define NUMTYPE_HEXA    1
#define NUMTYPE_OCTAL   2
int WINAPI AtoI(LPCSTR Str, int *NonStrLoc)
    {
    int  Cha, Rslt, Sign, NoErr, NumType;
    LPCSTR lp;

    Rslt=Sign=NoErr=NumType=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;        //���� Skip
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha!='0') {lp--; break;}
        Cha=*lp++;
        if (Cha=='x' || Cha=='X') {NumType=NUMTYPE_HEXA; break;}
        lp-=2; NumType=NUMTYPE_OCTAL;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (NumType==NUMTYPE_OCTAL)
            {
            if (Cha>'7') break;
            Cha-='0';
            }
        else if (Cha<='9') Cha-='0';
        else{
            if (NumType!=NUMTYPE_HEXA) break;
            if (Cha<'A') break;
            if (Cha<='F') Cha-='A'-10;
            else{
                if (Cha<'a' || Cha>'f') break;
                Cha-='a'-10;
                }
            }
        NoErr=1;
        if (NumType==NUMTYPE_DECIMAL) {Rslt<<=1; Rslt+=Rslt<<2;}    //*10
        else if (NumType==NUMTYPE_OCTAL) Rslt<<=3;                  //*8
        else Rslt<<=4;                                              //*16
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }




#ifndef _AMD64_
//-----------------------------------------------------------------------------
//              64Bit=64Bit/32Bit ... 32Bit
//
// ���� C������ ��� �������� ��� �ʿ��� �� �ι� �������� �ϰ� �Ǵ°� ��ȿ�����̿��� �� �����ƾ�� �����
// C�� ǥ���ϸ� ������ ���� ó����
//      *lpRemain=(DWORD)(Dividend % Divisor);
//      return Dividend / Divisor;
//-----------------------------------------------------------------------------
UINT64 WINAPI UDiv64_32(UINT64 Dividend, DWORD Divisor, DWORD *lpRemain)
    {
    _asm{
                mov     ecx,Divisor
                mov     eax,dword ptr Dividend[4]
                xor     edx,edx
                div     ecx
                xchg    eax,ebx         //ebx<-���� ����
                mov     eax,dword ptr Dividend
                div     ecx
                mov     ecx,lpRemain
                mov     [ecx],edx
                mov     edx,ebx
        }
    }
#endif




//-----------------------------------------------------------------------------
//      ���ڿ��� ������ Format���� ����� �ݴϴ�
//      %c, %d, %u, %s, %x, %X, %lld, %llu, %I64d, %I64u, %ws, %llX
//      %[-][,][#][0][width][.decimal]type
//
//      Test
//      ====
//      CHAR Buff[80];
//      Jsprintf(Buff, "%,X  %.4d   %.2d  %,d  %,.2d", 0x125679AF, 23, 123456789, 123456789, 123456789);
//      DispMsg(NULL, Buff);
//
// Ver 2.02 2001/01/07 "%.01d" �Ҽ����ڿ� 0�� ������ �Ҽ����ڿ��� 0�̾ ǥ����
// Ver 2.03 2005/10/17 "%.02d" ���� ���� ��ġ�� 0�� ��� ������ 0���� ������� 0.00 ���� ����
// Ver 2.04 2012/01/20 "%.lld %.llu %I64d %I64u"�߰� 64bit���� ǥ��
// Ver 2.05 2012/08/30 "%ws" Utf16���ڿ� ǥ�� �߰�
// Ver 2.06 2015/07/30 "%llX" 64bit���� Hexǥ��
// Ver 2.07 2016/04/11 DestBuff�� ũ�⸦ �ް� ��ġ�� �ʰ� ó����
// Ver 2.08 2017/01/11 .12 -> 0.12
// Ver 2.09 2018/01/12 %U8s �߰�, UTF8���ڿ� ���� �� ����
// Ver 2.10 2018/08/24 BuffSize==0 �̸� �� �ʿ��� ����ũ�⸦ ������
//
// 64��Ʈ������ va_arg()�� �������� �ִ� ũ�Ⱑ 64��Ʈ��. %c,%d �� ��������
//
//  ���ϰ��� Null���ڸ� ������ �䱸�Ǵ� ����ũ����
//  ���۰� �����ϸ� ���ۿ��� �ֱⰡ �ߴܵ�
//-----------------------------------------------------------------------------
#define JSPRINTF_PUTCHA(Cha)\
    {\
    TotalSize++;\
    if (BuffSize>1) {*DestBuff++=Cha; BuffSize--;}\
    }
#define JSPRINTF_FILLCHA(Cha, Cnt)\
    {\
    int Copys;\
    TotalSize+=Cnt;\
    if ((Copys=GetMin(BuffSize-1, Cnt))>0) {FillMem(DestBuff, Copys, Cha); DestBuff+=Copys; BuffSize-=Copys;}\
    }
#define JSPRINTF_PUTSTR(Str)\
    {\
    int Copys;\
    TotalSize+=Len;\
    if ((Copys=GetMin(BuffSize-1, Len))>0) {CopyMem(DestBuff, Str, Copys); DestBuff+=Copys; BuffSize-=Copys;}\
    }

int WINAPI VsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormStr, va_list VL)
    {
    int    I, Width, CommaUnit, FractionUnit, TotalSize=1,
           Cha, ZeroFillCha, TypeCha, Len;
    #ifdef _AMD64_
    UINT64 ArgValue;
    #else
    UINT   ArgValue;
    #endif
    BOOL   LeftAlignFg, HexPrefixFg, FractionZFillFg, I64;
    LPSTR  lp, lpMultiStr;
    LPCSTR lpPsntNextPtr;
    CHAR   Buff[32];
    static CHAR NullExp[]="<null>";
    #ifdef _WIN32
    static CHAR IntErrMsg[]="<InternalError>";
    #endif

    for (;;)
        {
        Cha=*FormStr++;
        if (Cha!='%')
            {
            PassCha:
            if (Cha==0) break;
            JSPRINTF_PUTCHA(Cha)
            }
        else{
            if (FormStr[0]=='%') {FormStr++; goto PassCha;}     //'%%'�� %�� �Ϲ� ���ڷ� ���
            lpPsntNextPtr=FormStr;
            Width=LeftAlignFg=HexPrefixFg=FractionUnit=CommaUnit=FractionZFillFg=I64=0;
            lpMultiStr=NULL;
            ZeroFillCha=' ';

            for (;;)
                {
                Cha=*FormStr++;
                if (Cha=='-') LeftAlignFg=1;
                else if (Cha==',') CommaUnit=3;
                else if (Cha=='#') HexPrefixFg=1;
                else if (Cha=='0') ZeroFillCha='0';
                else if (Cha>='1' && Cha<='9') {FormStr--; Width=AtoI(FormStr, &I); FormStr+=I;}
                else if (Cha=='.')
                    {
                    if (FormStr[0]=='0') FractionZFillFg=1;
                    FractionUnit=-AtoI(FormStr, &I); FormStr+=I;
                    }
                else if (Cha=='I' && FormStr[0]=='6' && FormStr[1]=='4') {FormStr+=2; I64=1;}
                else if (Cha=='l' && FormStr[0]=='l') {FormStr++; I64=1;}
                else{
                    TypeCha=Cha;
                    #ifdef _AMD64_
                    ArgValue=va_arg(VL, UINT64);
                    #else
                    ArgValue=va_arg(VL, UINT);
                    #endif

                    if (Cha=='c')               //%c
                        {
                        Buff[0]=(BYTE)ArgValue; Buff[1]=0;
                        lp=Buff;

                        PutStr:
                        Len=lstrlenA(lp);
                        if (LeftAlignFg!=0)     //'-'�� ������ ����������
                            {
                            JSPRINTF_PUTSTR(lp)
                            if ((Width-=Len)>0) JSPRINTF_FILLCHA(' ', Width)
                            }
                        else{                   //������ ���� ó��
                            if (Width!=0 && (Width-=Len)>0) JSPRINTF_FILLCHA(ZeroFillCha, Width)
                            JSPRINTF_PUTSTR(lp)
                            }
                        if (lpMultiStr!=NULL) {FreeMem(lpMultiStr); lpMultiStr=NULL;}
                        break;
                        }
                    else if (Cha=='s')          //%s
                        {
                        if ((lp=(LPSTR)ArgValue)==NULL) lp=NullExp;
                        goto PutStr;
                        }
                    #ifdef _WIN32
                    else if (Cha=='w' && FormStr[0]=='s')       //%ws
                        {
                        FormStr++;
                        if ((LPWSTR)ArgValue==NULL) {lp=NullExp; goto PutStr;}
                        if ((lp=lpMultiStr=Utf16ToEucKrEx((LPWSTR)ArgValue, MEMOWNER_VsprintfN_U16s))==NULL) lp=IntErrMsg;
                        goto PutStr;
                        }
                    else if (Cha=='U' && FormStr[0]=='8' && FormStr[1]=='s')    //%U8s
                        {
                        FormStr+=2;
                        if ((LPSTR)ArgValue==NULL) {lp=NullExp; goto PutStr;}
                        if ((lp=lpMultiStr=Utf8ToEucKrEx((LPSTR)ArgValue, MEMOWNER_VsprintfN_U8s))==NULL) lp=IntErrMsg;
                        goto PutStr;
                        }
                    #endif
                    else if (Cha=='x' || Cha=='X')      //%x, %X
                        {
                        int HexChaOfs;

                        I=0;                            //�ڸ��� ī����
                        HexChaOfs=(TypeCha=='x') ? 'a'-10:'A'-10;
                        lp=Buff+sizeof(Buff)-1; lp[0]=0;
                        if (I64==0)
                            {
                            #ifdef _AMD64_
                            int  ArgValue32;

                            ArgValue32=(int)ArgValue;
                            #else
                            #define ArgValue32  ArgValue
                            #endif

                            do  {
                                Cha=ArgValue32 & 0x0F; ArgValue32>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue32!=0);
                            #ifndef _AMD64_
                            #undef ArgValue32
                            #endif
                            }
                        else{
                            #ifdef _AMD64_
                            #define ArgValue64  ArgValue
                            #else
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;
                            #endif

                            do  {
                                Cha=(int)(ArgValue64 & 0x0F); ArgValue64>>=4;
                                if (Cha<=9) Cha+='0'; else Cha+=HexChaOfs;
                                if (CommaUnit!=0 && I!=0 && (I&3)==0) *--lp=',';
                                *--lp=Cha;
                                I++;
                                } while (ArgValue64!=0);
                            #ifdef _AMD64_
                            #undef ArgValue64
                            #endif
                            }

                        if (HexPrefixFg!=0)
                            {
                            *--lp='x';
                            *--lp='0';
                            }
                        goto PutStr;
                        }
                    else if (Cha=='d' || Cha=='u')      //%d, %u
                        {
                        BOOL FirstFg=1, Sign=0;

                        if (I64==0)
                            {
                            #ifdef _AMD64_
                            int  ArgValue32;

                            ArgValue32=(int)ArgValue;
                            #else
                            #define ArgValue32  ArgValue
                            #endif

                            if (TypeCha=='d' && (int)ArgValue32<0) {ArgValue32=-(int)ArgValue32; Sign=1;}
                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue32==0) {*--lp='0'; goto PutStr;}

                            do  {
                                Cha=(ArgValue32%10)+'0';
                                ArgValue32/=10;
                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue32==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit==-1) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue32!=0);
                            #ifndef _AMD64_
                            #undef ArgValue32
                            #endif
                            }
                        else{
                            #ifdef _AMD64_
                            #define ArgValue64  ArgValue
                            if (TypeCha=='d' && (INT64)ArgValue64<0) {ArgValue64=-(INT64)ArgValue64; Sign=1;}
                            #else
                            UINT   HighValue;
                            UINT64 ArgValue64;

                            HighValue=va_arg(VL, UINT);

                            //*((DWORD*)&ArgValue64+0)=ArgValue;                //GCC������ �̷� ����� �������� ����
                            //*((DWORD*)&ArgValue64+1)=HighValue;
                            ArgValue64=(((UINT64)HighValue)<<32) | ArgValue;    //�����Ϸ��� �˾Ƽ�ó���ϴ��� __allshl() �θ��� ����
                            if (TypeCha=='d' && (int)HighValue<0) {ArgValue64=-(INT64)ArgValue64; Sign=1;}
                            #endif

                            lp=Buff+sizeof(Buff)-1; lp[0]=0;

                            if (FractionZFillFg==0 && ArgValue64==0) {*--lp='0'; goto PutStr;}

                            do  {
                                //Cha=(UCHAR)(ArgValue64%10)+'0';
                                //ArgValue64/=10;
                                ArgValue64=UDiv64_32(ArgValue64, 10, (DWORD*)&I);
                                Cha=I+'0';

                                if (FractionUnit>=0)
                                    {
                                    if (CommaUnit!=0 && FractionUnit!=0 && (FractionUnit%CommaUnit)==0) *--lp=',';
                                    *--lp=Cha;
                                    }
                                else{
                                    if (FractionZFillFg!=0 || Cha!='0' || FirstFg==0 || ArgValue64==0)
                                        {
                                        FirstFg=0;
                                        *--lp=Cha;
                                        if (FractionUnit==-1) *--lp='.';
                                        }
                                    }
                                FractionUnit++;
                                } while (ArgValue64!=0);
                            #ifdef _AMD64_
                            #undef ArgValue64
                            #endif
                            }

                        if (FractionUnit<0)
                            {
                            while (FractionUnit<0) {*--lp='0'; FractionUnit++;}
                            *--lp='.';
                            }
                        if (FractionUnit==0) *--lp='0';
                        if (TypeCha=='d' && Sign!=0) *--lp='-';
                        goto PutStr;
                        }
                    else{
                        FormStr=lpPsntNextPtr;      //ó������ �ʴ� '%' Type�̸� �״�� ǥ��
                        //ArgList--;                //va_list���� �ڷ� ���ư��� ��� ��ã��
                        Cha='%';
                        goto PassCha;
                        }
                    }
                } //while (*FormStr++)
            } //'%' ó��
        } //for (;;)

    if (BuffSize>0) DestBuff[0]=0;
    return TotalSize;
    }

int JsprintfN(LPSTR DestBuff, int BuffSize, LPCSTR FormatStr, ...)
    {
    int Rslt;
    va_list VL;

    va_start(VL, FormatStr);
    Rslt=VsprintfN(DestBuff, BuffSize, FormatStr, VL);
    va_end(VL);
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      JLIB �ʱ�ȭ
//-----------------------------------------------------------------------------
VOID WINAPI InitJLib(HINSTANCE hInstApp, HINSTANCE hInstRes)
    {
    HInst=hInstApp;
    HInstRes=hInstRes;
    }




//-----------------------------------------------------------------------------
//      JLIB ��ü
//-----------------------------------------------------------------------------
VOID WINAPI ReleaseJLib()
    {
    int I;

    if ((I=GetMemAllocQty())!=0) Printf("MemLeak=%d", I);
    }




#if !defined(NOWINMAINCRTSTARTUP) && !defined(_CONSOLE) && !defined(_DLL)
//-----------------------------------------------------------------------------
//      VC�� ������ ���� �� �������Ͽ��� ���� ���� ȣ��Ǵ� �Լ�
//      ��ũ �ɼǿ��� /NODEFAULTLIB �� �־�� ȣ���
//-----------------------------------------------------------------------------
int WinMainCRTStartup()
    {
    int Rslt;
    STARTUPINFO SI;

    SI.dwFlags=0;
    GetStartupInfo(&SI);
    Rslt=WinMain(GetModuleHandle(0), 0, GetCmdPrmPtr(),
        SI.dwFlags & STARTF_USESHOWWINDOW ? SI.wShowWindow:SW_SHOWDEFAULT);

    ExitProcess(Rslt);
    return Rslt;
    }
#endif



