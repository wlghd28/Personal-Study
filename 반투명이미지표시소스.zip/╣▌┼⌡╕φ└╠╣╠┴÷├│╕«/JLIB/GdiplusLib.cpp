//-----------------------------------------------------------------------------
//      BMP, GIF, JPEG, PNG, TIFF, Exif, WMF, and EMF �ε�
//-----------------------------------------------------------------------------

#include "JLib.h"
#include <Unknwn.h>
#include <GdiPlus.h>
#include "GdiplusLib.h"
//using namespace Gdiplus;

#pragma comment(lib, "GDIPLUS.LIB")
#pragma comment(lib, "OLE32.LIB")       //CreateStreamOnHGlobal()



//Image Lock Mode
#define ImageLockModeRead         1
#define ImageLockModeWrite        2
#define ImageLockModeUserInputBuf 4


//DATABKUP.H���� 10�� �Ҵ����
//#define MEMOWNER_LoadImgUseGL (MEMOWNER_GdiplusLib+0)


//-----------------------------------------------------------------------------
//      Gdiplus Init/Release
//      LoadImgUseGL()�� ȣ���ϱ� ���� �ݵ�� ȣ���� ��
//-----------------------------------------------------------------------------
GdiplusInitClass::GdiplusInitClass()
    {
    Gdiplus::GdiplusStartupInput GPSI;
    Gdiplus::GdiplusStartup(&GpToken, &GPSI, NULL);
    }

GdiplusInitClass::~GdiplusInitClass()
    {
    Gdiplus::GdiplusShutdown(GpToken);
    }



//-----------------------------------------------------------------------------
//      BitMap������ �ε���, ���ϰ��� delete�� ��ü�Ұ�
//      GdiplusInitClass �� ȣ������ ������ ���۾���
//      BMP, GIF, JPEG, PNG, TIFF, Exif, WMF, and EMF �� �ٷ�
//-----------------------------------------------------------------------------
LPBYTE WINAPI LoadImageFile(LPCSTR FileName, int *lpWidth, int *lpHeight)
    {
    int Rslt, Width, Height;
    LPBYTE BitData=NULL, lpS, lpD;
    LPWSTR FNameU16;
    Gdiplus::Bitmap *GpBM;
    Gdiplus::BitmapData GpBD;

    if ((FNameU16=new WCHAR[MAXPATH_U8])!=NULL)
        {
        Width=Height=0;
        Utf8ToUtf16(FileName, FNameU16);
        ChangeChaW(FNameU16, '/', '\\');
        if ((GpBM=new Gdiplus::Bitmap(FNameU16, FALSE))!=NULL)  //���� http://msdn.microsoft.com/en-us/library/windows/desktop/ms536316(v=vs.85).aspx
            {
            Width=GpBM->GetWidth();
            Height=GpBM->GetHeight();
            }
        delete FNameU16;
        }

    Gdiplus::Rect GPR(0, 0, Width, Height);
    if (GpBM==NULL) {Printf("Not Initialized Gdiplus"); goto ProcExit;}  //goto ProcExit;�� ������ �ϸ� GPR�ʱ�ȭ�� �ȵ�

    if ((Rslt=GpBM->LockBits(&GPR, ImageLockModeRead, PixelFormat32bppPARGB, &GpBD))!=Gdiplus::Ok) {Printf("GpBM.LockBits() Err=%d", Rslt); goto ProcExit;}
    //Printf("W=%d, H=%d, Stride=%d",Width,Height,GpBD.Stride);

    if (lpWidth!=NULL) *lpWidth=Width;
    if (lpHeight!=NULL) *lpHeight=Height;
    //if ((BitData=(LPBYTE)AllocMem(GpBD.Stride*Height, MEMOWNER_LoadImgUseGL))==NULL) goto ProcExit; //AllocMem()�� �ϸ� ����
    if ((BitData=new BYTE[GpBD.Stride*Height])==NULL) goto ProcExit;

    //�̹����� ������ ����, BMP�� ������ �� �ʿ�
    lpS=(BYTE*)GpBD.Scan0;
    lpD=GpBD.Stride*(Height-1)+BitData;
    while (Height--)
        {
        CopyMemory(lpD, lpS, GpBD.Stride);
        lpS+=GpBD.Stride;
        lpD-=GpBD.Stride;
        }

    ProcExit:
    if (GpBM!=NULL) {GpBM->UnlockBits(&GpBD); delete GpBM;}
    return BitData;
    }



//-----------------------------------------------------------------------------
//      BitMap������ �ε���, ������ DeleteObject()�� ��ü�Ұ�
//      GdiplusInitClass �� ȣ������ ������ ���۾���
//      BMP, GIF, JPEG, PNG, TIFF, Exif, WMF, and EMF �� �ٷ�
//-----------------------------------------------------------------------------
HBITMAP WINAPI LoadImageFile(HDC hDC, LPCSTR FileName, int *lpWidth, int *lpHeight)
    {
    int Rslt, Width, Height;
    HBITMAP hBtm=NULL;
    LPWSTR FNameU16;
    Gdiplus::Bitmap *GpBM;
    Gdiplus::BitmapData GpBD;

    if ((FNameU16=new WCHAR[MAXPATH_U8])!=NULL)
        {
        Width=Height=0;
        Utf8ToUtf16(FileName, FNameU16);
        ChangeChaW(FNameU16, '/', '\\');
        if ((GpBM=new Gdiplus::Bitmap(FNameU16, FALSE))!=NULL)  //���� http://msdn.microsoft.com/en-us/library/windows/desktop/ms536316(v=vs.85).aspx
            {
            Width=GpBM->GetWidth();
            Height=GpBM->GetHeight();
            }
        delete FNameU16;
        }

    Gdiplus::Rect GPR(0, 0, Width, Height);
    if (GpBM==NULL) {Printf("Not Initialized Gdiplus"); goto ProcExit;}  //goto ProcExit;�� ������ �ϸ� GPR�ʱ�ȭ�� �ȵ�

    if ((Rslt=GpBM->LockBits(&GPR, ImageLockModeRead, PixelFormat32bppPARGB, &GpBD))!=Gdiplus::Ok) {Printf("GpBM.LockBits() Err=%d", Rslt); goto ProcExit;}
    //Printf("W=%d, H=%d, Stride=%d",Width,Height,GpBD.Stride);

    if (lpWidth!=NULL) *lpWidth=Width;
    if (lpHeight!=NULL) *lpHeight=Height;
    hBtm=MyCreateDIBitmap(hDC, Width, Height, 32, (BYTE*)GpBD.Scan0);

    ProcExit:
    if (GpBM!=NULL) {GpBM->UnlockBits(&GpBD); delete GpBM;}
    return hBtm;
    }




//-----------------------------------------------------------------------------
//      ���ҽ��� ���� Bitmap�� �ε���, hGbl�� ����� �ȵ�
//-----------------------------------------------------------------------------
LOCAL(Gdiplus::Bitmap*) LoadBitmapFromRes(int ResID)
    {
    int Size;
    HGLOBAL hRes, hGbl=NULL;
    IStream *ISTM;
    LPVOID lpBuff;
    Gdiplus::Bitmap *GpBM=NULL;

    if ((hRes=MyLoadResource(MAKEINTRESOURCE(ResID), "IMAGE", &Size))==NULL) goto ProcExit;

    if ((hGbl=GlobalAlloc(GMEM_MOVEABLE, Size))==NULL) goto ProcExit;
    if ((lpBuff=GlobalLock(hGbl))==NULL) goto ProcExit;
    CopyMemory(lpBuff, LockResource(hRes), Size);
    GlobalUnlock(hGbl);                                                 //hGbl�� �ٸ����� �ѱ� ���� GlobalUnlock()�ϰ� �ѱ��

    ISTM=NULL;
    if (CreateStreamOnHGlobal(hGbl, TRUE, &ISTM)==S_OK)                 //hRes�� �ٷ� �ָ� ����
        {                                                               //2��° ���ڸ� TRUE�� �ϸ� GpBM Release�� �� HGLOBAL�� ��ü��
        if ((GpBM=Gdiplus::Bitmap::FromStream(ISTM))!=NULL &&
            GpBM->GetLastStatus()!=Gdiplus::Ok) {delete GpBM; GpBM=NULL;}       //Gdiplus::Ok = 0
        ISTM->Release();
        }

    ProcExit:
    if (GpBM==NULL && hGbl!=NULL) GlobalFree(hGbl);
    if (hRes!=NULL) FreeResource(hRes);
    return GpBM;
    }




//-----------------------------------------------------------------------------
//      BitMap������ �ε���, ������ DeleteObject()�� ��ü�Ұ�
//      GdiplusInitClass �� ȣ������ ������ ���۾���
//      BMP, GIF, JPEG, PNG, TIFF, Exif, WMF, and EMF �� �ٷ�
//      ����: http://msdn.microsoft.com/en-us/library/windows/desktop/ms536316(v=vs.85).aspx
//-----------------------------------------------------------------------------
HBITMAP WINAPI LoadImageRes(HDC hDC, int ImgResID, int *lpWidth, int *lpHeight)
    {
    int Rslt, Width, Height;
    HBITMAP hBtm=NULL;
    Gdiplus::Bitmap *GpBM;
    Gdiplus::BitmapData GpBD;

    Width=Height=0;
    //if ((GpBM=new Gdiplus::Bitmap(HInstRes, (LPCWSTR)ImgResID))!=NULL)        //���Լ��� BMP���ϸ� ������
    if ((GpBM=LoadBitmapFromRes(ImgResID))!=NULL)                               //���⼭ goto ProcExit;�� �ϸ� GPR�ʱ�ȭ�� �ȵ�
        {
        Width=GpBM->GetWidth();
        Height=GpBM->GetHeight();
        }

    Gdiplus::Rect GPR(0, 0, Width, Height);
    if (GpBM==NULL) {Printf("Not Initialized Gdiplus or Not Found Resource (ID=%d)", ImgResID); goto ProcExit;}

    if ((Rslt=GpBM->LockBits(&GPR, ImageLockModeRead, PixelFormat32bppPARGB, &GpBD))!=Gdiplus::Ok) {Printf("GpBM.LockBits() Err=%d", Rslt); goto ProcExit;}
    //Printf("W=%d, H=%d, Stride=%d",Width,Height,GpBD.Stride);

    if (lpWidth!=NULL) *lpWidth=Width;
    if (lpHeight!=NULL) *lpHeight=Height;
    hBtm=MyCreateDIBitmap(hDC, Width, Height, 32, (BYTE*)GpBD.Scan0);

    ProcExit:
    if (GpBM!=NULL) {GpBM->UnlockBits(&GpBD); delete GpBM;}
    return hBtm;
    }




